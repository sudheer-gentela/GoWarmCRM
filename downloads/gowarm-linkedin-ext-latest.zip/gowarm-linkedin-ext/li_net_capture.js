// li_net_capture.js — runs in the PAGE / MAIN world at document_start.
//
// Why this exists: LinkedIn moved sent-invitations and connections to its
// internal GraphQL endpoint, whose queryId hash is generated from LinkedIn's
// own Ember bundle and rotates on every front-end deploy. We can't reliably
// hit those URLs blind (we saw 404/400 doing exactly that). So instead of
// guessing, we let LinkedIn fire its OWN correct request — and we passively
// record the response.
//
// How: we wrap window.fetch and XMLHttpRequest at document_start (before any
// LinkedIn script runs, so our wrappers are the ones in place). Whenever a
// relationship-related Voyager request completes, we stash {url, status, body}
// on window.__gowarmConnCapture. The service worker harvests that array on
// demand (executeScript in the MAIN world) when the user clicks
// "Check sent & accepted".
//
// This means the workflow is: browse to My Network → Sent / Connections (so
// LinkedIn loads that data), THEN click the button. The capture is the user's
// own data, recorded only while they themselves browse — no background polling.

(function () {
  if (window.__gowarmConnCaptureInstalled) return;
  window.__gowarmConnCaptureInstalled = true;
  window.__gowarmConnCapture = window.__gowarmConnCapture || [];

  const MAX_ENTRIES = 40;
  const MAX_BODY    = 300000;   // chars; GraphQL relationship payloads are large

  // URL fragments that indicate a relationships payload worth keeping.
  const RELEVANT = /(invitation|connection|memberrelationship|relationships\/dash|relationshipsdash|invitationsdash)/i;

  // ── Profile-URN capture (v1.20) ──────────────────────────────────────────────
  //
  // Separate, narrowly-scoped path that records the *page owner's* fsd_profile
  // URN whenever LinkedIn loads a profile. We do NOT push these into
  // __gowarmConnCapture (the connection harvester must stay untouched); we keep
  // them in their own map and postMessage them to the content script (isolated
  // world) so it can attach member_urn to the capture payload.
  //
  // WHY this beats a per-send live resolve: LinkedIn fires its OWN identity
  // request with the currently-valid (rotating) queryId, so we never hardcode a
  // hash. And because we only emit a URN we can BIND to the current page slug
  // (publicIdentifier === /in/<slug>), there is zero wrong-person risk — a
  // failure to bind emits nothing, and the send path falls back to live resolve.
  //
  // NOTE: the owner-binding parser below is written against (a) the known
  // voyagerIdentityDashProfiles?variables=(memberIdentity:<publicId>) shape the
  // backend already resolves against, and (b) the standard normalized-json
  // included[] entity shape. It FAILS SAFE (emits nothing) on any other shape.
  // Verify against a live profile-browse capture before trusting at volume —
  // same posture as PROFILE_QUERY_ID, but failure here is silent, not wrong.
  const PROFILE_RELEVANT = /(identitydashprofiles|voyager\/api\/identity)/i;
  window.__gowarmProfileUrns = window.__gowarmProfileUrns || {};   // slug -> { urn, ts }

  // Current /in/<slug> being viewed, lowercased. Null when not on a profile.
  function currentProfileSlug() {
    try {
      const m = (location.pathname || '').match(/\/in\/([^/?#]+)/);
      return m ? decodeURIComponent(m[1]).toLowerCase() : null;
    } catch (_) { return null; }
  }

  // Extract the page-owner's fsd_profile URN from a profile/identity response,
  // bound to `slug`. Returns the urn string or null. Pure + defensive.
  function extractOwnerUrn(url, body, slug) {
    if (!body || !slug) return null;
    // Strategy A (proven shape): the request was BY memberIdentity:<slug>, so the
    // first fsd_profile in the body is unambiguously that member's.
    try {
      const mi = String(url).match(/memberIdentity:([^,)\s&]+)/);
      if (mi && decodeURIComponent(mi[1]).toLowerCase() === slug) {
        const m = body.match(/urn:li:fsd_profile:[A-Za-z0-9_-]+/);
        if (m) return m[0];
      }
    } catch (_) { /* fall through */ }
    // Strategy B (normalized-json): find the included entity whose
    // publicIdentifier === slug and take its fsd_profile entityUrn.
    try {
      const j = JSON.parse(body);
      const buckets = [];
      if (Array.isArray(j.included)) buckets.push(j.included);
      if (j.data && Array.isArray(j.data.included)) buckets.push(j.data.included);
      for (const arr of buckets) {
        for (const e of arr) {
          if (!e || typeof e !== 'object') continue;
          const pid = (e.publicIdentifier || '').toLowerCase();
          const eu  = e.entityUrn || '';
          if (pid === slug && /^urn:li:fsd_profile:[A-Za-z0-9_-]+$/.test(eu)) return eu;
        }
      }
    } catch (_) { /* not JSON / unexpected shape — fall through */ }
    return null;
  }

  function handleProfile(url, body) {
    try {
      if (!body || body.length > MAX_BODY) return;
      const slug = currentProfileSlug();
      if (!slug) return;
      if (window.__gowarmProfileUrns[slug]) return;        // already have it this session
      const urn = extractOwnerUrn(url, body, slug);
      if (!urn) return;
      window.__gowarmProfileUrns[slug] = { urn, ts: Date.now() };
      // Bridge to the isolated-world content script.
      window.postMessage({ __gowarm: true, kind: 'profile_urn', slug, urn }, '*');
    } catch (_) { /* never let capture break the page */ }
  }

  // Reply to a content-script catch-up request: if we already recorded the URN
  // for the requested slug (before content.js attached its listener), re-emit it.
  window.addEventListener('message', (ev) => {
    try {
      if (ev.source !== window) return;
      const d = ev.data;
      if (!d || d.__gowarm !== true || d.kind !== 'profile_urn_request') return;
      const slug = String(d.slug || '').toLowerCase();
      const hit  = slug && window.__gowarmProfileUrns[slug];
      if (hit && hit.urn) window.postMessage({ __gowarm: true, kind: 'profile_urn', slug, urn: hit.urn }, '*');
    } catch (_) {}
  });

  function classify(url) {
    const u = url.toLowerCase();
    // Sent-invitation views carry "sent" in the query/variables; received do not.
    if (u.includes('sentinvitation') || (u.includes('invitation') && u.includes('sent'))) return 'sent';
    if (u.includes('invitation')) return 'invitations';     // ambiguous (likely received) — kept, but labelled
    if (u.includes('connection') || u.includes('memberrelationship')) return 'connections';
    return 'other';
  }

  function record(url, status, body) {
    try {
      if (!url || !RELEVANT.test(url)) return;
      window.__gowarmConnCapture.push({
        url: String(url),
        status: status || 0,
        kind: classify(url),
        ts: Date.now(),
        body: (typeof body === 'string') ? body.slice(0, MAX_BODY) : null,
      });
      const arr = window.__gowarmConnCapture;
      if (arr.length > MAX_ENTRIES) arr.splice(0, arr.length - MAX_ENTRIES);
    } catch (_) { /* never let capture break the page */ }
  }

  // ── Wrap fetch ──────────────────────────────────────────────────────────────
  const origFetch = window.fetch;
  if (typeof origFetch === 'function' && !origFetch.__gowarmWrapped) {
    const wrapped = function (input, init) {
      const url = (typeof input === 'string') ? input : (input && input.url) || '';
      const promise = origFetch.apply(this, arguments);
      if (url && RELEVANT.test(url)) {
        promise.then((res) => {
          try {
            res.clone().text()
              .then((body) => record(url, res.status, body))
              .catch(() => {});
          } catch (_) {}
        }).catch(() => {});
      }
      if (url && PROFILE_RELEVANT.test(url)) {
        promise.then((res) => {
          try {
            res.clone().text()
              .then((body) => handleProfile(url, body))
              .catch(() => {});
          } catch (_) {}
        }).catch(() => {});
      }
      return promise;
    };
    wrapped.__gowarmWrapped = true;
    window.fetch = wrapped;
  }

  // ── Wrap XMLHttpRequest ───────────────────────────────────────────────────
  const XO = XMLHttpRequest.prototype.open;
  if (typeof XO === 'function' && !XO.__gowarmWrapped) {
    XMLHttpRequest.prototype.open = function (method, url) {
      this.__gowarmUrl = url;
      return XO.apply(this, arguments);
    };
    XMLHttpRequest.prototype.open.__gowarmWrapped = true;

    const XS = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.send = function () {
      const xhr = this;
      const url = xhr.__gowarmUrl || '';
      if (url && RELEVANT.test(url)) {
        xhr.addEventListener('load', function () {
          try { record(url, xhr.status, xhr.responseText); } catch (_) {}
        });
      }
      if (url && PROFILE_RELEVANT.test(url)) {
        xhr.addEventListener('load', function () {
          try { handleProfile(url, xhr.responseText); } catch (_) {}
        });
      }
      return XS.apply(this, arguments);
    };
  }

  console.log('[GoWarm] relationship network capture installed — browse My Network to populate.');
})();
