// li_net_capture.js — runs in the PAGE / MAIN world at document_start.
//
// Why this exists: LinkedIn moved sent-invitations and connections to its
// internal GraphQL endpoint, whose queryId hash is generated from LinkedIn's
// own Ember bundle and rotates on every front-end deploy. We can't reliably
// hit those URLs blind (we saw 404/400 doing exactly that). So instead of
// guessing, we let LinkedIn fire its OWN correct request — and we passively
// record the response.
//
// How: we wrap window.fetch and XMLHttpRequest at document_start (before any
// LinkedIn script runs, so our wrappers are the ones in place). Whenever a
// relationship-related Voyager request completes, we stash {url, status, body}
// on window.__gowarmConnCapture. The service worker harvests that array on
// demand (executeScript in the MAIN world) when the user clicks
// "Check sent & accepted".
//
// This means the workflow is: browse to My Network → Sent / Connections (so
// LinkedIn loads that data), THEN click the button. The capture is the user's
// own data, recorded only while they themselves browse — no background polling.

(function () {
  if (window.__gowarmConnCaptureInstalled) return;
  window.__gowarmConnCaptureInstalled = true;
  window.__gowarmConnCapture = window.__gowarmConnCapture || [];

  const MAX_ENTRIES = 40;
  const MAX_BODY    = 300000;   // chars; GraphQL relationship payloads are large

  // URL fragments that indicate a relationships payload worth keeping.
  const RELEVANT = /(invitation|connection|memberrelationship|relationships\/dash|relationshipsdash|invitationsdash)/i;

  function classify(url) {
    const u = url.toLowerCase();
    // Sent-invitation views carry "sent" in the query/variables; received do not.
    if (u.includes('sentinvitation') || (u.includes('invitation') && u.includes('sent'))) return 'sent';
    if (u.includes('invitation')) return 'invitations';     // ambiguous (likely received) — kept, but labelled
    if (u.includes('connection') || u.includes('memberrelationship')) return 'connections';
    return 'other';
  }

  function record(url, status, body) {
    try {
      if (!url || !RELEVANT.test(url)) return;
      window.__gowarmConnCapture.push({
        url: String(url),
        status: status || 0,
        kind: classify(url),
        ts: Date.now(),
        body: (typeof body === 'string') ? body.slice(0, MAX_BODY) : null,
      });
      const arr = window.__gowarmConnCapture;
      if (arr.length > MAX_ENTRIES) arr.splice(0, arr.length - MAX_ENTRIES);
    } catch (_) { /* never let capture break the page */ }
  }

  // ── Wrap fetch ──────────────────────────────────────────────────────────────
  const origFetch = window.fetch;
  if (typeof origFetch === 'function' && !origFetch.__gowarmWrapped) {
    const wrapped = function (input, init) {
      const url = (typeof input === 'string') ? input : (input && input.url) || '';
      const promise = origFetch.apply(this, arguments);
      if (url && RELEVANT.test(url)) {
        promise.then((res) => {
          try {
            res.clone().text()
              .then((body) => record(url, res.status, body))
              .catch(() => {});
          } catch (_) {}
        }).catch(() => {});
      }
      return promise;
    };
    wrapped.__gowarmWrapped = true;
    window.fetch = wrapped;
  }

  // ── Wrap XMLHttpRequest ───────────────────────────────────────────────────
  const XO = XMLHttpRequest.prototype.open;
  if (typeof XO === 'function' && !XO.__gowarmWrapped) {
    XMLHttpRequest.prototype.open = function (method, url) {
      this.__gowarmUrl = url;
      return XO.apply(this, arguments);
    };
    XMLHttpRequest.prototype.open.__gowarmWrapped = true;

    const XS = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.send = function () {
      const xhr = this;
      const url = xhr.__gowarmUrl || '';
      if (url && RELEVANT.test(url)) {
        xhr.addEventListener('load', function () {
          try { record(url, xhr.status, xhr.responseText); } catch (_) {}
        });
      }
      return XS.apply(this, arguments);
    };
  }

  console.log('[GoWarm] relationship network capture installed — browse My Network to populate.');
})();
