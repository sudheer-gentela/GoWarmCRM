// li_net_capture.js — runs in the PAGE / MAIN world at document_start.
//
// Why this exists: LinkedIn moved sent-invitations and connections to its
// internal GraphQL endpoint, whose queryId hash is generated from LinkedIn's
// own Ember bundle and rotates on every front-end deploy. We can't reliably
// hit those URLs blind (we saw 404/400 doing exactly that). So instead of
// guessing, we let LinkedIn fire its OWN correct request — and we passively
// record the response.
//
// How: we wrap window.fetch and XMLHttpRequest at document_start (before any
// LinkedIn script runs, so our wrappers are the ones in place). Whenever a
// relationship-related Voyager request completes, we stash {url, status, body}
// on window.__gowarmConnCapture. The service worker harvests that array on
// demand (executeScript in the MAIN world) when the user clicks
// "Check sent & accepted".
//
// This means the workflow is: browse to My Network → Sent / Connections (so
// LinkedIn loads that data), THEN click the button. The capture is the user's
// own data, recorded only while they themselves browse — no background polling.
//
// ── Messaging capture (v1.21) ────────────────────────────────────────────────
// Same passive posture, separate buffer. When the rep opens their LinkedIn
// inbox, LinkedIn fires its OWN messaging GraphQL/Voyager requests (rotating
// queryId), and we stash the responses on a DEDICATED window.__gowarmMsgCapture
// array — kept entirely separate from __gowarmConnCapture so the connection
// harvester stays untouched. Nothing is parsed or sent here; this only records
// raw responses so we can (a) inspect the real payload shape from the page
// console (window.__gowarmMsgProbe()) and (b) later harvest + reconcile them.

(function () {
  if (window.__gowarmConnCaptureInstalled) return;
  window.__gowarmConnCaptureInstalled = true;
  window.__gowarmConnCapture = window.__gowarmConnCapture || [];

  const MAX_ENTRIES = 40;
  const MAX_BODY    = 300000;   // chars; GraphQL relationship payloads are large

  // URL fragments that indicate a relationships payload worth keeping.
  const RELEVANT = /(invitation|connection|memberrelationship|relationships\/dash|relationshipsdash|invitationsdash)/i;

  // ── Messaging capture buffer (v1.21) ──────────────────────────────────────
  // Dedicated array — NEVER mixed into __gowarmConnCapture. Matches LinkedIn's
  // messaging surfaces: "messenger…" (messengerConversations / messengerMessages
  // / messengerMessagingParticipants) and the "messaging" REST/dash variants
  // (voyager/api/messaging/…, voyagerMessagingDash…). The two stems "messeng"
  // and "messagi" together cover every shape we've seen.
  window.__gowarmMsgCapture = window.__gowarmMsgCapture || [];
  const MSG_RELEVANT   = /(messeng|messagi)/i;
  const MSG_MAX_ENTRIES = 60;   // inbox list + a few open threads → a handful of calls

  // ── Profile-URN capture (v1.20) ──────────────────────────────────────────────
  //
  // Separate, narrowly-scoped path that records the *page owner's* fsd_profile
  // URN whenever LinkedIn loads a profile. We do NOT push these into
  // __gowarmConnCapture (the connection harvester must stay untouched); we keep
  // them in their own map and postMessage them to the content script (isolated
  // world) so it can attach member_urn to the capture payload.
  //
  // WHY this beats a per-send live resolve: LinkedIn fires its OWN identity
  // request with the currently-valid (rotating) queryId, so we never hardcode a
  // hash. And because we only emit a URN we can BIND to the current page slug
  // (publicIdentifier === /in/<slug>), there is zero wrong-person risk — a
  // failure to bind emits nothing, and the send path falls back to live resolve.
  //
  // NOTE: the owner-binding parser below is written against (a) the known
  // voyagerIdentityDashProfiles?variables=(memberIdentity:<publicId>) shape the
  // backend already resolves against, and (b) the standard normalized-json
  // included[] entity shape. It FAILS SAFE (emits nothing) on any other shape.
  // Verify against a live profile-browse capture before trusting at volume —
  // same posture as PROFILE_QUERY_ID, but failure here is silent, not wrong.
  const PROFILE_RELEVANT = /(identitydashprofiles|voyager\/api\/identity)/i;
  window.__gowarmProfileUrns = window.__gowarmProfileUrns || {};   // slug -> { urn, ts }

  // Current /in/<slug> being viewed, lowercased. Null when not on a profile.
  function currentProfileSlug() {
    try {
      const m = (location.pathname || '').match(/\/in\/([^/?#]+)/);
      return m ? decodeURIComponent(m[1]).toLowerCase() : null;
    } catch (_) { return null; }
  }

  // Deep-walk an arbitrary parsed object graph for the object carrying the
  // owner's publicIdentifier and return the fsd_profile URN on that same object.
  // Structure-agnostic (LinkedIn's shapes/decorations rotate).
  function deepFindOwnerUrn(root, slug) {
    try {
      const stack = [root];
      let guard = 0;
      while (stack.length && guard < 200000) {
        guard++;
        const node = stack.pop();
        if (!node || typeof node !== 'object') continue;
        const pid = typeof node.publicIdentifier === 'string' ? node.publicIdentifier.toLowerCase() : null;
        if (pid === slug) {
          for (const k of Object.keys(node)) {
            const v = node[k];
            if (typeof v === 'string' && /^urn:li:fsd_profile:[A-Za-z0-9_-]+$/.test(v)) return v;
          }
        }
        for (const k of Object.keys(node)) {
          const v = node[k];
          if (v && typeof v === 'object') stack.push(v);
        }
      }
    } catch (_) {}
    return null;
  }

  // Extract the page-owner's fsd_profile URN from a profile/identity response,
  // bound to `slug`. Returns the urn string or null. Pure + defensive.
  function extractOwnerUrn(url, body, slug) {
    if (!body || !slug) return null;
    // Strategy A (proven shape): request was BY memberIdentity:<slug>, so the
    // first fsd_profile in the body is unambiguously that member's.
    try {
      const mi = String(url).match(/memberIdentity:([^,)\s&]+)/);
      if (mi && decodeURIComponent(mi[1]).toLowerCase() === slug) {
        const m = body.match(/urn:li:fsd_profile:[A-Za-z0-9_-]+/);
        if (m) return m[0];
      }
    } catch (_) { /* fall through */ }
    // Strategy B (deep-walk): find the entity whose publicIdentifier === slug
    // anywhere in the parsed graph and take its fsd_profile entityUrn.
    try {
      const urn = deepFindOwnerUrn(JSON.parse(body), slug);
      if (urn) return urn;
    } catch (_) { /* not JSON / unexpected — fall through */ }
    return null;
  }

  // Capture the CURRENT voyagerIdentityDashProfiles queryId from ANY request URL.
  // The hash is a property of LinkedIn's deployed front-end build — identical
  // across every such call until they ship a new build — so grabbing it from any
  // request and PERSISTING it (via content.js) means a later cached/SPA profile
  // load that fires no identity request still has a fresh hash, and it survives
  // page loads / SW restarts. This is what makes the resolve self-healing when
  // LinkedIn rotates the hash. URL-only (no body parse), so it's cheap + robust.
  function captureQueryId(url) {
    try {
      const q = String(url).match(/queryId=(voyagerIdentityDashProfiles\.[0-9a-fA-F]+)/);
      if (!q || window.__gowarmProfileQueryId === q[1]) return;
      window.__gowarmProfileQueryId = q[1];
      window.postMessage({ __gowarm: true, kind: 'profile_queryid', queryId: q[1] }, '*');  // content.js persists it
    } catch (_) {}
  }

  function handleProfile(url, body) {
    try {
      if (!body || body.length > MAX_BODY) return;
      const slug = currentProfileSlug();
      if (!slug) return;
      if (window.__gowarmProfileUrns[slug]) return;        // already have it this session
      const urn = extractOwnerUrn(url, body, slug);
      if (!urn) return;
      window.__gowarmProfileUrns[slug] = { urn, ts: Date.now() };
      console.log('[GoWarm] profile URN captured (network):', slug, urn);
      // Bridge to the isolated-world content script.
      window.postMessage({ __gowarm: true, kind: 'profile_urn', slug, urn }, '*');
    } catch (_) { /* never let capture break the page */ }
  }

  // Reply to a content-script catch-up request. If we don't already have the
  // URN for the requested slug (passively captured), RESOLVE IT LIVE via the
  // same proven Voyager GraphQL call the send path uses — this is the reliable
  // path: it doesn't depend on <code> hydration blocks (which LinkedIn strips
  // after boot / never renders on SPA navigation) being present in the DOM.
  const PROFILE_QUERY_ID_FALLBACK = 'voyagerIdentityDashProfiles.273a499c117721535e6da078bee17e9c'; // ROTATES; captured one preferred

  async function resolveOwnerUrnLive(slug) {
    try {
      if (!slug) return null;
      const cm = document.cookie.match(/JSESSIONID=("?)([^";]+)\1/);
      const csrf = cm ? cm[2] : null;
      if (!csrf) return null;
      const qid = (window.__gowarmProfileQueryId && /^voyagerIdentityDashProfiles\./.test(window.__gowarmProfileQueryId))
        ? window.__gowarmProfileQueryId : PROFILE_QUERY_ID_FALLBACK;
      const r = await fetch(
        'https://www.linkedin.com/voyager/api/graphql?includeWebMetadata=true&variables=(memberIdentity:' +
          encodeURIComponent(slug) + ')&queryId=' + qid,
        { method: 'GET', credentials: 'include', headers: {
          'csrf-token': csrf,
          'accept': 'application/vnd.linkedin.normalized+json+2.1',
          'x-restli-protocol-version': '2.0.0',
          'x-li-lang': 'en_US',
        }}
      );
      if (r.status !== 200) { console.warn('[GoWarm] URN resolve HTTP', r.status, 'for', slug); return null; }
      const txt = await r.text();
      const m = txt.match(/urn:li:fsd_profile:[A-Za-z0-9_-]+/);   // query is BY this publicId → first match is the owner
      return m ? m[0] : null;
    } catch (e) { console.warn('[GoWarm] URN resolve error', e && e.message); return null; }
  }

  window.addEventListener('message', (ev) => {
    (async () => {
      try {
        if (ev.source !== window) return;
        const d = ev.data;
        if (!d || d.__gowarm !== true || d.kind !== 'profile_urn_request') return;
        const slug = String(d.slug || '').toLowerCase();
        if (!slug) return;
        let hit = window.__gowarmProfileUrns[slug];
        if (!hit || !hit.urn) {
          const urn = await resolveOwnerUrnLive(slug);
          if (urn) { hit = { urn, ts: Date.now(), via: 'resolve' }; window.__gowarmProfileUrns[slug] = hit; }
        }
        if (hit && hit.urn) window.postMessage({ __gowarm: true, kind: 'profile_urn', slug, urn: hit.urn }, '*');
      } catch (_) {}
    })();
  });

  // Seed window.__gowarmProfileQueryId from the value content.js persisted —
  // covers cached/SPA loads that fire no identity request this session. Only
  // seeds when we haven't already observed a (fresher) one this page.
  window.addEventListener('message', (ev) => {
    try {
      if (ev.source !== window) return;
      const d = ev.data;
      if (!d || d.__gowarm !== true || d.kind !== 'profile_queryid_seed') return;
      if (d.queryId && /^voyagerIdentityDashProfiles\./.test(d.queryId) && !window.__gowarmProfileQueryId) {
        window.__gowarmProfileQueryId = d.queryId;
      }
    } catch (_) {}
  });

  // Page-console diagnostic (MAIN world, so it's callable from the console —
  // unlike content.js's __gowarmUrnDebug which lives in the isolated world):
  //   __gowarmUrnProbe()  → resolves the current profile's URN live and logs it.
  window.__gowarmUrnProbe = async function (slug) {
    const s = String(slug || (location.pathname.match(/\/in\/([^/?#]+)/) || [])[1] || '').toLowerCase();
    const urn = await resolveOwnerUrnLive(s);
    const out = { slug: s, urn, queryId: window.__gowarmProfileQueryId || '(fallback)', captured: window.__gowarmProfileUrns[s] || null };
    console.log('[GoWarm] __gowarmUrnProbe', out);
    return out;
  };

  function classify(url) {
    const u = url.toLowerCase();
    // Sent-invitation views carry "sent" in the query/variables; received do not.
    if (u.includes('sentinvitation') || (u.includes('invitation') && u.includes('sent'))) return 'sent';
    if (u.includes('invitation')) return 'invitations';     // ambiguous (likely received) — kept, but labelled
    if (u.includes('connection') || u.includes('memberrelationship')) return 'connections';
    return 'other';
  }

  function record(url, status, body) {
    try {
      if (!url || !RELEVANT.test(url)) return;
      window.__gowarmConnCapture.push({
        url: String(url),
        status: status || 0,
        kind: classify(url),
        ts: Date.now(),
        body: (typeof body === 'string') ? body.slice(0, MAX_BODY) : null,
      });
      const arr = window.__gowarmConnCapture;
      if (arr.length > MAX_ENTRIES) arr.splice(0, arr.length - MAX_ENTRIES);
    } catch (_) { /* never let capture break the page */ }
  }

  // Label a messaging payload so the later harvester (and the console probe)
  // can tell the conversation LIST from a single THREAD's messages. URL-only,
  // best-effort — 'other' is fine, the parser keys off body shape too.
  function classifyMsg(url) {
    const u = String(url).toLowerCase();
    if (u.includes('messengermessages') || u.includes('/events'))            return 'messages';        // a thread's messages
    if (u.includes('messengerconversations') || u.includes('/conversations')) return 'conversations';   // inbox list
    if (u.includes('participant'))                                            return 'participants';
    return 'other';
  }

  function recordMsg(url, status, body) {
    try {
      if (!url || !MSG_RELEVANT.test(url)) return;
      window.__gowarmMsgCapture.push({
        url: String(url),
        status: status || 0,
        kind: classifyMsg(url),
        ts: Date.now(),
        body: (typeof body === 'string') ? body.slice(0, MAX_BODY) : null,
      });
      const arr = window.__gowarmMsgCapture;
      if (arr.length > MSG_MAX_ENTRIES) arr.splice(0, arr.length - MSG_MAX_ENTRIES);
    } catch (_) { /* never let capture break the page */ }
  }

  // ── Wrap fetch ──────────────────────────────────────────────────────────────
  const origFetch = window.fetch;
  if (typeof origFetch === 'function' && !origFetch.__gowarmWrapped) {
    const wrapped = function (input, init) {
      const url = (typeof input === 'string') ? input : (input && input.url) || '';
      const promise = origFetch.apply(this, arguments);
      if (url) captureQueryId(url);
      if (url && RELEVANT.test(url)) {
        promise.then((res) => {
          try {
            res.clone().text()
              .then((body) => record(url, res.status, body))
              .catch(() => {});
          } catch (_) {}
        }).catch(() => {});
      }
      if (url && PROFILE_RELEVANT.test(url)) {
        promise.then((res) => {
          try {
            res.clone().text()
              .then((body) => handleProfile(url, body))
              .catch(() => {});
          } catch (_) {}
        }).catch(() => {});
      }
      if (url && MSG_RELEVANT.test(url)) {
        promise.then((res) => {
          try {
            res.clone().text()
              .then((body) => recordMsg(url, res.status, body))
              .catch(() => {});
          } catch (_) {}
        }).catch(() => {});
      }
      return promise;
    };
    wrapped.__gowarmWrapped = true;
    window.fetch = wrapped;
  }

  // ── Wrap XMLHttpRequest ───────────────────────────────────────────────────
  const XO = XMLHttpRequest.prototype.open;
  if (typeof XO === 'function' && !XO.__gowarmWrapped) {
    XMLHttpRequest.prototype.open = function (method, url) {
      this.__gowarmUrl = url;
      return XO.apply(this, arguments);
    };
    XMLHttpRequest.prototype.open.__gowarmWrapped = true;

    const XS = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.send = function () {
      const xhr = this;
      const url = xhr.__gowarmUrl || '';
      if (url) captureQueryId(url);
      if (url && RELEVANT.test(url)) {
        xhr.addEventListener('load', function () {
          try { record(url, xhr.status, xhr.responseText); } catch (_) {}
        });
      }
      if (url && PROFILE_RELEVANT.test(url)) {
        xhr.addEventListener('load', function () {
          try { handleProfile(url, xhr.responseText); } catch (_) {}
        });
      }
      if (url && MSG_RELEVANT.test(url)) {
        xhr.addEventListener('load', function () {
          try { recordMsg(url, xhr.status, xhr.responseText); } catch (_) {}
        });
      }
      return XS.apply(this, arguments);
    };
  }

  // Page-console diagnostic for the messaging capture (MAIN world → callable
  // straight from the console). Prints a compact summary so you can confirm the
  // inbox/thread requests were recorded, and tells you how to copy the full raw
  // payload out for shape inspection.
  //   __gowarmMsgProbe()         → summary table of captured messaging responses
  //   copy(window.__gowarmMsgCapture)   → copies the full array to clipboard
  window.__gowarmMsgProbe = function () {
    const arr = Array.isArray(window.__gowarmMsgCapture) ? window.__gowarmMsgCapture : [];
    const summary = arr.map((e, i) => ({
      i,
      kind: e.kind,
      status: e.status,
      bodyChars: e.body ? e.body.length : 0,
      url: String(e.url).slice(0, 120),
    }));
    console.log('[GoWarm] __gowarmMsgProbe — captured', arr.length, 'messaging responses');
    try { console.table(summary); } catch (_) { console.log(summary); }
    console.log('[GoWarm] To export: run  copy(window.__gowarmMsgCapture)  then paste into a .json file.');
    return summary;
  };

  console.log('[GoWarm] relationship + messaging network capture installed — browse My Network / open your inbox to populate. Messaging: run __gowarmMsgProbe() to inspect.');
})();
