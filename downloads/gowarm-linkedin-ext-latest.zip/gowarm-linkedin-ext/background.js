// background.js — GoWarmCRM LinkedIn Extension v1.20
//
// New in v1.17:
//   • SYNC_CONNECTION_ACTIVITY — scrapes the logged-in LinkedIn member's
//     sent-pending invitations or recently-added connections (same scrape
//     as READ_CONNECTION_ACTIVITY) and pushes them to
//     POST /api/linkedin-connections/reconcile. The backend binds the
//     LinkedIn seat to the GoWarm user, slug-matches people to prospects
//     OWNED by that user, and records connection_request_sent /
//     connection_accepted idempotently. Drives the popup's split
//     "Check & update sent" / "Check & update accepted" buttons.
//
// Auto-auth: token is harvested automatically from app.gowarmcrm.com
// by auth_bridge.js — no manual paste needed.
//
// New in v1.5:
//   • GET_IDENTITY — calls /api/auth/verify, caches { email, org_name,
//     org_id, org_slug } in chrome.storage.local. Used by popup +
//     in-page panel to show "Saving as <email> · <org_name>" so reps
//     can tell at a glance which workspace their captures land in.
//
//   • GET_LINKEDIN_PROFILE — calls /api/linkedin-profiles/by-url to
//     fetch the existing captured profile (if any). Drives the delta-
//     refresh UX in content.js: rows are pre-populated with what's
//     already in DB, and live scrapes are diffed against that.
//
//   • GET_CONFIG — exposes API_BASE so the popup can show the user
//     which backend they're talking to (prod vs staging vs custom).
//
//   • Identity is invalidated whenever the token changes or is
//     cleared, so switching CRM accounts in another tab is reflected
//     correctly.

const API_BASE = 'https://api.gowarmcrm.com/api';

// Identity cache TTL — re-fetch from /verify if the cached identity is
// older than this. Short enough that a stale email/org name never
// lingers; long enough that we don't hammer the endpoint on every
// LinkedIn profile visit. The token-change path also invalidates.
const IDENTITY_TTL_MS = 10 * 60 * 1000;   // 10 minutes

// ── Token management ─────────────────────────────────────────────────────────

async function getToken() {
  return new Promise(resolve => {
    chrome.storage.local.get(['gowarm_token'], result => {
      resolve(result.gowarm_token || null);
    });
  });
}

async function saveToken(token) {
  // Compare against existing — if it changed, drop cached identity so
  // the next GET_IDENTITY call refetches under the new token.
  return new Promise(resolve => {
    chrome.storage.local.get(['gowarm_token'], (result) => {
      const previous = result.gowarm_token || null;
      const changed  = previous !== token;
      const writes   = { gowarm_token: token };
      if (changed) {
        // Wipe identity so we don't keep showing the old user/org.
        writes.gowarm_identity      = null;
        writes.gowarm_identity_ts   = null;
      }
      chrome.storage.local.set(writes, resolve);
    });
  });
}

async function clearToken() {
  return new Promise(resolve => {
    chrome.storage.local.remove(
      ['gowarm_token', 'gowarm_identity', 'gowarm_identity_ts'],
      resolve
    );
  });
}

// ── Identity cache ────────────────────────────────────────────────────────────

async function getCachedIdentity() {
  return new Promise(resolve => {
    chrome.storage.local.get(['gowarm_identity', 'gowarm_identity_ts'], (r) => {
      resolve({
        identity:  r.gowarm_identity   || null,
        cachedAt:  r.gowarm_identity_ts || 0,
      });
    });
  });
}

async function saveIdentity(identity) {
  return new Promise(resolve => {
    chrome.storage.local.set({
      gowarm_identity:    identity,
      gowarm_identity_ts: Date.now(),
    }, resolve);
  });
}

// ── Harvest token from an open GoWarmCRM tab ─────────────────────────────────
// Falls back to scripting API if auth_bridge.js hasn't fired yet,
// or if the token was written before the extension was installed.
async function harvestTokenFromOpenTab() {
  return new Promise(resolve => {
    chrome.tabs.query({ url: 'https://app.gowarmcrm.com/*' }, async (tabs) => {
      if (!tabs || tabs.length === 0) {
        resolve(null);
        return;
      }
      try {
        const results = await chrome.scripting.executeScript({
          target: { tabId: tabs[0].id },
          func: () => {
            return (
              localStorage.getItem('token') ||
              localStorage.getItem('authToken') ||
              localStorage.getItem('gowarm_token') ||
              null
            );
          },
        });
        const token = results?.[0]?.result || null;
        if (token) await saveToken(token);
        resolve(token);
      } catch (err) {
        resolve(null);
      }
    });
  });
}

// ── Authenticated API fetch with auto-refresh ─────────────────────────────────

async function apiFetch(path, options = {}, retried = false) {
  let token = await getToken();

  // No stored token — try to grab it from open GoWarmCRM tab first
  if (!token) {
    token = await harvestTokenFromOpenTab();
  }

  if (!token) throw new Error('NOT_AUTHENTICATED');

  const res = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
      'X-GoWarm-Extension-Key': 'gowarm-ext-2024-xK9mP3qR',
      ...(options.headers || {}),
    },
  });

  // 401 = token expired — harvest fresh token and retry once
  if (res.status === 401 && !retried) {
    await clearToken();
    const freshToken = await harvestTokenFromOpenTab();
    if (freshToken) return apiFetch(path, options, true);
    throw new Error('NOT_AUTHENTICATED');
  }

  const data = await res.json();
  if (!res.ok) throw new Error(data?.error?.message || `HTTP ${res.status}`);
  return data;
}

// ── Identity fetch ────────────────────────────────────────────────────────────
//
// Hits /auth/verify (which already returns user + org_id + org_name + org_slug
// after the v1.5 backend change). Cached for IDENTITY_TTL_MS. Pass
// { force: true } to bypass the cache, e.g. immediately after the
// popup harvests a new token.
//
// Returns { identity, cachedAt } — cachedAt is the unix-ms timestamp
// of the last successful /verify response (read from storage on cache
// hit, set to Date.now() on cache miss). The popup's settings view
// reads this to show "Last refreshed 2m ago" so reps know whether
// the displayed account is fresh or stale.
async function fetchIdentity({ force = false } = {}) {
  if (!force) {
    const { identity, cachedAt } = await getCachedIdentity();
    if (identity && Date.now() - cachedAt < IDENTITY_TTL_MS) {
      return { identity, cachedAt };
    }
  }

  // /auth/verify lives at /api/auth/verify (same /api prefix as everything
  // else the extension talks to).
  const data = await apiFetch('/auth/verify');
  const u = data?.user || {};

  const identity = {
    user_id:     u.id          ?? null,
    email:       u.email       ?? null,
    first_name:  u.firstName   ?? null,
    last_name:   u.lastName    ?? null,
    org_id:      u.org_id      ?? null,
    org_name:    u.org_name    ?? null,
    org_slug:    u.org_slug    ?? null,
    org_role:    u.org_role    ?? null,
  };
  await saveIdentity(identity);
  return { identity, cachedAt: Date.now() };
}

// ── API host classification ──────────────────────────────────────────────────
//
// The popup uses this to decide whether to show a green "production"
// pill or an amber "non-production" warning. A hostname containing
// 'staging', 'dev', 'localhost', or a Railway preview URL is treated
// as non-prod. Pure prod is api.gowarmcrm.com.
function classifyApiHost() {
  let host = '';
  try { host = new URL(API_BASE).host; } catch (_) { host = ''; }

  const isProd =
    host === 'api.gowarmcrm.com';

  return {
    api_base: API_BASE,
    host,
    env:      isProd ? 'production' : 'non-production',
    is_prod:  isProd,
  };
}

// ── Version check ────────────────────────────────────────────────────────────
//
// Polls the backend's /extension/version endpoint to find out whether a
// newer build is available. We don't auto-update — Chrome won't allow that
// for unpacked extensions — but we cache the result so the popup can show
// a banner directing the user to the install page.
//
// Design choices worth knowing:
//   • Unauthenticated: version info isn't sensitive, and an unauth endpoint
//     means the check still works when the user is logged out.
//   • Silent on failure: if the endpoint is unreachable or returns junk,
//     we leave the cached result alone and the popup just doesn't show
//     a banner. The extension MUST keep working when the version service
//     is down — this is a nice-to-have, not load-bearing.
//   • Cached in chrome.storage.local under gowarm_update_check so the popup
//     can read it synchronously (no network call on popup open).
//   • Re-checked on service-worker startup and every 6 hours via alarms.

const VERSION_ENDPOINT       = '/extension/version';
const UPDATE_CHECK_ALARM     = 'gowarm_version_check';
const UPDATE_CHECK_PERIOD_MIN = 6 * 60; // 6 hours

// Compare two dotted version strings ("1.7.3" vs "1.7.10"). Returns
// negative if a < b, 0 if equal, positive if a > b. Pads with zeros so
// "1.7" compares correctly against "1.7.0". Non-numeric segments
// (pre-release tags etc.) are treated as 0 — good enough for our use.
function compareVersions(a, b) {
  const pa = String(a || '').split('.').map(n => parseInt(n, 10) || 0);
  const pb = String(b || '').split('.').map(n => parseInt(n, 10) || 0);
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const da = pa[i] || 0;
    const db = pb[i] || 0;
    if (da !== db) return da - db;
  }
  return 0;
}

async function checkForUpdate() {
  const current = chrome.runtime.getManifest().version;
  try {
    // Unauthenticated, short timeout. AbortController gives us a hard
    // ceiling so a hung backend doesn't keep the service worker alive.
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 5000);
    // No JWT here — the version check must work when the user is signed out.
    // We DO send the extension key so the request passes the server's
    // chrome-extension origin guard even if the public exemption is ever
    // tightened. The endpoint itself stays unauthenticated.
    const res = await fetch(`${API_BASE}${VERSION_ENDPOINT}`, {
      method: 'GET',
      headers: { 'X-GoWarm-Extension-Key': 'gowarm-ext-2024-xK9mP3qR' },
      signal: ctrl.signal,
    });
    clearTimeout(timer);
    if (!res.ok) return;
    const data = await res.json();
    const latest = data?.latest;
    if (!latest || typeof latest !== 'string') return;

    const status = {
      current,
      latest,
      update_available: compareVersions(current, latest) < 0,
      download_url:     data?.download_url || null,
      min_supported:    data?.min_supported || null,
      checked_at:       Date.now(),
    };
    await new Promise(resolve =>
      chrome.storage.local.set({ gowarm_update_check: status }, resolve)
    );
  } catch (_) {
    // Silent — keep whatever the previous cached value was. The popup
    // gracefully renders "no banner" when nothing is cached or when
    // update_available is false.
  }
}

// Run once on service-worker startup, then on a recurring alarm.
chrome.runtime.onStartup.addListener(() => {
  checkForUpdate();
  // Re-assert the autosend alarm (durable, but cheap) and take one immediate
  // shot so a rep who already has LinkedIn open doesn't wait a full period.
  chrome.alarms.create(AUTOSEND_ALARM, { periodInMinutes: AUTOSEND_PERIOD_MIN, delayInMinutes: 1 });
  runAutoSendTick().catch(() => {});
});
chrome.runtime.onInstalled.addListener(() => {
  checkForUpdate();
  chrome.alarms.create(UPDATE_CHECK_ALARM, { periodInMinutes: UPDATE_CHECK_PERIOD_MIN });
  // v1.19: optional LinkedIn auto-send + weekly opportunistic harvest. Creating
  // the alarms is harmless even when auto-send is OFF for this rep — the handler
  // bails immediately unless (a) a LinkedIn tab is already open and (b) the
  // backend reports the rep is enabled. We never synthesize a browsing session.
  // delayInMinutes:1 gives a near-immediate first tick instead of waiting a full
  // 15-min period after install/opt-in.
  chrome.alarms.create(AUTOSEND_ALARM,       { periodInMinutes: AUTOSEND_PERIOD_MIN, delayInMinutes: 1 });
  chrome.alarms.create(WEEKLY_HARVEST_ALARM, { periodInMinutes: WEEKLY_HARVEST_PERIOD_MIN });
  runAutoSendTick().catch(() => {});
});
chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name === UPDATE_CHECK_ALARM)     checkForUpdate();
  if (alarm.name === AUTOSEND_ALARM)         runAutoSendTick().catch(e => console.warn('[GoWarm] autosend tick:', e && e.message));
  if (alarm.name === AUTOSEND_STEP_ALARM)    autoSendStep({}).catch(e => console.warn('[GoWarm] autosend step:', e && e.message));
  if (alarm.name === WEEKLY_HARVEST_ALARM)   runWeeklyHarvest().catch(e => console.warn('[GoWarm] weekly harvest:', e && e.message));
});

// ── LinkedIn connection-activity reader (v1.9) ────────────────────────────────
//
// Reads the logged-in LinkedIn member's SENT (still-pending) invitations and
// RECENTLY-ADDED connections (the practical "accepted" signal) straight from
// LinkedIn's own Voyager API. Purpose: let a rep confirm a connection request
// actually went out — and see which of those went out have since been accepted.
//
// How it works (same shape as the token-harvest path):
//   • We find (or briefly open) a www.linkedin.com tab.
//   • chrome.scripting.executeScript injects gowarmReadConnectionActivity()
//     into that tab's ISOLATED world. Because the document origin is
//     linkedin.com, fetch(..., {credentials:'include'}) carries the member's
//     session cookies, and the JSESSIONID cookie value doubles as the
//     csrf-token header — exactly like content.js's profile capture.
//
// Why candidates + raw passthrough:
//   Voyager endpoint shapes / decoration IDs rotate with LinkedIn deploys and
//   can't be verified offline. So the injected fn tries the known endpoint
//   shapes in priority order, returns the first 200, and ALSO stashes the full
//   raw JSON on window.__gowarmConnRaw (inspectable in the LinkedIn tab's
//   devtools) plus a truncated sample in the response — so one live run tells
//   us the exact shape and we tune the parser from real data.
//
// IMPORTANT — this is the user's OWN network activity, read on demand by a
// human click. Keep it that way: do NOT put this on an alarm/poll. Automated,
// high-frequency Voyager traffic is what gets accounts flagged.

// Find an open LinkedIn tab, or open one in the background and wait for load.
// Returns { tabId, created } — `created` tells the caller whether to clean up.
async function getOrCreateLinkedInTab() {
  const tabs = await chrome.tabs.query({ url: 'https://www.linkedin.com/*' });
  if (tabs && tabs.length) return { tabId: tabs[0].id, created: false };

  const tab = await chrome.tabs.create({
    url: 'https://www.linkedin.com/feed/',
    active: false,
  });

  await new Promise((resolve) => {
    function listener(tabId, info) {
      if (tabId === tab.id && info.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    }
    chrome.tabs.onUpdated.addListener(listener);
    // Safety valve — don't hang forever if the tab never reports complete.
    setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      resolve();
    }, 12000);
  });

  return { tabId: tab.id, created: true };
}

// Injected into the LinkedIn tab (MAIN world, so it can read the capture array
// that li_net_capture.js populates). MUST be fully self-contained — execute-
// Script serialises it via toString(). Returns a plain object.
//
// Strategy: rather than guess rotating GraphQL queryIds, we harvest the
// requests LinkedIn already fired (and we recorded) while the user browsed
// My Network. We also do one stable direct call — /voyager/api/me — for the
// logged-in member's identity, which is a fixed endpoint that doesn't rotate.
async function gowarmReadConnectionActivity() {
  const out = {
    ok: false, ts: Date.now(), viewer: null,
    sent: null, accepted: null, captures: [], needsBrowse: false, error: null,
  };

  // Defensive person extractor — recurse and pull out anything member-shaped.
  function collectPeople(root) {
    const seen = new Set();
    const people = [];
    (function visit(node) {
      if (!node || typeof node !== 'object') return;
      if (Array.isArray(node)) { node.forEach(visit); return; }
      const fn = node.firstName, ln = node.lastName, pub = node.publicIdentifier;
      const key = pub || node.entityUrn;
      if ((typeof fn === 'string' || typeof ln === 'string') && key && !seen.has(key)) {
        seen.add(key);
        let headline = node.occupation || node.headline || null;
        if (headline && typeof headline === 'object') headline = headline.text || null;
        people.push({
          name: [fn, ln].filter(Boolean).join(' ').trim() || null,
          publicIdentifier: pub || null,
          url: pub ? ('https://www.linkedin.com/in/' + pub + '/') : null,
          headline: typeof headline === 'string' ? headline : null,
        });
      }
      for (const k in node) {
        if (node[k] && typeof node[k] === 'object') visit(node[k]);
      }
    })(root);
    return people;
  }

  // ── Viewer identity: /voyager/api/me (stable endpoint, no rotating id) ──
  const cm = document.cookie.match(/JSESSIONID=("?)([^";]+)\1/);
  const csrf = cm ? cm[2] : null;
  if (csrf) {
    try {
      const meRes = await fetch('https://www.linkedin.com/voyager/api/me', {
        method: 'GET',
        credentials: 'include',
        headers: {
          'csrf-token': csrf,
          'x-restli-protocol-version': '2.0.0',
          'accept': 'application/vnd.linkedin.normalized+json+2.1',
        },
      });
      if (meRes.status === 200) {
        const meJson = await meRes.json();
        const p = collectPeople(meJson)[0] || null;
        let memberUrn = null;
        try {
          const um = JSON.stringify(meJson).match(/urn:li:fs[a-z]*_(?:miniProfile|profile):[A-Za-z0-9_-]+/);
          memberUrn = um ? um[0] : null;
        } catch (_) {}
        out.viewer = {
          name: p ? p.name : null,
          publicIdentifier: p ? p.publicIdentifier : null,
          url: p ? p.url : null,
          headline: p ? p.headline : null,
          memberUrn, status: 200,
        };
      } else {
        out.viewer = { name: null, status: meRes.status, error: 'me ' + meRes.status };
      }
    } catch (e) {
      out.viewer = { name: null, status: 0, error: String((e && e.message) || e) };
    }
  }

  // ── Scrape the rendered DOM ───────────────────────────────────────────────
  // LinkedIn's My Network is now server-driven UI (flagship-web/RSC), so the
  // network payloads are an opaque React-Flight component tree — no structured
  // member objects to parse. But the names/links ARE rendered in the DOM, and
  // each row carries a stable semantic anchor: sent invitations have a
  // "Withdraw" button, connections have a "Message" button. We locate rows via
  // those buttons, then pull the /in/ link + name out of the surrounding card.
  function scrapeListByButton(btnRegex) {
    const out = [];
    const seen = new Set();
    const triggers = Array.from(document.querySelectorAll('button, a'))
      .filter(b => btnRegex.test((b.textContent || '').trim()));

    triggers.forEach((btn) => {
      // Climb to the nearest ancestor that contains a profile link.
      let el = btn, card = null;
      for (let i = 0; i < 9 && el; i++) {
        if (el.querySelector && el.querySelector('a[href*="/in/"]')) { card = el; break; }
        el = el.parentElement;
      }
      if (!card) return;

      const links = Array.from(card.querySelectorAll('a[href*="/in/"]'));
      let slug = null;
      for (const a of links) {
        const mm = (a.getAttribute('href') || '').match(/\/in\/([^/?#]+)/);
        if (mm) { slug = mm[1]; break; }
      }
      if (!slug || seen.has(slug)) return;
      seen.add(slug);

      // Name extraction. The visible name is NOT inside the /in/ link's text on
      // these server-driven-UI cards, so "longest link text" returns empty and
      // we'd fall back to the slug. The avatar <img alt> is the clean source
      // (LinkedIn sets it to the member's name). Fallbacks: de-duplicated link
      // text (LinkedIn often doubles it with a visually-hidden span), then
      // aria-label, then the slug.
      let name = '';
      const img = card.querySelector('img[alt]');
      if (img) {
        let alt = (img.getAttribute('alt') || '').replace(/\s+/g, ' ').trim();
        // LinkedIn alt is typically "<Name>'s profile picture" / "...photo" /
        // "...profile photo" — strip the possessive suffix to get the name.
        alt = alt.replace(/[\u2019'`]s\s+(profile\s+)?(picture|photo|image|profile).*$/i, '').trim();
        if (alt && alt.length > 1 && !/(logo|background|company|graphic)/i.test(alt)) name = alt;
      }
      if (!name) {
        let best = '';
        links.forEach(a => {
          const t = (a.textContent || '').replace(/\s+/g, ' ').trim();
          if (t.length > best.length) best = t;
        });
        if (best) {
          const half = best.slice(0, Math.floor(best.length / 2)).trim();
          if (half && best === half + half) best = half;          // "NameName" → "Name"
          if (half && best === half + ' ' + half) best = half;    // "Name Name" → "Name"
          name = best;
        }
      }
      if (!name) {
        for (const a of links) {
          const al = (a.getAttribute('aria-label') || '').trim();
          if (al) { name = al.replace(/^view\s+/i, '').replace(/[\u2019']s profile.*$/i, '').trim(); break; }
        }
      }
      name = (name || slug).replace(/\s+/g, ' ').trim();

      // Time + headline best-effort from the card text.
      const cardText = (card.textContent || '').replace(/\s+/g, ' ').trim();
      const timeMatch = cardText.match(/(sent|connected)\b[^.|·]*?\bago/i);

      out.push({
        name: name || slug,
        publicIdentifier: slug,
        url: 'https://www.linkedin.com/in/' + slug + '/',
        headline: null,                            // refine later if needed
        timeText: timeMatch ? timeMatch[0].trim() : null,
      });
    });
    return out;
  }

  function asGroup(label, people, source) {
    return {
      endpoint: source,
      source: 'dom',
      status: 200,
      peopleCount: people.length,
      people: people.slice(0, 200),
      rawSample: null,
    };
  }

  const path = (location.pathname || '').toLowerCase();
  const onSent        = path.includes('/invitation-manager/sent');
  const onConnections = path.includes('/connections');   // matches both /mynetwork/connections and /mynetwork/invite-connect/connections

  if (onSent) {
    const people = scrapeListByButton(/withdraw/i);
    out.sent = asGroup('Sent', people, 'DOM · invitation-manager/sent');
  }
  if (onConnections) {
    const people = scrapeListByButton(/^message$/i);
    out.accepted = asGroup('Connections', people, 'DOM · mynetwork/connections');
  }

  // Keep the network capture purely as a diagnostic now (opaque SDUI bodies).
  const capture = Array.isArray(window.__gowarmConnCapture) ? window.__gowarmConnCapture : [];
  out.captures = capture.map(c => ({ endpoint: c.url, kind: c.kind, status: c.status }));

  if (!out.sent && !out.accepted) {
    out.needsBrowse = true;
    out.error = 'NOT_ON_LIST_PAGE';
  }

  try {
    window.__gowarmConnRaw = { viewer: out.viewer, path, sent: out.sent, accepted: out.accepted, capture, ts: out.ts };
  } catch (_) {}
  console.log('[GoWarm] connection activity — inspect window.__gowarmConnRaw', out);

  out.ok = true;
  return out;
}

// ════════════════════════════════════════════════════════════════════════════
// ── (v1.19) OPTIONAL LinkedIn connection-request AUTO-SEND ───────────────────
// ════════════════════════════════════════════════════════════════════════════
//
// READ THIS BEFORE TOUCHING — it is in deliberate tension with the warning ~200
// lines up ("do NOT put this on an alarm/poll … is what gets accounts flagged").
//
// That warning is about NEVER manufacturing LinkedIn activity. This feature does
// not violate it: the auto-send tick is gated so it only ever acts while the rep
// ALREADY has LinkedIn open and is inside their own configured working hours —
// it piggybacks on a genuine human session instead of synthesizing one. It is
// OFF unless an org admin enabled it AND this rep explicitly opted in (the
// backend /claim endpoint returns enabled:false otherwise, and we go dormant).
// Every send is throttled by a server-enforced daily cap, a randomized jitter
// gap, the human-hours window, and a hard abort on any LinkedIn challenge/
// captcha. It is still a knowing LinkedIn-ToS tradeoff the rep accepted via an
// in-product disclaimer — keep all of these guardrails intact.

const AUTOSEND_ALARM             = 'gowarm_autosend';
const AUTOSEND_PERIOD_MIN        = 15;   // check every 15 min; most ticks no-op
const AUTOSEND_BATCH             = 3;    // (legacy) batch cap — superseded by one-send-per-tick
const AUTOSEND_STEP_ALARM        = 'gowarm_autosend_step';   // one-shot pacer between sends
const AUTOSEND_STATE_KEY         = 'gowarm_autosend_state';  // { next_send_at } in chrome.storage.local
const WEEKLY_HARVEST_ALARM       = 'gowarm_weekly_harvest';
const WEEKLY_HARVEST_PERIOD_MIN  = 6 * 60;          // check every 6h…
const WEEKLY_HARVEST_MIN_GAP_MS  = 7 * 24 * 3600 * 1000;  // …but act at most weekly

const sleep = (ms) => new Promise(r => setTimeout(r, ms));

// ── One-send-per-tick durability (v1.20) ──────────────────────────────────────
// MV3 can kill the service worker during an in-memory `await sleep(jitter)`, so
// we no longer pace sends inside one long-lived loop. Instead each send is its
// own alarm wake: state (the pacing deadline) lives in chrome.storage.local and
// the queue lives server-side as `scheduled` rows. The worker may die freely
// between sends — nothing is orphaned (an interrupted `sending` lease is
// reclaimed by the server sweep). Alarms floor at ~1 min, so we also gate on
// next_send_at to honor the finer jitter on wake.
async function getAutoSendState() {
  return new Promise(r => chrome.storage.local.get([AUTOSEND_STATE_KEY], o => r(o[AUTOSEND_STATE_KEY] || {})));
}
async function setAutoSendState(s) {
  return new Promise(r => chrome.storage.local.set({ [AUTOSEND_STATE_KEY]: s || {} }, () => r()));
}
async function getAlarm(name) {
  return new Promise(r => { try { chrome.alarms.get(name, a => r(a || null)); } catch (_) { r(null); } });
}
// End the current send chain: drop the pacer alarm and the pacing state. The
// periodic kickoff alarm will restart a chain later if new rows appear.
async function clearStepChain() {
  try { await new Promise(r => chrome.alarms.clear(AUTOSEND_STEP_ALARM, () => r())); } catch (_) {}
  await setAutoSendState({});
}
function autoSendJitterMs(jit) {
  const min = Math.max(20, (jit && jit.min) || 45);
  const max = Math.max(min, (jit && jit.max) || 180);
  return (min + Math.floor(Math.random() * (max - min + 1))) * 1000;
}
async function scheduleNextStep(delayMs) {
  const mins = Math.max(1, (delayMs || 0) / 60000);   // alarm floor ≈ 1 min
  try { chrome.alarms.create(AUTOSEND_STEP_ALARM, { delayInMinutes: mins }); } catch (_) {}
}

// Is at least one real LinkedIn tab open right now? (Honor "no synthetic
// sessions": if the rep isn't on LinkedIn, we do nothing.)
async function hasOpenLinkedInTab() {
  const tabs = await chrome.tabs.query({ url: 'https://www.linkedin.com/*' });
  return !!(tabs && tabs.length);
}

// Local-time human-hours check, using the window the backend handed us.
// window = { start_hour, end_hour, days:[1..7] } evaluated in the rep's LOCAL
// clock (1=Mon … 7=Sun). Defensive: if window is missing, treat as closed.
function withinHumanHours(window) {
  if (!window) return false;
  const now = new Date();
  const isoDay = now.getDay() === 0 ? 7 : now.getDay();   // JS 0=Sun → 7
  if (Array.isArray(window.days) && !window.days.includes(isoDay)) return false;
  const h = now.getHours();
  return h >= window.start_hour && h < window.end_hour;
}

// Read the logged-in member's identity (publicIdentifier) from an open LinkedIn
// tab. Lightweight — just /voyager/api/me — so we can name the seat on /claim
// without running the full My-Network scrape.
function gowarmReadViewerInjected() {
  return (async () => {
    const cm = document.cookie.match(/JSESSIONID=("?)([^";]+)\1/);
    const csrf = cm ? cm[2] : null;
    if (!csrf) return { ok: false, error: 'NO_JSESSIONID' };
    try {
      const res = await fetch('https://www.linkedin.com/voyager/api/me', {
        method: 'GET', credentials: 'include',
        headers: {
          'csrf-token': csrf,
          'x-restli-protocol-version': '2.0.0',
          'accept': 'application/vnd.linkedin.normalized+json+2.1',
        },
      });
      if (res.status !== 200) return { ok: false, error: 'me ' + res.status };
      const j = await res.json();
      let slug = null, name = null, memberUrn = null;
      const s = JSON.stringify(j);
      const pm = s.match(/"publicIdentifier"\s*:\s*"([^"]+)"/);
      if (pm) slug = pm[1];
      const um = s.match(/urn:li:fs[a-z]*_(?:miniProfile|profile):[A-Za-z0-9_-]+/);
      if (um) memberUrn = um[0];
      const fn = s.match(/"firstName"\s*:\s*"([^"]+)"/);
      const ln = s.match(/"lastName"\s*:\s*"([^"]+)"/);
      if (fn || ln) name = [fn && fn[1], ln && ln[1]].filter(Boolean).join(' ').trim() || null;
      return { ok: !!slug, publicIdentifier: slug, name, memberUrn };
    } catch (e) {
      return { ok: false, error: String((e && e.message) || e) };
    }
  })();
}

// Get the viewer by injecting into the first open LinkedIn tab. Returns
// { publicIdentifier, name, memberUrn } or null.
async function getViewerFromOpenTab() {
  const tabs = await chrome.tabs.query({ url: 'https://www.linkedin.com/*' });
  if (!tabs || !tabs.length) return null;
  for (const t of tabs) {
    try {
      const results = await chrome.scripting.executeScript({
        target: { tabId: t.id }, func: gowarmReadViewerInjected, world: 'MAIN',
      });
      const r = results?.[0]?.result;
      if (r && r.ok && r.publicIdentifier) {
        return { publicIdentifier: r.publicIdentifier, name: r.name || null, memberUrn: r.memberUrn || null };
      }
    } catch (_) { /* tab mid-nav — skip */ }
  }
  return null;
}

// Injected into a freshly-opened profile tab. Self-contained (serialized via
// toString). Finds and clicks Connect, optionally with a note, and watches for
// challenges. LinkedIn's DOM rotates, so this is intentionally defensive and
// stashes diagnostics on window.__gowarmAutoSendLast — tune against live pages
// exactly like the scrape code. Returns one of:
//   { status: 'sent' }                        — invitation submitted
//   { status: 'already' }                     — already connected / pending (idempotent OK)
//   { status: 'challenge' }                   — captcha/checkpoint seen → ABORT the run
//   { status: 'limited' }                     — weekly invite limit hit → ABORT the run
//   { status: 'not_found', reason }           — no Connect affordance → row failure
//   { status: 'error', reason }
function gowarmSendConnectionRequestInjected(note) {
  return (async () => {
    const out = { status: 'error', reason: null, ts: Date.now() };
    const wait = (ms) => new Promise(r => setTimeout(r, ms));
    const visible = (el) => !!(el && el.offsetParent !== null && !el.disabled);
    const norm = (s) => (s || '').replace(/\s+/g, ' ').trim();

    // Clickable candidates. CRITICAL: includes a[role="menuitem"] / [role="menuitem"]
    // because LinkedIn renders the overflow Connect as <a role="menuitem">Connect</a>
    // — the old button-only selector could never see it on Follow-primary profiles.
    function candidates(root) {
      root = root || document;
      return Array.from(root.querySelectorAll(
        'button, a[role="button"], div[role="button"], a[role="menuitem"], [role="menuitem"]'
      )).filter(visible);
    }

    // Find a clickable matching text/aria, scoped to a root (default document).
    function findBtn(matchers, root) {
      for (const el of candidates(root)) {
        const txt = norm(el.textContent).toLowerCase();
        const al  = norm(el.getAttribute('aria-label')).toLowerCase();
        for (const m of matchers) {
          if (m.test(txt) || m.test(al)) return el;
        }
      }
      return null;
    }

    // Scope primary-action detection to THIS profile's top card. The page sidebar
    // ("More profiles for you") is full of OTHER people's Connect buttons — an
    // unscoped search risks inviting the wrong person.
    //
    // We do NOT anchor on an <h1>: LinkedIn does not reliably render the profile
    // name as an h1 (querySelector('h1') comes back null on real profiles), which
    // made the old anchor fail every time and surface as "action bar did not
    // render". Instead we anchor on the owner's action buttons inside <main> —
    // the sidebar rail lives in <aside>, so scoping to main excludes it — then
    // climb a few levels to the button row.
    function topCardRoot() {
      const main = document.querySelector('main');
      if (!main) return null;
      const anchor = main.querySelector(
        'button[aria-label="More"], button[aria-label^="Follow "], button[aria-label*="to connect" i]'
      );
      if (!anchor) return null;   // top-card actions not hydrated yet
      // Climb until the container holds the FULL action cluster — both the "More"
      // overflow AND a primary button (Follow or Connect). A fixed 4-level climb
      // landed on just the secondary cluster (Save + More) and missed the primary
      // Connect (that was Timothy's false no_connect). Fall back to <main> (the
      // sidebar lives in <aside>, so it's excluded either way).
      let el = anchor;
      for (let i = 0; i < 8 && el && el !== main; i++) {
        const hasMore    = el.querySelector && el.querySelector('button[aria-label="More"]');
        const hasPrimary = el.querySelector && el.querySelector('button[aria-label^="Follow "], button[aria-label*="to connect" i]');
        if (hasMore && hasPrimary) return el;
        el = el.parentElement;
      }
      return main;
    }

    // LinkedIn's overflow menu items (and some buttons) don't react to a bare
    // .click() — the action is bound to a fuller pointer/mouse sequence. This
    // dispatches the whole sequence so the menuitem Connect actually fires (the
    // bare .click() opened no modal — Prasanth's "modal did not appear").
    function realClick(el) {
      if (!el) return;
      try { el.scrollIntoView({ block: 'center' }); } catch (_) {}
      const r = el.getBoundingClientRect();
      const o = { bubbles: true, cancelable: true, view: window,
                  clientX: Math.floor(r.left + r.width / 2), clientY: Math.floor(r.top + r.height / 2), button: 0 };
      try { el.dispatchEvent(new PointerEvent('pointerover', o)); } catch (_) {}
      try { el.dispatchEvent(new PointerEvent('pointerdown', o)); } catch (_) {}
      el.dispatchEvent(new MouseEvent('mousedown', o));
      try { el.dispatchEvent(new PointerEvent('pointerup', o)); } catch (_) {}
      el.dispatchEvent(new MouseEvent('mouseup', o));
      el.dispatchEvent(new MouseEvent('click', o));
      if (typeof el.click === 'function') { try { el.click(); } catch (_) {} }
    }

    // Poll for an element that appears asynchronously (dropdown items after the
    // "···" opens, or the invite modal after Connect is clicked).
    async function poll(fn, timeoutMs, stepMs) {
      const t0 = Date.now();
      for (;;) {
        const r = fn();
        if (r) return r;
        if (Date.now() - t0 > (timeoutMs || 2500)) return null;
        await wait(stepMs || 200);
      }
    }

    function challengePresent() {
      const url = location.href;
      if (/\/checkpoint\/|\/challenge/i.test(url)) return true;
      if (document.querySelector('iframe[src*="captcha"], iframe[title*="captcha" i], #captcha-internal, .challenge-dialog')) return true;
      const bodyTxt = norm(document.body && document.body.innerText).toLowerCase();
      if (/(verify (it'?s|that you are) you|unusual activity|are you a human|security verification)/i.test(bodyTxt)) return true;
      return false;
    }

    try {
      if (challengePresent()) { out.status = 'challenge'; window.__gowarmAutoSendLast = out; return out; }

      // Wait for LinkedIn's action bar to actually render before searching.
      // topCardRoot() returns null until the owner's Follow/More/Connect buttons
      // are hydrated in <main>, so we just poll it. (The real failure mode was a
      // bad h1 anchor, not slow rendering — see topCardRoot.)
      const scope = await poll(() => topCardRoot(), 10000, 250);
      if (!scope) {
        // Transient: page never finished rendering (slow load / throttled tab).
        // Distinct from no_connect — this one is worth retrying.
        out.status = 'not_rendered';
        out.reason = 'Profile action bar did not render in time';
        window.__gowarmAutoSendLast = out;
        return out;
      }

      // Already connected / pending — scoped, so a sidebar state never counts.
      const pending = findBtn([/^pending$/, /invitation sent/, /^withdraw$/, /click to withdraw/], scope);
      if (pending) { out.status = 'already'; window.__gowarmAutoSendLast = out; return out; }

      // 1. Direct top-card Connect (profiles where Connect is the primary action,
      //    e.g. smaller networks). The owner's invite aria is "Invite <Owner> to connect".
      let connect = findBtn([/^connect$/, /^invite .+ to connect$/], scope);

      // 2. Follow-primary profiles — the NORM for senior people with large
      //    networks. Connect is hidden in the "···" overflow as
      //    <a role="menuitem">Connect</a>; the trigger's aria-label is exactly
      //    "More". Open it, then poll the opened menu (it portals outside the top
      //    card, so search document-wide) for the unambiguous Connect item.
      if (!connect) {
        const more = findBtn([/^more$/], scope);
        if (more) {
          more.click();
          await wait(900);   // let the artdeco dropdown become interactive before
                             // clicking the item — clicking too fast does nothing,
                             // and realClick's double-activation closed the menu.
          connect = await poll(() => {
            // The overflow Connect is <a role="menuitem">Connect</a>. Require
            // role="menuitem" so we NEVER match the sidebar "More profiles for
            // you" Connect BUTTONS — they share the text "Connect", carry
            // role=null, and appear earlier in the DOM, so without this guard the
            // poll grabbed a sidebar person and clicking it opened no modal
            // (and risked inviting the wrong human).
            for (const el of candidates(document)) {
              if ((el.getAttribute('role') || '').toLowerCase() !== 'menuitem') continue;
              const txt = norm(el.textContent).toLowerCase();
              const al  = norm(el.getAttribute('aria-label')).toLowerCase();
              if (txt === 'connect' || /^invite .+ to connect$/.test(al)) return el;
            }
            return null;
          }, 2800, 200);
        }
      }

      if (!connect) {
        // Genuine Follow-only / restricted profile, or DOM drift. Distinct status
        // so the rep handles it manually rather than treating it as a retryable
        // error. Stash what we saw so a real miss is debuggable.
        out.status = 'no_connect';
        out.reason = 'No Connect option on this profile (Follow-only or restricted)';
        out.sawTopCard = candidates(scope).slice(0, 12).map(e => ({
          tag: e.tagName, role: e.getAttribute('role'),
          text: norm(e.textContent).slice(0, 24), aria: norm(e.getAttribute('aria-label')).slice(0, 40),
        }));
        window.__gowarmAutoSendLast = out;
        return out;
      }

      connect.click();

      // The invite either opens the "Add a note to your invitation?" modal
      // (buttons: "Send without a note" + "Add a note") or — for some accounts —
      // sends directly and flips the top card to "Pending". Poll for whichever,
      // up to ~6s. (A single fixed wait was searching before the modal rendered —
      // that was the "Send button not found" failure.)
      const phase = await poll(() => {
        if (challengePresent()) return { kind: 'challenge' };
        const bt = norm(document.body.innerText).toLowerCase();
        if (/reached the weekly invitation limit|weekly invitation limit|weekly limit/i.test(bt)) return { kind: 'limited' };
        if (findBtn([/^pending$/, /invitation sent/, /pending, click to withdraw/], scope)) return { kind: 'sent' };
        const sendNoNote = findBtn([/^send without a note$/]);
        const sendPlain  = findBtn([/^send( invitation)?$/, /^send now$/]);
        if (sendNoNote || sendPlain) return { kind: 'modal', sendNoNote, sendPlain };
        return null;
      }, 6000, 200);

      if (!phase) {
        out.status = 'error';
        out.reason = 'Invite modal/Send did not appear';
        out.sawButtons = candidates(document).slice(0, 16).map(e => ({
          tag: e.tagName, text: norm(e.textContent).slice(0, 28), aria: norm(e.getAttribute('aria-label')).slice(0, 40),
        }));
        window.__gowarmAutoSendLast = out; return out;
      }
      if (phase.kind === 'challenge') { out.status = 'challenge'; window.__gowarmAutoSendLast = out; return out; }
      if (phase.kind === 'limited')   { out.status = 'limited';   window.__gowarmAutoSendLast = out; return out; }
      if (phase.kind === 'sent')      { out.status = 'sent';      window.__gowarmAutoSendLast = out; return out; }

      // Modal present. Send WITHOUT a note: reliable one click, no free-account
      // note-quota limit, accepts at least as well. Any personalized message is
      // better delivered as a post-accept message step in the sequence.
      const sendBtn = phase.sendNoNote || phase.sendPlain;
      if (!sendBtn || sendBtn.disabled) {
        out.status = 'error';
        out.reason = 'Send button present but not clickable';
        window.__gowarmAutoSendLast = out; return out;
      }
      sendBtn.click();

      await wait(1000);
      if (challengePresent()) { out.status = 'challenge'; window.__gowarmAutoSendLast = out; return out; }

      out.status = 'sent';
      window.__gowarmAutoSendLast = out;
      return out;
    } catch (e) {
      out.status = 'error';
      out.reason = String((e && e.message) || e);
      window.__gowarmAutoSendLast = out;
      return out;
    }
  })();
}

// Open the prospect's profile in a BACKGROUND tab, inject the send fn, then
// close the tab. Unlike the read path (which we keep to already-open tabs), a
// send MUST navigate to the profile — there is no other way to click Connect.
// We keep it background + short-lived + jittered to stay low-and-slow.
async function actuateOneSend(linkedinUrl, note) {
  let tabId = null;
  let restoreTabId = null;
  try {
    // Remember the tab the rep is actually looking at, so we can hand focus back.
    try {
      const active = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
      if (active && active[0]) restoreTabId = active[0].id;
    } catch (_) {}

    const tab = await chrome.tabs.create({ url: linkedinUrl, active: false });
    tabId = tab.id;
    // Wait for load (bounded).
    await new Promise((resolve) => {
      function listener(id, info) {
        if (id === tabId && info.status === 'complete') {
          chrome.tabs.onUpdated.removeListener(listener);
          resolve();
        }
      }
      chrome.tabs.onUpdated.addListener(listener);
      setTimeout(() => { chrome.tabs.onUpdated.removeListener(listener); resolve(); }, 15000);
    });

    // Chrome throttles rendering in BACKGROUND tabs, and LinkedIn's top-card
    // action bar is React-hydrated well after 'complete' — so an unfocused tab
    // often never paints Connect. This was the real cause of the failures,
    // including the direct-Connect profile. Briefly focus the tab so it
    // hydrates, then hand focus straight back to the rep. The buttons persist in
    // the DOM once hydrated, so the clicker (injected next) operates fine while
    // the tab is backgrounded again — .click() doesn't require focus.
    // Focus the tab so LinkedIn hydrates AND stays un-throttled while the
    // clicker's render-poll runs. The previous version restored focus to the
    // rep's tab BEFORE injecting, so the 10s render poll ran in a re-backgrounded,
    // throttled tab — that's the "action bar did not render" failure. Keep focus
    // through the click and restore only in `finally`. Cost: the profile tab is
    // visible for the few seconds of the send.
    try { await chrome.tabs.update(tabId, { active: true }); } catch (_) {}
    // Also focus the WINDOW: activating the tab isn't enough if OS focus is on
    // another window (e.g. the worker DevTools). LinkedIn's "···" overflow menu
    // closes on document blur, so the menuitem click landed on an already-closed
    // menu ("modal did not appear"). Focusing the window keeps the menu open.
    try { if (tab.windowId != null) await chrome.windows.update(tab.windowId, { focused: true }); } catch (_) {}
    await sleep(600);

    const results = await chrome.scripting.executeScript({
      target: { tabId }, func: gowarmSendConnectionRequestInjected, args: [note || ''], world: 'MAIN',
    });
    return results?.[0]?.result || { status: 'error', reason: 'No result from injected send' };
  } catch (err) {
    return { status: 'error', reason: String((err && err.message) || err) };
  } finally {
    // Belt-and-suspenders: ensure focus is back on the rep's tab.
    if (restoreTabId != null && restoreTabId !== tabId) {
      try { await chrome.tabs.update(restoreTabId, { active: true }); } catch (_) {}
    }
    if (tabId != null) {
      setTimeout(() => { try { chrome.tabs.remove(tabId); } catch (_) {} }, 600);
    }
  }
}

// ── Voyager invitation send ──────────────────────────────────────────────────
//
// The connection invite is a same-origin authenticated POST, so it runs from any
// already-open linkedin.com tab — no profile tab, no DOM, no clicking. This is
// the path we moved to after the overflow-menu click proved un-automatable.
// Injected into an open LinkedIn tab (world: MAIN) so document.cookie carries the
// session and JSESSIONID doubles as the csrf-token, exactly like the reads.
//
// NOTE: queryId values rotate with LinkedIn deploys. If URN resolution starts
// failing (status 'error', reason URN_*), re-capture PROFILE_QUERY_ID from a live
// IdentityDashProfiles request. customMessage is omitted by default — note-invites
// are quota-limited on non-premium accounts; the personalized line belongs in a
// post-accept message step.
function gowarmSendInviteVoyagerInjected(publicId, customMessage, presetUrn, queryIdOverride) {
  return (async () => {
    const out = { status: 'error', reason: null, ts: Date.now() };
    const cm = document.cookie.match(/JSESSIONID=("?)([^";]+)\1/);
    const csrf = cm ? cm[2] : null;
    if (!csrf) { out.reason = 'NO_JSESSIONID'; return out; }
    const H = {
      'csrf-token': csrf,
      'accept': 'application/vnd.linkedin.normalized+json+2.1',
      'x-restli-protocol-version': '2.0.0',
      'x-li-lang': 'en_US',
    };

    // 1. Resolve the target's fsd_profile URN. Layered, most-durable first:
    //    (a) stored URN passed from the DB (prospects.member_urn) — best;
    //    (b) a URN captured this session by li_net_capture for this slug;
    //    (c) a live resolve, using the rotating queryId captured from LinkedIn's
    //        own traffic (window.__gowarmProfileQueryId) and only falling back to
    //        the hardcoded hash if none was observed.
    const PROFILE_QUERY_ID = 'voyagerIdentityDashProfiles.273a499c117721535e6da078bee17e9c'; // ROTATES — captured dynamically below when possible
    const isFsd = (u) => typeof u === 'string' && /^urn:li:fsd_profile:[A-Za-z0-9_-]+$/.test(u);
    let urn = null;
    if (isFsd(presetUrn)) { urn = presetUrn; out.urnSource = 'stored'; }
    if (!urn) {
      try {
        const key = String(publicId || '').toLowerCase();
        const hit = window.__gowarmProfileUrns && window.__gowarmProfileUrns[key];
        if (hit && isFsd(hit.urn)) { urn = hit.urn; out.urnSource = 'captured'; }
      } catch (_) {}
    }
    if (!urn) {
      // Precedence: SW-passed persisted hash (survives reloads, self-healing) →
      // one observed live in this page → hardcoded fallback.
      const valid = (q) => typeof q === 'string' && /^voyagerIdentityDashProfiles\./.test(q);
      const qid = valid(queryIdOverride) ? queryIdOverride
                : (valid(window.__gowarmProfileQueryId) ? window.__gowarmProfileQueryId : PROFILE_QUERY_ID);
      out.urnSource = (qid === PROFILE_QUERY_ID) ? 'resolved_static' : 'resolved_dynamic';
      try {
        const r = await fetch(
          'https://www.linkedin.com/voyager/api/graphql?includeWebMetadata=true&variables=(memberIdentity:' +
            encodeURIComponent(publicId) + ')&queryId=' + qid,
          { method: 'GET', credentials: 'include', headers: H }
        );
        if (r.status === 200) {
          const txt = await r.text();
          const m = txt.match(/urn:li:fsd_profile:[A-Za-z0-9_-]+/);
          if (m) urn = m[0];
          else out.reason = 'URN_NOT_IN_RESPONSE';
        } else {
          out.reason = 'URN_RESOLVE_HTTP_' + r.status;
        }
      } catch (e) { out.reason = 'URN_RESOLVE_ERR:' + ((e && e.message) || e); }
    }
    if (!urn) { return out; }   // out.reason already set
    out.urn = urn;

    // 2. POST the invitation. Send WITH the note; if LinkedIn rejects for a
    //    note/personalized-invite quota reason, retry once WITHOUT the note so
    //    the invite still goes out. A retry that ALSO fails on quota means a real
    //    total invitation limit → 'limited' (hard-abort upstream).
    const ENDPOINT = 'https://www.linkedin.com/voyager/api/voyagerRelationshipsDashMemberRelationships' +
      '?action=verifyQuotaAndCreateV2' +
      '&decorationId=com.linkedin.voyager.dash.deco.relationships.InvitationCreationResultWithInvitee-2';
    const POST_HEADERS = Object.assign({}, H, { 'content-type': 'application/json; charset=UTF-8' });
    async function postInvite(includeMessage) {
      const body = { invitee: { inviteeUnion: { memberProfile: urn } } };
      if (includeMessage && customMessage && String(customMessage).trim()) {
        body.customMessage = String(customMessage).trim().slice(0, 280);
      }
      const res = await fetch(ENDPOINT, { method: 'POST', credentials: 'include', headers: POST_HEADERS, body: JSON.stringify(body) });
      let txt = ''; try { txt = await res.text(); } catch (_) {}
      return { status: res.status, txt };
    }
    const isAlready = (t) => /CANT_RESEND_YET|ALREADY_INVITED|ALREADY_CONNECTED|already invited|duplicate/i.test(t);
    const isQuota   = (s, t) => s === 429 || /quota|invitation limit|reached the (weekly|monthly)|exceeded/i.test(t);
    try {
      const hasMsg = !!(customMessage && String(customMessage).trim());
      let r = await postInvite(hasMsg);
      out.httpStatus = r.status;
      if (isAlready(r.txt)) { out.status = 'already'; return out; }

      // Retry note-less if the WITH-note attempt looks blocked by the note/quota.
      if (hasMsg && (isQuota(r.status, r.txt) || (r.status >= 400 && /message|note|customMessage|personaliz/i.test(r.txt)))) {
        out.noteDropped = true;
        r = await postInvite(false);
        out.httpStatus = r.status;
        if (isAlready(r.txt)) { out.status = 'already'; return out; }
      }

      if (r.status === 200 || r.status === 201) { out.status = 'sent'; return out; }
      if (isQuota(r.status, r.txt)) { out.status = 'limited'; out.reason = 'quota/429'; return out; }
      out.status = 'error';
      out.reason = 'invite HTTP ' + r.status + ' ' + (r.txt || '').slice(0, 200);
      return out;
    } catch (e) {
      out.status = 'error'; out.reason = 'invite ERR:' + ((e && e.message) || e);
      return out;
    }
  })();
}

// Send via Voyager from an existing LinkedIn tab. No tab is opened or focused.
// presetUrn (optional) = prospects.member_urn from the claim; preferred over a
// live resolve inside the injected fn.
async function actuateOneSendVoyager(linkedinUrl, note, presetUrn) {
  const m = (linkedinUrl || '').match(/\/in\/([^/?#]+)/);
  if (!m) return { status: 'error', reason: 'No /in/ publicId in URL: ' + linkedinUrl };
  const publicId = decodeURIComponent(m[1]);
  // Self-healing queryId: persisted by content.js from observed traffic; survives
  // SW restarts and covers cached/SPA loads. Falls back inside the injected fn.
  const queryId = await new Promise(r =>
    chrome.storage.local.get(['gowarm_profile_queryid'], o => r((o && o.gowarm_profile_queryid) || '')));
  const tabs = await chrome.tabs.query({ url: 'https://www.linkedin.com/*' });
  if (!tabs || !tabs.length) return { status: 'error', reason: 'No open LinkedIn tab' };
  for (const t of tabs) {
    try {
      const results = await chrome.scripting.executeScript({
        // customMessage = the sequence step's note. Sent when quota allows; the
        // injected fn falls back to note-less if LinkedIn rejects the note.
        // presetUrn = stored fsd_profile URN (preferred over live resolve).
        // queryId = persisted self-healing hash for the live-resolve fallback.
        target: { tabId: t.id }, func: gowarmSendInviteVoyagerInjected, args: [publicId, note || '', presetUrn || '', queryId || ''], world: 'MAIN',
      });
      const r = results?.[0]?.result;
      if (r && r.status) return r;
    } catch (_) { /* tab mid-nav — try the next */ }
  }
  return { status: 'error', reason: 'No LinkedIn tab could run the invite' };
}

// The auto-send tick. Bails fast unless we're on LinkedIn, enabled, and in-hours.
// Kickoff / safety-net (fires on the periodic AUTOSEND_ALARM and on
// startup/install). If a send chain is already in flight (step alarm pending),
// do nothing — the chain paces itself. Otherwise take one step, which will
// schedule the next.
let _autoSendRunning = false;   // retained name; guards the kickoff
async function runAutoSendTick() {
  if (_autoSendRunning) return;
  _autoSendRunning = true;
  try {
    const pending = await getAlarm(AUTOSEND_STEP_ALARM);
    if (pending) return;                 // chain already running
    await autoSendStep({});
  } finally {
    _autoSendRunning = false;
  }
}

// One send per wake. All the old gates are preserved; the difference is the
// inter-send wait is an alarm, not an in-memory sleep, so the worker can die
// between sends without losing the batch.
let _autoSendStepRunning = false;
async function autoSendStep({ force = false } = {}) {
  if (_autoSendStepRunning) return;      // no overlap within a worker lifetime
  _autoSendStepRunning = true;
  try {
    if (!(await hasOpenLinkedInTab())) { await clearStepChain(); return; }   // honor "no synthetic sessions"
    const token = await getToken();
    if (!token) { await clearStepChain(); return; }

    // Cheap local pre-gate from the last cfg we learned (skipped under force).
    const NEG_CFG_TTL_MS = 30 * 60 * 1000;
    const cached = await new Promise(r => chrome.storage.local.get(['gowarm_autosend_cfg'], o => r(o.gowarm_autosend_cfg || null)));
    const cfgFresh = cached && (Date.now() - (cached.ts || 0) < NEG_CFG_TTL_MS);
    if (!force && cfgFresh && cached.enabled === false) { await clearStepChain(); return; }
    if (!force && cached && cached.window && !withinHumanHours(cached.window)) { await clearStepChain(); return; }

    // Jitter pacing: if we sent recently, reschedule instead of sending now.
    if (!force) {
      const st = await getAutoSendState();
      if (st && st.next_send_at && Date.now() < st.next_send_at) {
        await scheduleNextStep(st.next_send_at - Date.now());
        return;
      }
    }

    const viewer = await getViewerFromOpenTab();
    if (!viewer) { await scheduleNextStep(60000); return; }   // tab mid-nav — retry shortly

    // Claim exactly one row.
    let claim;
    try {
      claim = await apiFetch('/linkedin-autosend/claim', {
        method: 'POST',
        body: JSON.stringify({ viewer, limit: 1 }),
      });
    } catch (e) {
      console.warn('[GoWarm] autosend claim failed:', e.message);
      await scheduleNextStep(60000);     // transient (auth/network/seat) — retry next minute
      return;
    }

    // Cache enablement + window/jitter for the next pre-gate.
    await new Promise(r => chrome.storage.local.set({ gowarm_autosend_cfg: {
      enabled: !!claim.enabled,
      window:  claim.window || null,
      jitter:  claim.jitter_seconds || null,
      ts: Date.now(),
    }}, r));

    if (!claim.enabled) { await clearStepChain(); return; }
    if (claim.window && !withinHumanHours(claim.window)) { await clearStepChain(); return; }   // live window always honored

    const items = Array.isArray(claim.items) ? claim.items : [];
    if (!items.length) { await clearStepChain(); return; }   // queue drained → end chain

    const it = items[0];
    if (!it.prospect || !it.prospect.linkedinUrl) {
      await reportAutoSendFailure(viewer, it.logId, 'No LinkedIn URL');
    } else {
      // v1.20: pass the stored fsd_profile URN so the injected send prefers it
      // over a live (rotating-queryId) resolve.
      const result = await actuateOneSendVoyager(it.prospect.linkedinUrl, it.note, it.prospect.memberUrn);
      console.log('[GoWarm] autosend result:', it.logId, it.prospect.linkedinUrl, result);

      if (result.status === 'sent' || result.status === 'already') {
        try {
          await apiFetch('/linkedin-autosend/confirm', {
            method: 'POST',
            body: JSON.stringify({ viewer, logId: it.logId, timeText: 'Just now' }),
          });
        } catch (e) { console.warn('[GoWarm] autosend confirm failed:', e.message); }
      } else if (result.status === 'challenge' || result.status === 'limited') {
        // HARD STOP the chain the moment LinkedIn pushes back. The in-flight row
        // is failed+paused; there are no other leases (we claim one at a time).
        console.warn(`[GoWarm] autosend ABORT — ${result.status}; ending chain`);
        await reportAutoSendFailure(viewer, it.logId, `Aborted: ${result.status}`);
        await clearStepChain();
        return;
      } else {
        // not_found / error → fail just this row, keep the chain going.
        await reportAutoSendFailure(viewer, it.logId, result.reason || result.status);
      }
    }

    // Pace the next send and continue the chain. The next claim ends the chain
    // when the queue is empty.
    const gap = autoSendJitterMs(claim.jitter_seconds);
    await setAutoSendState({ next_send_at: Date.now() + gap });
    await scheduleNextStep(gap);
  } finally {
    _autoSendStepRunning = false;
  }
}

async function reportAutoSendFailure(viewer, logId, reason) {
  try {
    await apiFetch('/linkedin-autosend/report-failure', {
      method: 'POST',
      body: JSON.stringify({ viewer, logId, reason: String(reason || '').slice(0, 500) }),
    });
  } catch (e) { console.warn('[GoWarm] autosend report-failure failed:', e.message); }
}

// ── (v1.19) Weekly opportunistic harvest ─────────────────────────────────────
//
// The extension half of the weekly refresh. Like auto-send, it NEVER opens a
// LinkedIn tab and NEVER polls: it only runs the existing read+reconcile if the
// rep ALREADY has a My Network page open, and at most once per WEEKLY_HARVEST_
// MIN_GAP_MS. The on-demand "Check & update" buttons are unaffected; the
// server-side nudge (LinkedInRefreshNudge) covers reps who don't happen to have
// My Network open.
async function runWeeklyHarvest() {
  const last = await new Promise(r => chrome.storage.local.get(['gowarm_weekly_harvest_ts'], o => r(o.gowarm_weekly_harvest_ts || 0)));
  if (Date.now() - last < WEEKLY_HARVEST_MIN_GAP_MS) return;   // at most weekly

  const token = await getToken();
  if (!token) return;

  // Only if a My Network / connections / sent page is already open. We do NOT
  // open one.
  const tabs = await chrome.tabs.query({ url: 'https://www.linkedin.com/mynetwork/*' });
  if (!tabs || !tabs.length) return;

  try {
    const merged = await readConnectionActivityAcrossTabs();   // reuses existing reader; won't open a tab (one is open)
    const viewer = merged && merged.viewer;
    if (!viewer || !viewer.publicIdentifier) return;

    // Push whichever group we actually found, silently. Same endpoint as the
    // popup buttons — fully idempotent server-side.
    for (const kind of ['sent', 'accepted']) {
      const group = merged[kind];
      if (!group || !Array.isArray(group.people) || !group.people.length) continue;
      try {
        await apiFetch('/linkedin-connections/reconcile', {
          method: 'POST',
          body: JSON.stringify({
            kind,
            viewer: { publicIdentifier: viewer.publicIdentifier, name: viewer.name || null, memberUrn: viewer.memberUrn || null },
            people: group.people.map(p => ({ publicIdentifier: p.publicIdentifier || null, url: p.url || null, name: p.name || null, timeText: p.timeText || null })),
          }),
        });
      } catch (e) { console.warn(`[GoWarm] weekly harvest ${kind} reconcile failed:`, e.message); }
    }
    await new Promise(r => chrome.storage.local.set({ gowarm_weekly_harvest_ts: Date.now() }, r));
  } catch (e) {
    console.warn('[GoWarm] weekly harvest failed:', e.message);
  }
}

// ── Message listener ──────────────────────────────────────────────────────────

// Scrape connection activity across all open LinkedIn tabs and merge.
// Shared by READ_CONNECTION_ACTIVITY (display-only) and
// SYNC_CONNECTION_ACTIVITY (display + push to backend). Throws on hard
// failure; returns the merged object otherwise. Cleans up any tab it had
// to open itself.
async function readConnectionActivityAcrossTabs() {
  let createdTabId = null;
  try {
    let tabs = await chrome.tabs.query({ url: 'https://www.linkedin.com/*' });

    // No LinkedIn open at all — open one so we can at least read identity,
    // and flag that the user needs to browse My Network to get activity.
    if (!tabs || !tabs.length) {
      const created = await getOrCreateLinkedInTab();
      createdTabId = created.created ? created.tabId : null;
      tabs = await chrome.tabs.query({ url: 'https://www.linkedin.com/*' });
    }

    const perTab = [];
    for (const t of tabs) {
      try {
        const results = await chrome.scripting.executeScript({
          target: { tabId: t.id },
          func: gowarmReadConnectionActivity,
          world: 'MAIN',     // must match li_net_capture.js's world to see the capture array
        });
        const r = results?.[0]?.result;
        if (r) perTab.push(r);
      } catch (_) { /* tab may be mid-navigation; skip it */ }
    }

    if (!perTab.length) throw new Error('NO_RESULT');

    // Merge: viewer = first identified; sent/accepted = best across tabs
    // (most people, then most recent); needsBrowse only if nothing anywhere.
    const merged = {
      ok: true, ts: Date.now(),
      viewer: null, sent: null, accepted: null, captures: [], needsBrowse: true, error: null,
    };
    const better = (a, b) => {
      if (!b) return a; if (!a) return b;
      if ((b.peopleCount || 0) !== (a.peopleCount || 0)) return (b.peopleCount > a.peopleCount) ? b : a;
      return ((b.ts || 0) > (a.ts || 0)) ? b : a;
    };
    for (const r of perTab) {
      if (!merged.viewer && r.viewer && (r.viewer.name || r.viewer.publicIdentifier)) merged.viewer = r.viewer;
      if (r.sent)     merged.sent     = better(merged.sent, r.sent);
      if (r.accepted) merged.accepted = better(merged.accepted, r.accepted);
      if (Array.isArray(r.captures)) merged.captures = merged.captures.concat(r.captures);
    }
    merged.needsBrowse = !merged.sent && !merged.accepted;
    if (merged.needsBrowse) {
      merged.error = merged.captures.length
        ? 'Recorded requests but none parsed to people yet — see captures list.'
        : 'NO_CAPTURE';
    }
    if (!merged.viewer) merged.viewer = perTab[0].viewer || null;

    return merged;
  } finally {
    if (createdTabId != null) {
      setTimeout(() => { try { chrome.tabs.remove(createdTabId); } catch (_) {} }, 600);
    }
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {

  if (message.type === 'LOOKUP_PROSPECT') {
    apiFetch(`/prospects/by-linkedin-url?url=${encodeURIComponent(message.linkedinUrl)}`)
      .then(data => sendResponse({ ok: true,  prospect: data.prospect }))
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (message.type === 'ADD_PROSPECT') {
    apiFetch('/prospects', {
      method: 'POST',
      body: JSON.stringify({
        firstName:          message.firstName,
        lastName:           message.lastName,
        linkedinHeadline:   message.linkedinHeadline,
        companyName:        message.companyName,
        companyLinkedInUrl: message.companyLinkedInUrl,
        email:              message.email,
        linkedinUrl:        message.linkedinUrl,
        location:           message.location,
        source:             message.source || 'linkedin_extension',
        // v1.20: durable fsd_profile URN (owner-bound at capture). Backend
        // stores on prospects.member_urn and dedups URN-first.
        memberUrn:          message.memberUrn || null,
        stage:              'target',
        // NEW (v1.8): optional campaign + sequence. The defaults are
        // set in the popup's Settings view and stored in chrome.storage.
        // The content script reads them per-org and may override per
        // prospect via the inline "change" link on the Not-in-CRM form.
        campaignId:         message.campaignId || null,
        sequenceId:         message.sequenceId || null,
      }),
    })
      .then(data => sendResponse({
        ok:              true,
        prospect:        data.prospect,
        enrollment:      data.enrollment      || null,
        enrollmentError: data.enrollmentError || null,
      }))
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  // ── NEW (v1.8): lookup lists for the popup's Push-defaults settings
  // and the in-page form's inline override.
  //
  // The popup uses this on Settings open to populate the two dropdowns;
  // content.js uses it lazily on first "change" click (and caches the
  // result for the lifetime of that LinkedIn page). Both calls share one
  // backend round-trip via Promise.all.
  //
  // Only ACTIVE campaigns and ACTIVE sequences are returned — picking a
  // paused campaign or archived sequence is almost always an accident.
  // Reps who really need them can change status in the web app first.
  if (message.type === 'LIST_CAMPAIGNS_AND_SEQUENCES') {
    Promise.all([
      apiFetch('/prospecting-campaigns?status=active').catch(err => {
        console.warn('LIST_CAMPAIGNS_AND_SEQUENCES: campaigns fetch failed:', err.message);
        return { campaigns: [] };
      }),
      apiFetch('/sequences').catch(err => {
        console.warn('LIST_CAMPAIGNS_AND_SEQUENCES: sequences fetch failed:', err.message);
        return { sequences: [] };
      }),
    ])
      .then(([campData, seqData]) => {
        // Slim each row to what dropdowns actually need. Keeping the
        // wire-format small matters because this fires on every popup
        // open (cheap, but worth not bloating).
        const campaigns = (campData.campaigns || []).map(c => ({
          id:                  c.id,
          name:                c.name,
          status:              c.status,
          default_sequence_id: c.default_sequence_id || null,
        }));
        // GET /sequences excludes archived but includes paused/draft.
        // POST /api/sequences/enroll requires status='active' so filter
        // here to match the backend's acceptance criteria.
        const sequences = (seqData.sequences || [])
          .filter(s => s.status === 'active')
          .map(s => ({
            id:          s.id,
            name:        s.name,
            step_count:  s.step_count || 0,
          }));
        sendResponse({ ok: true, campaigns, sequences });
      })
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (message.type === 'LOG_EVENT') {
    apiFetch(`/prospects/${message.prospectId}/linkedin-event`, {
      method: 'POST',
      body: JSON.stringify({
        event:       message.event,
        note:        message.note,
        sentiment:   message.sentiment,
        occurred_at: message.occurredAt,
      }),
    })
      .then(data => sendResponse({ ok: true,  data }))
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  // Upserts captured LinkedIn profile data (about, experience, education,
  // posts, etc.) to the canonical linkedin_profiles table. Optionally links
  // the profile to a prospect or contact in the same call.
  if (message.type === 'UPSERT_LINKEDIN_PROFILE') {
    apiFetch('/linkedin-profiles/upsert', {
      method: 'POST',
      body: JSON.stringify({
        linkedin_url: message.linkedinUrl,
        fields:       message.fields || {},
        // v1.22: per-item merge directives (rep field-locks / removals).
        // Optional — absent for a plain capture, in which case the server
        // merges with no locks/suppressions (union + richer-wins only).
        edits:        message.edits || undefined,
        source:       'extension',
        link_to:      message.linkTo || null,
        // v1.20: durable fsd_profile URN, COALESCE-persisted onto the linked
        // prospect's member_urn (never overwrites an existing good one).
        member_urn:   message.memberUrn || null,
      }),
    })
      .then(data => sendResponse({ ok: true, profile_id: data.profile_id, profile: data.profile, linked: data.linked, account_id: data.account_id }))
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  // ── NEW in v1.5 ──────────────────────────────────────────────────────────
  // Fetch the existing captured profile (if any) from the linkedin_profiles
  // table. Used by content.js to hydrate the capture rows on profile
  // arrival, so reps can see what's already on file BEFORE scrolling
  // triggers a fresh scrape — and so the live scrape can be diffed
  // against the stored values.
  //
  // Returns { ok: true, profile: <row>|null }.
  if (message.type === 'GET_ACTIVITIES') {
    apiFetch(`/prospects/${message.prospectId}/activities`)
      .then(data => sendResponse({ ok: true, activities: data.activities || [] }))
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (message.type === 'RUN_SEGMENTATION') {
    apiFetch(`/skills/segmentation-individual/run`, {
      method: 'POST',
      body: JSON.stringify({ prospectId: message.prospectId }),
    })
      .then(data => sendResponse({ ok: true, result: data }))
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (message.type === 'GET_LINKEDIN_PROFILE') {
    apiFetch(`/linkedin-profiles/by-url?url=${encodeURIComponent(message.linkedinUrl)}`)
      .then(data => sendResponse({ ok: true, profile: data.profile || null }))
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  // Triggers Coresignal enrichment for an existing prospect.
  // Use sparingly — each call costs Coresignal credits.
  if (message.type === 'ENRICH_PROSPECT_FROM_CORESIGNAL') {
    apiFetch(`/prospects/${message.prospectId}/enrich-from-coresignal`, {
      method: 'POST',
    })
      .then(data => sendResponse({ ok: true, data }))
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  // ── NEW (v1.8): assign an existing prospect to a campaign + sequence.
  // Powers the "smart-suggest" prompt on the in-page panel for prospects
  // that are already in CRM but aren't in the rep's default target. Same
  // partial-failure semantics as ADD_PROSPECT (campaign update may
  // succeed while enrollment fails — both surfaced separately).
  if (message.type === 'PUSH_PROSPECT_TO_TARGET') {
    apiFetch(`/prospects/${message.prospectId}/push-to-target`, {
      method: 'POST',
      body: JSON.stringify({
        campaignId: message.campaignId || null,
        sequenceId: message.sequenceId || null,
      }),
    })
      .then(data => sendResponse({
        ok:              true,
        prospect:        data.prospect,
        enrollment:      data.enrollment      || null,
        enrollmentError: data.enrollmentError || null,
      }))
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  // ── NEW in v1.5 ──────────────────────────────────────────────────────────
  // Identity & config — drives the popup's "Connected as <email> · <org>"
  // line and the in-page panel header subline.
  //
  // GET_IDENTITY honours a cached value (TTL 10min); pass { force: true }
  // to bypass the cache (popup does this right after harvesting a new
  // token, so we don't briefly show the previous user's identity).
  if (message.type === 'GET_IDENTITY') {
    fetchIdentity({ force: !!message.force })
      .then(({ identity, cachedAt }) => sendResponse({ ok: true, identity, cachedAt }))
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (message.type === 'GET_CONFIG') {
    sendResponse({ ok: true, config: classifyApiHost() });
    return false;   // synchronous response
  }

  // Returns the cached version-check result for the popup to render its
  // update banner. If `refresh` is true the handler also kicks off a
  // background check — but with one important twist: if there's NO
  // cached result yet (the very first time the popup opens, or after
  // storage was cleared), it awaits the fresh check before responding.
  // Otherwise the popup would render with no banner on a fresh install
  // even when an update is available, and the user would have to open
  // the popup twice to see it.
  //
  // Once cache exists, we serve it immediately and refresh asynchronously
  // — fast popup open, eventually-consistent cache.
  if (message.type === 'GET_UPDATE_STATUS') {
    chrome.storage.local.get(['gowarm_update_check'], async (r) => {
      const cached = r.gowarm_update_check || null;
      if (cached) {
        sendResponse({ ok: true, status: cached });
        if (message.refresh) checkForUpdate(); // fire-and-forget
        return;
      }
      // No cache. If the caller asked for a refresh, do it synchronously
      // so the popup gets a real answer on this open. Bounded by the
      // 5-second timeout inside checkForUpdate(), so we won't hang.
      if (message.refresh) {
        await checkForUpdate();
        const r2 = await new Promise(resolve =>
          chrome.storage.local.get(['gowarm_update_check'], resolve)
        );
        sendResponse({ ok: true, status: r2.gowarm_update_check || null });
      } else {
        sendResponse({ ok: true, status: null });
      }
    });
    return true;
  }

  // Triggered by the "Reload extension" button in the popup's update
  // banner. chrome.runtime.reload() restarts the extension's service
  // worker, content scripts, and popup — re-reading the unpacked
  // folder from disk in the process. This is how the user picks up
  // a new version they've copied into the existing folder without
  // having to go to chrome://extensions and click reload manually.
  //
  // We respond before reloading so the popup gets an ack, though in
  // practice the popup is torn down by the reload anyway.
  if (message.type === 'RELOAD_EXTENSION') {
    sendResponse({ ok: true });
    // Defer the reload by a tick so the response flushes first.
    setTimeout(() => chrome.runtime.reload(), 50);
    return false;
  }

  // ── (v1.10) Read connection activity by harvesting LinkedIn's OWN captured
  // requests. Runs the harvester in the MAIN world (so it can read the
  // window.__gowarmConnCapture array that li_net_capture.js populates) across
  // ALL open LinkedIn tabs, then merges — because the user may have browsed
  // My Network in one tab and have the profile open in another.
  if (message.type === 'READ_CONNECTION_ACTIVITY') {
    (async () => {
      try {
        const merged = await readConnectionActivityAcrossTabs();
        sendResponse({ ok: true, data: merged });
      } catch (err) {
        sendResponse({ ok: false, error: err.message });
      }
    })();
    return true;
  }

  // ── (v1.17) Scrape + PUSH connection activity to GoWarmCRM ──────────────────
  //
  // message: { type: 'SYNC_CONNECTION_ACTIVITY', kind: 'sent' | 'accepted' }
  //
  // Runs the same scrape as READ_CONNECTION_ACTIVITY, then POSTs the requested
  // group to POST /api/linkedin-connections/reconcile, which:
  //   • binds the logged-in LinkedIn member (viewer) to the GoWarm user —
  //     rejecting with SEAT_CONFLICT if the LinkedIn account belongs to a
  //     different teammate, so reps can only update their own prospects;
  //   • slug-matches people to prospects OWNED by this user;
  //   • records connection_accepted / connection_request_sent idempotently
  //     (re-clicking is always safe — already-recorded rows are no-ops).
  //
  // Response: { ok, kind, result: <reconcile response>, data: <merged scrape> }
  // On failure `data` is still included when the scrape itself succeeded, so
  // the popup can render what was found alongside the error.
  if (message.type === 'SYNC_CONNECTION_ACTIVITY') {
    (async () => {
      let merged = null;
      try {
        merged = await readConnectionActivityAcrossTabs();
        const kind  = message.kind === 'sent' ? 'sent' : 'accepted';
        const group = merged[kind];

        if (!group || !Array.isArray(group.people) || group.people.length === 0) {
          sendResponse({ ok: false, error: 'NOT_ON_PAGE', kind, data: merged });
          return;
        }

        const viewer = merged.viewer || {};
        if (!viewer.publicIdentifier) {
          sendResponse({ ok: false, error: 'SEAT_UNKNOWN', kind, data: merged });
          return;
        }

        const payload = {
          kind,
          viewer: {
            publicIdentifier: viewer.publicIdentifier,
            name:             viewer.name      || null,
            memberUrn:        viewer.memberUrn || null,
          },
          // Slim to what the backend needs — keep the wire format small.
          people: group.people.map(p => ({
            publicIdentifier: p.publicIdentifier || null,
            url:              p.url              || null,
            name:             p.name             || null,
            timeText:         p.timeText         || null,
          })),
        };

        const result = await apiFetch('/linkedin-connections/reconcile', {
          method: 'POST',
          body: JSON.stringify(payload),
        });

        sendResponse({ ok: true, kind, result, data: merged });
      } catch (err) {
        // apiFetch surfaces the backend's error.message (e.g. the friendly
        // SEAT_CONFLICT text) — pass it through verbatim.
        sendResponse({ ok: false, error: err.message, kind: message.kind, data: merged });
      }
    })();
    return true;
  }

  // Manual trigger — clears the cached pre-gate (so a stale disabled flag can't
  // block it) and sends one immediately (force bypasses the cached gate and the
  // jitter pacing; the live claim's enabled/window still apply). Continues the
  // chain on its own thereafter. Wire to a popup button, or call from the
  // service-worker console for testing.
  if (message.type === 'RUN_AUTOSEND_NOW') {
    chrome.storage.local.remove('gowarm_autosend_cfg', () => {
      autoSendStep({ force: true })
        .then(() => sendResponse({ ok: true }))
        .catch(e => sendResponse({ ok: false, error: (e && e.message) || String(e) }));
    });
    return true;
  }

  // Forwarded automatically by auth_bridge.js when GoWarmCRM is open
  if (message.type === 'SAVE_TOKEN') {
    saveToken(message.token).then(() => sendResponse({ ok: true }));
    return true;
  }

  if (message.type === 'GET_TOKEN') {
    getToken().then(token => sendResponse({ token }));
    return true;
  }

  if (message.type === 'CLEAR_TOKEN') {
    clearToken().then(() => sendResponse({ ok: true }));
    return true;
  }

  // Popup requests an immediate harvest attempt
  if (message.type === 'TRY_HARVEST') {
    harvestTokenFromOpenTab()
      .then(token => sendResponse({ ok: !!token, token }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }
});
