// background.js — GoWarmCRM LinkedIn Extension v1.17
//
// New in v1.17:
//   • SYNC_CONNECTION_ACTIVITY — scrapes the logged-in LinkedIn member's
//     sent-pending invitations or recently-added connections (same scrape
//     as READ_CONNECTION_ACTIVITY) and pushes them to
//     POST /api/linkedin-connections/reconcile. The backend binds the
//     LinkedIn seat to the GoWarm user, slug-matches people to prospects
//     OWNED by that user, and records connection_request_sent /
//     connection_accepted idempotently. Drives the popup's split
//     "Check & update sent" / "Check & update accepted" buttons.
//
// Auto-auth: token is harvested automatically from app.gowarmcrm.com
// by auth_bridge.js — no manual paste needed.
//
// New in v1.5:
//   • GET_IDENTITY — calls /api/auth/verify, caches { email, org_name,
//     org_id, org_slug } in chrome.storage.local. Used by popup +
//     in-page panel to show "Saving as <email> · <org_name>" so reps
//     can tell at a glance which workspace their captures land in.
//
//   • GET_LINKEDIN_PROFILE — calls /api/linkedin-profiles/by-url to
//     fetch the existing captured profile (if any). Drives the delta-
//     refresh UX in content.js: rows are pre-populated with what's
//     already in DB, and live scrapes are diffed against that.
//
//   • GET_CONFIG — exposes API_BASE so the popup can show the user
//     which backend they're talking to (prod vs staging vs custom).
//
//   • Identity is invalidated whenever the token changes or is
//     cleared, so switching CRM accounts in another tab is reflected
//     correctly.

const API_BASE = 'https://api.gowarmcrm.com/api';

// Identity cache TTL — re-fetch from /verify if the cached identity is
// older than this. Short enough that a stale email/org name never
// lingers; long enough that we don't hammer the endpoint on every
// LinkedIn profile visit. The token-change path also invalidates.
const IDENTITY_TTL_MS = 10 * 60 * 1000;   // 10 minutes

// ── Token management ─────────────────────────────────────────────────────────

async function getToken() {
  return new Promise(resolve => {
    chrome.storage.local.get(['gowarm_token'], result => {
      resolve(result.gowarm_token || null);
    });
  });
}

async function saveToken(token) {
  // Compare against existing — if it changed, drop cached identity so
  // the next GET_IDENTITY call refetches under the new token.
  return new Promise(resolve => {
    chrome.storage.local.get(['gowarm_token'], (result) => {
      const previous = result.gowarm_token || null;
      const changed  = previous !== token;
      const writes   = { gowarm_token: token };
      if (changed) {
        // Wipe identity so we don't keep showing the old user/org.
        writes.gowarm_identity      = null;
        writes.gowarm_identity_ts   = null;
      }
      chrome.storage.local.set(writes, resolve);
    });
  });
}

async function clearToken() {
  return new Promise(resolve => {
    chrome.storage.local.remove(
      ['gowarm_token', 'gowarm_identity', 'gowarm_identity_ts'],
      resolve
    );
  });
}

// ── Identity cache ────────────────────────────────────────────────────────────

async function getCachedIdentity() {
  return new Promise(resolve => {
    chrome.storage.local.get(['gowarm_identity', 'gowarm_identity_ts'], (r) => {
      resolve({
        identity:  r.gowarm_identity   || null,
        cachedAt:  r.gowarm_identity_ts || 0,
      });
    });
  });
}

async function saveIdentity(identity) {
  return new Promise(resolve => {
    chrome.storage.local.set({
      gowarm_identity:    identity,
      gowarm_identity_ts: Date.now(),
    }, resolve);
  });
}

// ── Harvest token from an open GoWarmCRM tab ─────────────────────────────────
// Falls back to scripting API if auth_bridge.js hasn't fired yet,
// or if the token was written before the extension was installed.
async function harvestTokenFromOpenTab() {
  return new Promise(resolve => {
    chrome.tabs.query({ url: 'https://app.gowarmcrm.com/*' }, async (tabs) => {
      if (!tabs || tabs.length === 0) {
        resolve(null);
        return;
      }
      try {
        const results = await chrome.scripting.executeScript({
          target: { tabId: tabs[0].id },
          func: () => {
            return (
              localStorage.getItem('token') ||
              localStorage.getItem('authToken') ||
              localStorage.getItem('gowarm_token') ||
              null
            );
          },
        });
        const token = results?.[0]?.result || null;
        if (token) await saveToken(token);
        resolve(token);
      } catch (err) {
        resolve(null);
      }
    });
  });
}

// ── Authenticated API fetch with auto-refresh ─────────────────────────────────

async function apiFetch(path, options = {}, retried = false) {
  let token = await getToken();

  // No stored token — try to grab it from open GoWarmCRM tab first
  if (!token) {
    token = await harvestTokenFromOpenTab();
  }

  if (!token) throw new Error('NOT_AUTHENTICATED');

  const res = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
      'X-GoWarm-Extension-Key': 'gowarm-ext-2024-xK9mP3qR',
      ...(options.headers || {}),
    },
  });

  // 401 = token expired — harvest fresh token and retry once
  if (res.status === 401 && !retried) {
    await clearToken();
    const freshToken = await harvestTokenFromOpenTab();
    if (freshToken) return apiFetch(path, options, true);
    throw new Error('NOT_AUTHENTICATED');
  }

  const data = await res.json();
  if (!res.ok) throw new Error(data?.error?.message || `HTTP ${res.status}`);
  return data;
}

// ── Identity fetch ────────────────────────────────────────────────────────────
//
// Hits /auth/verify (which already returns user + org_id + org_name + org_slug
// after the v1.5 backend change). Cached for IDENTITY_TTL_MS. Pass
// { force: true } to bypass the cache, e.g. immediately after the
// popup harvests a new token.
//
// Returns { identity, cachedAt } — cachedAt is the unix-ms timestamp
// of the last successful /verify response (read from storage on cache
// hit, set to Date.now() on cache miss). The popup's settings view
// reads this to show "Last refreshed 2m ago" so reps know whether
// the displayed account is fresh or stale.
async function fetchIdentity({ force = false } = {}) {
  if (!force) {
    const { identity, cachedAt } = await getCachedIdentity();
    if (identity && Date.now() - cachedAt < IDENTITY_TTL_MS) {
      return { identity, cachedAt };
    }
  }

  // /auth/verify lives at /api/auth/verify (same /api prefix as everything
  // else the extension talks to).
  const data = await apiFetch('/auth/verify');
  const u = data?.user || {};

  const identity = {
    user_id:     u.id          ?? null,
    email:       u.email       ?? null,
    first_name:  u.firstName   ?? null,
    last_name:   u.lastName    ?? null,
    org_id:      u.org_id      ?? null,
    org_name:    u.org_name    ?? null,
    org_slug:    u.org_slug    ?? null,
    org_role:    u.org_role    ?? null,
  };
  await saveIdentity(identity);
  return { identity, cachedAt: Date.now() };
}

// ── API host classification ──────────────────────────────────────────────────
//
// The popup uses this to decide whether to show a green "production"
// pill or an amber "non-production" warning. A hostname containing
// 'staging', 'dev', 'localhost', or a Railway preview URL is treated
// as non-prod. Pure prod is api.gowarmcrm.com.
function classifyApiHost() {
  let host = '';
  try { host = new URL(API_BASE).host; } catch (_) { host = ''; }

  const isProd =
    host === 'api.gowarmcrm.com';

  return {
    api_base: API_BASE,
    host,
    env:      isProd ? 'production' : 'non-production',
    is_prod:  isProd,
  };
}

// ── Version check ────────────────────────────────────────────────────────────
//
// Polls the backend's /extension/version endpoint to find out whether a
// newer build is available. We don't auto-update — Chrome won't allow that
// for unpacked extensions — but we cache the result so the popup can show
// a banner directing the user to the install page.
//
// Design choices worth knowing:
//   • Unauthenticated: version info isn't sensitive, and an unauth endpoint
//     means the check still works when the user is logged out.
//   • Silent on failure: if the endpoint is unreachable or returns junk,
//     we leave the cached result alone and the popup just doesn't show
//     a banner. The extension MUST keep working when the version service
//     is down — this is a nice-to-have, not load-bearing.
//   • Cached in chrome.storage.local under gowarm_update_check so the popup
//     can read it synchronously (no network call on popup open).
//   • Re-checked on service-worker startup and every 6 hours via alarms.

const VERSION_ENDPOINT       = '/extension/version';
const UPDATE_CHECK_ALARM     = 'gowarm_version_check';
const UPDATE_CHECK_PERIOD_MIN = 6 * 60; // 6 hours

// Compare two dotted version strings ("1.7.3" vs "1.7.10"). Returns
// negative if a < b, 0 if equal, positive if a > b. Pads with zeros so
// "1.7" compares correctly against "1.7.0". Non-numeric segments
// (pre-release tags etc.) are treated as 0 — good enough for our use.
function compareVersions(a, b) {
  const pa = String(a || '').split('.').map(n => parseInt(n, 10) || 0);
  const pb = String(b || '').split('.').map(n => parseInt(n, 10) || 0);
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const da = pa[i] || 0;
    const db = pb[i] || 0;
    if (da !== db) return da - db;
  }
  return 0;
}

async function checkForUpdate() {
  const current = chrome.runtime.getManifest().version;
  try {
    // Unauthenticated, short timeout. AbortController gives us a hard
    // ceiling so a hung backend doesn't keep the service worker alive.
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 5000);
    const res = await fetch(`${API_BASE}${VERSION_ENDPOINT}`, {
      method: 'GET',
      signal: ctrl.signal,
    });
    clearTimeout(timer);
    if (!res.ok) return;
    const data = await res.json();
    const latest = data?.latest;
    if (!latest || typeof latest !== 'string') return;

    const status = {
      current,
      latest,
      update_available: compareVersions(current, latest) < 0,
      download_url:     data?.download_url || null,
      min_supported:    data?.min_supported || null,
      checked_at:       Date.now(),
    };
    await new Promise(resolve =>
      chrome.storage.local.set({ gowarm_update_check: status }, resolve)
    );
  } catch (_) {
    // Silent — keep whatever the previous cached value was. The popup
    // gracefully renders "no banner" when nothing is cached or when
    // update_available is false.
  }
}

// Run once on service-worker startup, then on a recurring alarm.
chrome.runtime.onStartup.addListener(() => { checkForUpdate(); });
chrome.runtime.onInstalled.addListener(() => {
  checkForUpdate();
  chrome.alarms.create(UPDATE_CHECK_ALARM, { periodInMinutes: UPDATE_CHECK_PERIOD_MIN });
});
chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name === UPDATE_CHECK_ALARM) checkForUpdate();
});

// ── LinkedIn connection-activity reader (v1.9) ────────────────────────────────
//
// Reads the logged-in LinkedIn member's SENT (still-pending) invitations and
// RECENTLY-ADDED connections (the practical "accepted" signal) straight from
// LinkedIn's own Voyager API. Purpose: let a rep confirm a connection request
// actually went out — and see which of those went out have since been accepted.
//
// How it works (same shape as the token-harvest path):
//   • We find (or briefly open) a www.linkedin.com tab.
//   • chrome.scripting.executeScript injects gowarmReadConnectionActivity()
//     into that tab's ISOLATED world. Because the document origin is
//     linkedin.com, fetch(..., {credentials:'include'}) carries the member's
//     session cookies, and the JSESSIONID cookie value doubles as the
//     csrf-token header — exactly like content.js's profile capture.
//
// Why candidates + raw passthrough:
//   Voyager endpoint shapes / decoration IDs rotate with LinkedIn deploys and
//   can't be verified offline. So the injected fn tries the known endpoint
//   shapes in priority order, returns the first 200, and ALSO stashes the full
//   raw JSON on window.__gowarmConnRaw (inspectable in the LinkedIn tab's
//   devtools) plus a truncated sample in the response — so one live run tells
//   us the exact shape and we tune the parser from real data.
//
// IMPORTANT — this is the user's OWN network activity, read on demand by a
// human click. Keep it that way: do NOT put this on an alarm/poll. Automated,
// high-frequency Voyager traffic is what gets accounts flagged.

// Find an open LinkedIn tab, or open one in the background and wait for load.
// Returns { tabId, created } — `created` tells the caller whether to clean up.
async function getOrCreateLinkedInTab() {
  const tabs = await chrome.tabs.query({ url: 'https://www.linkedin.com/*' });
  if (tabs && tabs.length) return { tabId: tabs[0].id, created: false };

  const tab = await chrome.tabs.create({
    url: 'https://www.linkedin.com/feed/',
    active: false,
  });

  await new Promise((resolve) => {
    function listener(tabId, info) {
      if (tabId === tab.id && info.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    }
    chrome.tabs.onUpdated.addListener(listener);
    // Safety valve — don't hang forever if the tab never reports complete.
    setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      resolve();
    }, 12000);
  });

  return { tabId: tab.id, created: true };
}

// Injected into the LinkedIn tab (MAIN world, so it can read the capture array
// that li_net_capture.js populates). MUST be fully self-contained — execute-
// Script serialises it via toString(). Returns a plain object.
//
// Strategy: rather than guess rotating GraphQL queryIds, we harvest the
// requests LinkedIn already fired (and we recorded) while the user browsed
// My Network. We also do one stable direct call — /voyager/api/me — for the
// logged-in member's identity, which is a fixed endpoint that doesn't rotate.
async function gowarmReadConnectionActivity() {
  const out = {
    ok: false, ts: Date.now(), viewer: null,
    sent: null, accepted: null, captures: [], needsBrowse: false, error: null,
  };

  // Defensive person extractor — recurse and pull out anything member-shaped.
  function collectPeople(root) {
    const seen = new Set();
    const people = [];
    (function visit(node) {
      if (!node || typeof node !== 'object') return;
      if (Array.isArray(node)) { node.forEach(visit); return; }
      const fn = node.firstName, ln = node.lastName, pub = node.publicIdentifier;
      const key = pub || node.entityUrn;
      if ((typeof fn === 'string' || typeof ln === 'string') && key && !seen.has(key)) {
        seen.add(key);
        let headline = node.occupation || node.headline || null;
        if (headline && typeof headline === 'object') headline = headline.text || null;
        people.push({
          name: [fn, ln].filter(Boolean).join(' ').trim() || null,
          publicIdentifier: pub || null,
          url: pub ? ('https://www.linkedin.com/in/' + pub + '/') : null,
          headline: typeof headline === 'string' ? headline : null,
        });
      }
      for (const k in node) {
        if (node[k] && typeof node[k] === 'object') visit(node[k]);
      }
    })(root);
    return people;
  }

  // ── Viewer identity: /voyager/api/me (stable endpoint, no rotating id) ──
  const cm = document.cookie.match(/JSESSIONID=("?)([^";]+)\1/);
  const csrf = cm ? cm[2] : null;
  if (csrf) {
    try {
      const meRes = await fetch('https://www.linkedin.com/voyager/api/me', {
        method: 'GET',
        credentials: 'include',
        headers: {
          'csrf-token': csrf,
          'x-restli-protocol-version': '2.0.0',
          'accept': 'application/vnd.linkedin.normalized+json+2.1',
        },
      });
      if (meRes.status === 200) {
        const meJson = await meRes.json();
        const p = collectPeople(meJson)[0] || null;
        let memberUrn = null;
        try {
          const um = JSON.stringify(meJson).match(/urn:li:fs[a-z]*_(?:miniProfile|profile):[A-Za-z0-9_-]+/);
          memberUrn = um ? um[0] : null;
        } catch (_) {}
        out.viewer = {
          name: p ? p.name : null,
          publicIdentifier: p ? p.publicIdentifier : null,
          url: p ? p.url : null,
          headline: p ? p.headline : null,
          memberUrn, status: 200,
        };
      } else {
        out.viewer = { name: null, status: meRes.status, error: 'me ' + meRes.status };
      }
    } catch (e) {
      out.viewer = { name: null, status: 0, error: String((e && e.message) || e) };
    }
  }

  // ── Scrape the rendered DOM ───────────────────────────────────────────────
  // LinkedIn's My Network is now server-driven UI (flagship-web/RSC), so the
  // network payloads are an opaque React-Flight component tree — no structured
  // member objects to parse. But the names/links ARE rendered in the DOM, and
  // each row carries a stable semantic anchor: sent invitations have a
  // "Withdraw" button, connections have a "Message" button. We locate rows via
  // those buttons, then pull the /in/ link + name out of the surrounding card.
  function scrapeListByButton(btnRegex) {
    const out = [];
    const seen = new Set();
    const triggers = Array.from(document.querySelectorAll('button, a'))
      .filter(b => btnRegex.test((b.textContent || '').trim()));

    triggers.forEach((btn) => {
      // Climb to the nearest ancestor that contains a profile link.
      let el = btn, card = null;
      for (let i = 0; i < 9 && el; i++) {
        if (el.querySelector && el.querySelector('a[href*="/in/"]')) { card = el; break; }
        el = el.parentElement;
      }
      if (!card) return;

      const links = Array.from(card.querySelectorAll('a[href*="/in/"]'));
      let slug = null;
      for (const a of links) {
        const mm = (a.getAttribute('href') || '').match(/\/in\/([^/?#]+)/);
        if (mm) { slug = mm[1]; break; }
      }
      if (!slug || seen.has(slug)) return;
      seen.add(slug);

      // Name extraction. The visible name is NOT inside the /in/ link's text on
      // these server-driven-UI cards, so "longest link text" returns empty and
      // we'd fall back to the slug. The avatar <img alt> is the clean source
      // (LinkedIn sets it to the member's name). Fallbacks: de-duplicated link
      // text (LinkedIn often doubles it with a visually-hidden span), then
      // aria-label, then the slug.
      let name = '';
      const img = card.querySelector('img[alt]');
      if (img) {
        let alt = (img.getAttribute('alt') || '').replace(/\s+/g, ' ').trim();
        // LinkedIn alt is typically "<Name>'s profile picture" / "...photo" /
        // "...profile photo" — strip the possessive suffix to get the name.
        alt = alt.replace(/[\u2019'`]s\s+(profile\s+)?(picture|photo|image|profile).*$/i, '').trim();
        if (alt && alt.length > 1 && !/(logo|background|company|graphic)/i.test(alt)) name = alt;
      }
      if (!name) {
        let best = '';
        links.forEach(a => {
          const t = (a.textContent || '').replace(/\s+/g, ' ').trim();
          if (t.length > best.length) best = t;
        });
        if (best) {
          const half = best.slice(0, Math.floor(best.length / 2)).trim();
          if (half && best === half + half) best = half;          // "NameName" → "Name"
          if (half && best === half + ' ' + half) best = half;    // "Name Name" → "Name"
          name = best;
        }
      }
      if (!name) {
        for (const a of links) {
          const al = (a.getAttribute('aria-label') || '').trim();
          if (al) { name = al.replace(/^view\s+/i, '').replace(/[\u2019']s profile.*$/i, '').trim(); break; }
        }
      }
      name = (name || slug).replace(/\s+/g, ' ').trim();

      // Time + headline best-effort from the card text.
      const cardText = (card.textContent || '').replace(/\s+/g, ' ').trim();
      const timeMatch = cardText.match(/(sent|connected)\b[^.|·]*?\bago/i);

      out.push({
        name: name || slug,
        publicIdentifier: slug,
        url: 'https://www.linkedin.com/in/' + slug + '/',
        headline: null,                            // refine later if needed
        timeText: timeMatch ? timeMatch[0].trim() : null,
      });
    });
    return out;
  }

  function asGroup(label, people, source) {
    return {
      endpoint: source,
      source: 'dom',
      status: 200,
      peopleCount: people.length,
      people: people.slice(0, 200),
      rawSample: null,
    };
  }

  const path = (location.pathname || '').toLowerCase();
  const onSent        = path.includes('/invitation-manager/sent');
  const onConnections = path.includes('/connections');   // matches both /mynetwork/connections and /mynetwork/invite-connect/connections

  if (onSent) {
    const people = scrapeListByButton(/withdraw/i);
    out.sent = asGroup('Sent', people, 'DOM · invitation-manager/sent');
  }
  if (onConnections) {
    const people = scrapeListByButton(/^message$/i);
    out.accepted = asGroup('Connections', people, 'DOM · mynetwork/connections');
  }

  // Keep the network capture purely as a diagnostic now (opaque SDUI bodies).
  const capture = Array.isArray(window.__gowarmConnCapture) ? window.__gowarmConnCapture : [];
  out.captures = capture.map(c => ({ endpoint: c.url, kind: c.kind, status: c.status }));

  if (!out.sent && !out.accepted) {
    out.needsBrowse = true;
    out.error = 'NOT_ON_LIST_PAGE';
  }

  try {
    window.__gowarmConnRaw = { viewer: out.viewer, path, sent: out.sent, accepted: out.accepted, capture, ts: out.ts };
  } catch (_) {}
  console.log('[GoWarm] connection activity — inspect window.__gowarmConnRaw', out);

  out.ok = true;
  return out;
}

// ── Message listener ──────────────────────────────────────────────────────────

// Scrape connection activity across all open LinkedIn tabs and merge.
// Shared by READ_CONNECTION_ACTIVITY (display-only) and
// SYNC_CONNECTION_ACTIVITY (display + push to backend). Throws on hard
// failure; returns the merged object otherwise. Cleans up any tab it had
// to open itself.
async function readConnectionActivityAcrossTabs() {
  let createdTabId = null;
  try {
    let tabs = await chrome.tabs.query({ url: 'https://www.linkedin.com/*' });

    // No LinkedIn open at all — open one so we can at least read identity,
    // and flag that the user needs to browse My Network to get activity.
    if (!tabs || !tabs.length) {
      const created = await getOrCreateLinkedInTab();
      createdTabId = created.created ? created.tabId : null;
      tabs = await chrome.tabs.query({ url: 'https://www.linkedin.com/*' });
    }

    const perTab = [];
    for (const t of tabs) {
      try {
        const results = await chrome.scripting.executeScript({
          target: { tabId: t.id },
          func: gowarmReadConnectionActivity,
          world: 'MAIN',     // must match li_net_capture.js's world to see the capture array
        });
        const r = results?.[0]?.result;
        if (r) perTab.push(r);
      } catch (_) { /* tab may be mid-navigation; skip it */ }
    }

    if (!perTab.length) throw new Error('NO_RESULT');

    // Merge: viewer = first identified; sent/accepted = best across tabs
    // (most people, then most recent); needsBrowse only if nothing anywhere.
    const merged = {
      ok: true, ts: Date.now(),
      viewer: null, sent: null, accepted: null, captures: [], needsBrowse: true, error: null,
    };
    const better = (a, b) => {
      if (!b) return a; if (!a) return b;
      if ((b.peopleCount || 0) !== (a.peopleCount || 0)) return (b.peopleCount > a.peopleCount) ? b : a;
      return ((b.ts || 0) > (a.ts || 0)) ? b : a;
    };
    for (const r of perTab) {
      if (!merged.viewer && r.viewer && (r.viewer.name || r.viewer.publicIdentifier)) merged.viewer = r.viewer;
      if (r.sent)     merged.sent     = better(merged.sent, r.sent);
      if (r.accepted) merged.accepted = better(merged.accepted, r.accepted);
      if (Array.isArray(r.captures)) merged.captures = merged.captures.concat(r.captures);
    }
    merged.needsBrowse = !merged.sent && !merged.accepted;
    if (merged.needsBrowse) {
      merged.error = merged.captures.length
        ? 'Recorded requests but none parsed to people yet — see captures list.'
        : 'NO_CAPTURE';
    }
    if (!merged.viewer) merged.viewer = perTab[0].viewer || null;

    return merged;
  } finally {
    if (createdTabId != null) {
      setTimeout(() => { try { chrome.tabs.remove(createdTabId); } catch (_) {} }, 600);
    }
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {

  if (message.type === 'LOOKUP_PROSPECT') {
    apiFetch(`/prospects/by-linkedin-url?url=${encodeURIComponent(message.linkedinUrl)}`)
      .then(data => sendResponse({ ok: true,  prospect: data.prospect }))
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (message.type === 'ADD_PROSPECT') {
    apiFetch('/prospects', {
      method: 'POST',
      body: JSON.stringify({
        firstName:          message.firstName,
        lastName:           message.lastName,
        linkedinHeadline:   message.linkedinHeadline,
        companyName:        message.companyName,
        companyLinkedInUrl: message.companyLinkedInUrl,
        email:              message.email,
        linkedinUrl:        message.linkedinUrl,
        location:           message.location,
        source:             message.source || 'linkedin_extension',
        stage:              'target',
        // NEW (v1.8): optional campaign + sequence. The defaults are
        // set in the popup's Settings view and stored in chrome.storage.
        // The content script reads them per-org and may override per
        // prospect via the inline "change" link on the Not-in-CRM form.
        campaignId:         message.campaignId || null,
        sequenceId:         message.sequenceId || null,
      }),
    })
      .then(data => sendResponse({
        ok:              true,
        prospect:        data.prospect,
        enrollment:      data.enrollment      || null,
        enrollmentError: data.enrollmentError || null,
      }))
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  // ── NEW (v1.8): lookup lists for the popup's Push-defaults settings
  // and the in-page form's inline override.
  //
  // The popup uses this on Settings open to populate the two dropdowns;
  // content.js uses it lazily on first "change" click (and caches the
  // result for the lifetime of that LinkedIn page). Both calls share one
  // backend round-trip via Promise.all.
  //
  // Only ACTIVE campaigns and ACTIVE sequences are returned — picking a
  // paused campaign or archived sequence is almost always an accident.
  // Reps who really need them can change status in the web app first.
  if (message.type === 'LIST_CAMPAIGNS_AND_SEQUENCES') {
    Promise.all([
      apiFetch('/prospecting-campaigns?status=active').catch(err => {
        console.warn('LIST_CAMPAIGNS_AND_SEQUENCES: campaigns fetch failed:', err.message);
        return { campaigns: [] };
      }),
      apiFetch('/sequences').catch(err => {
        console.warn('LIST_CAMPAIGNS_AND_SEQUENCES: sequences fetch failed:', err.message);
        return { sequences: [] };
      }),
    ])
      .then(([campData, seqData]) => {
        // Slim each row to what dropdowns actually need. Keeping the
        // wire-format small matters because this fires on every popup
        // open (cheap, but worth not bloating).
        const campaigns = (campData.campaigns || []).map(c => ({
          id:                  c.id,
          name:                c.name,
          status:              c.status,
          default_sequence_id: c.default_sequence_id || null,
        }));
        // GET /sequences excludes archived but includes paused/draft.
        // POST /api/sequences/enroll requires status='active' so filter
        // here to match the backend's acceptance criteria.
        const sequences = (seqData.sequences || [])
          .filter(s => s.status === 'active')
          .map(s => ({
            id:          s.id,
            name:        s.name,
            step_count:  s.step_count || 0,
          }));
        sendResponse({ ok: true, campaigns, sequences });
      })
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (message.type === 'LOG_EVENT') {
    apiFetch(`/prospects/${message.prospectId}/linkedin-event`, {
      method: 'POST',
      body: JSON.stringify({
        event:       message.event,
        note:        message.note,
        sentiment:   message.sentiment,
        occurred_at: message.occurredAt,
      }),
    })
      .then(data => sendResponse({ ok: true,  data }))
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  // Upserts captured LinkedIn profile data (about, experience, education,
  // posts, etc.) to the canonical linkedin_profiles table. Optionally links
  // the profile to a prospect or contact in the same call.
  if (message.type === 'UPSERT_LINKEDIN_PROFILE') {
    apiFetch('/linkedin-profiles/upsert', {
      method: 'POST',
      body: JSON.stringify({
        linkedin_url: message.linkedinUrl,
        fields:       message.fields || {},
        source:       'extension',
        link_to:      message.linkTo || null,
      }),
    })
      .then(data => sendResponse({ ok: true, profile_id: data.profile_id, profile: data.profile, linked: data.linked, account_id: data.account_id }))
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  // ── NEW in v1.5 ──────────────────────────────────────────────────────────
  // Fetch the existing captured profile (if any) from the linkedin_profiles
  // table. Used by content.js to hydrate the capture rows on profile
  // arrival, so reps can see what's already on file BEFORE scrolling
  // triggers a fresh scrape — and so the live scrape can be diffed
  // against the stored values.
  //
  // Returns { ok: true, profile: <row>|null }.
  if (message.type === 'GET_ACTIVITIES') {
    apiFetch(`/prospects/${message.prospectId}/activities`)
      .then(data => sendResponse({ ok: true, activities: data.activities || [] }))
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (message.type === 'RUN_SEGMENTATION') {
    apiFetch(`/skills/segmentation-individual/run`, {
      method: 'POST',
      body: JSON.stringify({ prospectId: message.prospectId }),
    })
      .then(data => sendResponse({ ok: true, result: data }))
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (message.type === 'GET_LINKEDIN_PROFILE') {
    apiFetch(`/linkedin-profiles/by-url?url=${encodeURIComponent(message.linkedinUrl)}`)
      .then(data => sendResponse({ ok: true, profile: data.profile || null }))
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  // Triggers Coresignal enrichment for an existing prospect.
  // Use sparingly — each call costs Coresignal credits.
  if (message.type === 'ENRICH_PROSPECT_FROM_CORESIGNAL') {
    apiFetch(`/prospects/${message.prospectId}/enrich-from-coresignal`, {
      method: 'POST',
    })
      .then(data => sendResponse({ ok: true, data }))
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  // ── NEW (v1.8): assign an existing prospect to a campaign + sequence.
  // Powers the "smart-suggest" prompt on the in-page panel for prospects
  // that are already in CRM but aren't in the rep's default target. Same
  // partial-failure semantics as ADD_PROSPECT (campaign update may
  // succeed while enrollment fails — both surfaced separately).
  if (message.type === 'PUSH_PROSPECT_TO_TARGET') {
    apiFetch(`/prospects/${message.prospectId}/push-to-target`, {
      method: 'POST',
      body: JSON.stringify({
        campaignId: message.campaignId || null,
        sequenceId: message.sequenceId || null,
      }),
    })
      .then(data => sendResponse({
        ok:              true,
        prospect:        data.prospect,
        enrollment:      data.enrollment      || null,
        enrollmentError: data.enrollmentError || null,
      }))
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  // ── NEW in v1.5 ──────────────────────────────────────────────────────────
  // Identity & config — drives the popup's "Connected as <email> · <org>"
  // line and the in-page panel header subline.
  //
  // GET_IDENTITY honours a cached value (TTL 10min); pass { force: true }
  // to bypass the cache (popup does this right after harvesting a new
  // token, so we don't briefly show the previous user's identity).
  if (message.type === 'GET_IDENTITY') {
    fetchIdentity({ force: !!message.force })
      .then(({ identity, cachedAt }) => sendResponse({ ok: true, identity, cachedAt }))
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (message.type === 'GET_CONFIG') {
    sendResponse({ ok: true, config: classifyApiHost() });
    return false;   // synchronous response
  }

  // Returns the cached version-check result for the popup to render its
  // update banner. If `refresh` is true the handler also kicks off a
  // background check — but with one important twist: if there's NO
  // cached result yet (the very first time the popup opens, or after
  // storage was cleared), it awaits the fresh check before responding.
  // Otherwise the popup would render with no banner on a fresh install
  // even when an update is available, and the user would have to open
  // the popup twice to see it.
  //
  // Once cache exists, we serve it immediately and refresh asynchronously
  // — fast popup open, eventually-consistent cache.
  if (message.type === 'GET_UPDATE_STATUS') {
    chrome.storage.local.get(['gowarm_update_check'], async (r) => {
      const cached = r.gowarm_update_check || null;
      if (cached) {
        sendResponse({ ok: true, status: cached });
        if (message.refresh) checkForUpdate(); // fire-and-forget
        return;
      }
      // No cache. If the caller asked for a refresh, do it synchronously
      // so the popup gets a real answer on this open. Bounded by the
      // 5-second timeout inside checkForUpdate(), so we won't hang.
      if (message.refresh) {
        await checkForUpdate();
        const r2 = await new Promise(resolve =>
          chrome.storage.local.get(['gowarm_update_check'], resolve)
        );
        sendResponse({ ok: true, status: r2.gowarm_update_check || null });
      } else {
        sendResponse({ ok: true, status: null });
      }
    });
    return true;
  }

  // Triggered by the "Reload extension" button in the popup's update
  // banner. chrome.runtime.reload() restarts the extension's service
  // worker, content scripts, and popup — re-reading the unpacked
  // folder from disk in the process. This is how the user picks up
  // a new version they've copied into the existing folder without
  // having to go to chrome://extensions and click reload manually.
  //
  // We respond before reloading so the popup gets an ack, though in
  // practice the popup is torn down by the reload anyway.
  if (message.type === 'RELOAD_EXTENSION') {
    sendResponse({ ok: true });
    // Defer the reload by a tick so the response flushes first.
    setTimeout(() => chrome.runtime.reload(), 50);
    return false;
  }

  // ── (v1.10) Read connection activity by harvesting LinkedIn's OWN captured
  // requests. Runs the harvester in the MAIN world (so it can read the
  // window.__gowarmConnCapture array that li_net_capture.js populates) across
  // ALL open LinkedIn tabs, then merges — because the user may have browsed
  // My Network in one tab and have the profile open in another.
  if (message.type === 'READ_CONNECTION_ACTIVITY') {
    (async () => {
      try {
        const merged = await readConnectionActivityAcrossTabs();
        sendResponse({ ok: true, data: merged });
      } catch (err) {
        sendResponse({ ok: false, error: err.message });
      }
    })();
    return true;
  }

  // ── (v1.17) Scrape + PUSH connection activity to GoWarmCRM ──────────────────
  //
  // message: { type: 'SYNC_CONNECTION_ACTIVITY', kind: 'sent' | 'accepted' }
  //
  // Runs the same scrape as READ_CONNECTION_ACTIVITY, then POSTs the requested
  // group to POST /api/linkedin-connections/reconcile, which:
  //   • binds the logged-in LinkedIn member (viewer) to the GoWarm user —
  //     rejecting with SEAT_CONFLICT if the LinkedIn account belongs to a
  //     different teammate, so reps can only update their own prospects;
  //   • slug-matches people to prospects OWNED by this user;
  //   • records connection_accepted / connection_request_sent idempotently
  //     (re-clicking is always safe — already-recorded rows are no-ops).
  //
  // Response: { ok, kind, result: <reconcile response>, data: <merged scrape> }
  // On failure `data` is still included when the scrape itself succeeded, so
  // the popup can render what was found alongside the error.
  if (message.type === 'SYNC_CONNECTION_ACTIVITY') {
    (async () => {
      let merged = null;
      try {
        merged = await readConnectionActivityAcrossTabs();
        const kind  = message.kind === 'sent' ? 'sent' : 'accepted';
        const group = merged[kind];

        if (!group || !Array.isArray(group.people) || group.people.length === 0) {
          sendResponse({ ok: false, error: 'NOT_ON_PAGE', kind, data: merged });
          return;
        }

        const viewer = merged.viewer || {};
        if (!viewer.publicIdentifier) {
          sendResponse({ ok: false, error: 'SEAT_UNKNOWN', kind, data: merged });
          return;
        }

        const payload = {
          kind,
          viewer: {
            publicIdentifier: viewer.publicIdentifier,
            name:             viewer.name      || null,
            memberUrn:        viewer.memberUrn || null,
          },
          // Slim to what the backend needs — keep the wire format small.
          people: group.people.map(p => ({
            publicIdentifier: p.publicIdentifier || null,
            url:              p.url              || null,
            name:             p.name             || null,
            timeText:         p.timeText         || null,
          })),
        };

        const result = await apiFetch('/linkedin-connections/reconcile', {
          method: 'POST',
          body: JSON.stringify(payload),
        });

        sendResponse({ ok: true, kind, result, data: merged });
      } catch (err) {
        // apiFetch surfaces the backend's error.message (e.g. the friendly
        // SEAT_CONFLICT text) — pass it through verbatim.
        sendResponse({ ok: false, error: err.message, kind: message.kind, data: merged });
      }
    })();
    return true;
  }

  // Forwarded automatically by auth_bridge.js when GoWarmCRM is open
  if (message.type === 'SAVE_TOKEN') {
    saveToken(message.token).then(() => sendResponse({ ok: true }));
    return true;
  }

  if (message.type === 'GET_TOKEN') {
    getToken().then(token => sendResponse({ token }));
    return true;
  }

  if (message.type === 'CLEAR_TOKEN') {
    clearToken().then(() => sendResponse({ ok: true }));
    return true;
  }

  // Popup requests an immediate harvest attempt
  if (message.type === 'TRY_HARVEST') {
    harvestTokenFromOpenTab()
      .then(token => sendResponse({ ok: !!token, token }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }
});
