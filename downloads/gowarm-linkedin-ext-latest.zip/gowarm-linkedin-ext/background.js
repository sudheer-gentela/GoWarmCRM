// background.js — GoWarmCRM LinkedIn Extension v1.5
//
// Auto-auth: token is harvested automatically from app.gowarmcrm.com
// by auth_bridge.js — no manual paste needed.
//
// New in v1.5:
//   • GET_IDENTITY — calls /api/auth/verify, caches { email, org_name,
//     org_id, org_slug } in chrome.storage.local. Used by popup +
//     in-page panel to show "Saving as <email> · <org_name>" so reps
//     can tell at a glance which workspace their captures land in.
//
//   • GET_LINKEDIN_PROFILE — calls /api/linkedin-profiles/by-url to
//     fetch the existing captured profile (if any). Drives the delta-
//     refresh UX in content.js: rows are pre-populated with what's
//     already in DB, and live scrapes are diffed against that.
//
//   • GET_CONFIG — exposes API_BASE so the popup can show the user
//     which backend they're talking to (prod vs staging vs custom).
//
//   • Identity is invalidated whenever the token changes or is
//     cleared, so switching CRM accounts in another tab is reflected
//     correctly.

const API_BASE = 'https://api.gowarmcrm.com/api';

// Identity cache TTL — re-fetch from /verify if the cached identity is
// older than this. Short enough that a stale email/org name never
// lingers; long enough that we don't hammer the endpoint on every
// LinkedIn profile visit. The token-change path also invalidates.
const IDENTITY_TTL_MS = 10 * 60 * 1000;   // 10 minutes

// ── Token management ─────────────────────────────────────────────────────────

async function getToken() {
  return new Promise(resolve => {
    chrome.storage.local.get(['gowarm_token'], result => {
      resolve(result.gowarm_token || null);
    });
  });
}

async function saveToken(token) {
  // Compare against existing — if it changed, drop cached identity so
  // the next GET_IDENTITY call refetches under the new token.
  return new Promise(resolve => {
    chrome.storage.local.get(['gowarm_token'], (result) => {
      const previous = result.gowarm_token || null;
      const changed  = previous !== token;
      const writes   = { gowarm_token: token };
      if (changed) {
        // Wipe identity so we don't keep showing the old user/org.
        writes.gowarm_identity      = null;
        writes.gowarm_identity_ts   = null;
      }
      chrome.storage.local.set(writes, resolve);
    });
  });
}

async function clearToken() {
  return new Promise(resolve => {
    chrome.storage.local.remove(
      ['gowarm_token', 'gowarm_identity', 'gowarm_identity_ts'],
      resolve
    );
  });
}

// ── Identity cache ────────────────────────────────────────────────────────────

async function getCachedIdentity() {
  return new Promise(resolve => {
    chrome.storage.local.get(['gowarm_identity', 'gowarm_identity_ts'], (r) => {
      resolve({
        identity:  r.gowarm_identity   || null,
        cachedAt:  r.gowarm_identity_ts || 0,
      });
    });
  });
}

async function saveIdentity(identity) {
  return new Promise(resolve => {
    chrome.storage.local.set({
      gowarm_identity:    identity,
      gowarm_identity_ts: Date.now(),
    }, resolve);
  });
}

// ── Harvest token from an open GoWarmCRM tab ─────────────────────────────────
// Falls back to scripting API if auth_bridge.js hasn't fired yet,
// or if the token was written before the extension was installed.
async function harvestTokenFromOpenTab() {
  return new Promise(resolve => {
    chrome.tabs.query({ url: 'https://app.gowarmcrm.com/*' }, async (tabs) => {
      if (!tabs || tabs.length === 0) {
        resolve(null);
        return;
      }
      try {
        const results = await chrome.scripting.executeScript({
          target: { tabId: tabs[0].id },
          func: () => {
            return (
              localStorage.getItem('token') ||
              localStorage.getItem('authToken') ||
              localStorage.getItem('gowarm_token') ||
              null
            );
          },
        });
        const token = results?.[0]?.result || null;
        if (token) await saveToken(token);
        resolve(token);
      } catch (err) {
        resolve(null);
      }
    });
  });
}

// ── Authenticated API fetch with auto-refresh ─────────────────────────────────

async function apiFetch(path, options = {}, retried = false) {
  let token = await getToken();

  // No stored token — try to grab it from open GoWarmCRM tab first
  if (!token) {
    token = await harvestTokenFromOpenTab();
  }

  if (!token) throw new Error('NOT_AUTHENTICATED');

  const res = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
      'X-GoWarm-Extension-Key': 'gowarm-ext-2024-xK9mP3qR',
      ...(options.headers || {}),
    },
  });

  // 401 = token expired — harvest fresh token and retry once
  if (res.status === 401 && !retried) {
    await clearToken();
    const freshToken = await harvestTokenFromOpenTab();
    if (freshToken) return apiFetch(path, options, true);
    throw new Error('NOT_AUTHENTICATED');
  }

  const data = await res.json();
  if (!res.ok) throw new Error(data?.error?.message || `HTTP ${res.status}`);
  return data;
}

// ── Identity fetch ────────────────────────────────────────────────────────────
//
// Hits /auth/verify (which already returns user + org_id + org_name + org_slug
// after the v1.5 backend change). Cached for IDENTITY_TTL_MS. Pass
// { force: true } to bypass the cache, e.g. immediately after the
// popup harvests a new token.
//
// Returns { identity, cachedAt } — cachedAt is the unix-ms timestamp
// of the last successful /verify response (read from storage on cache
// hit, set to Date.now() on cache miss). The popup's settings view
// reads this to show "Last refreshed 2m ago" so reps know whether
// the displayed account is fresh or stale.
async function fetchIdentity({ force = false } = {}) {
  if (!force) {
    const { identity, cachedAt } = await getCachedIdentity();
    if (identity && Date.now() - cachedAt < IDENTITY_TTL_MS) {
      return { identity, cachedAt };
    }
  }

  // /auth/verify lives at /api/auth/verify (same /api prefix as everything
  // else the extension talks to).
  const data = await apiFetch('/auth/verify');
  const u = data?.user || {};

  const identity = {
    user_id:     u.id          ?? null,
    email:       u.email       ?? null,
    first_name:  u.firstName   ?? null,
    last_name:   u.lastName    ?? null,
    org_id:      u.org_id      ?? null,
    org_name:    u.org_name    ?? null,
    org_slug:    u.org_slug    ?? null,
    org_role:    u.org_role    ?? null,
  };
  await saveIdentity(identity);
  return { identity, cachedAt: Date.now() };
}

// ── API host classification ──────────────────────────────────────────────────
//
// The popup uses this to decide whether to show a green "production"
// pill or an amber "non-production" warning. A hostname containing
// 'staging', 'dev', 'localhost', or a Railway preview URL is treated
// as non-prod. Pure prod is api.gowarmcrm.com.
function classifyApiHost() {
  let host = '';
  try { host = new URL(API_BASE).host; } catch (_) { host = ''; }

  const isProd =
    host === 'api.gowarmcrm.com';

  return {
    api_base: API_BASE,
    host,
    env:      isProd ? 'production' : 'non-production',
    is_prod:  isProd,
  };
}

// ── Version check ────────────────────────────────────────────────────────────
//
// Polls the backend's /extension/version endpoint to find out whether a
// newer build is available. We don't auto-update — Chrome won't allow that
// for unpacked extensions — but we cache the result so the popup can show
// a banner directing the user to the install page.
//
// Design choices worth knowing:
//   • Unauthenticated: version info isn't sensitive, and an unauth endpoint
//     means the check still works when the user is logged out.
//   • Silent on failure: if the endpoint is unreachable or returns junk,
//     we leave the cached result alone and the popup just doesn't show
//     a banner. The extension MUST keep working when the version service
//     is down — this is a nice-to-have, not load-bearing.
//   • Cached in chrome.storage.local under gowarm_update_check so the popup
//     can read it synchronously (no network call on popup open).
//   • Re-checked on service-worker startup and every 6 hours via alarms.

const VERSION_ENDPOINT       = '/extension/version';
const UPDATE_CHECK_ALARM     = 'gowarm_version_check';
const UPDATE_CHECK_PERIOD_MIN = 6 * 60; // 6 hours

// Compare two dotted version strings ("1.7.3" vs "1.7.10"). Returns
// negative if a < b, 0 if equal, positive if a > b. Pads with zeros so
// "1.7" compares correctly against "1.7.0". Non-numeric segments
// (pre-release tags etc.) are treated as 0 — good enough for our use.
function compareVersions(a, b) {
  const pa = String(a || '').split('.').map(n => parseInt(n, 10) || 0);
  const pb = String(b || '').split('.').map(n => parseInt(n, 10) || 0);
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const da = pa[i] || 0;
    const db = pb[i] || 0;
    if (da !== db) return da - db;
  }
  return 0;
}

async function checkForUpdate() {
  const current = chrome.runtime.getManifest().version;
  try {
    // Unauthenticated, short timeout. AbortController gives us a hard
    // ceiling so a hung backend doesn't keep the service worker alive.
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 5000);
    const res = await fetch(`${API_BASE}${VERSION_ENDPOINT}`, {
      method: 'GET',
      signal: ctrl.signal,
    });
    clearTimeout(timer);
    if (!res.ok) return;
    const data = await res.json();
    const latest = data?.latest;
    if (!latest || typeof latest !== 'string') return;

    const status = {
      current,
      latest,
      update_available: compareVersions(current, latest) < 0,
      download_url:     data?.download_url || null,
      min_supported:    data?.min_supported || null,
      checked_at:       Date.now(),
    };
    await new Promise(resolve =>
      chrome.storage.local.set({ gowarm_update_check: status }, resolve)
    );
  } catch (_) {
    // Silent — keep whatever the previous cached value was. The popup
    // gracefully renders "no banner" when nothing is cached or when
    // update_available is false.
  }
}

// Run once on service-worker startup, then on a recurring alarm.
chrome.runtime.onStartup.addListener(() => { checkForUpdate(); });
chrome.runtime.onInstalled.addListener(() => {
  checkForUpdate();
  chrome.alarms.create(UPDATE_CHECK_ALARM, { periodInMinutes: UPDATE_CHECK_PERIOD_MIN });
});
chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name === UPDATE_CHECK_ALARM) checkForUpdate();
});

// ── Message listener ──────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {

  if (message.type === 'LOOKUP_PROSPECT') {
    apiFetch(`/prospects/by-linkedin-url?url=${encodeURIComponent(message.linkedinUrl)}`)
      .then(data => sendResponse({ ok: true,  prospect: data.prospect }))
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (message.type === 'ADD_PROSPECT') {
    apiFetch('/prospects', {
      method: 'POST',
      body: JSON.stringify({
        firstName:          message.firstName,
        lastName:           message.lastName,
        linkedinHeadline:   message.linkedinHeadline,
        companyName:        message.companyName,
        companyLinkedInUrl: message.companyLinkedInUrl,
        email:              message.email,
        linkedinUrl:        message.linkedinUrl,
        location:           message.location,
        source:             message.source || 'linkedin_extension',
        stage:              'target',
      }),
    })
      .then(data => sendResponse({ ok: true, prospect: data.prospect }))
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (message.type === 'LOG_EVENT') {
    apiFetch(`/prospects/${message.prospectId}/linkedin-event`, {
      method: 'POST',
      body: JSON.stringify({
        event:     message.event,
        note:      message.note,
        sentiment: message.sentiment,
      }),
    })
      .then(data => sendResponse({ ok: true,  data }))
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  // Upserts captured LinkedIn profile data (about, experience, education,
  // posts, etc.) to the canonical linkedin_profiles table. Optionally links
  // the profile to a prospect or contact in the same call.
  if (message.type === 'UPSERT_LINKEDIN_PROFILE') {
    apiFetch('/linkedin-profiles/upsert', {
      method: 'POST',
      body: JSON.stringify({
        linkedin_url: message.linkedinUrl,
        fields:       message.fields || {},
        source:       'extension',
        link_to:      message.linkTo || null,
      }),
    })
      .then(data => sendResponse({ ok: true, profile_id: data.profile_id, profile: data.profile, linked: data.linked, account_id: data.account_id }))
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  // ── NEW in v1.5 ──────────────────────────────────────────────────────────
  // Fetch the existing captured profile (if any) from the linkedin_profiles
  // table. Used by content.js to hydrate the capture rows on profile
  // arrival, so reps can see what's already on file BEFORE scrolling
  // triggers a fresh scrape — and so the live scrape can be diffed
  // against the stored values.
  //
  // Returns { ok: true, profile: <row>|null }.
  if (message.type === 'GET_LINKEDIN_PROFILE') {
    apiFetch(`/linkedin-profiles/by-url?url=${encodeURIComponent(message.linkedinUrl)}`)
      .then(data => sendResponse({ ok: true, profile: data.profile || null }))
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  // Triggers Coresignal enrichment for an existing prospect.
  // Use sparingly — each call costs Coresignal credits.
  if (message.type === 'ENRICH_PROSPECT_FROM_CORESIGNAL') {
    apiFetch(`/prospects/${message.prospectId}/enrich-from-coresignal`, {
      method: 'POST',
    })
      .then(data => sendResponse({ ok: true, data }))
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  // ── NEW in v1.5 ──────────────────────────────────────────────────────────
  // Identity & config — drives the popup's "Connected as <email> · <org>"
  // line and the in-page panel header subline.
  //
  // GET_IDENTITY honours a cached value (TTL 10min); pass { force: true }
  // to bypass the cache (popup does this right after harvesting a new
  // token, so we don't briefly show the previous user's identity).
  if (message.type === 'GET_IDENTITY') {
    fetchIdentity({ force: !!message.force })
      .then(({ identity, cachedAt }) => sendResponse({ ok: true, identity, cachedAt }))
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (message.type === 'GET_CONFIG') {
    sendResponse({ ok: true, config: classifyApiHost() });
    return false;   // synchronous response
  }

  // Returns the cached version-check result for the popup to render its
  // update banner. Triggers a fresh check in the background if requested
  // (e.g. user opened the popup and we want a freshly-warm result next
  // time they open it). Never throws — returns { status: null } if
  // nothing has been cached yet.
  if (message.type === 'GET_UPDATE_STATUS') {
    chrome.storage.local.get(['gowarm_update_check'], (r) => {
      sendResponse({ ok: true, status: r.gowarm_update_check || null });
    });
    // Fire-and-forget refresh — don't block the response on it.
    if (message.refresh) checkForUpdate();
    return true;
  }

  // Forwarded automatically by auth_bridge.js when GoWarmCRM is open
  if (message.type === 'SAVE_TOKEN') {
    saveToken(message.token).then(() => sendResponse({ ok: true }));
    return true;
  }

  if (message.type === 'GET_TOKEN') {
    getToken().then(token => sendResponse({ token }));
    return true;
  }

  if (message.type === 'CLEAR_TOKEN') {
    clearToken().then(() => sendResponse({ ok: true }));
    return true;
  }

  // Popup requests an immediate harvest attempt
  if (message.type === 'TRY_HARVEST') {
    harvestTokenFromOpenTab()
      .then(token => sendResponse({ ok: !!token, token }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }
});
