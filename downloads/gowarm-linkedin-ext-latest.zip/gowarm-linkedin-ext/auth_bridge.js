// auth_bridge.js
// Injected silently into app.gowarmcrm.com by the Chrome extension.
// Reads the JWT token from localStorage and forwards it to the
// background service worker. Runs every time GoWarmCRM loads.
// The user never sees or interacts with this — it's fully automatic.

(function () {
  'use strict';

  function readAndForwardToken() {
    // GoWarmCRM stores the token under one of these keys
    const token =
      localStorage.getItem('token') ||
      localStorage.getItem('authToken') ||
      localStorage.getItem('gowarm_token') ||
      null;

    if (!token) return; // not logged in yet — nothing to forward

    // Send to background worker which stores it in chrome.storage.local
    chrome.runtime.sendMessage({ type: 'SAVE_TOKEN', token }, (response) => {
      if (chrome.runtime.lastError) {
        // Extension may have been reloaded — safe to ignore
        return;
      }
    });
  }

  // Run immediately on page load (covers hard refreshes and direct navigation)
  readAndForwardToken();

  // Also watch for token being written after login (covers SPA login flow
  // where the page doesn't reload but localStorage is written post-auth)
  const _setItem = localStorage.setItem.bind(localStorage);
  localStorage.setItem = function (key, value) {
    _setItem(key, value);
    if (key === 'token' || key === 'authToken' || key === 'gowarm_token') {
      chrome.runtime.sendMessage({ type: 'SAVE_TOKEN', token: value }, () => {
        if (chrome.runtime.lastError) return;
      });
    }
  };

  // Also watch for token removal (logout) — clear from extension storage too
  const _removeItem = localStorage.removeItem.bind(localStorage);
  localStorage.removeItem = function (key) {
    _removeItem(key);
    if (key === 'token' || key === 'authToken' || key === 'gowarm_token') {
      chrome.runtime.sendMessage({ type: 'CLEAR_TOKEN' }, () => {
        if (chrome.runtime.lastError) return;
      });
    }
  };

})();
