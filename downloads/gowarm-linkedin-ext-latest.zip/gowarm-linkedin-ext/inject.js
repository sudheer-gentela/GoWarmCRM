// inject.js — runs in the PAGE WORLD (not the extension's isolated world).
//
// Loaded by content.js via <script src=chrome-extension://<id>/inject.js>,
// because LinkedIn's CSP blocks inline scripts but allows extension files
// listed in manifest.json's web_accessible_resources.
//
// Installs window.__gowarmCapture(), window.__gowarmCaptureDebug() and
// window.__gowarmCaptureHydrate() so you can call profile extraction directly
// from DevTools console:
//
//     (await __gowarmCaptureDebug())     // full diagnostic object (reads DOM as-is)
//     (await __gowarmCaptureHydrate())   // hydrate lazy sections + expand "see more", THEN diagnose
//     (await __gowarmCapture())          // production payload
//     copy(JSON.stringify(await __gowarmCaptureDebug(), null, 2))   // to clipboard
//
// Extraction itself runs back inside the content-script world via a
// CustomEvent ping/pong — see content.js for the listener.

(function () {
  if (window.__gowarmCapture) return;   // idempotent — guards against double-injection

  function call(mode, timeoutMs) {
    return new Promise((resolve, reject) => {
      const requestId = 'req_' + Math.random().toString(36).slice(2);
      const timeout = setTimeout(() => {
        document.removeEventListener('gowarm:capture-response', handler);
        reject(new Error('GoWarm capture timed out (' + Math.round((timeoutMs || 5000) / 1000) + 's) — content script may not be running'));
      }, timeoutMs || 5000);

      const handler = (e) => {
        if (e.detail && e.detail.requestId !== requestId) return;
        clearTimeout(timeout);
        document.removeEventListener('gowarm:capture-response', handler);
        resolve(e.detail ? e.detail.result : null);
      };

      document.addEventListener('gowarm:capture-response', handler);
      document.dispatchEvent(new CustomEvent('gowarm:capture-request', {
        detail: { requestId, mode },
      }));
    });
  }

  window.__gowarmCapture        = () => call('payload');
  window.__gowarmCaptureDebug   = () => call('debug');
  // Hydrate scrolls the whole page + expands "see more", so allow much longer.
  window.__gowarmCaptureHydrate = () => call('hydrate', 45000);

  console.log('[GoWarm] debug hooks ready: __gowarmCapture(), __gowarmCaptureDebug(), __gowarmCaptureHydrate()');
  console.log('[GoWarm] all return Promises — use: (await __gowarmCaptureHydrate())');
})();
