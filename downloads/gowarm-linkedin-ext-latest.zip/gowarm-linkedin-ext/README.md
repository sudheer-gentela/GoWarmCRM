# GoWarmCRM — LinkedIn Chrome Extension

Log LinkedIn interactions directly to GoWarmCRM without leaving LinkedIn.

Version 1.7.13 · Chrome Manifest V3

---

## What it does

- Detects when you're on a LinkedIn profile page
- Looks up whether that person is a prospect in your GoWarmCRM
- Shows a floating panel with their current LinkedIn status and outreach timeline
- One-tap logging for: Request Sent → Connected → Message Sent → Reply Received
- Optional note field for message content or reply summary
- Captures profile and company data directly into GoWarmCRM

---

## Requirements

- Google Chrome (or any Chromium browser — Edge, Brave, etc.)
- A GoWarmCRM account

That's it. The extension talks to the live GoWarmCRM API — there is no
backend setup, no server configuration, and nothing to deploy on your side.

---

## Install (3 steps, ~1 minute)

1. Open Chrome and go to `chrome://extensions`
2. Enable **Developer mode** (toggle in the top-right corner)
3. Click **Load unpacked** and select the `gowarm-linkedin-ext/` folder
   (the folder containing `manifest.json`)

The GoWarmCRM icon will appear in your Chrome toolbar. Pin it for easy access:
click the puzzle-piece icon in the toolbar, then the pin next to GoWarmCRM.

---

## Connecting to your account

The extension authenticates automatically. Just make sure you're signed in
to GoWarmCRM:

1. Open `https://app.gowarmcrm.com` in a Chrome tab and sign in
2. The extension picks up your session automatically — no token to copy or paste
3. Click the GoWarmCRM toolbar icon to confirm it shows you as connected

If the popup says you're not signed in, open GoWarmCRM, sign in, then
reopen the popup.

---

## Using it

1. Go to any LinkedIn profile: `linkedin.com/in/username`
2. The GoWarm panel appears on the right side of the page
3. If the person is in your CRM, their timeline and status show immediately
4. Tap any event button to log it — it updates GoWarmCRM instantly
5. Use "Add a note" to record the message you sent or key points from a reply

If the person isn't in your CRM yet, the panel shows a link to add them.

---

## Matching prospects to LinkedIn profiles

The extension matches by the `linkedin_url` stored on the prospect record.
Make sure your prospects have their LinkedIn URL saved — set it when creating
a prospect, or via the Edit button in the prospect detail panel.

Format: `https://www.linkedin.com/in/username`

---

## Troubleshooting

**Panel doesn't appear**
- Make sure you're on a `linkedin.com/in/` URL (not search or feed)
- Refresh the LinkedIn page
- Check that the extension is enabled at `chrome://extensions`

**"Not in GoWarmCRM"**
- The prospect exists but has no LinkedIn URL saved — add it in GoWarmCRM first
- Or the URL format doesn't match — check for trailing slashes

**"Sign in to GoWarmCRM first"**
- Open `https://app.gowarmcrm.com`, sign in, then reopen the extension popup

**Event logs but panel doesn't update**
- It re-renders after about a second — wait a moment and it will refresh

**Need to dig deeper**
- This build ships with debug hooks. On any `linkedin.com/in/*` page, open
  Chrome DevTools (F12) → Console and run:
  - `await __gowarmCapture()` — returns the payload that would be sent
  - `await __gowarmCaptureDebug()` — richer output with layout detection and
    per-section diagnostics
  - `copy(JSON.stringify(await __gowarmCaptureDebug(), null, 2))` — copies it
    to the clipboard so you can share it

---

## Updating to a new version

When you receive a newer build:

1. Replace the `gowarm-linkedin-ext/` folder with the new one
2. Go to `chrome://extensions`
3. Click the refresh/reload icon on the GoWarmCRM card

---

## File structure

```
gowarm-linkedin-ext/
├── manifest.json       Chrome extension manifest (MV3)
├── background.js       Service worker — API calls + auto-auth
├── content.js          Injected into linkedin.com/in/* — renders the panel
├── auth_bridge.js      Injected into app.gowarmcrm.com — picks up your session
├── inject.js           Page-context helper for profile data capture
├── popup/
│   ├── popup.html      Extension toolbar popup
│   └── popup.js        Popup logic
└── icons/
    ├── icon16.png
    ├── icon48.png
    └── icon128.png
```

---

## Privacy

Your GoWarmCRM session stays in your browser. The extension communicates only
with `app.gowarmcrm.com` / `api.gowarmcrm.com` (to read and log prospect
activity) and reads LinkedIn profile pages you visit. It does not send data
anywhere else.
