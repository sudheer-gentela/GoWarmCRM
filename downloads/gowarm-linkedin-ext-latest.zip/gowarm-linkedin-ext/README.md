# GoWarmCRM — LinkedIn Chrome Extension

Log LinkedIn interactions, capture profile and company data, sync connection
requests and messages, and (opt-in) auto-send connection requests — directly
to GoWarmCRM.

Version 1.24.4 · Chrome Manifest V3

---

## What it does

- Detects when you're on a LinkedIn profile page and looks up whether that
  person is a prospect in your GoWarmCRM
- Shows a floating panel with their current LinkedIn status and outreach timeline
- One-tap logging for: Request Sent → Connected → Message Sent → Reply Received
- Optional note field for message content or reply summary
- **Captures profile data** directly into GoWarmCRM — added to your default
  campaign and sequence, or standalone
- **Captures company pages** (`linkedin.com/company/*`) — firmographics,
  visible employees, and observed activity flow in as accounts, prospect
  candidates, and signals
- **Connection sync** — one click reconciles your sent invitations and
  acceptances with GoWarmCRM in bulk (this is what triggers a sequence's
  stop-on-connection-accept)
- **Message sync** — resolves your conversation threads to tracked prospects
  and harvests those messages into GoWarmCRM, so LinkedIn replies stop
  sequences just like email replies do
- **Connection auto-send** (opt-in, org-gated) — queued connection requests
  send themselves with a hard daily cap, randomized delays, a working-hours
  window, and an immediate halt on any LinkedIn security challenge

---

## Requirements

- Google Chrome (or any Chromium browser — Edge, Brave, etc.)
- A GoWarmCRM account

That's it. The extension talks to the live GoWarmCRM API — there is no
backend setup, no server configuration, and nothing to deploy on your side.

---

## Install (3 steps, ~1 minute)

1. Open Chrome and go to `chrome://extensions`
2. Enable **Developer mode** (toggle in the top-right corner)
3. Click **Load unpacked** and select the `gowarm-linkedin-ext/` folder
   (the folder containing `manifest.json`)

The GoWarmCRM icon will appear in your Chrome toolbar. Pin it for easy access:
click the puzzle-piece icon in the toolbar, then the pin next to GoWarmCRM.

---

## Connecting to your account

The extension authenticates automatically. Just make sure you're signed in
to GoWarmCRM:

1. Open `https://app.gowarmcrm.com` in a Chrome tab and sign in
2. The extension picks up your session automatically — no token to copy or paste
3. Click the GoWarmCRM toolbar icon to confirm it shows you as connected

If the popup says you're not signed in, open GoWarmCRM, sign in, then
reopen the popup (there's a "Try connecting now" button if it needs a nudge).

---

## Using it

### On a profile

1. Go to any LinkedIn profile: `linkedin.com/in/username`
2. The GoWarm panel appears on the right side of the page
3. If the person is in your CRM, their timeline and status show immediately
4. Tap any event button to log it — it updates GoWarmCRM instantly
5. Use "Add a note" to record the message you sent or key points from a reply

If the person isn't in your CRM yet, capture them — review the fields
inline, save, and they land in your research queue (enrolled in your
default campaign and sequence if you've set them).

### On a company page

Open `linkedin.com/company/name` and capture the company — firmographics
come in as an account, visible employees as prospect candidates, and what
you observed feeds the signal store for signal-driven campaigns.

### From the popup

- **Check & update sent / accepted** — reconciles connection requests and
  acceptances with GoWarmCRM in bulk
- **Resolve identities**, then **Sync messages** — maps your threads to
  tracked prospects (in batches; re-click to continue) and harvests those
  conversations. Each message is recorded exactly once, so re-running is
  always safe
- **Push defaults** — the campaign and sequence new captures land in.
  Leave both blank to save captures as standalone prospects

A good habit: end every LinkedIn session with *Check & update* and *Sync
messages* — replies only stop sequences once GoWarmCRM has seen them.

### Connection auto-send

Requires both your org admin enabling it (Org Admin → Prospecting →
LinkedIn) **and** you opting in (Settings → LinkedIn Auto-Connect, where
you can also set a personal daily cap). Guardrails: hard rolling-24h cap
per rep, randomized delay between sends, working-hours window, and an
instant stop on any LinkedIn security prompt — no retries until a human
resolves it.

⚠️ Automating actions on LinkedIn is against LinkedIn's terms of service
and carries account risk regardless of guardrails. Keep caps conservative.

---

## Matching prospects to LinkedIn profiles

The extension matches by the `linkedin_url` stored on the prospect record.
Make sure your prospects have their LinkedIn URL saved — set it when creating
a prospect, or via the Edit button in the prospect detail panel.

Format: `https://www.linkedin.com/in/username`

---

## Troubleshooting

**Panel doesn't appear**
- Make sure you're on a `linkedin.com/in/` URL (not search or feed)
- Refresh the LinkedIn page
- Check that the extension is enabled at `chrome://extensions`

**"Not in GoWarmCRM"**
- The prospect exists but has no LinkedIn URL saved — add it in GoWarmCRM first
- Or the URL format doesn't match — check for trailing slashes

**"Sign in to GoWarmCRM first"**
- Open `https://app.gowarmcrm.com`, sign in, then reopen the extension popup

**Event logs but panel doesn't update**
- It re-renders after about a second — wait a moment and it will refresh

**Sync buttons seem to do nothing**
- Identity resolution runs in batches — re-click "Resolve identities" to
  continue through your list, then run "Sync messages"

**Behaving oddly after an update**
- Reload the extension at `chrome://extensions` and hard-refresh LinkedIn

**Need to dig deeper**
- This build ships with debug hooks. On any `linkedin.com/in/*` page, open
  Chrome DevTools (F12) → Console and run:
  - `await __gowarmCapture()` — returns the payload that would be sent
  - `await __gowarmCaptureDebug()` — richer output with layout detection and
    per-section diagnostics
  - `copy(JSON.stringify(await __gowarmCaptureDebug(), null, 2))` — copies it
    to the clipboard so you can share it

---

## Updating to a new version

The popup shows a banner when a newer version is available, with a link to
the install page. Then:

1. Replace the `gowarm-linkedin-ext/` folder with the new one
2. Go to `chrome://extensions`
3. Click the refresh/reload icon on the GoWarmCRM card (or use the popup's
   "Reload extension" button)

Updating never touches your connection or push defaults — they carry over.

---

## File structure

```
gowarm-linkedin-ext/
├── manifest.json        Chrome extension manifest (MV3)
├── background.js        Service worker — API calls, auto-auth, auto-send
├── content.js           Injected into linkedin.com/in/* — renders the panel
├── company_content.js   Injected into linkedin.com/company/* — company capture
├── li_net_capture.js    Page-context capture helper (runs on linkedin.com)
├── auth_bridge.js       Injected into app.gowarmcrm.com — picks up your session
├── inject.js            Page-context helper for profile data capture
├── popup/
│   ├── popup.html       Extension toolbar popup
│   └── popup.js         Popup logic
└── icons/
    ├── gw-flame.png
    ├── icon16.png
    ├── icon48.png
    └── icon128.png
```

---

## Privacy

Your GoWarmCRM session stays in your browser. The extension communicates only
with `app.gowarmcrm.com` / `api.gowarmcrm.com` (to read and log prospect
activity) and reads LinkedIn pages you visit. Message sync only persists
conversations with prospects you're tracking in GoWarmCRM — the rest of your
inbox is never read into the system. It does not send data anywhere else.
