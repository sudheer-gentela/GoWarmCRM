// popup.js — GoWarmCRM LinkedIn Extension v1.7.1
//
// Three views: connected (compact), disconnected, and settings.
// - Connected shows the most important fact (you're connected, as
//   <email>) plus a single primary action ("Open GoWarmCRM"). The
//   gear icon in the header opens settings.
// - Settings shows the full account / workspace / backend breakdown
//   plus a manual "Refresh now" action that bypasses the background
//   worker's 10-minute identity TTL. Disconnect lives here too,
//   intentionally far from the everyday button so it can't be
//   fat-fingered.
// - Disconnected stays the same as v1.5 — no settings until auth.

function bgMessage(payload) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(payload, response => {
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else resolve(response);
    });
  });
}

function showFeedback(el, msg, type) {
  el.textContent = msg;
  el.className = `feedback ${type}`;
  el.style.display = 'block';
  if (type === 'success') setTimeout(() => { el.style.display = 'none'; }, 3000);
}

// ── View toggling ────────────────────────────────────────────────────────────
//
// Three views, exactly one active at a time. We don't try to preserve
// scroll/state across switches because the popup is small and short-
// lived; each switch re-renders the content it needs.

function showView(name) {
  ['connected', 'disconnected', 'settings'].forEach(v => {
    const el = document.getElementById(`view-${v}`);
    if (el) el.classList.toggle('active', v === name);
  });
}

// ── Backend host + env pill ──────────────────────────────────────────────────
//
// Renders the API base host with a prod/non-prod pill. Reused across
// disconnected (#id-host-disc) and settings (#set-host) views — both
// surface the destination so the user can verify it.
async function renderConfig({ hostId, envId, envNameId }) {
  const hostEl    = document.getElementById(hostId);
  const envEl     = document.getElementById(envId);
  const envNameEl = envNameId ? document.getElementById(envNameId) : null;
  if (!hostEl || !envEl) return;

  try {
    const res = await bgMessage({ type: 'GET_CONFIG' });
    const cfg = res?.config;
    if (!cfg) return;

    // Replace the host text node, keeping the pill <span> intact.
    hostEl.firstChild && hostEl.removeChild(hostEl.firstChild);
    const host = document.createTextNode(cfg.host || cfg.api_base);
    hostEl.insertBefore(host, envEl);

    envEl.textContent = cfg.is_prod ? 'PROD' : 'NON-PROD';
    envEl.className   = `env-pill ${cfg.is_prod ? 'prod' : 'nonprod'}`;
    envEl.style.display = 'inline-block';

    if (envNameEl) {
      envNameEl.textContent = cfg.is_prod
        ? 'Production'
        : 'Non-production (staging, dev, or custom host)';
    }
  } catch (_) {
    // Stay quiet — config never fails in practice.
  }
}

// ── Compact identity (connected view) ────────────────────────────────────────
//
// Just email + workspace, in a small teal card. Anything else — role,
// workspace ID, last-refreshed time — lives behind the gear so the
// default view stays scannable.
async function renderCompactIdentity({ force = false } = {}) {
  const emailEl = document.getElementById('compact-email');
  const orgEl   = document.getElementById('compact-org');

  if (force) {
    emailEl.textContent = 'Loading…';
    orgEl.textContent   = 'Loading…';
    emailEl.classList.add('skeleton');
    orgEl.classList.add('skeleton');
  }

  try {
    const res = await bgMessage({ type: 'GET_IDENTITY', force });
    if (!res?.ok || !res.identity) {
      emailEl.textContent = '—';
      orgEl.textContent   = 'Identity unavailable';
      emailEl.classList.remove('skeleton');
      orgEl.classList.remove('skeleton');
      return;
    }
    const id = res.identity;
    emailEl.textContent = id.email || '(no email)';
    emailEl.title       = id.email || '';
    orgEl.textContent   = id.org_name
      ? `${id.org_name}${id.org_role ? ' · ' + id.org_role : ''}`
      : (id.org_id ? `Workspace #${id.org_id}` : 'No workspace');
    emailEl.classList.remove('skeleton');
    orgEl.classList.remove('skeleton');
  } catch (err) {
    emailEl.textContent = '—';
    orgEl.textContent   = `(${err.message || 'identity unavailable'})`;
    emailEl.classList.remove('skeleton');
    orgEl.classList.remove('skeleton');
  }
}

// ── Settings view rendering ──────────────────────────────────────────────────
//
// Populates every detail row in the settings view from the cached
// (or freshly-fetched) identity. Skeleton classes are removed once
// the value is set so the placeholder grey colour goes away even when
// the value is "—".
async function renderSettings({ force = false } = {}) {
  const setText = (id, val) => {
    const el = document.getElementById(id);
    if (!el) return;
    el.textContent = (val === null || val === undefined || val === '') ? '—' : val;
    el.classList.remove('skeleton');
  };

  // Show skeleton state when forcing a refresh so the user sees the
  // refresh actually happening — otherwise stale values would just
  // sit there until the new fetch returns.
  if (force) {
    ['set-name', 'set-email', 'set-role', 'set-org-name', 'set-org-id'].forEach(id => {
      const el = document.getElementById(id);
      if (!el) return;
      el.textContent = 'Loading…';
      el.classList.add('skeleton');
    });
    document.getElementById('set-cached-at').textContent = 'Refreshing…';
  }

  try {
    const res = await bgMessage({ type: 'GET_IDENTITY', force });
    if (!res?.ok || !res.identity) {
      // Fail soft — leave the rows showing — and surface the error.
      const fb = document.getElementById('settings-feedback');
      if (fb) showFeedback(fb, res?.error || 'Could not load account info', 'error');
      // Clear skeletons so the user isn't stuck on "Loading…"
      ['set-name', 'set-email', 'set-role', 'set-org-name', 'set-org-id'].forEach(id => setText(id, '—'));
      setText('set-cached-at', '—');
      return;
    }

    const id = res.identity;
    const fullName = [id.first_name, id.last_name].filter(Boolean).join(' ').trim();

    setText('set-name',     fullName || '(no name)');
    setText('set-email',    id.email);
    setText('set-role',     id.org_role);
    setText('set-org-name', id.org_name);
    setText('set-org-id',
      (id.org_id != null || id.org_slug)
        ? `${id.org_id != null ? `#${id.org_id}` : ''}${id.org_slug ? `  ·  ${id.org_slug}` : ''}`
        : null
    );

    // Last-refreshed timestamp. cachedAt is a unix-ms value coming
    // from the background worker — it's the time of the last
    // successful /verify call, which may be different from "now"
    // even when force=true (rare race, but possible).
    if (res.cachedAt) {
      setText('set-cached-at', formatRelativeShort(res.cachedAt));
    } else {
      setText('set-cached-at', 'just now');
    }
  } catch (err) {
    const fb = document.getElementById('settings-feedback');
    if (fb) showFeedback(fb, err.message || 'Refresh failed', 'error');
  }
}

// Smaller variant of the formatter used in content.js — settings shows
// "just now" / "2m ago" / "Mar 14, 9:32 AM" rather than the bigger
// stepped buckets the in-page panel uses.
function formatRelativeShort(unixMs) {
  if (!unixMs) return '—';
  const diffSec = Math.floor((Date.now() - unixMs) / 1000);
  if (diffSec < 30)        return 'just now';
  if (diffSec < 60)        return `${diffSec}s ago`;
  if (diffSec < 3600)      return `${Math.floor(diffSec / 60)}m ago`;
  if (diffSec < 86400)     return `${Math.floor(diffSec / 3600)}h ago`;
  const d = new Date(unixMs);
  return d.toLocaleString(undefined, {
    month: 'short', day: 'numeric',
    hour: 'numeric', minute: '2-digit',
  });
}

// ── Push defaults (v1.8) ────────────────────────────────────────────────────
//
// Renders the two dropdowns that let the rep pick a default campaign +
// sequence for prospects captured from LinkedIn. Both are optional; an
// empty selection means "save as standalone prospect", preserving the
// pre-v1.8 behavior.
//
// Persistence: scoped per-org under chrome.storage.local key
// `gw_push_defaults_<orgId>`. Switching CRM accounts in another tab
// would otherwise carry the wrong campaign id over. We rely on
// GET_IDENTITY to give us the right org_id.
//
// Failures here are non-fatal — if the lists don't load, the dropdowns
// show "(could not load)" but the rest of Settings keeps working. The
// in-page panel separately re-fetches the lists when the rep opens the
// inline override on a profile, so even a broken popup load doesn't
// permanently break the push flow.

const PUSH_DEFAULTS_KEY_PREFIX = 'gw_push_defaults_';

function pushDefaultsStorageKey(orgId) {
  return orgId ? `${PUSH_DEFAULTS_KEY_PREFIX}${orgId}` : null;
}

function readPushDefaults(orgId) {
  return new Promise(resolve => {
    const key = pushDefaultsStorageKey(orgId);
    if (!key) return resolve({ campaignId: null, sequenceId: null });
    chrome.storage.local.get([key], result => {
      const v = result[key] || {};
      resolve({
        campaignId: v.campaignId || null,
        sequenceId: v.sequenceId || null,
      });
    });
  });
}

function writePushDefaults(orgId, { campaignId, sequenceId }) {
  return new Promise(resolve => {
    const key = pushDefaultsStorageKey(orgId);
    if (!key) return resolve();
    chrome.storage.local.set({
      [key]: {
        campaignId: campaignId || null,
        sequenceId: sequenceId || null,
        updated_at: Date.now(),
      },
    }, resolve);
  });
}

// Tracks whether the rep has manually changed the sequence on this
// popup-open. While false, picking a campaign auto-fills the sequence
// with that campaign's default. Once they touch the sequence directly,
// auto-fill stops — explicit user choice wins. Re-set on each popup open
// because the popup is short-lived; we don't want stickiness across
// closes.
let userManuallyPickedSequence = false;

async function renderPushDefaults() {
  const campSel    = document.getElementById('set-default-campaign');
  const seqSel     = document.getElementById('set-default-sequence');
  const savedFlag  = document.getElementById('push-defaults-saved');
  if (!campSel || !seqSel) return;

  // Reset auto-fill tracking on every render of this view. If the rep
  // closed and re-opened the popup, we treat them as starting fresh.
  userManuallyPickedSequence = false;

  // We need org_id to scope storage. If identity isn't ready yet (rare
  // — renderSettings is called first and warms the cache), wait for it.
  let orgId = null;
  try {
    const idRes = await bgMessage({ type: 'GET_IDENTITY' });
    orgId = idRes?.identity?.org_id || null;
  } catch (_) { /* leave orgId null — dropdowns will still render, picks won't persist */ }

  // Load both lists in parallel and the saved selection alongside.
  // None of these blocks UI — until they all resolve the user sees
  // the "Loading…" placeholder option.
  const [listRes, saved] = await Promise.all([
    bgMessage({ type: 'LIST_CAMPAIGNS_AND_SEQUENCES' }).catch(err => ({ ok: false, error: err.message })),
    readPushDefaults(orgId),
  ]);

  if (!listRes?.ok) {
    campSel.innerHTML = '<option value="">(could not load campaigns)</option>';
    seqSel.innerHTML  = '<option value="">(could not load sequences)</option>';
    campSel.disabled  = true;
    seqSel.disabled   = true;
    return;
  }

  const campaigns = listRes.campaigns || [];
  const sequences = listRes.sequences || [];

  // Always render "No campaign" / "No sequence" as the first option so
  // the rep can deliberately UN-set the default. Empty placeholder
  // labels would conflate "nothing set" with "I haven't picked yet".
  campSel.innerHTML = ['<option value="">No campaign — save as standalone</option>']
    .concat(campaigns.map(c => `<option value="${c.id}">${escapeHtmlText(c.name)}</option>`))
    .join('');

  seqSel.innerHTML = ['<option value="">No sequence — don\'t enroll</option>']
    .concat(sequences.map(s => {
      const stepLabel = s.step_count ? ` (${s.step_count} step${s.step_count === 1 ? '' : 's'})` : '';
      return `<option value="${s.id}">${escapeHtmlText(s.name)}${stepLabel}</option>`;
    }))
    .join('');

  // Restore the saved picks — but only if those ids still exist in the
  // current list. Items can be archived since the rep last set them; we
  // silently fall back to "no selection" rather than confusing them with
  // a missing-id error.
  if (saved.campaignId && campaigns.some(c => String(c.id) === String(saved.campaignId))) {
    campSel.value = String(saved.campaignId);
  }
  if (saved.sequenceId && sequences.some(s => String(s.id) === String(saved.sequenceId))) {
    seqSel.value = String(saved.sequenceId);
    // A restored sequence is a deliberate prior choice — treat it as
    // manual so an unrelated campaign change doesn't clobber it.
    userManuallyPickedSequence = true;
  }

  const flashSaved = () => {
    if (!savedFlag) return;
    savedFlag.classList.add('visible');
    setTimeout(() => savedFlag.classList.remove('visible'), 1500);
  };

  // Both selects save on change. We don't debounce — there's nothing
  // sensitive about repeated writes, and immediate persistence means
  // the rep can close the popup right after a change without losing it.
  campSel.addEventListener('change', async () => {
    if (!userManuallyPickedSequence) {
      const picked = campaigns.find(c => String(c.id) === campSel.value);
      const defSeqId = picked?.default_sequence_id || null;
      if (defSeqId && sequences.some(s => String(s.id) === String(defSeqId))) {
        seqSel.value = String(defSeqId);
      }
    }
    await writePushDefaults(orgId, {
      campaignId: campSel.value ? parseInt(campSel.value, 10) : null,
      sequenceId: seqSel.value  ? parseInt(seqSel.value, 10)  : null,
    });
    flashSaved();
  });

  seqSel.addEventListener('change', async () => {
    userManuallyPickedSequence = true;
    await writePushDefaults(orgId, {
      campaignId: campSel.value ? parseInt(campSel.value, 10) : null,
      sequenceId: seqSel.value  ? parseInt(seqSel.value, 10)  : null,
    });
    flashSaved();
  });
}

// Inline-safe text escaper for the dropdown options. Campaign/sequence
// names are user-controlled, so they could contain <, &, etc. — escape
// before stuffing into innerHTML.
function escapeHtmlText(str) {
  return String(str ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

// ── Update banner ────────────────────────────────────────────────────────────
//
// Reads the cached version-check result from background and, if a newer
// version is available, shows a banner in whichever view is currently
// active (connected or disconnected). The settings view doesn't show
// the banner — it's behind the gear and would only repeat what the
// top-level views already say.
//
// We never fail loudly. If the check has never run, or the network was
// down, status will be null/empty and we simply don't show the banner.

async function renderUpdateBanner() {
  let status;
  try {
    const res = await bgMessage({ type: 'GET_UPDATE_STATUS', refresh: true });
    status = res?.status;
  } catch (_) { return; }

  if (!status || !status.update_available) return;

  const url = status.download_url || 'https://app.gowarmcrm.com/install-extension';
  const versionsText = `Installed v${status.current} · Latest v${status.latest}`;

  ['connected', 'disconnected'].forEach(view => {
    const banner = document.getElementById(`update-banner-${view}`);
    const link   = document.getElementById(`update-link-${view}`);
    const vers   = document.getElementById(`update-versions-${view}`);
    const reload = document.getElementById(`update-reload-${view}`);
    if (!banner || !link || !vers) return;
    link.href = url;
    vers.textContent = versionsText;
    banner.classList.add('visible');

    // Open the install page in a new tab. Using chrome.tabs.create is
    // more reliable than a plain href click from inside the popup
    // (which sometimes closes before the navigation lands).
    link.addEventListener('click', (e) => {
      e.preventDefault();
      chrome.tabs.create({ url });
    });

    // "Reload extension" — for the case where the user has already
    // replaced the extension folder with the new version but hasn't
    // gone to chrome://extensions to click the reload icon there.
    // Sending RELOAD_EXTENSION to the service worker triggers
    // chrome.runtime.reload(), which re-reads the unpacked folder
    // from disk and restarts every component cleanly. The popup
    // closes automatically when the extension reloads.
    //
    // If the folder hasn't been replaced yet, this still runs — but
    // it just reloads the same code, which is harmless. The button's
    // hint text tells users to replace the folder first, and the
    // version-check on next startup will keep nagging them if they
    // haven't actually upgraded.
    if (reload) {
      reload.addEventListener('click', async () => {
        reload.disabled    = true;
        reload.textContent = 'Reloading…';
        try {
          await bgMessage({ type: 'RELOAD_EXTENSION' });
        } catch (_) {
          // The popup gets torn down as part of the reload, so we
          // rarely see the response — that's expected, not an error.
        }
      });
    }
  });
}

// Stamp the manifest's version into every .ext-version element so the
// popup footer and settings row always agree with the actual build,
// instead of drifting like the old hardcoded "1.7.1" strings did.
function stampExtensionVersion() {
  const v = chrome.runtime.getManifest().version;
  document.querySelectorAll('.ext-version').forEach(el => { el.textContent = v; });
}

// ── Connection-activity panel (v1.9) ────────────────────────────────────────
//
// Renders the READ_CONNECTION_ACTIVITY result: two groups (sent-pending,
// recently-accepted) with a count + short scrollable name list each, plus a
// collapsible raw sample for tuning the parser against the live shape. All
// ── Connection-activity persistence (v1.10.3) ───────────────────────────────
//
// The scrape is ephemeral, so the popup would start blank every open. We cache
// the last result in chrome.storage.local, keyed by the viewer's LinkedIn slug
// (so a second rep's data never overwrites the first). Because "sent" comes
// from the Sent page and "accepted" from the Connections page — two different
// tabs/visits — we MERGE on save: a sent-only scrape keeps the previously
// cached accepted list, and vice-versa, so the two accumulate instead of
// clobbering each other.
const CONN_CACHE_PREFIX = 'gw_conn_activity_';

function connCacheKey(viewer) {
  const slug = (viewer && viewer.publicIdentifier) ? viewer.publicIdentifier : 'default';
  return CONN_CACHE_PREFIX + slug;
}

function saveConnActivity(data) {
  return new Promise((resolve) => {
    const key = connCacheKey(data.viewer);
    chrome.storage.local.get([key], (o) => {
      const prev = o[key] || null;
      const merged = {
        viewer:   data.viewer   || (prev && prev.viewer)   || null,
        sent:     data.sent     || (prev && prev.sent)     || null,
        accepted: data.accepted || (prev && prev.accepted) || null,
        ts: Date.now(),
      };
      chrome.storage.local.set({ [key]: merged }, () => resolve(merged));
    });
  });
}

// Load the most recently saved activity across any cached account.
function loadConnActivity() {
  return new Promise((resolve) => {
    chrome.storage.local.get(null, (all) => {
      const entries = Object.keys(all)
        .filter(k => k.startsWith(CONN_CACHE_PREFIX))
        .map(k => all[k])
        .filter(Boolean);
      if (!entries.length) return resolve(null);
      entries.sort((a, b) => (b.ts || 0) - (a.ts || 0));
      resolve(entries[0]);
    });
  });
}

// DOM is built with createElement/textContent — member names/headlines are
// untrusted, so never via innerHTML.
function renderConnResults(box, data) {
  box.innerHTML = '';
  if (!data) return;

  // "Last checked" line — shown for cached results so the user knows the data
  // may be stale and that Check re-scrapes.
  if (data._cachedTs) {
    const stamp = document.createElement('div');
    stamp.className = 'conn-updated';
    const fresh = (Date.now() - data._cachedTs) < 4000;
    stamp.textContent = fresh ? 'Updated just now' : ('Last checked ' + formatRelativeShort(data._cachedTs));
    box.appendChild(stamp);
  }

  const group = (label, g) => {
    const wrap = document.createElement('div');
    wrap.className = 'conn-group';

    const head = document.createElement('div');
    head.className = 'conn-group-head';
    const lab = document.createElement('span');
    lab.className = 'conn-group-label';
    lab.textContent = label;
    const n = (g && g.peopleCount) ? g.peopleCount : 0;
    const cnt = document.createElement('span');
    cnt.className = 'conn-count' + (n ? '' : ' zero');
    cnt.textContent = String(n);
    head.appendChild(lab);
    head.appendChild(cnt);
    wrap.appendChild(head);

    if (g && g.status === 200 && n > 0) {
      const ul = document.createElement('ul');
      ul.className = 'conn-list';
      g.people.forEach(p => {
        const li = document.createElement('li');
        const name = document.createElement('div');
        name.className = 'conn-name';
        if (p.url) {
          const a = document.createElement('a');
          a.href = p.url; a.target = '_blank'; a.rel = 'noopener';
          a.textContent = p.name || p.publicIdentifier || '(unknown)';
          name.appendChild(a);
        } else {
          name.textContent = p.name || '(unknown)';
        }
        li.appendChild(name);
        const meta = p.headline || p.timeText;
        if (meta) {
          const h = document.createElement('div');
          h.className = 'conn-headline';
          h.textContent = [p.headline, p.timeText].filter(Boolean).join(' · ');
          li.appendChild(h);
        }
        ul.appendChild(li);
      });
      wrap.appendChild(ul);
    } else {
      const e = document.createElement('div');
      e.className = 'conn-empty';
      e.textContent = !g
        ? 'None recorded yet.'
        : (g.status === 200 ? 'None found.' : `Couldn't read (status ${g.status}).`);
      wrap.appendChild(e);
    }

    if (g && g.endpoint) {
      const ep = document.createElement('div');
      ep.className = 'conn-endpoint';
      ep.textContent = g.endpoint
        .replace('https://www.linkedin.com/voyager/api/', '…/')
        .slice(0, 90);
      wrap.appendChild(ep);
    }
    return wrap;
  };

  // Logged-in LinkedIn identity this activity belongs to.
  const v = data.viewer;
  if (v && (v.name || v.publicIdentifier)) {
    const head = document.createElement('div');
    head.className = 'conn-viewer';
    head.textContent = 'LinkedIn account: ';
    const strong = document.createElement('span');
    strong.className = 'conn-viewer-name';
    if (v.url) {
      const a = document.createElement('a');
      a.href = v.url; a.target = '_blank'; a.rel = 'noopener';
      a.textContent = v.name || v.publicIdentifier;
      strong.appendChild(a);
    } else {
      strong.textContent = v.name || v.publicIdentifier;
    }
    head.appendChild(strong);
    if (v.publicIdentifier && v.name) {
      const slug = document.createElement('span');
      slug.className = 'conn-viewer-slug';
      slug.textContent = ' · ' + v.publicIdentifier;
      head.appendChild(slug);
    }
    box.appendChild(head);
  }

  box.appendChild(group('Sent · pending', data.sent));
  box.appendChild(group('Recently accepted', data.accepted));

  // Empty state — LinkedIn loads this data lazily, so the user has to visit the
  // pages once (this turn) for us to record the requests.
  if (data.needsBrowse) {
    const tip = document.createElement('div');
    tip.className = 'conn-tip';
    tip.innerHTML =
      'Open a LinkedIn tab on <b>My Network → Manage → Sent</b> then click ' +
      '<b>Check &amp; update sent</b> — or <b>My Network → Connections</b> then click ' +
      '<b>Check &amp; update accepted</b>. Each reads the page you have open and ' +
      'updates your prospects in GoWarmCRM.';
    box.appendChild(tip);
  }

  const hasSample = (data.sent && data.sent.rawSample) || (data.accepted && data.accepted.rawSample);
  if (hasSample) {
    const det = document.createElement('details');
    det.className = 'conn-raw';
    const sum = document.createElement('summary');
    sum.textContent = 'Raw response sample';
    const pre = document.createElement('pre');
    pre.textContent =
      'SENT: ' + ((data.sent && data.sent.rawSample) || '(none)') +
      '\n\nACCEPTED: ' + ((data.accepted && data.accepted.rawSample) || '(none)') +
      '\n\nFull objects → open the LinkedIn tab DevTools console: window.__gowarmConnRaw';
    det.appendChild(sum);
    det.appendChild(pre);
    box.appendChild(det);
  }
}

function friendlyConnError(err) {
  if (err === 'NO_JSESSIONID') return 'Not logged into LinkedIn in this browser. Open linkedin.com and sign in, then retry.';
  if (err === 'NO_RESULT')     return 'No response from the LinkedIn tab. Make sure linkedin.com is reachable, then retry.';
  return err || 'Could not read connection activity.';
}

// ── Wire up everything on DOMContentLoaded ───────────────────────────────────

document.addEventListener('DOMContentLoaded', async () => {
  stampExtensionVersion();
  renderUpdateBanner();  // fire-and-forget; failures are silent

  // Backend host + env pill: render in BOTH views that need it.
  // Connected view doesn't show backend in the compact card — it lives
  // in settings. So only disconnected + settings need the host pill.
  renderConfig({ hostId: 'id-host-disc', envId: 'id-env-disc' });
  renderConfig({ hostId: 'set-host',     envId: 'set-env', envNameId: 'set-env-name' });

  // Decide initial view based on token presence.
  const { token } = await bgMessage({ type: 'GET_TOKEN' });
  if (token) {
    showView('connected');
    renderCompactIdentity();
    // Show last-cached connection activity immediately, so the panel isn't
    // blank on open and the user can see prior results without re-scraping.
    loadConnActivity().then((cached) => {
      if (!cached) return;
      const box = document.getElementById('conn-results');
      if (!box) return;
      cached._cachedTs = cached.ts;
      cached.needsBrowse = !cached.sent && !cached.accepted;
      renderConnResults(box, cached);
    });
  } else {
    showView('disconnected');
  }

  // ── Connected view actions ─────────────────────────────────────────────────
  document.getElementById('open-crm-btn').addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://app.gowarmcrm.com' });
  });

  // ── "Check & update sent / accepted" (v1.17) ───────────────────────────────
  // Each button scrapes the relevant LinkedIn page for the logged-in member
  // AND pushes the result to the backend reconcile endpoint, which matches
  // people to THIS rep's prospects by slug and records the event idempotently.
  // The scrape result still renders below (and merges into the local cache)
  // exactly like the old read-only check did.
  async function runConnectionSync(kind) {
    const sentBtn = document.getElementById('sync-sent-btn');
    const accBtn  = document.getElementById('sync-accepted-btn');
    const btn     = kind === 'sent' ? sentBtn : accBtn;
    const idleLbl = kind === 'sent' ? 'Check & update sent' : 'Check & update accepted';
    const fb      = document.getElementById('conn-feedback');
    const box     = document.getElementById('conn-results');
    const sum     = document.getElementById('conn-sync-summary');

    sentBtn.disabled = true;
    accBtn.disabled  = true;
    btn.textContent  = 'Checking…';
    fb.style.display  = 'none';
    sum.style.display = 'none';

    try {
      const res = await bgMessage({ type: 'SYNC_CONNECTION_ACTIVITY', kind });
      console.log('[GoWarm] SYNC_CONNECTION_ACTIVITY', kind, res);

      // Whatever happened, if the scrape itself produced data, persist +
      // render it so the rep sees what was found.
      if (res && res.data) {
        const merged = await saveConnActivity(res.data);
        merged._cachedTs = merged.ts;
        merged.needsBrowse = !merged.sent && !merged.accepted;
        renderConnResults(box, merged);
      }

      if (!res || !res.ok) {
        const err = res && res.error;
        if (err === 'NOT_ON_PAGE') {
          showFeedback(fb, kind === 'sent'
            ? 'No sent invitations found. Open LinkedIn on My Network → Manage → Sent, then retry.'
            : 'No connections found. Open LinkedIn on My Network → Connections, then retry.', 'error');
        } else if (err === 'SEAT_UNKNOWN') {
          showFeedback(fb, 'Could not identify the logged-in LinkedIn account. Open linkedin.com, make sure you are signed in, then retry.', 'error');
        } else {
          // Includes backend SEAT_CONFLICT text ("…already linked to <name>…")
          showFeedback(fb, friendlyConnError(err), 'error');
        }
        return;
      }

      // Success — render the reconcile summary.
      const s = (res.result && res.result.summary) || {};
      const bits = [];
      bits.push(`✓ ${s.updated || 0} updated`);
      if (s.timestamp_backfilled) bits.push(`${s.timestamp_backfilled} backfilled`);
      bits.push(`${s.already_recorded || 0} already recorded`);
      if (s.matched_other_owner) bits.push(`${s.matched_other_owner} owned by teammates (untouched)`);
      bits.push(`${s.unmatched_count || 0} not in CRM`);
      if (kind === 'accepted' && s.accepted_without_logged_request) {
        bits.push(`${s.accepted_without_logged_request} accepted with no logged request`);
      }
      sum.textContent = bits.join(' · ');
      sum.className = 'conn-sync-summary' + ((s.updated || 0) === 0 ? ' warn' : '');
      sum.style.display = 'block';
    } catch (err) {
      showFeedback(fb, err.message || 'Sync failed', 'error');
    } finally {
      sentBtn.disabled = false;
      accBtn.disabled  = false;
      btn.textContent  = idleLbl;
    }
  }

  document.getElementById('sync-sent-btn')
    .addEventListener('click', () => runConnectionSync('sent'));
  document.getElementById('sync-accepted-btn')
    .addEventListener('click', () => runConnectionSync('accepted'));

  // Gear icon — switch to settings. We re-render the settings view
  // each time so cached values are picked up and "last refreshed"
  // reflects time-of-open, not time-of-popup-load.
  document.getElementById('open-settings-btn').addEventListener('click', () => {
    showView('settings');
    renderSettings();
    // Push defaults render in parallel — they pull from a different
    // backend endpoint (campaigns + sequences) than identity, so neither
    // blocks the other.
    renderPushDefaults();
  });

  // ── Settings view actions ──────────────────────────────────────────────────
  document.getElementById('back-from-settings-btn').addEventListener('click', () => {
    showView('connected');
    // Refresh the compact card too in case the user did a manual
    // refresh inside settings — keeps the two surfaces consistent.
    renderCompactIdentity();
  });

  document.getElementById('refresh-identity-btn').addEventListener('click', async () => {
    const btn = document.getElementById('refresh-identity-btn');
    const fb  = document.getElementById('settings-feedback');
    btn.disabled    = true;
    btn.textContent = '↻ Refreshing…';
    try {
      await renderSettings({ force: true });
      showFeedback(fb, '✓ Refreshed', 'success');
    } catch (err) {
      showFeedback(fb, err.message || 'Refresh failed', 'error');
    } finally {
      btn.disabled    = false;
      btn.textContent = '↻ Refresh now';
    }
  });

  document.getElementById('logout-btn-settings').addEventListener('click', async () => {
    await bgMessage({ type: 'CLEAR_TOKEN' });
    showView('disconnected');
  });

  // ── Disconnected view actions ──────────────────────────────────────────────
  document.getElementById('try-connect-btn').addEventListener('click', async () => {
    const btn = document.getElementById('try-connect-btn');
    const fb  = document.getElementById('disconnected-feedback');
    btn.textContent = 'Checking…';
    btn.disabled    = true;

    const res = await bgMessage({ type: 'TRY_HARVEST' });
    if (res.ok) {
      showFeedback(fb, '✓ Connected!', 'success');
      setTimeout(() => {
        showView('connected');
        // Force-refresh identity since the token just changed; the
        // background worker dropped the cached identity on token
        // change so this would re-fetch anyway, but force=true skips
        // the storage round-trip.
        renderCompactIdentity({ force: true });
      }, 800);
    } else {
      btn.textContent = 'Try connecting now';
      btn.disabled    = false;
      showFeedback(fb, 'GoWarmCRM not found. Open it in another tab and log in first.', 'error');
    }
  });

  document.getElementById('open-crm-btn2').addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://app.gowarmcrm.com' });
  });
});
