// popup.js — GoWarmCRM LinkedIn Extension v1.7.1
//
// Three views: connected (compact), disconnected, and settings.
// - Connected shows the most important fact (you're connected, as
//   <email>) plus a single primary action ("Open GoWarmCRM"). The
//   gear icon in the header opens settings.
// - Settings shows the full account / workspace / backend breakdown
//   plus a manual "Refresh now" action that bypasses the background
//   worker's 10-minute identity TTL. Disconnect lives here too,
//   intentionally far from the everyday button so it can't be
//   fat-fingered.
// - Disconnected stays the same as v1.5 — no settings until auth.

function bgMessage(payload) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(payload, response => {
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else resolve(response);
    });
  });
}

function showFeedback(el, msg, type) {
  el.textContent = msg;
  el.className = `feedback ${type}`;
  el.style.display = 'block';
  if (type === 'success') setTimeout(() => { el.style.display = 'none'; }, 3000);
}

// ── View toggling ────────────────────────────────────────────────────────────
//
// Three views, exactly one active at a time. We don't try to preserve
// scroll/state across switches because the popup is small and short-
// lived; each switch re-renders the content it needs.

function showView(name) {
  ['connected', 'disconnected', 'settings'].forEach(v => {
    const el = document.getElementById(`view-${v}`);
    if (el) el.classList.toggle('active', v === name);
  });
}

// ── Backend host + env pill ──────────────────────────────────────────────────
//
// Renders the API base host with a prod/non-prod pill. Reused across
// disconnected (#id-host-disc) and settings (#set-host) views — both
// surface the destination so the user can verify it.
async function renderConfig({ hostId, envId, envNameId }) {
  const hostEl    = document.getElementById(hostId);
  const envEl     = document.getElementById(envId);
  const envNameEl = envNameId ? document.getElementById(envNameId) : null;
  if (!hostEl || !envEl) return;

  try {
    const res = await bgMessage({ type: 'GET_CONFIG' });
    const cfg = res?.config;
    if (!cfg) return;

    // Replace the host text node, keeping the pill <span> intact.
    hostEl.firstChild && hostEl.removeChild(hostEl.firstChild);
    const host = document.createTextNode(cfg.host || cfg.api_base);
    hostEl.insertBefore(host, envEl);

    envEl.textContent = cfg.is_prod ? 'PROD' : 'NON-PROD';
    envEl.className   = `env-pill ${cfg.is_prod ? 'prod' : 'nonprod'}`;
    envEl.style.display = 'inline-block';

    if (envNameEl) {
      envNameEl.textContent = cfg.is_prod
        ? 'Production'
        : 'Non-production (staging, dev, or custom host)';
    }
  } catch (_) {
    // Stay quiet — config never fails in practice.
  }
}

// ── Compact identity (connected view) ────────────────────────────────────────
//
// Just email + workspace, in a small teal card. Anything else — role,
// workspace ID, last-refreshed time — lives behind the gear so the
// default view stays scannable.
async function renderCompactIdentity({ force = false } = {}) {
  const emailEl = document.getElementById('compact-email');
  const orgEl   = document.getElementById('compact-org');

  if (force) {
    emailEl.textContent = 'Loading…';
    orgEl.textContent   = 'Loading…';
    emailEl.classList.add('skeleton');
    orgEl.classList.add('skeleton');
  }

  try {
    const res = await bgMessage({ type: 'GET_IDENTITY', force });
    if (!res?.ok || !res.identity) {
      emailEl.textContent = '—';
      orgEl.textContent   = 'Identity unavailable';
      emailEl.classList.remove('skeleton');
      orgEl.classList.remove('skeleton');
      return;
    }
    const id = res.identity;
    emailEl.textContent = id.email || '(no email)';
    emailEl.title       = id.email || '';
    orgEl.textContent   = id.org_name
      ? `${id.org_name}${id.org_role ? ' · ' + id.org_role : ''}`
      : (id.org_id ? `Workspace #${id.org_id}` : 'No workspace');
    emailEl.classList.remove('skeleton');
    orgEl.classList.remove('skeleton');
  } catch (err) {
    emailEl.textContent = '—';
    orgEl.textContent   = `(${err.message || 'identity unavailable'})`;
    emailEl.classList.remove('skeleton');
    orgEl.classList.remove('skeleton');
  }
}

// ── Settings view rendering ──────────────────────────────────────────────────
//
// Populates every detail row in the settings view from the cached
// (or freshly-fetched) identity. Skeleton classes are removed once
// the value is set so the placeholder grey colour goes away even when
// the value is "—".
async function renderSettings({ force = false } = {}) {
  const setText = (id, val) => {
    const el = document.getElementById(id);
    if (!el) return;
    el.textContent = (val === null || val === undefined || val === '') ? '—' : val;
    el.classList.remove('skeleton');
  };

  // Show skeleton state when forcing a refresh so the user sees the
  // refresh actually happening — otherwise stale values would just
  // sit there until the new fetch returns.
  if (force) {
    ['set-name', 'set-email', 'set-role', 'set-org-name', 'set-org-id'].forEach(id => {
      const el = document.getElementById(id);
      if (!el) return;
      el.textContent = 'Loading…';
      el.classList.add('skeleton');
    });
    document.getElementById('set-cached-at').textContent = 'Refreshing…';
  }

  try {
    const res = await bgMessage({ type: 'GET_IDENTITY', force });
    if (!res?.ok || !res.identity) {
      // Fail soft — leave the rows showing — and surface the error.
      const fb = document.getElementById('settings-feedback');
      if (fb) showFeedback(fb, res?.error || 'Could not load account info', 'error');
      // Clear skeletons so the user isn't stuck on "Loading…"
      ['set-name', 'set-email', 'set-role', 'set-org-name', 'set-org-id'].forEach(id => setText(id, '—'));
      setText('set-cached-at', '—');
      return;
    }

    const id = res.identity;
    const fullName = [id.first_name, id.last_name].filter(Boolean).join(' ').trim();

    setText('set-name',     fullName || '(no name)');
    setText('set-email',    id.email);
    setText('set-role',     id.org_role);
    setText('set-org-name', id.org_name);
    setText('set-org-id',
      (id.org_id != null || id.org_slug)
        ? `${id.org_id != null ? `#${id.org_id}` : ''}${id.org_slug ? `  ·  ${id.org_slug}` : ''}`
        : null
    );

    // Last-refreshed timestamp. cachedAt is a unix-ms value coming
    // from the background worker — it's the time of the last
    // successful /verify call, which may be different from "now"
    // even when force=true (rare race, but possible).
    if (res.cachedAt) {
      setText('set-cached-at', formatRelativeShort(res.cachedAt));
    } else {
      setText('set-cached-at', 'just now');
    }
  } catch (err) {
    const fb = document.getElementById('settings-feedback');
    if (fb) showFeedback(fb, err.message || 'Refresh failed', 'error');
  }
}

// Smaller variant of the formatter used in content.js — settings shows
// "just now" / "2m ago" / "Mar 14, 9:32 AM" rather than the bigger
// stepped buckets the in-page panel uses.
function formatRelativeShort(unixMs) {
  if (!unixMs) return '—';
  const diffSec = Math.floor((Date.now() - unixMs) / 1000);
  if (diffSec < 30)        return 'just now';
  if (diffSec < 60)        return `${diffSec}s ago`;
  if (diffSec < 3600)      return `${Math.floor(diffSec / 60)}m ago`;
  if (diffSec < 86400)     return `${Math.floor(diffSec / 3600)}h ago`;
  const d = new Date(unixMs);
  return d.toLocaleString(undefined, {
    month: 'short', day: 'numeric',
    hour: 'numeric', minute: '2-digit',
  });
}

// ── Update banner ────────────────────────────────────────────────────────────
//
// Reads the cached version-check result from background and, if a newer
// version is available, shows a banner in whichever view is currently
// active (connected or disconnected). The settings view doesn't show
// the banner — it's behind the gear and would only repeat what the
// top-level views already say.
//
// We never fail loudly. If the check has never run, or the network was
// down, status will be null/empty and we simply don't show the banner.

async function renderUpdateBanner() {
  let status;
  try {
    const res = await bgMessage({ type: 'GET_UPDATE_STATUS', refresh: true });
    status = res?.status;
  } catch (_) { return; }

  if (!status || !status.update_available) return;

  const url = status.download_url || 'https://app.gowarmcrm.com/install-extension';
  const versionsText = `Installed v${status.current} · Latest v${status.latest}`;

  ['connected', 'disconnected'].forEach(view => {
    const banner = document.getElementById(`update-banner-${view}`);
    const link   = document.getElementById(`update-link-${view}`);
    const vers   = document.getElementById(`update-versions-${view}`);
    if (!banner || !link || !vers) return;
    link.href = url;
    vers.textContent = versionsText;
    banner.classList.add('visible');

    // Open the install page in a new tab. Using chrome.tabs.create is
    // more reliable than a plain href click from inside the popup
    // (which sometimes closes before the navigation lands).
    link.addEventListener('click', (e) => {
      e.preventDefault();
      chrome.tabs.create({ url });
    });
  });
}

// Stamp the manifest's version into every .ext-version element so the
// popup footer and settings row always agree with the actual build,
// instead of drifting like the old hardcoded "1.7.1" strings did.
function stampExtensionVersion() {
  const v = chrome.runtime.getManifest().version;
  document.querySelectorAll('.ext-version').forEach(el => { el.textContent = v; });
}

// ── Wire up everything on DOMContentLoaded ───────────────────────────────────

document.addEventListener('DOMContentLoaded', async () => {
  stampExtensionVersion();
  renderUpdateBanner();  // fire-and-forget; failures are silent

  // Backend host + env pill: render in BOTH views that need it.
  // Connected view doesn't show backend in the compact card — it lives
  // in settings. So only disconnected + settings need the host pill.
  renderConfig({ hostId: 'id-host-disc', envId: 'id-env-disc' });
  renderConfig({ hostId: 'set-host',     envId: 'set-env', envNameId: 'set-env-name' });

  // Decide initial view based on token presence.
  const { token } = await bgMessage({ type: 'GET_TOKEN' });
  if (token) {
    showView('connected');
    renderCompactIdentity();
  } else {
    showView('disconnected');
  }

  // ── Connected view actions ─────────────────────────────────────────────────
  document.getElementById('open-crm-btn').addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://app.gowarmcrm.com' });
  });

  // Gear icon — switch to settings. We re-render the settings view
  // each time so cached values are picked up and "last refreshed"
  // reflects time-of-open, not time-of-popup-load.
  document.getElementById('open-settings-btn').addEventListener('click', () => {
    showView('settings');
    renderSettings();
  });

  // ── Settings view actions ──────────────────────────────────────────────────
  document.getElementById('back-from-settings-btn').addEventListener('click', () => {
    showView('connected');
    // Refresh the compact card too in case the user did a manual
    // refresh inside settings — keeps the two surfaces consistent.
    renderCompactIdentity();
  });

  document.getElementById('refresh-identity-btn').addEventListener('click', async () => {
    const btn = document.getElementById('refresh-identity-btn');
    const fb  = document.getElementById('settings-feedback');
    btn.disabled    = true;
    btn.textContent = '↻ Refreshing…';
    try {
      await renderSettings({ force: true });
      showFeedback(fb, '✓ Refreshed', 'success');
    } catch (err) {
      showFeedback(fb, err.message || 'Refresh failed', 'error');
    } finally {
      btn.disabled    = false;
      btn.textContent = '↻ Refresh now';
    }
  });

  document.getElementById('logout-btn-settings').addEventListener('click', async () => {
    await bgMessage({ type: 'CLEAR_TOKEN' });
    showView('disconnected');
  });

  // ── Disconnected view actions ──────────────────────────────────────────────
  document.getElementById('try-connect-btn').addEventListener('click', async () => {
    const btn = document.getElementById('try-connect-btn');
    const fb  = document.getElementById('disconnected-feedback');
    btn.textContent = 'Checking…';
    btn.disabled    = true;

    const res = await bgMessage({ type: 'TRY_HARVEST' });
    if (res.ok) {
      showFeedback(fb, '✓ Connected!', 'success');
      setTimeout(() => {
        showView('connected');
        // Force-refresh identity since the token just changed; the
        // background worker dropped the cached identity on token
        // change so this would re-fetch anyway, but force=true skips
        // the storage round-trip.
        renderCompactIdentity({ force: true });
      }, 800);
    } else {
      btn.textContent = 'Try connecting now';
      btn.disabled    = false;
      showFeedback(fb, 'GoWarmCRM not found. Open it in another tab and log in first.', 'error');
    }
  });

  document.getElementById('open-crm-btn2').addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://app.gowarmcrm.com' });
  });
});
