// content.js — injected into every linkedin.com/in/* page

(function () {
  'use strict';

  const TEAL    = '#0F9D8E';
  const ORANGE  = '#E8630A';   // GoWarmCRM brand
  const PANEL_ID = 'gowarm-li-panel';

  // Debug mode — when set, the in-page panel shows a small strip with the
  // DB IDs (linkedin_profile_id, prospect_id, account_id) for test/debug
  // verification. Toggle via:
  //   Ctrl+Shift+D (Cmd+Shift+D on Mac) — keyboard shortcut, anywhere on a
  //     LinkedIn page (except while typing in an input or textarea).
  //   chrome.storage.local.set({ gowarm_debug: '1' })   — programmatic enable
  //   chrome.storage.local.remove(['gowarm_debug'])     — programmatic disable
  // Defaults to off. Read on init() and refreshed when the shortcut fires.
  let debugMode = false;

  // Last-known set of IDs for the current panel. Set by renderDebugIds() so
  // the keyboard-shortcut toggle can replay them without a re-fetch.
  // Reset on each init() (new profile = clear previous IDs).
  let lastDebugIds = {};

  const EVENTS = [
    { key: 'connection_request_sent', label: 'Connection request sent', tsField: 'request_sent_at',      statusStep: true,  color: '#185FA5', bg: '#E6F1FB', isOutreach: true  },
    { key: 'connection_accepted',     label: 'Connection accepted',     tsField: 'connected_at',         statusStep: true,  color: '#3B6D11', bg: '#EAF3DE', isOutreach: false },
    { key: 'message_sent',            label: 'Message sent',            tsField: 'last_message_at',      statusStep: true,  color: '#BA7517', bg: '#FAEEDA', isOutreach: true  },
    { key: 'inmail_sent',             label: 'InMail sent',             tsField: 'last_message_at',      statusStep: false, color: '#854F0B', bg: '#FAEEDA', isOutreach: true  },
    { key: 'reply_received',          label: 'Reply received',          tsField: 'last_reply_at',        statusStep: true,  color: '#0F6E56', bg: '#E1F5EE', isOutreach: false },
    { key: 'voice_note_sent',         label: 'Voice note sent',         tsField: 'last_voice_note_at',   statusStep: false, color: '#993C1D', bg: '#FAECE7', isOutreach: true  },
    { key: 'profile_viewed',          label: 'Profile viewed (noted)',  tsField: 'last_profile_view_at', statusStep: false, color: '#5F5E5A', bg: '#F1EFE8', isOutreach: false },
    { key: 'meeting_booked',          label: 'Meeting booked',          tsField: 'meeting_booked_at',    statusStep: true,  color: '#185FA5', bg: '#E6F1FB', isOutreach: false },
  ];

  const TIMELINE_EVENTS = EVENTS.filter(e => e.statusStep);

  const STATUS_ORDER = [
    'connection_request_sent', 'connection_accepted',
    'message_sent', 'reply_received', 'meeting_booked',
  ];

  const SENTIMENTS = [
    { value: '',                label: '— sentiment (optional) —' },
    { value: 'positive',        label: 'Positive — keen to learn more' },
    { value: 'neutral',         label: 'Neutral — polite, non-committal' },
    { value: 'negative',        label: 'Negative — not interested' },
    { value: 'follow_up_later', label: 'Asked to follow up later' },
  ];

  // ── Helpers ──────────────────────────────────────────────────────────────────

  function getCurrentLinkedInUrl() {
    const match = location.href.match(/https:\/\/www\.linkedin\.com\/in\/([^/?#]+)/);
    return match ? `https://www.linkedin.com/in/${match[1]}` : null;
  }

  function formatDate(iso) {
    if (!iso) return '';
    return new Date(iso).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  }

  function escHtml(str) {
    return String(str || '')
      .replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  // Stable id for activity items derived from a URL/text. Same input → same id.
  function hashId(input) {
    let h = 0;
    const s = String(input || '');
    for (let i = 0; i < s.length; i++) {
      h = ((h << 5) - h) + s.charCodeAt(i);
      h |= 0;
    }
    return 'li_' + Math.abs(h).toString(36);
  }

  // ── Profile extraction (basics — name/title/company/location) ─────────────────
  // LinkedIn is rolling out a new SDUI-based profile layout alongside the old
  // classed-HTML layout. We try the new layout first and fall back to the old
  // one so the extension works for users on either variant.

  // Parse a company name out of a headline string. LinkedIn headlines very
  // commonly name the employer after an "@" or " at " — e.g.
  //   "Head of Product Engineering @ Replit | We're hiring!"
  //   "Founder at glByte, Inc · Investor"
  // We take the text after the first @/at delimiter and trim it at the next
  // separator (| · — –). Returns '' when the headline has no such pattern.
  function companyFromHeadline(headline) {
    if (!headline) return '';
    const m = String(headline).match(/(?:^|\s)(?:@|at)\s+(.+)$/i);
    if (!m) return '';
    // Cut at the first separator that typically begins a new headline clause.
    let co = m[1].split(/\s*[|·—–]\s*/)[0].trim();
    // Drop a trailing employment-type suffix if present ("Replit · Full-time").
    co = co.split(/\s+·\s+/)[0].trim();
    // Guard against absurdly long captures — a real company name is short.
    if (co.length > 120) return '';
    return co;
  }

  // Read the current employer from the topcard "company chip" — the small
  // card next to the profile name showing the company logo and name, with
  // an <a href="/company/<slug>/"> wrapping it. LinkedIn renders this on
  // most profiles where the person has a current employer with a LinkedIn
  // page, regardless of how their headline is written. Unlike the
  // headline-parse and experience-derived fallbacks, this anchor is
  // always visible at page load (no scroll-loading), making it the most
  // reliable company source when present.
  //
  // The challenge is picking the RIGHT /company/ link — the profile page
  // also contains many unrelated /company/ links (sidebar "More profiles
  // for you", "Pages you might like", ads, etc). The reliable signal is
  // PROXIMITY TO THE PROFILE NAME H1: the topcard chip sits in the same
  // DOM section as the name. We find the section containing the name,
  // then take the first /company/ link inside it (excluding any nested
  // experience section just in case).
  function companyFromTopcardChip() {
    try {
      // Find the profile name heading. LinkedIn uses h1 for the name on
      // profile pages — there's typically exactly one in main content.
      const main = document.querySelector('main') || document.body;
      const h1   = main.querySelector('h1');
      if (!h1) return '';

      // Bound the search to the topcard region: the closest <section>
      // ancestor of the h1. The topcard is rendered as its own <section>.
      const topcard = h1.closest('section') || h1.parentElement;
      if (!topcard) return '';

      const links = [...topcard.querySelectorAll('a[href*="/company/"]')]
        .filter(a => {
          // Exclude links inside a nested Experience section (defensive;
          // the topcard shouldn't contain Experience but guard anyway).
          const enclosingSection = a.closest('section');
          if (enclosingSection && enclosingSection !== topcard) {
            const heading = enclosingSection.querySelector('h2, h3')?.innerText?.trim() || '';
            if (/^experience$/i.test(heading)) return false;
          }
          const text = (a.innerText || '').trim();
          if (!text || text.length > 120) return false;
          // Reject icon-only or generic widget text.
          if (/^(see all|show all|view|mutual)/i.test(text)) return false;
          return true;
        });

      if (links.length === 0) return '';
      if (links.length === 1) return (links[0].innerText || '').trim();

      // Multiple /company/ links in the topcard section (e.g. a sidebar
      // "More profiles" widget rendered into the same <section> as the
      // name). The right one is the company CHIP — it sits next to the
      // name, so pick the link with the SMALLEST distance to the h1 in
      // the DOM tree. We measure distance by walking up from each link
      // until we hit a common ancestor of the h1; fewer steps = closer.
      const distanceToH1 = (el) => {
        let n = el;
        let d = 0;
        while (n && !n.contains(h1)) {
          n = n.parentElement;
          d++;
          if (d > 30) return Infinity; // safety
        }
        return d;
      };
      links.sort((a, b) => distanceToH1(a) - distanceToH1(b));
      return (links[0].innerText || '').trim();
    } catch (_) {
      return '';
    }
  }

  function extractProfileInfo() {
    const linkedinUrl = getCurrentLinkedInUrl();

    // Name is stable: document.title is always "Full Name | LinkedIn"
    const name = (document.title || '').split(' | ')[0].trim();

    // Try new SDUI layout first, fall back to old classed-HTML layout.
    let info;
    const sdui = extractFromSduiLayout(name);
    if (sdui && (sdui.title || sdui.company || sdui.location)) {
      info = { name, ...sdui, linkedinUrl };
    } else {
      const legacy = extractFromLegacyLayout(name);
      info = { name, ...legacy, linkedinUrl };
    }

    // Company fallback chain. The top-card extractors only find `company`
    // when LinkedIn renders a *separate* company line in the topcard — many
    // profiles don't (the employer lives only inside the headline, or in
    // a logo-card chip next to the name). When that happens `company` is
    // empty even though the page clearly shows it.
    //
    //   Fallback 1: the topcard COMPANY CHIP — a small card next to the
    //               profile name showing the current employer's logo, with
    //               an <a href="/company/<slug>/"> wrapping it. This is
    //               LinkedIn's own notion of "current employer" and is
    //               always visible (no scroll-load required), making it
    //               the most reliable source when present.
    //   Fallback 2: parse it out of the headline ("... @ Replit | ...").
    //   Fallback 3: take it from the current experience entry — the most
    //               authoritative source for current role but requires the
    //               Experience section to have loaded, which it often
    //               hasn't at panel-render time.
    if (!info.company || !info.company.trim()) {
      const fromTopcardChip = companyFromTopcardChip();
      if (fromTopcardChip) {
        info.company = fromTopcardChip;
      } else {
        const fromHeadline = companyFromHeadline(info.title);
        if (fromHeadline) {
          info.company = fromHeadline;
        } else {
          try {
            const exp = getExperience();
            const isCurrent = (e) => {
              const ed = e?.end_date;
              if (ed == null) return true;
              const s = String(ed).trim().toLowerCase();
              return s === '' || s === 'present';
            };
            const current = exp.find(isCurrent) || exp[0];
            if (current?.company) info.company = current.company;
          } catch (_) { /* experience not available — leave company empty */ }
        }
      }
    }

    return info;
  }

  function extractFromSduiLayout(name) {
    const topCard = document.querySelector('section[componentkey*="Topcard"]');
    if (!topCard) return null;

    // Read the topcard's <p> elements in DOM order. The new SDUI layout puts
    // each profile field in its own <p>, in this rough order:
    //   1. Name (already known)
    //   2. Verification badge ("•")
    //   3. Connection degree badge ("· 2nd")
    //   4. Headline (e.g. "Founder at glByte, Inc")
    //   5. Company name (e.g. "glByte, Inc") — only on some profiles
    //   6. Location (e.g. "San Francisco Bay Area")
    //   7. "Contact info" (link)
    //   8. "X connections" / "X followers"
    //   9. Mutual connections, etc.
    //
    // We work in DOM order rather than guessing by content shape, because
    // headlines like "Founder at glByte, Inc" contain commas (so the old
    // "first line with a comma is location" heuristic mis-fired).
    // Only consider <p> elements that are actually rendered. LinkedIn ships
    // hidden duplicate topcards (responsive variants — e.g. a desktop layout
    // and a collapsed mobile layout in the same DOM) whose text otherwise
    // pollutes our DOM-order walk. A hidden "· 1st" or hidden
    // "<company> · <school>" row would otherwise be picked as the headline.
    const isVisible = (el) => {
      if (!el || el.offsetParent === null) return false;
      const r = el.getBoundingClientRect();
      return r.width > 0 && r.height > 0;
    };

    const ps = [...topCard.querySelectorAll('p')]
      .filter(isVisible)
      .map(p => (p.innerText || '').trim())
      .filter(Boolean);

    // Filter out junk elements that aren't profile data.
    const isJunk = s =>
      s === '·' || s === '•' ||
      /^·\s*(1st|2nd|3rd)$/i.test(s) ||           // degree badge
      /^(Contact info)$/i.test(s) ||
      /^\d[\d,]*\+?\s*(connections?|followers?|following)$/i.test(s) ||
      /\bmutual connections?\b/i.test(s) ||
      /^(Connect|Message|Follow|More|Save in Sales Navigator|Visit my website|Visit my)$/i.test(s) ||
      // Pronoun badge — LinkedIn renders "She/Her", "He/Him", "They/Them",
      // "Ze/Zir", and the more verbose "(He/Him)" form. These appear as their
      // own <p> in the topcard and were getting selected as the headline.
      /^\(?(she|he|they|ze|xe|ey|hir)\s*\/\s*(her|him|them|zir|xem|em|hirs)\)?$/i.test(s) ||
      // "Open to work" / "Hiring" badges
      /^(open to work|#opentowork|hiring)$/i.test(s) ||
      s === name;

    const clean = ps.filter(s => !isJunk(s));

    // Location detector — applied to short lines only. Recognises common
    // geo shapes; a line like "Founder at glByte, Inc" is rejected because
    // it contains the word "at" or has a corporate suffix.
    // (Defined at module scope below as `looksLikeLocation` so capture
    // functions can share it.)

    // Find location: prefer the last short line that looks geographic.
    // Walking backwards through `clean` works because location appears
    // late in the topcard, right before "Contact info" / connection counts
    // (which we've already filtered out).
    //
    // Some topcard layouts join the location with "Contact info" into a
    // single <p>: "New York, New York, United States · Contact info".
    // Splitting on " · " before testing handles that case.
    let location = '';
    for (let i = clean.length - 1; i >= 0; i--) {
      const line = clean[i];
      if (looksLikeLocation(line)) { location = line; break; }
      // Split-on-bullet fallback for joined "<location> · Contact info" rows.
      const parts = line.split(/\s+·\s+/).map(p => p.trim()).filter(Boolean);
      if (parts.length > 1) {
        const match = parts.find(looksLikeLocation);
        if (match) { location = match; break; }
      }
    }

    // Headline = first non-junk line that isn't the location.
    const title = clean.find(s => s !== location) || '';

    // Company = anything between headline and location that's short and
    // doesn't itself look like a location. On profiles where LinkedIn doesn't
    // surface a separate company line, this remains empty.
    const titleIdx = clean.indexOf(title);
    const locIdx   = location ? clean.indexOf(location) : clean.length;
    let company = '';
    for (let i = titleIdx + 1; i < locIdx; i++) {
      const s = clean[i];
      if (s.length > 200) continue;
      if (looksLikeLocation(s)) continue;
      // Strip employment-type suffix ("Acme · Full-time")
      company = s.split(/\s+·\s+/)[0].trim();
      break;
    }

    // Connection degree badge — look for "· 1st" / "· 2nd" / "· 3rd".
    const degreePs = [...topCard.querySelectorAll('p')]
      .filter(p => /·\s*(1st|2nd|3rd)/i.test(p.innerText || ''));
    const visibleDegreeP = degreePs.find(p => {
      if (p.offsetParent === null) return false;
      const r = p.getBoundingClientRect();
      return r.width > 0 && r.height > 0;
    }) || degreePs[0];
    const degreeMatch = visibleDegreeP?.innerText?.match(/·\s*([123])(st|nd|rd)/i);
    const degree = degreeMatch?.[1] || null;

    return { title, company, location, degree };
  }

  function extractFromLegacyLayout(name) {
    let title = '';
    let company = '';
    let location = '';

    const junk = ['save in sales navigator', 'connect', 'message', 'follow', 'more', 'more...'];

    const topCard = [...document.querySelectorAll('div')].find(d =>
      d.className?.includes('_23131edd') && d.textContent?.includes(name)
    );
    if (topCard) {
      const leaves = [...topCard.querySelectorAll('*')]
        .filter(el => el.children.length === 0)
        .map(el => el.textContent?.trim())
        .filter(t => t && t.length > 2)
        .filter((t, i, arr) => arr.indexOf(t) === i);

      title    = leaves[1] || '';
      company  = leaves[2] || '';
      location = leaves[3] || '';

      if (junk.includes(company.toLowerCase()))  company  = '';
      if (junk.includes(location.toLowerCase())) location = '';
    }

    if (!location) {
      const locEl = [...document.querySelectorAll('span, div, p')]
        .filter(el => el.children.length === 0)
        .find(el => {
          const t = el.textContent?.trim();
          return t && /metropolitan area|greater .+ area|, [A-Z][A-Z]$| area$|india|united states|telangana|hyderabad/i.test(t) && t.length < 80;
        });
      location = locEl?.textContent?.trim() || '';
    }

    const nameSpan = [...document.querySelectorAll('span[aria-hidden="true"]')]
      .find(s => s.textContent?.includes(name) && s.textContent?.includes('•'));
    const degreeMatch = nameSpan?.textContent?.match(/•\s*([123])(st|nd|rd)/);
    const degree = degreeMatch?.[1] || null;

    return { title, company, location, degree };
  }

  // ── NEW in v1.2: full-profile extraction ─────────────────────────────────────
  //
  // Best-effort scrapers for the About / Experience / Education / Activity
  // sections of the profile page the rep is currently viewing. LinkedIn's
  // markup is unstable across A/B tests and locales — every selector here is
  // tolerant: each function returns null/[] cleanly when it can't find data.
  //
  // What this captures depends on what the rep has scrolled into view and
  // expanded. We do NOT try to navigate to /detail/recent-activity/ pages
  // automatically — that's a content-script no-go (cross-origin nav, anti-bot).
  // The rep's flow is: scroll the page once, then click "Capture profile".

  // ── Module-scoped helpers ─────────────────────────────────────────────────
  //
  // Heuristic: does this line look like a geographic location?
  //
  // Used by both extractFromSduiLayout (top-card location) and
  // captureExperience (per-job location). Rejects corporate suffixes, "at"
  // and "of" (which appear in headlines like "Founder at glByte, Inc"),
  // and accepts common geo shapes: "X Area", "Metropolitan", "City, Region",
  // ", Country", or a single capitalized place name.
  function looksLikeLocation(s) {
    if (!s || s.length > 80) return false;
    if (/\b(Inc|LLC|Ltd|Corp|Corporation|Pvt|Limited|GmbH|Co\.)\b/i.test(s)) return false;
    if (/\b(at|of|for)\b/i.test(s)) return false;

    // Strong signal: an "Area" or "Metropolitan" mention, or "Greater <City>".
    if (/\barea\b|metropolitan|greater\s/i.test(s)) return true;

    // "City, Region" or "City, Region, Country" — at least one comma + matching
    // capitalisation pattern. This is the most reliable shape for LinkedIn
    // locations.
    if (/^[A-Z][\w.\s'-]+(,\s*[A-Z][\w.\s'-]+){1,2}$/.test(s)) return true;

    // Anchored country/state suffixes — covers "Berlin, Germany",
    // "Mumbai, MH", "Dallas, TX, USA". Useful when leading char isn't capital
    // (e.g. "iPhone, India" — rare but it happens).
    if (/,\s*(India|United States|USA|UK|United Kingdom|Canada|Australia|Germany|France|Singapore|UAE|Ireland|Netherlands|Spain|Italy|Brazil|Mexico|Japan|China|[A-Z]{2})$/.test(s)) return true;

    // Note: we deliberately do NOT have a single-capitalised-word fallback
    // here. Single words like "Clay" (a company), "Sphoorthy" (a school)
    // would slip through and get picked as locations. LinkedIn nearly always
    // emits multi-part locations; missing the rare single-word case
    // ("Hyderabad" alone) is a smaller cost than misclassifying companies.
    return false;
  }

  // Find a top-level <section> by heading text (works on both layouts).
  function findSectionByHeading(headingPatterns) {
    const sections = document.querySelectorAll('section, div[componentkey*="Section"]');
    for (const sec of sections) {
      const hh = sec.querySelector('h2, h3, [role="heading"]');
      const text = (hh?.innerText || '').trim();
      if (!text) continue;
      for (const re of headingPatterns) {
        if (re.test(text)) return sec;
      }
    }
    return null;
  }

  function captureAboutText() {
    // "About" section. Headings vary: "About", "About me".
    const sec = findSectionByHeading([/^about\b/i]);
    if (!sec) return null;

    // The About text is usually inside the first long <p> or <span>
    // (post-collapse, "see more" must have been clicked for full text).
    const candidates = [...sec.querySelectorAll('span[aria-hidden="true"], p, div')]
      .map(el => el.innerText?.trim())
      .filter(t => t && t.length > 60 && !/^see (more|less)$/i.test(t));

    // Take the longest candidate (the About text itself, not surrounding chrome)
    candidates.sort((a, b) => b.length - a.length);
    let text = candidates[0] || null;

    // Strip trailing truncation markers that LinkedIn appends inline:
    //   "...full text...\n\n… more"
    //   "...full text… more"
    if (text) {
      text = text
        .replace(/\s*…\s*more\s*$/i, '')
        .replace(/\s*\.\.\.\s*more\s*$/i, '')
        .replace(/\s*see more\s*$/i, '')
        .trim();
    }
    return text;
  }

  // Read the text "lines" of a profile-section item, in DOM order.
  // The new SDUI layout puts each line in its own <p>; older layouts used
  // <span aria-hidden="true">. We try both and dedupe.
  function readItemLines(item) {
    // 1) New SDUI: <p> tags directly inside the item.
    let lines = [...item.querySelectorAll('p')]
      .map(el => (el.innerText || '').trim())
      .filter(Boolean);

    // 2) Legacy: <span aria-hidden="true">. Only fall back if we didn't
    //    find <p> lines, otherwise we'd duplicate everything.
    if (lines.length === 0) {
      lines = [...item.querySelectorAll('span[aria-hidden="true"]')]
        .map(el => (el.innerText || '').trim())
        .filter(Boolean);
    }

    // Strip "…" and "more" truncation markers (they appear as separate <p>s
    // on collapsed long descriptions in SDUI).
    lines = lines
      .filter(l => l !== '…' && l !== 'more' && l !== '... more' && l !== '…more')
      .filter(l => l.length < 4000)
      .filter((t, i, arr) => arr.indexOf(t) === i);   // dedupe contiguous repeats

    return lines;
  }

  function captureExperience() {
    const sec = findSectionByHeading([/^experience$/i]);
    if (!sec) return [];

    // Items: new SDUI tags items with componentkey="entity-collection-item-<hash>".
    // We OR with legacy selectors so older layouts still work.
    let items = [...sec.querySelectorAll('[componentkey^="entity-collection-item-"]')];
    if (items.length === 0) {
      items = [...sec.querySelectorAll(
        'li.artdeco-list__item, li[data-test="experience-item"], div[data-view-name="profile-component-entity"]'
      )];
    }

    // Some SDUI items are nested duplicates (e.g. an inner <a> with the same
    // componentkey as its outer <div>). Keep only items that have meaningful
    // text content AND are not contained within another already-kept item.
    const filtered = [];
    items.forEach(it => {
      const txt = (it.innerText || '').trim();
      if (txt.length < 10) return;
      if (filtered.some(prev => prev.contains(it))) return;   // skip nested dup
      filtered.push(it);
    });

    const out = [];
    filtered.forEach(item => {
      const lines = readItemLines(item);
      if (lines.length < 2) return;

      const title = lines[0] || null;

      // Find the date line. Pattern: "Feb 2019 - Present", "Jul 2018 - Feb 2020",
      // optionally followed by " · 2 yrs 3 mos".
      const isDateLine = l =>
        /\b(19|20)\d{2}\b/.test(l) &&
        /\s[-–]\s|to/i.test(l);
      const dateLineIdx = lines.findIndex(isDateLine);
      const dateLine    = dateLineIdx >= 0 ? lines[dateLineIdx] : null;
      const { startDate, endDate, durationMonths } = parseDateRange(dateLine);

      // Company line: everything between title (line 0) and the date line.
      // On the new SDUI it's typically just lines[1]. On older layouts it
      // might have an employment-type suffix ("Acme · Full-time").
      let companyLine = null;
      if (dateLineIdx > 1) {
        companyLine = lines[1];
      } else if (dateLineIdx === 1) {
        // No company line at all (rare — usually because LinkedIn rolled
        // company into the title for self-employment).
        companyLine = null;
      } else if (dateLineIdx < 0) {
        // No date line found — fall back to lines[1] if it's short.
        companyLine = lines[1] && lines[1].length < 120 ? lines[1] : null;
      }
      const company = companyLine
        ? companyLine.split(/\s+·\s+/)[0].trim()
        : null;

      // Location: line right after the date line. Must look like an actual
      // geographic location — short, recognisable city/region/area shape.
      // Some profiles join the location with a job-mode suffix in a single
      // line: "Bengaluru, Karnataka, India · On-site". We split on " · "
      // and accept the first part that looks geographic.
      let location = null;
      if (dateLineIdx >= 0 && lines[dateLineIdx + 1]) {
        const candidate = lines[dateLineIdx + 1];
        if (looksLikeLocation(candidate)) {
          location = candidate;
        } else {
          const parts = candidate.split(/\s+·\s+/).map(p => p.trim()).filter(Boolean);
          const geoPart = parts.find(looksLikeLocation);
          if (geoPart) location = geoPart;
        }
      }

      // Description: longest remaining line, after excluding title/company/date/location.
      const used = new Set([title, companyLine, dateLine, location].filter(Boolean));
      const description = lines
        .filter(l => !used.has(l) && l.length > 60)
        .sort((a, b) => b.length - a.length)[0] || null;

      // Company LinkedIn URL: the experience item wraps the company name in an
      // <a href="/company/<slug>/...">. We read the first such link inside the
      // item and canonicalise to https://www.linkedin.com/company/<slug>.
      // For multi-position items at the same company, the outer link is what
      // querySelector returns, which is what we want.
      let companyLinkedInUrl = null;
      const companyAnchor = item.querySelector('a[href*="/company/"]');
      if (companyAnchor) {
        const href = companyAnchor.getAttribute('href') || companyAnchor.href || '';
        const m = href.match(/\/company\/([A-Za-z0-9._-]+)/);
        if (m) {
          const slug = m[1].toLowerCase();
          if (slug !== 'setup' && slug !== 'new' && slug !== 'admin') {
            companyLinkedInUrl = `https://www.linkedin.com/company/${slug}`;
          }
        }
      }

      out.push({
        title,
        company,
        company_linkedin_url: companyLinkedInUrl,
        location,
        start_date:      startDate,
        end_date:        endDate,
        duration_months: durationMonths,
        description,
      });
    });
    return out;
  }

  // Returns experience entries, preferring the already-captured value over
  // a fresh scrape.
  //
  // Why this exists: captureExperience() reads the experience <section>,
  // but LinkedIn lazy-renders that section — it isn't in the DOM until the
  // user scrolls near it. Calling captureExperience() "cold" (e.g. from the
  // Add-prospect form while the user is scrolled up at the top card)
  // therefore returns [] even on profiles that clearly have experience.
  //
  // The capture panel doesn't have this problem because its scroll-driven
  // IntersectionObserver runs captureExperience() at the moment the section
  // IS on screen, and stores the result in captureState.experience.value.
  //
  // So: trust that stored value first. Only fall back to a live scrape if
  // the observer hasn't captured anything yet (user added the prospect
  // before ever scrolling down). This makes every consumer — the company
  // name fallback, the ADD_PROSPECT company-URL resolver, and the debug
  // __gowarmCapture hook — robust to scroll position.
  function getExperience() {
    try {
      const slot = captureState && captureState.experience;
      if (slot && Array.isArray(slot.value) && slot.value.length > 0) {
        return slot.value;
      }
    } catch (_) { /* captureState not initialised yet — fall through */ }
    // Fallback: cold scrape. Works only if the section happens to be
    // rendered; returns [] otherwise (same as before this helper existed).
    try {
      return captureExperience() || [];
    } catch (_) {
      return [];
    }
  }

  // Guarantees experience data is available before the caller needs it.
  //
  // getExperience() returns the observer-captured value when the user has
  // already scrolled past the experience section. But a user can open a
  // profile and immediately click "Add" without ever scrolling — the
  // observer never fires, captureState.experience.value stays [], and the
  // cold-scrape fallback also fails because LinkedIn hasn't lazy-rendered
  // the section yet.
  //
  // This helper closes that gap: if experience hasn't been captured, it
  // scrolls the section into view, waits briefly for LinkedIn to hydrate
  // it, runs the capture, and stores the result in captureState so every
  // consumer (and the panel) sees it. It restores the original scroll
  // position afterward so the user isn't left somewhere unexpected.
  //
  // Returns the experience array (possibly still [] if the profile
  // genuinely has no experience section — callers handle that gracefully).
  async function ensureExperienceCaptured() {
    // Already have it — nothing to do, no scroll-jump.
    const existing = getExperience();
    if (existing && existing.length > 0) return existing;

    // Find the experience section. If it isn't in the DOM yet we still
    // try scrolling — LinkedIn renders it as the viewport approaches.
    const sec = findSectionByHeading([/^experience$/i]);
    if (!sec) {
      // No section node at all — best effort scrape, may be [].
      return getExperience();
    }

    const originalScrollY = window.scrollY;
    try {
      sec.scrollIntoView({ behavior: 'instant', block: 'center' });
    } catch (_) {
      // Older engines may not accept behavior:'instant' — fall back.
      try { sec.scrollIntoView(); } catch (_) { /* ignore */ }
    }

    // Wait for LinkedIn to lazy-render the section's entries. Poll a few
    // times rather than a single fixed sleep — finishes as soon as the
    // capture succeeds, so it's usually fast.
    let captured = [];
    for (let attempt = 0; attempt < 6; attempt++) {
      await new Promise(r => setTimeout(r, 250));
      try {
        captured = captureExperience() || [];
      } catch (_) {
        captured = [];
      }
      if (captured.length > 0) break;
    }

    // Store into captureState so the panel and getExperience() agree.
    try {
      if (captureState && captureState.experience && captured.length > 0) {
        captureState.experience.value         = captured;
        captureState.experience.status        = 'captured';
        captureState.experience.lastCapturedAt = Date.now();
        if (typeof notifyCapture === 'function') notifyCapture('experience');
      }
    } catch (_) { /* state not ready — the return value still works */ }

    // Restore the user's scroll position.
    try {
      window.scrollTo({ top: originalScrollY, behavior: 'instant' });
    } catch (_) {
      try { window.scrollTo(0, originalScrollY); } catch (_) { /* ignore */ }
    }

    return captured.length > 0 ? captured : getExperience();
  }

  function captureEducation() {
    const sec = findSectionByHeading([/^education$/i]);
    if (!sec) return [];

    let items = [...sec.querySelectorAll('[componentkey^="entity-collection-item-"]')];
    if (items.length === 0) {
      items = [...sec.querySelectorAll(
        'li.artdeco-list__item, li[data-test="education-item"], div[data-view-name="profile-component-entity"]'
      )];
    }

    // Newer obfuscated layout (mid-2026): LinkedIn ships education entries
    // in fully class-obfuscated <div>s with no entity-collection-item,
    // no data-test, no data-view-name, no artdeco-list__item, and no
    // reliable per-entry attribute. Earlier versions of this fallback
    // anchored on the school's <a href="/school/...">, but that fails
    // for any education entry whose school doesn't have a LinkedIn page
    // (e.g. "Institute of Chartered Accountants of India") — those
    // entries have no school link at all.
    //
    // What IS consistent across every entry, linked or not: the school
    // name is rendered in a leaf-style <p> whose direct text content is
    // exactly the school name (no nested HTML).
    //
    // So the algorithm is:
    //   1) Find every <p> in the section whose own text (excluding
    //      descendants) is a plausible school-name string.
    //   2) For each, walk up to find the entry wrapper using SIZE-JUMP
    //      DETECTION: LinkedIn nests several near-identical wrapper
    //      <div>s around each entry, so textlen is stable across many
    //      levels (the "plateau") until you hit the multi-entry
    //      container, where it jumps significantly. The last ancestor
    //      whose textlen is still on the plateau is the entry wrapper.
    //   3) Dedupe wrappers — multiple anchors inside the same wrapper
    //      should yield it only once.
    if (items.length === 0) {
      // Step 1: candidate school-name anchors.
      const anchors = [];
      sec.querySelectorAll('p').forEach(p => {
        const ownText = [...p.childNodes]
          .filter(n => n.nodeType === Node.TEXT_NODE)
          .map(n => n.textContent).join('').trim();
        // Must be non-empty, not absurdly long, and not the section
        // heading or a date range. Date ranges contain a year and a
        // dash; school names typically don't.
        if (!ownText) return;
        if (ownText.length > 120) return;
        if (/^education$/i.test(ownText)) return;
        if (/^\s*(19|20)\d{2}\s*[-–—]\s*((19|20)\d{2}|present)/i.test(ownText)) return;
        anchors.push(p);
      });

      // Step 2: walk up from each anchor with size-jump detection.
      const entryFor = (anchor) => {
        let node    = anchor.parentElement;
        let prev    = anchor;
        let prevLen = (anchor.innerText || '').trim().length;
        let climbs  = 0;
        const MAX_CLIMBS = 12;
        while (node && node !== sec && climbs < MAX_CLIMBS) {
          const txt = (node.innerText || '').trim();
          const len = txt.length;
          // Big jump → we've climbed into a multi-entry container or
          // out of the entry. The previous ancestor was the boundary.
          // "Big" means more than ~60% growth AND an absolute increase
          // of at least 30 chars (avoids false trips on tiny entries).
          if (prevLen > 0 && len > prevLen * 1.6 && (len - prevLen) > 30) {
            return prev;
          }
          prev    = node;
          prevLen = len;
          node    = node.parentElement;
          climbs++;
        }
        // No jump detected within climb budget — accept the largest
        // ancestor we walked to, as long as it's still smaller than
        // the section itself (rough cap to avoid picking the body).
        const secLen = (sec.innerText || '').trim().length;
        if (prevLen < secLen * 0.8) return prev;
        return null;
      };

      // Step 3: collect and dedupe entries. Two anchors inside the
      // same wrapper (e.g. school name + degree + year all in <p>s)
      // resolve to the same wrapper — keep only one.
      const seen   = new Set();
      const byPara = [];
      anchors.forEach(p => {
        const entry = entryFor(p);
        if (!entry) return;
        if (seen.has(entry)) return;
        seen.add(entry);
        byPara.push(entry);
      });

      items = byPara;
    }

    // Drop nested duplicates the same way captureExperience does.
    const filtered = [];
    items.forEach(it => {
      const txt = (it.innerText || '').trim();
      if (txt.length < 5) return;
      if (filtered.some(prev => prev.contains(it))) return;
      filtered.push(it);
    });

    const out = [];
    filtered.forEach(item => {
      const lines = readItemLines(item);
      if (lines.length === 0) return;

      // Education item shape (confirmed on SDUI):
      //   line 0: school
      //   line 1: degree, field of study (may be combined as "BS, Computer Science")
      //   line 2: year range ("1986 – 1994" or "1986 - 1994")
      // On older layouts there can be extra activity lines after years —
      // we keep the regex scan for years so they're picked up regardless of position.
      const school = lines[0] || null;

      const dateLineIdx = lines.findIndex(l => /\b(19|20)\d{2}\b/.test(l));
      const dateLine    = dateLineIdx >= 0 ? lines[dateLineIdx] : null;
      const yearMatches = dateLine ? [...dateLine.matchAll(/\b(19|20)\d{2}\b/g)].map(m => parseInt(m[0], 10)) : [];
      const startYear   = yearMatches[0] || null;
      const endYear     = yearMatches[1] || null;

      // Degree/field: lines between school and date that aren't the date itself.
      let degree = null;
      let field  = null;
      const middleLines = lines.slice(1, dateLineIdx >= 0 ? dateLineIdx : lines.length);
      if (middleLines.length === 1) {
        // "ACS, Company Secretary" — split on first comma if present.
        const parts = middleLines[0].split(/,\s+/);
        degree = parts[0] || null;
        field  = parts.slice(1).join(', ') || null;
      } else if (middleLines.length >= 2) {
        degree = middleLines[0];
        field  = middleLines[1];
      }

      out.push({
        school,
        degree,
        field_of_study: field,
        start_year: startYear,
        end_year:   endYear,
      });
    });
    return out;
  }

  // Activity (recent posts/comments/reactions). On a profile page LinkedIn
  // shows a small preview of recent activity. We capture what's currently
  // rendered — the rep can navigate to the full activity tab to load more
  // before clicking Capture.
  function captureActivity() {
    const sec = findSectionByHeading([
      /^activity$/i,
      /(\bposts?\b|\bactivity\b).{0,30}\bfollowers?$/i,
      /\brecent activity\b/i,
    ]);
    if (!sec) return [];

    // Activity items are exposed in two different layouts depending on the
    // profile — and sometimes both at once:
    //
    //   Layout A — pillContent: simpler profiles render at most one wrapper
    //     per tab with componentkey="<slug>activity_<type>_pillContent",
    //     containing the highlighted post.
    //
    //   Layout B — carousel of individual cards: most profiles render a
    //     horizontal carousel of post/comment cards. Each card has a random
    //     UUID componentkey, no naming convention.
    //
    // The reliable signal across both is that every post links to
    // /feed/update/urn:li:activity:<id>/ via an <a href>. So we find every
    // such anchor, walk up to its enclosing card (the closest ancestor that
    // contains the activity URN AND substantial text), and dedupe by URN.
    //
    // LinkedIn has shipped layouts where the anchor href is NOT
    // /feed/update/... but a relative path that still embeds the
    // urn:li:activity: token, or where the URN is only on a container's
    // data-urn attribute with no anchor at all. We catch both: any <a> whose
    // href contains an activity URN, plus a fallback walk over
    // [data-urn^="urn:li:activity:"] containers.
    const anchors = [
      ...sec.querySelectorAll(
        'a[href*="urn:li:activity:"], a[href*="/feed/update/"], a[href*="/posts/"]'
      )
    ];
    const seenUrns  = new Set();
    const itemRoots = [];
    for (const a of anchors) {
      const urnMatch = (a.getAttribute('href') || '').match(/urn:li:activity:(\d+)/);
      if (!urnMatch) continue;
      const urn = urnMatch[1];
      if (seenUrns.has(urn)) continue;
      seenUrns.add(urn);

      // Find the smallest ancestor that contains exactly THIS URN and no
      // other activity URNs. By definition that's the card boundary —
      // higher containers (carousel rows, the whole Activity section) hold
      // multiple URNs and would be too coarse.
      const urnRegex = /urn:li:activity:(\d+)/g;
      function urnsInside(el) {
        const out = new Set();
        const html = el.innerHTML || '';
        let m;
        urnRegex.lastIndex = 0;
        while ((m = urnRegex.exec(html))) out.add(m[1]);
        return out;
      }

      let node = a.parentElement;
      while (node && node !== sec) {
        const urns = urnsInside(node);
        if (urns.size === 1 && urns.has(urn)) {
          // This ancestor contains exactly our URN — but make sure it
          // also has substantial card content (not just an <a> wrapping
          // the URN with no surrounding text).
          const t = (node.innerText || '').trim();
          if (t.length > 30) break;
        } else if (urns.size > 1) {
          // We've ascended past the card boundary into a multi-card
          // container. Descend back down to the smallest descendant that
          // still contains exactly our URN. A single-step "find child with
          // our URN" was insufficient — when the multi-URN ancestor is a
          // huge page container (e.g. <main>), its first matching child is
          // a giant column wrapper that also contains the topcard, About,
          // Experience, etc., so the card's `innerText` becomes the
          // entire profile column. We loop until no smaller child still
          // contains the URN.
          let descend = node;
          while (true) {
            const next = [...descend.children].find(c => urnsInside(c).has(urn));
            if (!next || next === descend) break;
            descend = next;
          }
          node = descend;
          break;
        }
        node = node.parentElement;
      }

      // If pillContent wrapper exists somewhere up the chain AND it
      // contains exactly our URN, prefer it for the kind classifier.
      let pillNode = node;
      while (pillNode && pillNode !== sec) {
        const ck = pillNode.getAttribute && pillNode.getAttribute('componentkey');
        if (ck && /activity_\w+_pillContent$/i.test(ck)) {
          if (urnsInside(pillNode).size === 1) node = pillNode;
          break;
        }
        pillNode = pillNode.parentElement;
      }

      if (node && node !== sec) {
        // Dedup: only add if this URN's chosen node isn't a parent or child
        // of one we already kept. (Different anchors for the same URN may
        // resolve to slightly different nesting levels.)
        if (!itemRoots.some(prev => prev.contains(node) || node.contains(prev))) {
          itemRoots.push(node);
        }
      }
    }

    // Second pass: pick up URNs that appear only via [data-urn]/[urn]
    // attributes on container divs (some carousel cards don't emit an <a>
    // wrapping the URN, only the container annotation).
    const urnContainers = [...sec.querySelectorAll(
      'div[data-urn^="urn:li:activity:"], div[urn^="urn:li:activity:"]'
    )];
    for (const node of urnContainers) {
      const attrUrn =
        node.getAttribute('data-urn') || node.getAttribute('urn') || '';
      const urnMatch = attrUrn.match(/urn:li:activity:(\d+)/);
      if (!urnMatch) continue;
      const urn = urnMatch[1];
      if (seenUrns.has(urn)) continue;
      const txt = (node.innerText || '').trim();
      if (txt.length < 20) continue;
      if (itemRoots.some(prev => prev.contains(node) || node.contains(prev))) continue;
      seenUrns.add(urn);
      itemRoots.push(node);
    }

    // Legacy fallback for layouts where no activity anchors are present.
    let items = itemRoots;
    if (items.length === 0) {
      items = [...sec.querySelectorAll(
        '[componentkey*="activity_"][componentkey$="_pillContent"], li, div[data-urn^="urn:li:activity:"], div[urn^="urn:li:activity:"]'
      )];
      // Re-apply nesting filter for the legacy path
      const filtered = [];
      items.forEach(it => {
        const txt = (it.innerText || '').trim();
        if (txt.length < 20) return;
        if (filtered.some(prev => prev.contains(it))) return;
        filtered.push(it);
      });
      items = filtered;
    }

    const out = [];
    // Activity classification.
    //
    // For each item we decide one of five outcomes:
    //   action = 'posted'          — original post authored by the prospect
    //   action = 'reposted'        — plain repost of someone else's post, no commentary
    //   action = 'quoted_repost'   — repost with the prospect's own commentary on top
    //   kind   = 'comment'         — commented on someone else's post
    //   kind   = 'reaction'        — liked/celebrated/supported/insightful
    //
    // For 'reposted' and 'quoted_repost' we also try to extract:
    //   quoted_author — the original author's display name
    //   quoted_text   — the original post body
    //   commentary    — only on quoted_repost: the prospect's words on top
    //
    // Repost detection uses two independent signals — either fires the
    // classification:
    //
    //   Signal A (verb header): the item's header text contains
    //     "<prospect> reposted this". LinkedIn renders this for repost cards
    //     that show the original inline with the embedded author block in
    //     the main item flow.
    //
    //   Signal B (nested URN): the item contains an inner reference to
    //     another post — urn:li:ugcPost: or urn:li:share: in a child element —
    //     distinct from the outer urn:li:activity: that wraps this item.
    //     LinkedIn uses this shape for quoted reposts where the original is
    //     shown in a bordered embedded card. The verb header may be absent
    //     in this case ("Jonathan Eide • 2nd" looks like an original post).
    //
    // After detecting a repost, commentary extraction decides plain vs quoted.
    items.forEach(item => {
      const componentKey = item.getAttribute('componentkey') || '';

      // Pull the activity URL — the <a> linking to /feed/update/urn:li:activity:...
      const anchor = [...item.querySelectorAll('a[href*="/feed/update/"], a[href*="/posts/"]')]
        .find(a => a.href);
      const url = anchor?.href || null;

      // Outer URN: the activity id this whole item represents (the prospect's
      // own action). For a plain or quoted repost, this is the wrapper URN.
      const outerUrnMatch = (url || '').match(/urn:li:activity:(\d+)/);
      const outerUrn = outerUrnMatch ? outerUrnMatch[1] : null;

      // Find ALL post URNs referenced anywhere inside this item. LinkedIn uses
      // three namespaces — activity:, ugcPost:, share: — and a quoted repost
      // typically wraps an outer activity: around an inner ugcPost: (or share:
      // on older posts). We collect every (namespace, id) pair, then exclude
      // the outer one to find any "inner" reference — the embedded original.
      const innerRefs = new Set();  // strings of form "namespace:id"
      const collectRefs = (str) => {
        if (!str) return;
        const re = /urn:li:(activity|ugcPost|share):(\d+)/g;
        let m;
        while ((m = re.exec(str))) innerRefs.add(`${m[1]}:${m[2]}`);
      };
      [...item.querySelectorAll('a[href*="/feed/update/"], a[href*="/posts/"]')]
        .forEach(a => collectRefs(a.getAttribute('href') || ''));
      [...item.querySelectorAll('[data-urn], [urn]')]
        .forEach(el => {
          collectRefs(el.getAttribute('data-urn') || '');
          collectRefs(el.getAttribute('urn') || '');
        });
      // Scan innerHTML once for any references we missed (defensive).
      collectRefs(item.innerHTML || '');
      if (outerUrn) innerRefs.delete(`activity:${outerUrn}`);
      const hasNestedRef = innerRefs.size > 0;

      // Read the lines as <p> first (new SDUI), fall back to aria-hidden spans.
      let lines = [...item.querySelectorAll('p')]
        .map(el => (el.innerText || '').trim())
        .filter(Boolean);
      if (lines.length === 0) {
        lines = (item.innerText || '').split('\n').map(s => s.trim()).filter(Boolean);
      }

      // First meaningful line is the action header: e.g.
      //   "<Name> commented on a post"
      //   "<Name> reposted this"
      //   "<Name> liked a post"
      //   "<Name> posted this"
      const firstLine = lines.find(l => /\b(commented|posted|reposted|liked|celebrated|supported|shared|reacted)\b/i.test(l)) || lines[0] || '';

      // Signal A: verb header says "reposted" (or "shared", which LinkedIn
      // uses for the same concept in some locales).
      const verbSaysRepost = /\b(reposted|shared)\b/i.test(firstLine);

      // Classify kind + initial action. Comments and reactions short-circuit;
      // posts go through repost detection.
      let kind = 'post';
      let actionVerb = null;
      let isRepost   = false;

      if (/comments_pillContent/i.test(componentKey) || /\bcommented\b/i.test(firstLine)) {
        kind = 'comment';
        actionVerb = 'commented';
      } else if (/reactions_pillContent/i.test(componentKey)) {
        kind = 'reaction';
        actionVerb = 'reacted';
      } else if (
        /\b(liked|celebrated|supported|insightful)\b/i.test(firstLine) &&
        !verbSaysRepost && !/\bposted\b/i.test(firstLine)
      ) {
        // Pure reaction header — exclude when "reposted/shared/posted" also
        // appears (some headers chain verbs).
        kind = 'reaction';
        const m = firstLine.match(/\b(liked|celebrated|supported|insightful)\b/i);
        actionVerb = m ? m[1].toLowerCase() : 'reacted';
      } else {
        // It's a post. Decide original vs repost using Signal A OR Signal B.
        kind = 'post';
        isRepost = verbSaysRepost || hasNestedRef;
        actionVerb = isRepost ? 'reposted' : 'posted';
        // 'reposted' is tentative — commentary extraction below may upgrade
        // it to 'quoted_repost'. 'posted' stays as-is.
      }

      // Relative timestamp: "1w", "3d", "5h", "2mo", "1y" — appears as its own
      // <p> in SDUI, often surrounded by "•" separators.
      const relTime = lines.find(l => /^[<•·\s]*(\d+)\s*([smhdwy]|mo|hr|min|sec)\b/i.test(l));

      // Body text: the longest non-header, non-time, non-bullet line.
      // For reposts this often picks up the original post body; commentary
      // extraction below pulls out the prospect's own commentary separately.
      const headerSet = new Set([firstLine, '•', '·', relTime].filter(Boolean));
      const bodyText = lines
        .filter(l => !headerSet.has(l))
        .filter(l => l.length > 5)
        .filter(l => !/^•\s*\d+[smhdwy]/i.test(l))   // "• 1w"
        .filter(l => l !== 'Show all' && l !== 'See more' && l !== 'See less')
        .sort((a, b) => b.length - a.length)[0] || null;

      // For reposts, try to split commentary vs quoted_text and extract the
      // original author. Two parallel strategies — whichever succeeds first
      // produces the card boundary.
      //
      //   Path 1 (URN-anchored): when there's an inner ugcPost:/share: URN,
      //     walk up from its anchor to find the smallest ancestor that
      //     contains the inner ref but not the outer activity: ref. That
      //     ancestor is the embedded card. Works for Satyajeet-style quoted
      //     reposts where the embedded original has its own URN.
      //
      //   Path 2 (verb-anchored): when only Signal A fired (verb header,
      //     no inner URN), the original author is rendered inline as the
      //     first <a href="/in/X/"> that ISN'T the prospect's own profile.
      //     The "card" is the subtree starting from that author link. Works
      //     for Travis/Aadil-style plain reposts.
      //
      // Both paths set quotedAuthor / quotedText. Commentary extraction is
      // then the same for both: any substantial text outside the card region.
      let commentary   = null;
      let quotedText   = null;
      let quotedAuthor = null;
      if (kind === 'post' && isRepost) {
        try {
          let cardNode = null;

          // ── Path 1: URN-anchored ────────────────────────────────────────
          if (hasNestedRef) {
            const innerAnchors = [...item.querySelectorAll('a[href*="/feed/update/"], a[href*="/posts/"]')]
              .filter(a => {
                const m = (a.getAttribute('href') || '').match(/urn:li:(activity|ugcPost|share):(\d+)/);
                if (!m) return false;
                const ref = `${m[1]}:${m[2]}`;
                // Inner = anything in our innerRefs set (we already excluded
                // the outer activity: ref). The outer is the only thing we
                // shouldn't follow back to a card.
                return innerRefs.has(ref);
              });
            for (const a of innerAnchors) {
              let node = a.parentElement;
              while (node && node !== item) {
                const html = node.innerHTML || '';
                const hasOuter = outerUrn ? html.includes(`urn:li:activity:${outerUrn}`) : false;
                const refCount = (html.match(/urn:li:(activity|ugcPost|share):\d+/g) || []).length;
                if (!hasOuter && refCount >= 1 && (node.innerText || '').trim().length > 20) {
                  cardNode = node;
                  break;
                }
                node = node.parentElement;
              }
              if (cardNode) break;
            }
          }

          // ── Path 2: verb-anchored ───────────────────────────────────────
          // Used when Signal A fired (verb says "reposted") but URN-anchoring
          // didn't find a card — i.e. plain reposts where the original is
          // shown inline without its own activity reference.
          if (!cardNode && verbSaysRepost) {
            // The prospect's own profile slug — used to exclude their own
            // profile link from the author candidates. Derived from the
            // page URL (we're on linkedin.com/in/<slug>/).
            const prospectSlug = (() => {
              const m = (location.pathname || '').match(/^\/in\/([^/]+)/);
              return m ? m[1].toLowerCase() : null;
            })();
            const profileLinks = [...item.querySelectorAll('a[href*="/in/"]')]
              .filter(a => {
                const href = a.getAttribute('href') || '';
                const m = href.match(/\/in\/([^/?#]+)/);
                if (!m) return false;
                const slug = m[1].toLowerCase();
                return prospectSlug ? slug !== prospectSlug : true;
              });
            // The first non-prospect profile link is the original author.
            // The card is its nearest ancestor that also contains the post
            // body — practically, walk up until the ancestor's text length
            // is meaningfully larger than just the author block.
            if (profileLinks.length > 0) {
              const authorLink = profileLinks[0];
              let node = authorLink.parentElement;
              while (node && node !== item) {
                if ((node.innerText || '').trim().length > 80) {
                  cardNode = node;
                  break;
                }
                node = node.parentElement;
              }
            }
          }

          if (cardNode) {
            const cardLines = [...cardNode.querySelectorAll('p')]
              .map(el => (el.innerText || '').trim())
              .filter(Boolean);
            const allCardLines = cardLines.length
              ? cardLines
              : (cardNode.innerText || '').split('\n').map(s => s.trim()).filter(Boolean);

            // Author candidate: first short capitalized non-sentence line.
            // Excludes phrases that show up in metadata rows.
            quotedAuthor = allCardLines.find(l =>
              l.length > 1 && l.length < 80 &&
              /^[A-Z]/.test(l) &&
              !/[.?!]/.test(l) &&
              !/^\d/.test(l) &&
              !/(followers|connections|reposted|posted|commented|likes?)/i.test(l)
            ) || null;

            // Quoted body: longest meaningful line in the card.
            quotedText = allCardLines
              .filter(l => l !== quotedAuthor)
              .filter(l => l.length > 10)
              .filter(l => !/^[<•·\s]*\d+\s*([smhdwy]|mo|hr|min|sec)\b/i.test(l))
              .filter(l => !/^(followers?|connections?|likes?|comments?|reposts?)\b/i.test(l))
              .sort((a, b) => b.length - a.length)[0] || null;

            // Commentary: substantial text in the item that ISN'T inside
            // the card AND ISN'T a header/timestamp. The prospect's own
            // words on top of the embedded original.
            const cardText = (cardNode.innerText || '').trim();
            const commentaryCandidates = lines.filter(l => {
              if (headerSet.has(l)) return false;
              if (l.length < 5) return false;
              if (cardText.includes(l)) return false;
              if (/^[<•·\s]*\d+\s*([smhdwy]|mo|hr|min|sec)\b/i.test(l)) return false;
              if (l === 'Show all' || l === 'See more' || l === 'See less') return false;
              return true;
            });
            commentary = commentaryCandidates.sort((a, b) => b.length - a.length)[0] || null;

            if (commentary && commentary.length >= 15) {
              actionVerb = 'quoted_repost';
            } else {
              actionVerb = 'reposted';
              commentary = null;
            }
          }
          // No card found — leave actionVerb as 'reposted', skip extraction.
        } catch (err) {
          // Defensive: any DOM exception leaves actionVerb as the tentative
          // 'reposted' (or 'posted' if isRepost was false from the start).
        }
      }

      // For comments/reactions, parent_post_summary = body of the post they
      // reacted to. In our captured DOM we only see the rep's comment, so
      // we use the body text as the summary too — it's the best signal we
      // have without navigating to the post page.
      let parentPostSummary = null;
      if (kind === 'comment' || kind === 'reaction') {
        parentPostSummary = bodyText;
      }

      // Stable id: prefer the activity URN out of the URL, fall back to a
      // hash of the visible content so re-captures don't duplicate.
      let id;
      const urnMatch = (url || '').match(/urn:li:activity:(\d+)/);
      if (urnMatch) id = `li_${urnMatch[1]}`;
      else          id = hashId(firstLine + (bodyText || '').slice(0, 120));

      const entry = {
        id,
        kind,
        // LinkedIn doesn't expose absolute timestamps; we record now() and
        // the relative-time string. Backend can convert "1w" → date-1w on insert.
        occurred_at: new Date().toISOString(),
        relative_time: relTime || null,
        text:        bodyText || firstLine || '',
        action:      actionVerb,
        source_url:  url,
      };
      if (parentPostSummary) entry.parent_post_summary = parentPostSummary;
      // Repost-detection detail fields. Only set when we successfully
      // extracted them — downstream consumers can safely null-check.
      if (commentary)   entry.commentary    = commentary;
      if (quotedText)   entry.quoted_text   = quotedText;
      if (quotedAuthor) entry.quoted_author = quotedAuthor;

      out.push(entry);
    });

    // De-dupe by id (we may have captured the same activity from multiple tabs).
    const seen = new Set();
    return out.filter(e => {
      if (seen.has(e.id)) return false;
      seen.add(e.id);
      return true;
    });
  }

  function parseDateRange(line) {
    if (!line) return { startDate: null, endDate: null, durationMonths: null };

    // Months map
    const months = {
      jan: '01', feb: '02', mar: '03', apr: '04', may: '05', jun: '06',
      jul: '07', aug: '08', sep: '09', oct: '10', nov: '11', dec: '12',
    };
    const parsePart = (raw) => {
      if (!raw) return null;
      // Strip trailing "· 1 yr 2 mos" / "· On-site" / etc. — anything after
      // the first " · " separator. Also handle "/" separators rarely used.
      const s = raw.split(/\s+·\s+|\s+\/\s+/)[0].trim();
      // "Mar 2026" / "March 2026"
      const m = s.match(/([A-Za-z]{3,9})\s+(\d{4})/);
      if (m) {
        const mm = months[m[1].slice(0, 3).toLowerCase()];
        if (mm) return `${m[2]}-${mm}-01`;
      }
      // Year-only — "2024" or "2025" (LinkedIn shows year-only when user
      // didn't enter a month)
      const y = s.match(/\b(19|20)\d{2}\b/);
      if (y) return `${y[0]}-01-01`;
      return null;
    };

    const parts = line.split(/\s+-\s+|\s+to\s+|\s+–\s+|\s+—\s+/i).map(s => s.trim());
    if (parts.length < 2) return { startDate: parsePart(parts[0] || ''), endDate: null, durationMonths: null };

    const startDate = parsePart(parts[0]);
    const endRaw    = parts[1];
    const endDate   = /present/i.test(endRaw) ? null : parsePart(endRaw);

    // Duration text after middle dot, e.g. "· 4 yrs 2 mos"
    const durMatch = line.match(/·\s*(?:(\d+)\s*yrs?)?\s*(?:(\d+)\s*mos?)?/i);
    const yrs  = parseInt(durMatch?.[1] || '0', 10);
    const mos  = parseInt(durMatch?.[2] || '0', 10);
    const durationMonths = (yrs * 12 + mos) || null;

    return { startDate, endDate, durationMonths };
  }

  // Aggregate all profile-section data into the shape expected by
  // POST /api/linkedin-profiles/upsert
  // ── Progressive capture state ────────────────────────────────────────────────
  //
  // Capture happens incrementally as the user scrolls the LinkedIn profile.
  // Each section has a status:
  //   'pending'  — section root not yet seen in viewport
  //   'loading'  — in viewport, waiting for LinkedIn lazy-load to populate
  //   'captured' — content read; `value` holds the result
  //   'empty'    — in viewport + populated, but section has no items
  //
  // Delta-refresh fields (v1.5):
  //   dbValue       — what the linkedin_profiles row holds for this section
  //                   (null until GET_LINKEDIN_PROFILE returns; null forever
  //                   if no row exists yet for this slug).
  //   dbCapturedAt  — last_*_captured_at timestamp from the DB row.
  //   dbHydrated    — true once GET_LINKEDIN_PROFILE has resolved, even
  //                   if it returned null. Lets the UI distinguish
  //                   "no data on file" from "still fetching".
  //
  // The state object is recreated for each profile (init() resets it). UI
  // subscribers (renderCaptureSection) listen for state changes via
  // captureSubscribe() and rerender just the row that changed.
  function makeCaptureState() {
    const slot = (emptyVal) => ({
      status:        'pending',
      value:         emptyVal,
      lastCapturedAt: null,
      edited:        false,
      dbValue:       null,
      dbCapturedAt:  null,
      dbHydrated:    false,
      // viewMode controls whether the expanded body shows the diff
      // view (default when a diff exists) or the full live data view.
      // Set to 'auto' so refreshRow picks the right default each time
      // based on the slot's current diff state. The user can override
      // by clicking "Show all live data" or "Show changes only" — that
      // sets viewMode to 'full' or 'diff' explicitly. Reset to 'auto'
      // when a fresh capture changes what's available to show.
      viewMode:      'auto',
    });
    return {
      about:      slot(null),
      experience: slot([]),
      education:  slot([]),
      activity:   slot([]),
    };
  }

  let captureState = makeCaptureState();
  const captureSubscribers = new Set();
  let activeObservers = [];   // disposed on SPA nav

  function captureSubscribe(fn) {
    captureSubscribers.add(fn);
    return () => captureSubscribers.delete(fn);
  }

  function notifyCapture(section) {
    captureSubscribers.forEach(fn => {
      try { fn(section, captureState[section]); } catch (e) { /* swallow */ }
    });
  }

  function disposeCaptureObservers() {
    activeObservers.forEach(o => { try { o.disconnect(); } catch (_) {} });
    activeObservers = [];
    captureSubscribers.clear();
  }

  // ── DB hydration + delta diffing (NEW in v1.5) ─────────────────────────────
  //
  // hydrateFromDbProfile(profile) — pulls the captured fields off a
  // linkedin_profiles row (returned by GET_LINKEDIN_PROFILE) and merges
  // them into captureState as `dbValue` + `dbCapturedAt`. Crucially,
  // it ALSO seeds slot.value when the slot is still pending — so reps
  // can see "what's on file" before scrolling triggers a live scrape.
  //
  // Once a section's live-scrape has fired (status moves past pending),
  // we leave slot.value alone — live wins over stored. This keeps the
  // diff badge meaningful: stored = baseline, live = candidate.
  //
  // Idempotent and safe to call multiple times. After it runs, every
  // subscriber gets a single notify per section so the panel re-renders
  // its rows with the new dbValue context.
  function hydrateFromDbProfile(profile) {
    // Always mark every slot as hydrated, even if `profile` is null —
    // that's how the UI distinguishes "no profile on file yet" from
    // "we haven't asked the backend yet."
    const dbAbout    = profile?.about         ?? null;
    const dbExp      = Array.isArray(profile?.experience) ? profile.experience : [];
    const dbEdu      = Array.isArray(profile?.education)  ? profile.education  : [];
    const dbActivity = Array.isArray(profile?.activity)   ? profile.activity   : [];

    const seedSlot = (key, dbVal, dbTs) => {
      const slot = captureState[key];
      slot.dbValue      = dbVal;
      slot.dbCapturedAt = dbTs;
      slot.dbHydrated   = true;
      // Diff state is about to change (we have a new baseline). Reset
      // viewMode so bodyFor re-picks the right default. Without this,
      // a user's "Show all live data" choice would persist across
      // saves even though the diff that justified it is gone.
      slot.viewMode     = 'auto';
      // Only seed the live value if the live scrape hasn't started.
      // `pending` means the IntersectionObserver hasn't fired yet —
      // showing the DB content there is purely informational and will
      // be replaced by a real scrape as soon as the rep scrolls past.
      if (slot.status === 'pending' && !slot.edited) {
        const isEmpty =
          dbVal == null ||
          (Array.isArray(dbVal) && dbVal.length === 0);
        if (!isEmpty) {
          slot.value      = dbVal;
          slot.status     = 'captured';
          // Mark this value as a DB seed rather than a fresh live scrape.
          // diffSection() reads this so it can distinguish "we're showing
          // you what's on file" from "we just verified live === DB."
          // runCapture clears this flag the moment it overwrites .value.
          slot.dbSeeded   = true;
        }
      }
      notifyCapture(key);
    };

    seedSlot('about',      dbAbout,    profile?.last_about_captured_at    || null);
    seedSlot('experience', dbExp,      profile?.last_exp_captured_at      || null);
    seedSlot('education',  dbEdu,      profile?.last_edu_captured_at      || null);
    seedSlot('activity',   dbActivity, profile?.last_activity_captured_at || null);
  }

  // Compare current live (or seeded) value against the DB value for one
  // section. Returns one of:
  //   'no-db'      — no profile on file (or hydration not yet returned)
  //   'on-file'    — DB has it AND live capture has not produced anything
  //                  meaningfully different (or hasn't run yet)
  //   'unchanged'  — live capture matches DB exactly
  //   'updated'    — live capture differs from DB
  //   'new-data'   — DB had nothing here, live capture produced something
  //
  // For arrays we use length+shallow-key equality rather than deep equals;
  // a stricter compare would flag every cosmetic LinkedIn DOM tweak as a
  // change. The signature for each section is intentionally narrow so
  // false positives don't push reps into pointless re-saves.
  function diffSection(key, slot) {
    if (!slot.dbHydrated)  return 'no-db';

    const live = slot.value;
    const dbV  = slot.dbValue;

    const dbEmpty   = (dbV == null) || (Array.isArray(dbV) && dbV.length === 0);
    const liveEmpty = (live == null) || (Array.isArray(live) && live.length === 0);

    // No DB data at all
    if (dbEmpty) {
      return liveEmpty ? 'no-db' : 'new-data';
    }

    // We have DB data. If live capture hasn't produced anything yet
    // (still pending/loading and we seeded with DB), report on-file.
    if (slot.status === 'pending' || slot.status === 'loading') {
      return 'on-file';
    }
    // We promoted a pending slot to 'captured' by seeding it from DB —
    // value === dbValue trivially. Treat as on-file until a real live
    // scrape happens. Once the rep edits the slot (slot.edited), we
    // exit seed-state and fall through to the real comparison below.
    if (slot.dbSeeded && !slot.edited) {
      return 'on-file';
    }
    // Live ran but came back empty (rep blocked, parser miss): treat
    // as on-file rather than "updated to empty" — the upsert merge
    // rules wouldn't clear it anyway.
    if (liveEmpty) return 'on-file';

    // Both populated — compare.
    if (key === 'about') {
      return (String(live).trim() === String(dbV).trim()) ? 'unchanged' : 'updated';
    }

    if (key === 'experience') {
      if (live.length !== dbV.length) return 'updated';
      const sig = (x) => `${x.title||''}|${x.company||''}|${x.start_date||''}|${x.end_date||''}`;
      const liveSet = new Set(live.map(sig));
      for (const d of dbV) if (!liveSet.has(sig(d))) return 'updated';
      return 'unchanged';
    }

    if (key === 'education') {
      if (live.length !== dbV.length) return 'updated';
      const sig = (x) => `${x.school||''}|${x.degree||''}|${x.field_of_study||''}|${x.start_year||''}|${x.end_year||''}`;
      const liveSet = new Set(live.map(sig));
      for (const d of dbV) if (!liveSet.has(sig(d))) return 'updated';
      return 'unchanged';
    }

    if (key === 'activity') {
      // Activity is merged on the server by id, so any live items not
      // in DB count as new — even one is enough to mark "updated".
      const dbIds = new Set((dbV || []).map(x => x?.id).filter(Boolean));
      const newOnes = (live || []).filter(x => x?.id && !dbIds.has(x.id));
      return newOnes.length > 0 ? 'updated' : 'unchanged';
    }

    return 'unchanged';
  }

  // Aggregate diff across all four sections. Returns:
  //   { hasDb, anyChanges, overall }
  //   overall ∈ 'no-db' | 'unchanged' | 'updated'
  //
  // The Save button uses this to flip its label and disabled state.
  function diffAll() {
    const perSection = {};
    let hasDb       = false;
    let anyChanges  = false;
    let anyOnFile   = false;

    for (const key of ['about', 'experience', 'education', 'activity']) {
      const slot = captureState[key];
      const d    = diffSection(key, slot);
      perSection[key] = d;
      if (slot.dbHydrated && (slot.dbValue != null && (!Array.isArray(slot.dbValue) || slot.dbValue.length))) {
        hasDb = true;
      }
      if (d === 'updated' || d === 'new-data') anyChanges = true;
      if (d === 'on-file' || d === 'unchanged') anyOnFile = true;
    }

    let overall;
    if (!hasDb && !anyOnFile) overall = 'no-db';
    else if (anyChanges)      overall = 'updated';
    else                      overall = 'unchanged';

    return { hasDb, anyChanges, anyOnFile, overall, perSection };
  }

  // Set up the IntersectionObserver + per-section MutationObservers that
  // populate captureState as the user scrolls. Idempotent — safe to call
  // multiple times; previous observers are disposed first.
  function setupCaptureObservers() {
    disposeCaptureObservers();
    captureState = makeCaptureState();

    // About is usually visible at the top of the page — capture immediately
    // if it's already there, otherwise wait for it to render.
    const sectionDefs = [
      { key: 'about',      headings: [/^about\b/i],         capture: () => captureAboutText(),  isEmpty: v => !v },
      { key: 'experience', headings: [/^experience$/i],    capture: () => captureExperience(), isEmpty: v => !v?.length },
      { key: 'education',  headings: [/^education$/i],     capture: () => captureEducation(),  isEmpty: v => !v?.length },
      { key: 'activity',   headings: [
          /^activity$/i,
          /(\bposts?\b|\bactivity\b).{0,30}\bfollowers?$/i,
          /\brecent activity\b/i,
        ], capture: () => captureActivity(), isEmpty: v => !v?.length },
    ];

    const captureDebounce = {};   // per-key debounce timers

    function runCapture(def, reason) {
      if (!extensionAlive()) return;
      clearTimeout(captureDebounce[def.key]);
      const delay =
        reason === 'attach'    ? 200 :   // already-visible at attach: quick
        reason === 'intersect' ? 600 :   // freshly scrolled into view: brief
                                  800;   // mutation: longer debounce
      captureDebounce[def.key] = setTimeout(() => {
        const slot = captureState[def.key];
        // If the rep has manually edited this section, leave their values
        // intact — auto-recapture would overwrite their corrections.
        if (slot.edited) return;
        // Mark loading on first attempt
        if (slot.status === 'pending') {
          slot.status = 'loading';
          notifyCapture(def.key);
        }
        let value;
        try { value = def.capture(); }
        catch (e) {
          // Extraction threw. Treat as a failed attempt — but do NOT
          // wipe a value we successfully captured earlier. LinkedIn
          // re-virtualizes sections on scroll, so a later scrape can
          // throw even though the section's data is real and was
          // already captured. Clobbering it here is what caused
          // getExperience() to return [] after the panel had shown
          // entries. Keep the prior value; only mark empty if we never
          // had one.
          const hadValue = def.key === 'about'
            ? (slot.value != null && String(slot.value).trim() !== '')
            : (Array.isArray(slot.value) && slot.value.length > 0);
          if (!hadValue) {
            slot.status = 'empty';
            slot.value  = def.key === 'about' ? null : [];
          }
          notifyCapture(def.key);
          return;
        }

        // Guard against an empty scrape overwriting a good one. Same
        // reasoning as the catch block: a section that previously
        // captured N entries should not silently drop to 0 because a
        // later scroll-triggered scrape ran while the DOM was mid
        // re-render. If the new value is empty but we already hold a
        // non-empty value, keep what we have.
        const newIsEmpty = def.isEmpty(value);
        const hadValue = def.key === 'about'
          ? (slot.value != null && String(slot.value).trim() !== '')
          : (Array.isArray(slot.value) && slot.value.length > 0);
        if (newIsEmpty && hadValue) {
          // Keep the existing value/status; just acknowledge the attempt.
          notifyCapture(def.key);
          return;
        }

        slot.value           = value;
        slot.lastCapturedAt  = Date.now();
        slot.status          = newIsEmpty ? 'empty' : 'captured';
        // Live scrape just produced a value — it's no longer a DB seed.
        slot.dbSeeded        = false;
        // Reset viewMode: a fresh capture may have introduced a diff
        // the user hasn't seen yet. 'auto' lets bodyFor pick the right
        // default (diff if there's a diff, full otherwise).
        slot.viewMode        = 'auto';
        notifyCapture(def.key);
      }, delay);
    }

    // Try to find each section's <section> wrapper. If a section isn't yet
    // in the DOM, we'll retry on every body mutation until it appears.
    //
    // We also track which DOM node we attached to (`def.__attachedSec`) so
    // the body MutationObserver below can detect when LinkedIn has replaced
    // the section node out from under us (React re-renders the SDUI tree on
    // tab switches, scroll-triggered hydration, etc.) and re-attach to the
    // live node. Without re-attach, the IntersectionObserver keeps watching
    // a detached node and never fires — the symptom was Activity sitting on
    // status='pending' forever even after scrolling it into view.
    function tryAttach(def) {
      const sec = findSectionByHeading(def.headings);
      if (!sec) return false;

      // Already attached to this exact node? Nothing to do.
      if (def.__attachedSec === sec) return true;

      def.__attachedSec = sec;

      // IntersectionObserver: triggers initial capture when the section
      // enters the viewport. Standard browser behavior is to fire the
      // callback once on observe() with the current intersection state,
      // so sections already in the viewport at attach time will be
      // captured immediately.
      const io = new IntersectionObserver((entries) => {
        for (const e of entries) {
          if (e.isIntersecting) runCapture(def, 'intersect');
        }
      }, { root: null, rootMargin: '200px', threshold: 0 });
      io.observe(sec);
      activeObservers.push(io);

      // Belt-and-braces: also fire capture immediately if the section
      // bounding rect is already on screen. Some layouts have caused the
      // initial IntersectionObserver callback to be skipped.
      const rect = sec.getBoundingClientRect();
      const inView = rect.top < window.innerHeight && rect.bottom > 0;
      if (inView) runCapture(def, 'attach');

      // MutationObserver: re-captures when items are added/removed in the
      // section (e.g. LinkedIn populating lazy-loaded entries, user expanding
      // "see more" which appends a longer text node, switching the Activity
      // tab strip). We deliberately don't observe characterData because it
      // fires constantly during page interactions; childList is enough to
      // catch the cases we care about.
      const mo = new MutationObserver(() => runCapture(def, 'mutation'));
      mo.observe(sec, { childList: true, subtree: true });
      activeObservers.push(mo);

      // Watchdog: if 3 seconds after attach the slot is still on its
      // initial 'pending' status (meaning runCapture has never fired —
      // neither IntersectionObserver nor inView path triggered) AND the
      // section is currently visible, force a capture. This catches the
      // case where IO never fires on a section that's already past the
      // root margin (e.g. very tall pages where the section was mounted
      // but the IO's initial callback was skipped on a stale node).
      setTimeout(() => {
        if (!extensionAlive()) return;
        if (def.__attachedSec !== sec) return;   // re-attached elsewhere
        const slot = captureState[def.key];
        if (!slot || slot.status !== 'pending') return;
        if (slot.edited) return;
        const r = sec.getBoundingClientRect();
        const visible = r.bottom > 0 && r.top < window.innerHeight && r.width > 0;
        if (visible) runCapture(def, 'watchdog');
      }, 3000);

      return true;
    }

    // Attach what we can right now…
    sectionDefs.forEach(def => tryAttach(def));

    // …and watch the body for late-arriving OR re-mounted sections. We
    // re-run tryAttach for every def on each body mutation: tryAttach is
    // a no-op for defs already pointing at the live node, and re-attaches
    // for defs whose section was swapped out by a React re-render. This
    // is more aggressive than the original "splice off once attached"
    // approach but the cost is low — debounced + cheap fast-path — and
    // the resilience is worth it.
    let bodyObsTimer = null;
    const bodyObs = new MutationObserver(() => {
      if (bodyObsTimer) return;   // already scheduled
      bodyObsTimer = setTimeout(() => {
        bodyObsTimer = null;
        if (!extensionAlive()) return;
        sectionDefs.forEach(def => {
          // Fast path: tracked node still connected and still has its
          // heading — nothing to do.
          if (def.__attachedSec && def.__attachedSec.isConnected) {
            const stillHasHeading = def.__attachedSec.querySelector(
              'h2, h3, [role="heading"]'
            );
            if (stillHasHeading) return;
          }
          tryAttach(def);
        });
      }, 400);
    });
    bodyObs.observe(document.body, { childList: true, subtree: true });
    activeObservers.push(bodyObs);
  }

  function captureFullProfile() {
    const basics = extractProfileInfo();
    return {
      linkedin_url: basics.linkedinUrl,
      fields: {
        full_name:  basics.name     || null,
        headline:   basics.title    || null,
        location:   basics.location || null,
        about:      captureState.about.value      || null,
        experience: captureState.experience.value || [],
        education:  captureState.education.value  || [],
        activity:   captureState.activity.value   || [],
      },
      counts: {
        about:      captureState.about.value ? 1 : 0,
        experience: (captureState.experience.value || []).length,
        education:  (captureState.education.value  || []).length,
        activity:   (captureState.activity.value   || []).length,
      },
      // A snapshot of capture progress, so callers can warn the user about
      // sections that haven't loaded yet.
      progress: {
        about:      captureState.about.status,
        experience: captureState.experience.status,
        education:  captureState.education.status,
        activity:   captureState.activity.status,
      },
    };
  }

  // ── bg messaging helper ──────────────────────────────────────────────────────

  function bgMessage(payload) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(payload, response => {
        if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
        else resolve(response);
      });
    });
  }

  function getStatusIdx(status) {
    return STATUS_ORDER.indexOf(status || '');
  }

  // ── Build panel shell ────────────────────────────────────────────────────────

  function buildPanel() {
    const el = document.createElement('div');
    el.id = PANEL_ID;
    el.style.cssText = `
      position: fixed; top: 72px; right: 16px; width: 290px;
      background: #ffffff; border: 1px solid #e2e8f0;
      border-radius: 10px; box-shadow: 0 4px 20px rgba(0,0,0,0.10);
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      font-size: 13px; color: #1a202c; z-index: 9999; overflow: hidden;
      max-height: calc(100vh - 90px); overflow-y: auto;
    `;
    return el;
  }

  function renderHeader(panel, name, title) {
    const header = document.createElement('div');
    header.style.cssText = `background:${TEAL};padding:9px 13px;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:10;`;
    header.innerHTML = `
      <div style="display:flex;align-items:center;gap:6px;">
        <span style="background:#fff;color:${TEAL};font-size:9px;font-weight:700;padding:1px 5px;border-radius:3px;">GW</span>
        <span style="color:#fff;font-size:12px;font-weight:600;">GoWarmCRM</span>
      </div>
      <button id="gw-close" style="background:none;border:none;color:#fff;font-size:18px;cursor:pointer;line-height:1;padding:0;opacity:0.85;">×</button>
    `;
    panel.appendChild(header);

    // Identity subline — populated asynchronously by renderIdentitySubline().
    // Reserved here so it sits between the header and the name row even
    // before /verify resolves. Hidden until populated.
    const idLine = document.createElement('div');
    idLine.id = 'gw-identity-subline';
    idLine.style.cssText = 'display:none;padding:5px 13px;background:#F0FDFA;border-bottom:1px solid #CCFBF1;font-size:10px;color:#0F766E;line-height:1.3;';
    panel.appendChild(idLine);

    // Debug IDs strip — populated by renderDebugIds() once we have IDs to
    // show AND the debug flag is on. Sits between the identity subline and
    // the name row so it's visible without scrolling. Hidden by default;
    // takes zero space when not shown.
    const dbgLine = document.createElement('div');
    dbgLine.id = 'gw-debug-ids';
    dbgLine.style.cssText = 'display:none;padding:4px 13px;background:#FEF3C7;border-bottom:1px solid #FDE68A;font-size:10px;color:#78350F;line-height:1.3;font-family:ui-monospace,SFMono-Regular,Menlo,monospace;letter-spacing:0.02em;';
    panel.appendChild(dbgLine);

    const nameRow = document.createElement('div');
    nameRow.style.cssText = 'padding:10px 13px 8px;border-bottom:1px solid #f1f5f9;';
    nameRow.innerHTML = `
      <div style="font-weight:600;font-size:14px;">${escHtml(name)}</div>
      ${title ? `<div style="font-size:11px;color:#64748b;margin-top:1px;">${escHtml(title)}</div>` : ''}
    `;
    panel.appendChild(nameRow);

    panel.querySelector('#gw-close').addEventListener('click', () => panel.remove());
  }

  // Populates the identity subline below the header. Called from init()
  // once GET_IDENTITY returns. Shows "Saving to <org> · <email>" so a
  // rep with multiple workspaces can tell at a glance which one their
  // capture will land in.
  function renderIdentitySubline(panel, identity) {
    const el = panel.querySelector('#gw-identity-subline');
    if (!el || !identity) return;
    const org   = identity.org_name || (identity.org_id ? `Org #${identity.org_id}` : 'Unknown workspace');
    const email = identity.email    || '';
    el.textContent = `Saving to ${org}${email ? ` · ${email}` : ''}`;
    el.title       = email;
    el.style.display = 'block';
  }

  // Populates the debug-IDs strip below the identity subline. Called
  // anywhere DB IDs become available (on prospect lookup, on upsert
  // response). Only renders if debugMode is true; otherwise the strip
  // stays hidden and the strip element is invisible (display:none).
  //
  // ids: { profile_id, prospect_id, account_id } — any subset is fine;
  //      keys with null/undefined values are omitted from the rendered
  //      strip. If all three are null, the strip stays hidden.
  //
  // The most recent non-empty `ids` is also cached in lastDebugIds so
  // the Ctrl+Shift+D shortcut can replay them on toggle without a
  // re-fetch. Empty calls do not overwrite the cache.
  function renderDebugIds(panel, ids) {
    if (!panel) return;
    const el = panel.querySelector('#gw-debug-ids');
    if (!el) return;
    // Merge new ids over the cache so partial calls (e.g. just profile_id
    // from GET_LINKEDIN_PROFILE) don't lose previously-known prospect_id
    // and account_id from the LOOKUP_PROSPECT response.
    if (ids && (ids.profile_id != null || ids.prospect_id != null || ids.account_id != null)) {
      lastDebugIds = {
        profile_id:  ids.profile_id  != null ? ids.profile_id  : lastDebugIds.profile_id,
        prospect_id: ids.prospect_id != null ? ids.prospect_id : lastDebugIds.prospect_id,
        account_id:  ids.account_id  != null ? ids.account_id  : lastDebugIds.account_id,
      };
    }
    if (!debugMode) {
      el.style.display = 'none';
      return;
    }
    const parts = [];
    if (lastDebugIds.profile_id   != null) parts.push(`profile: ${lastDebugIds.profile_id}`);
    if (lastDebugIds.prospect_id  != null) parts.push(`prospect: ${lastDebugIds.prospect_id}`);
    if (lastDebugIds.account_id   != null) parts.push(`account: ${lastDebugIds.account_id}`);
    if (parts.length === 0) {
      el.style.display = 'none';
      return;
    }
    el.textContent   = `DEBUG · ${parts.join(' · ')}`;
    el.style.display = 'block';
  }

  // Format a stored timestamp as "3 days ago", "just now", "Mar 14".
  // Used to show last-captured times in the delta-refresh badges.
  function formatRelative(iso) {
    if (!iso) return '';
    const then = new Date(iso);
    if (isNaN(then.getTime())) return '';
    const diffSec = Math.floor((Date.now() - then.getTime()) / 1000);
    if (diffSec < 60)        return 'just now';
    if (diffSec < 3600)      return `${Math.floor(diffSec / 60)}m ago`;
    if (diffSec < 86400)     return `${Math.floor(diffSec / 3600)}h ago`;
    if (diffSec < 86400 * 7) return `${Math.floor(diffSec / 86400)}d ago`;
    if (diffSec < 86400 * 30) return `${Math.floor(diffSec / (86400 * 7))}w ago`;
    return then.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
  }

  // ── State views ──────────────────────────────────────────────────────────────

  function renderLoading(panel) {
    const d = document.createElement('div');
    d.style.cssText = 'padding:20px;text-align:center;color:#94a3b8;font-size:12px;';
    d.textContent = 'Looking up prospect…';
    panel.appendChild(d);
  }

  function renderNotFound(panel, profileInfo) {
    const { name = '', title = '', company = '', location = '', degree = null } = profileInfo || {};
    const linkedinUrl = getCurrentLinkedInUrl();

    const nameParts  = name.trim().split(/\s+/);
    const firstName  = nameParts[0] || '';
    const lastName   = nameParts.slice(1).join(' ') || '';

    const d = document.createElement('div');
    d.style.cssText = 'padding:14px 13px;';

    const inp = (id, label, val = '') => `
      <div style="margin-bottom:7px;">
        <label style="font-size:10px;color:#64748b;display:block;margin-bottom:2px;">${label}</label>
        <input id="${id}" value="${escHtml(val)}" style="width:100%;padding:5px 7px;border:1px solid #e2e8f0;border-radius:5px;font-size:12px;color:#1a202c;box-sizing:border-box;" />
      </div>
    `;

    d.innerHTML = `
      <div style="font-size:11px;color:#94a3b8;margin-bottom:10px;">Not in your CRM. Add prospect:</div>
      ${inp('gw-add-firstname', 'First name *', firstName)}
      ${inp('gw-add-lastname',  'Last name',    lastName)}
      ${inp('gw-add-headline',  'LinkedIn Headline', title)}
      ${inp('gw-add-company',   'Company name', company)}
      ${inp('gw-add-email',     'Work email',   '')}
      ${inp('gw-add-location',  'Location',     location)}
      <button id="gw-add-btn" style="width:100%;padding:7px;background:${TEAL};color:#fff;border:none;border-radius:6px;font-size:12px;font-weight:600;cursor:pointer;margin-top:6px;">Add to GoWarmCRM</button>
      <div id="gw-add-feedback" style="margin-top:6px;font-size:11px;display:none;"></div>
    `;
    panel.appendChild(d);

    // Show progressive capture rows below the add form (no separate save
    // button — the "Add to GoWarmCRM" button below handles both: it creates
    // the prospect AND upserts the captured profile data linked to it).
    renderCaptureSection(panel, /* prospect */ null, { hideSaveButton: true });

    const btn      = d.querySelector('#gw-add-btn');
    const feedback = d.querySelector('#gw-add-feedback');

    setTimeout(() => {
      const focusEl = company ? '#gw-add-email' : '#gw-add-company';
      d.querySelector(focusEl)?.focus();
    }, 50);

    btn.addEventListener('click', async () => {
      const fn = d.querySelector('#gw-add-firstname').value.trim();
      const ln = d.querySelector('#gw-add-lastname').value.trim();
      let   co = d.querySelector('#gw-add-company').value.trim();
      const em = d.querySelector('#gw-add-email').value.trim();

      if (!fn) {
        feedback.style.cssText = 'font-size:11px;display:block;color:#dc2626;margin-top:4px;';
        feedback.textContent = 'First name is required';
        return;
      }

      btn.disabled    = true;
      btn.textContent = 'Adding…';
      feedback.style.display = 'none';

      // Make sure experience data is captured before we resolve the
      // company URL from it. If the user clicked Add without scrolling
      // down, this scrolls the experience section into view, waits for
      // LinkedIn to render it, captures, and restores scroll position.
      // No-op (and no scroll-jump) if experience was already captured.
      await ensureExperienceCaptured();

      // If the company field is still empty, experience may now have
      // arrived via the auto-scroll above even though it was missing when
      // the form was first rendered (common on profiles whose headline
      // names no employer — e.g. "Investor"). Backfill from the current
      // experience entry so both the payload and the visible field show
      // the company.
      if (!co) {
        try {
          const exp = getExperience();
          const isCurrentEntry = (e) => {
            const ed = e?.end_date;
            if (ed == null) return true;
            const s = String(ed).trim().toLowerCase();
            return s === '' || s === 'present';
          };
          const cur = exp.find(isCurrentEntry) || exp[0];
          if (cur?.company) {
            co = cur.company.trim();
            const field = d.querySelector('#gw-add-company');
            if (field && !field.value.trim()) field.value = co;
          }
        } catch (_) { /* leave co empty — backend still gets the rest */ }
      }

      // Resolve the employer's LinkedIn company URL from the experience
      // section. By this point experience has been captured if it exists
      // on the profile at all (see ensureExperienceCaptured above).
      //
      // A profile can have MULTIPLE concurrent roles (end_date null) — e.g.
      // a CEO who is also a board member elsewhere. Picking "first current
      // entry in DOM order" is unstable and frequently picks the wrong
      // company (or one with no company_linkedin_url at all, which then
      // creates a catchall account with no identifier for enrichment).
      //
      // Instead, anchor on `co` — the company name in the form, which is
      // pre-filled from the profile top card (LinkedIn's notion of the
      // person's PRIMARY company) and may have been corrected by the user.
      // Among current entries, prefer the one whose company name matches
      // `co`. Fall back through progressively looser strategies so we still
      // send *something* sensible when there's no clean match.
      let currentCompanyLinkedInUrl;
      try {
        const exp = getExperience();
        const isCurrent = (e) => {
          const ed = e?.end_date;
          if (ed == null) return true;
          const s = String(ed).trim().toLowerCase();
          return s === '' || s === 'present';
        };

        // Normalize for comparison: lowercase, trim, drop common corporate
        // suffixes and punctuation so "VitalEdge Technologies" matches
        // "VitalEdge Technologies, Inc." etc.
        const normCo = (s) => String(s || '')
          .toLowerCase()
          .replace(/[.,]/g, ' ')
          .replace(/\b(inc|llc|ltd|limited|corp|corporation|co|gmbh|plc|technologies|technology)\b/g, ' ')
          .replace(/\s+/g, ' ')
          .trim();

        const currentEntries = exp.filter(isCurrent);
        const coNorm         = normCo(co);

        // Strategy 1: a current entry whose company name matches the form's
        // company AND that actually has a company URL.
        let chosen = coNorm
          ? currentEntries.find(e => e.company_linkedin_url && normCo(e.company) === coNorm)
          : null;

        // Strategy 2: any current entry matching the company name (even if
        // it has no URL — at least it's the right company).
        if (!chosen && coNorm) {
          chosen = currentEntries.find(e => normCo(e.company) === coNorm);
        }

        // Strategy 3: the first current entry that at least HAS a URL —
        // better than an entry we know is URL-less.
        if (!chosen || !chosen.company_linkedin_url) {
          chosen = currentEntries.find(e => e.company_linkedin_url) || chosen;
        }

        // Strategy 4: original behavior — first current, else first overall.
        if (!chosen) {
          chosen = currentEntries[0] || exp[0];
        }

        currentCompanyLinkedInUrl = chosen?.company_linkedin_url || undefined;
      } catch (_) {
        currentCompanyLinkedInUrl = undefined;
      }

      try {
        const res = await bgMessage({
          type:               'ADD_PROSPECT',
          firstName:          fn,
          lastName:           ln,
          linkedinHeadline:   d.querySelector('#gw-add-headline')?.value?.trim() || undefined,
          companyName:        co || undefined,
          companyLinkedInUrl: currentCompanyLinkedInUrl,
          email:              em || undefined,
          linkedinUrl:        linkedinUrl,
          location:           d.querySelector('#gw-add-location')?.value?.trim() || undefined,
          source:             'linkedin_extension',
        });

        if (!res.ok) throw new Error(res.error);

        // Also upsert whatever profile data has been captured so far,
        // linked to the new prospect. Best-effort — failures here don't
        // block the "Added successfully" feedback for the prospect itself.
        const captured = captureFullProfile();
        if ((captured.counts.about + captured.counts.experience +
             captured.counts.education + captured.counts.activity) > 0) {
          bgMessage({
            type:        'UPSERT_LINKEDIN_PROFILE',
            linkedinUrl: captured.linkedin_url,
            fields:      captured.fields,
            linkTo:      { entity_type: 'prospects', entity_id: res.prospect.id },
          })
            .then((upsertRes) => {
              // Refresh the debug-IDs strip with the now-confirmed IDs.
              if (upsertRes?.ok) {
                renderDebugIds(panel, {
                  profile_id:  upsertRes.profile_id || upsertRes.profile?.id || null,
                  prospect_id: res.prospect.id,
                  account_id:  upsertRes.account_id || res.prospect.account?.id || res.prospect.account_id || null,
                });
              }
            })
            .catch(() => { /* non-fatal */ });
        } else {
          // No profile data to upsert, but we still have a new prospect.
          // Surface its IDs in the debug strip without waiting for upsert.
          renderDebugIds(panel, {
            prospect_id: res.prospect.id,
            account_id:  res.prospect.account?.id || res.prospect.account_id || null,
          });
        }

        feedback.style.cssText = 'font-size:11px;display:block;color:#059669;margin-top:4px;';
        feedback.textContent   = 'Added successfully!';

        // Re-render as a found prospect after short delay
        setTimeout(() => {
          // Clear the not-found form and capture rows; renderProspect will
          // rebuild including its own capture section.
          while (panel.children.length > 2) panel.lastChild.remove();
          renderProspect(panel, res.prospect);
        }, 800);

      } catch (err) {
        btn.disabled    = false;
        btn.textContent = 'Add to GoWarmCRM';
        feedback.style.cssText = 'font-size:11px;display:block;color:#dc2626;margin-top:4px;';
        feedback.textContent   = err.message;
      }
    });
  }

  function renderNotAuthenticated(panel) {
    const d = document.createElement('div');
    d.style.cssText = 'padding:16px 13px;text-align:center;';
    d.innerHTML = `
      <div style="color:#94a3b8;font-size:12px;margin-bottom:10px;">Sign in to GoWarmCRM first</div>
      <a href="https://app.gowarmcrm.com" target="_blank"
        style="display:block;padding:7px;background:${TEAL};color:#fff;
               border-radius:6px;font-size:12px;font-weight:600;text-decoration:none;">
        Go to GoWarmCRM ↗
      </a>`;
    panel.appendChild(d);
  }

  // ── Capture-profile section (progressive, v1.3) ──────────────────────────────
  //
  // Renders four expandable rows — About, Experience, Education, Activity —
  // each showing live capture status and counts. Subscribes to capture state
  // updates so it re-renders rows as the user scrolls and sections populate.
  // The "Save to GoWarmCRM" button at the bottom posts the current state;
  // if any section is still pending (not yet seen), the user is warned first.
  //
  // options.hideSaveButton: when true, only the rows render — the parent
  // (e.g. renderNotFound) is expected to handle saving via its own button.
  function renderCaptureSection(panel, prospect, options = {}) {
    const { hideSaveButton = false } = options;
    const sec = document.createElement('div');
    sec.style.cssText = 'padding:10px 13px;border-bottom:1px solid #f1f5f9;background:#FFF8F1;';

    const SECTIONS = [
      { key: 'about',      label: 'About',      countOf: s => s.value ? 1 : 0 },
      { key: 'experience', label: 'Experience', countOf: s => (s.value || []).length },
      { key: 'education',  label: 'Education',  countOf: s => (s.value || []).length },
      { key: 'activity',   label: 'Activity',   countOf: s => (s.value || []).length },
    ];

    sec.innerHTML = `
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;">
        <div style="font-size:10px;font-weight:600;color:${ORANGE};letter-spacing:0.05em;text-transform:uppercase;">Profile capture</div>
        <div id="gw-cap-hint" style="font-size:10px;color:#94a3b8;">Scroll to load all sections</div>
      </div>
      <div id="gw-cap-rows" style="background:#fff;border:1px solid #FBCF9D;border-radius:6px;overflow:hidden;${hideSaveButton ? '' : 'margin-bottom:8px;'}"></div>
      ${hideSaveButton ? '' : `
        <button id="gw-capture-btn"
          style="width:100%;padding:7px;background:${ORANGE};color:#fff;border:none;border-radius:6px;
                 font-size:12px;font-weight:600;cursor:pointer;">
          Save to GoWarmCRM
        </button>
        <div id="gw-capture-feedback" style="margin-top:6px;font-size:11px;display:none;"></div>
        <div id="gw-capture-warning" style="display:none;margin-top:6px;padding:7px 8px;background:#FFFBEB;border:1px solid #FCD34D;border-radius:5px;font-size:11px;color:#78350F;"></div>
      `}
    `;
    panel.appendChild(sec);

    const rowsRoot = sec.querySelector('#gw-cap-rows');
    const btn      = sec.querySelector('#gw-capture-btn');
    const feedback = sec.querySelector('#gw-capture-feedback');
    const warning  = sec.querySelector('#gw-capture-warning');

    // ── Row construction ───────────────────────────────────────────────────────
    const rowEls = {};   // { about: { row, head, status, count, body, expanded } }

    // Closure-scoped store for full experience descriptions, used by the
    // "Show details ↓" toggle. Populated by renderExpBody on each render;
    // referenced by the delegated click handler defined inside the
    // SECTIONS.forEach below. Declared up here so the closure is valid.
    const expDescMap = new Map();

    SECTIONS.forEach((def, idx) => {
      const row = document.createElement('div');
      row.style.cssText = `border-bottom:${idx < SECTIONS.length - 1 ? '1px solid #FEF3E0' : 'none'};`;

      const head = document.createElement('div');
      head.style.cssText = 'display:flex;align-items:center;justify-content:space-between;padding:7px 9px;cursor:pointer;font-size:11px;user-select:none;';
      head.innerHTML = `
        <div style="display:flex;align-items:center;gap:6px;">
          <span class="gw-cap-caret" style="font-size:9px;color:#94a3b8;width:8px;display:inline-block;">▸</span>
          <span style="font-weight:600;color:#374151;">${escHtml(def.label)}</span>
          <!-- Delta pill: "on file 3d ago", "+2 new", "updated", etc.
               Populated by refreshRow once GET_LINKEDIN_PROFILE has hydrated. -->
          <span class="gw-cap-delta" style="font-size:9px;padding:1px 5px;border-radius:8px;display:none;"></span>
        </div>
        <div style="display:flex;align-items:center;gap:6px;">
          <span class="gw-cap-count" style="font-size:11px;color:#64748b;"></span>
          <span class="gw-cap-status" style="font-size:9px;padding:1px 5px;border-radius:8px;"></span>
        </div>
      `;
      row.appendChild(head);

      const body = document.createElement('div');
      body.style.cssText = 'display:none;padding:6px 9px 8px;background:#fffaf3;font-size:11px;color:#475569;line-height:1.5;border-top:1px solid #FEF3E0;';
      row.appendChild(body);

      head.addEventListener('click', () => {
        const expanded = body.style.display !== 'none';
        body.style.display = expanded ? 'none' : 'block';
        head.querySelector('.gw-cap-caret').textContent = expanded ? '▸' : '▾';
      });

      // Delegated click handler for "Show details ↓" toggles inside any
      // experience-row description. Survives body innerHTML re-renders
      // because it's attached to the wrapper, not the toggle itself.
      // Full description text is held in expDescMap (defined below) keyed
      // by item index — safer than embedding multi-line text in DOM attrs.
      if (def.key === 'experience') {
        body.addEventListener('click', (e) => {
          const a = e.target.closest('.gw-exp-toggle');
          if (!a) return;
          e.stopPropagation();
          const idx     = a.dataset.idx;
          const descEl  = body.querySelector(`.gw-exp-desc[data-idx="${idx}"]`);
          const fullText = expDescMap.get(idx);
          if (!descEl || !fullText) return;
          const collapsed = descEl.dataset.collapsed === '1';
          if (collapsed) {
            descEl.textContent = fullText;
            descEl.dataset.collapsed = '0';
            a.textContent = 'Show less ↑';
          } else {
            descEl.textContent = fullText.length > 180 ? fullText.slice(0, 180) + '…' : fullText;
            descEl.dataset.collapsed = '1';
            a.textContent = 'Show details ↓';
          }
        });
      }

      rowEls[def.key] = { row, head, body };
      rowsRoot.appendChild(row);
    });

    // ── Status badges ──────────────────────────────────────────────────────────
    function statusBadge(status) {
      switch (status) {
        case 'pending':  return { text: 'pending',    bg: '#F1F5F9', fg: '#64748B' };
        case 'loading':  return { text: 'capturing…', bg: '#FEF3C7', fg: '#92400E' };
        case 'captured': return { text: 'captured',   bg: '#D1FAE5', fg: '#065F46' };
        case 'empty':    return { text: 'none',       bg: '#F1F5F9', fg: '#64748B' };
        default:         return { text: status,        bg: '#F1F5F9', fg: '#64748B' };
      }
    }

    // ── Inline edit machinery ──────────────────────────────────────────────────
    //
    // The rep can correct any displayed field by clicking a pencil icon. Edits
    // live entirely client-side and are wiped only by full re-init (SPA nav).
    // The "Save to GoWarmCRM" button picks up edited values via captureState,
    // so the same upsert flow ships them.
    //
    // Editing a section also flips slot.edited = true, which suppresses
    // automatic re-capture of that section (see runCapture). Without this,
    // a stray scroll could re-fire the IntersectionObserver and clobber
    // the rep's corrections.

    // Track which row currently has an open editor so a second pencil click
    // closes the previous one. { sectionKey, rowIdx, container } | null
    let openEditor = null;

    function closeOpenEditor() {
      if (!openEditor) return;
      // Restore any container the editor mutated by triggering the parent
      // section's refresh. The refresh path is idempotent.
      const { sectionKey } = openEditor;
      openEditor = null;
      refreshRow(sectionKey);
    }

    // Pencil icon SVG. data-edit is an opaque token the click handler uses
    // to dispatch to the right editor. data-rowidx narrows it to a specific
    // row inside multi-row sections (experience/education/activity).
    function pencilHtml(editToken, rowIdx) {
      const idxAttr = rowIdx != null ? ` data-rowidx="${rowIdx}"` : '';
      return `<span class="gw-edit-pencil" data-edit="${editToken}"${idxAttr}
        title="Edit"
        style="display:inline-flex;align-items:center;justify-content:center;
               width:18px;height:18px;border-radius:3px;cursor:pointer;
               color:#94A3B8;flex-shrink:0;"
        onmouseover="this.style.background='#FEF3E0';this.style.color='#E8630A';"
        onmouseout="this.style.background='';this.style.color='#94A3B8';">
        <svg width="11" height="11" viewBox="0 0 24 24" fill="none"
             stroke="currentColor" stroke-width="2.2" stroke-linecap="round"
             stroke-linejoin="round" aria-hidden="true">
          <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
          <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
        </svg>
      </span>`;
    }

    // Activity row badge. Visual signal for whether the activity was an
    // original post, plain repost, quoted repost (commentary on someone
    // else's post), comment, or reaction. Helps verify the classifier did
    // what we expect. Returns '' when the row has no useful classification
    // (e.g. legacy items captured before this code shipped, which have
    // null action and render as a neutral POST badge).
    function activityBadgeHtml(item) {
      if (!item) return '';
      const action = (item.action || '').toLowerCase();
      const kind   = (item.kind   || '').toLowerCase();
      // Pick a label + color per classification.
      let label, bg, fg;
      if (action === 'quoted_repost') {
        label = 'QUOTED REPOST'; bg = '#FEF3E0'; fg = '#9A3412';
      } else if (action === 'reposted') {
        label = 'REPOST';        bg = '#F3E8FF'; fg = '#581C87';
      } else if (action === 'posted' || (kind === 'post' && !action)) {
        // No-action posts are very likely originals from new captures; for
        // legacy data they're ambiguous. Same label either way — UI honest.
        label = action === 'posted' ? 'ORIGINAL' : 'POST'; bg = '#DCFCE7'; fg = '#14532D';
      } else if (kind === 'comment') {
        label = 'COMMENT';       bg = '#DBEAFE'; fg = '#1E3A8A';
      } else if (kind === 'reaction') {
        label = (action || 'reacted').toUpperCase(); bg = '#F3F4F6'; fg = '#374151';
      } else {
        return '';
      }
      return `<span style="display:inline-block;padding:1px 5px;border-radius:8px;
                            font-size:8px;font-weight:700;letter-spacing:0.04em;
                            background:${bg};color:${fg};margin-right:4px;
                            vertical-align:middle;">${escHtml(label)}</span>`;
    }

    // Render an inline editor block. Replaces a row's displayed content while
    // editing. fields = [{ key, label, value, type: 'text'|'textarea' }].
    function renderEditor(fields) {
      const inputs = fields.map((f, i) => {
        const safe = escHtml(f.value || '');
        if (f.type === 'textarea') {
          return `
            <div style="margin-bottom:6px;">
              <label style="display:block;font-size:9px;color:#64748B;margin-bottom:2px;font-weight:600;text-transform:uppercase;letter-spacing:0.05em;">${escHtml(f.label)}</label>
              <textarea data-field="${escHtml(f.key)}" data-fidx="${i}"
                style="width:100%;padding:5px 7px;border:1px solid #FBCF9D;border-radius:4px;
                       font-size:11px;font-family:inherit;line-height:1.5;
                       min-height:60px;max-height:200px;resize:vertical;box-sizing:border-box;"
              >${safe}</textarea>
            </div>`;
        }
        return `
          <div style="margin-bottom:6px;">
            <label style="display:block;font-size:9px;color:#64748B;margin-bottom:2px;font-weight:600;text-transform:uppercase;letter-spacing:0.05em;">${escHtml(f.label)}</label>
            <input type="text" data-field="${escHtml(f.key)}" data-fidx="${i}" value="${safe}"
              style="width:100%;padding:5px 7px;border:1px solid #FBCF9D;border-radius:4px;
                     font-size:11px;font-family:inherit;box-sizing:border-box;" />
          </div>`;
      }).join('');
      return `
        <div class="gw-editor" style="background:#FFFAF3;border:1px solid #FBCF9D;border-radius:5px;padding:8px 9px;">
          ${inputs}
          <div style="display:flex;gap:5px;margin-top:6px;">
            <button class="gw-edit-save"
              style="flex:1;padding:5px 8px;background:#E8630A;color:#fff;border:none;border-radius:4px;
                     font-size:11px;font-weight:600;cursor:pointer;">✓ Save</button>
            <button class="gw-edit-cancel"
              style="flex:1;padding:5px 8px;background:#fff;color:#64748B;border:1px solid #D1D5DB;
                     border-radius:4px;font-size:11px;cursor:pointer;">✗ Cancel</button>
          </div>
          <div style="margin-top:4px;font-size:9px;color:#94A3B8;">Enter to save · Esc to cancel</div>
        </div>`;
    }

    // Brief flash of green on a freshly-saved row, so the rep sees feedback.
    function flashSaved(el) {
      if (!el) return;
      const prevBg = el.style.background;
      el.style.transition = 'background 250ms ease';
      el.style.background = '#D1FAE5';
      setTimeout(() => { el.style.background = prevBg; }, 600);
    }

    // Wire keyboard handlers on the editor that just got mounted, plus the
    // Save/Cancel buttons. onSave receives a { fieldKey: value } map.
    function bindEditorEvents(container, onSave, onCancel) {
      const inputs = container.querySelectorAll('[data-field]');
      const saveBtn   = container.querySelector('.gw-edit-save');
      const cancelBtn = container.querySelector('.gw-edit-cancel');

      function commit() {
        const out = {};
        inputs.forEach(el => { out[el.dataset.field] = el.value.trim(); });
        onSave(out);
      }
      function cancel() { onCancel(); }

      saveBtn.addEventListener('click',   commit);
      cancelBtn.addEventListener('click', cancel);

      inputs.forEach(el => {
        el.addEventListener('keydown', (e) => {
          if (e.key === 'Escape') { e.preventDefault(); cancel(); return; }
          if (e.key === 'Enter') {
            // In textareas, plain Enter inserts newline; Shift+Enter or
            // Cmd/Ctrl+Enter forces commit. In inputs, plain Enter commits.
            if (el.tagName === 'TEXTAREA') {
              if (e.shiftKey || e.metaKey || e.ctrlKey) {
                e.preventDefault(); commit();
              }
            } else {
              e.preventDefault(); commit();
            }
          }
        });
      });

      // Focus the first input.
      const first = container.querySelector('[data-field]');
      if (first) {
        first.focus();
        if (first.select) first.select();
      }
    }

    // Open the about editor inline.
    function openAboutEditor() {
      closeOpenEditor();
      const slot = captureState.about;
      const els  = rowEls.about;
      if (!els) return;
      const current = (slot.value || '').replace(/^About\n+/i, '').trim();
      els.body.innerHTML = renderEditor([
        { key: 'text', label: 'About', value: current, type: 'textarea' },
      ]);
      const container = els.body.querySelector('.gw-editor');
      openEditor = { sectionKey: 'about', container };
      bindEditorEvents(container,
        ({ text }) => {
          slot.value  = text || null;
          slot.edited = true;
          slot.status = text ? 'captured' : 'empty';
          openEditor = null;
          notifyCapture('about');
          flashSaved(els.body);
        },
        () => closeOpenEditor()
      );
    }

    // Open the experience-row editor inline.
    function openExpEditor(rowIdx) {
      closeOpenEditor();
      const slot = captureState.experience;
      const items = slot.value || [];
      const it = items[rowIdx];
      if (!it) return;
      const els = rowEls.experience;
      if (!els) return;

      // Replace just this row's element with the editor; leave other rows alone.
      // We re-render the whole body but mark which index is in edit mode.
      els.body.innerHTML = items.map((row, i) => {
        if (i === rowIdx) {
          return `<div data-edit-row="${i}" style="margin-bottom:9px;padding-bottom:8px;${i < items.length - 1 ? 'border-bottom:1px dashed #E5E7EB;' : ''}"></div>`;
        }
        // Compact display of the non-edited rows so the editor stands out.
        const dates = formatDateRange(row.start_date, row.end_date, row.duration_months);
        const loc   = row.location ? ` · ${escHtml(row.location)}` : '';
        return `
          <div style="margin-bottom:9px;padding-bottom:8px;${i < items.length - 1 ? 'border-bottom:1px dashed #E5E7EB;' : ''};opacity:0.55;">
            <div style="font-weight:600;color:#1F2937;">${escHtml(row.title || '(no title)')}</div>
            <div style="color:#475569;">${escHtml(row.company || '(no company)')}${loc}</div>
            <div style="color:#94A3B8;font-size:10px;">${escHtml(dates)}</div>
          </div>`;
      }).join('');

      const editorMount = els.body.querySelector(`[data-edit-row="${rowIdx}"]`);
      editorMount.innerHTML = renderEditor([
        { key: 'title',       label: 'Title',       value: it.title       || '', type: 'text' },
        { key: 'company',     label: 'Company',     value: it.company     || '', type: 'text' },
        { key: 'location',    label: 'Location',    value: it.location    || '', type: 'text' },
        { key: 'description', label: 'Description', value: it.description || '', type: 'textarea' },
      ]);
      const container = editorMount.querySelector('.gw-editor');
      openEditor = { sectionKey: 'experience', container };

      bindEditorEvents(container,
        (vals) => {
          items[rowIdx] = {
            ...it,
            title:       vals.title       || null,
            company:     vals.company     || null,
            location:    vals.location    || null,
            description: vals.description || null,
          };
          slot.value  = items;
          slot.edited = true;
          openEditor = null;
          notifyCapture('experience');
          flashSaved(els.body);
        },
        () => closeOpenEditor()
      );
    }

    // Open the education-row editor inline.
    function openEduEditor(rowIdx) {
      closeOpenEditor();
      const slot = captureState.education;
      const items = slot.value || [];
      const it = items[rowIdx];
      if (!it) return;
      const els = rowEls.education;
      if (!els) return;

      els.body.innerHTML = items.map((row, i) => {
        if (i === rowIdx) {
          return `<div data-edit-row="${i}" style="margin-bottom:7px;"></div>`;
        }
        const years = (row.start_year || row.end_year)
          ? `${row.start_year || '?'}\u2009–\u2009${row.end_year || '?'}` : '';
        const detail = [row.degree, row.field_of_study].filter(Boolean).join(', ');
        return `
          <div style="margin-bottom:7px;opacity:0.55;">
            <div style="font-weight:600;color:#1F2937;">${escHtml(row.school || '(no school)')}</div>
            ${detail ? `<div style="color:#475569;">${escHtml(detail)}</div>` : ''}
            ${years   ? `<div style="color:#94A3B8;font-size:10px;">${escHtml(years)}</div>` : ''}
          </div>`;
      }).join('');

      const editorMount = els.body.querySelector(`[data-edit-row="${rowIdx}"]`);
      editorMount.innerHTML = renderEditor([
        { key: 'school',         label: 'School',         value: it.school || '',         type: 'text' },
        { key: 'degree',         label: 'Degree',         value: it.degree || '',         type: 'text' },
        { key: 'field_of_study', label: 'Field of study', value: it.field_of_study || '', type: 'text' },
      ]);
      const container = editorMount.querySelector('.gw-editor');
      openEditor = { sectionKey: 'education', container };

      bindEditorEvents(container,
        (vals) => {
          items[rowIdx] = {
            ...it,
            school:         vals.school || null,
            degree:         vals.degree || null,
            field_of_study: vals.field_of_study || null,
          };
          slot.value  = items;
          slot.edited = true;
          openEditor  = null;
          notifyCapture('education');
          flashSaved(els.body);
        },
        () => closeOpenEditor()
      );
    }

    // Open the activity-item editor inline.
    function openActEditor(rowIdx) {
      closeOpenEditor();
      const slot = captureState.activity;
      const items = slot.value || [];
      const it = items[rowIdx];
      if (!it) return;
      const els = rowEls.activity;
      if (!els) return;

      els.body.innerHTML = items.slice(0, 10).map((row, i) => {
        if (i === rowIdx) {
          return `<div data-edit-row="${i}" style="margin-bottom:7px;"></div>`;
        }
        const verb  = row.action ? row.action : row.kind;
        const time  = row.relative_time ? ` · ${escHtml(row.relative_time)}` : '';
        const text  = (row.text || '').slice(0, 200);
        const badge = activityBadgeHtml(row);
        return `
          <div style="margin-bottom:7px;opacity:0.55;">
            <div style="color:#94A3B8;font-size:10px;">${badge}${escHtml(verb)}${time}</div>
            ${text ? `<div style="color:#374151;">${escHtml(text)}</div>` : ''}
          </div>`;
      }).join('');

      const editorMount = els.body.querySelector(`[data-edit-row="${rowIdx}"]`);
      editorMount.innerHTML = renderEditor([
        { key: 'text', label: 'Text', value: it.text || '', type: 'textarea' },
      ]);
      const container = editorMount.querySelector('.gw-editor');
      openEditor = { sectionKey: 'activity', container };

      bindEditorEvents(container,
        (vals) => {
          items[rowIdx] = { ...it, text: vals.text || '' };
          slot.value  = items;
          slot.edited = true;
          openEditor  = null;
          notifyCapture('activity');
          flashSaved(els.body);
        },
        () => closeOpenEditor()
      );
    }

    // Single delegated click handler at the rows-root level. Catches every
    // pencil click in any of the four section bodies and dispatches.
    rowsRoot.addEventListener('click', (e) => {
      // ── Diff/full toggle (NEW in v1.7) ───────────────────────────────────
      // Catches "Show all live data ↓" / "Show changes only ↑" links in
      // the body footer. Flips the slot's viewMode and re-renders just
      // that row. We handle this BEFORE the pencil branch so the toggle
      // never gets misclassified as an edit click.
      const toggle = e.target.closest('.gw-diff-toggle');
      if (toggle) {
        e.stopPropagation();
        const key  = toggle.dataset.key;
        const mode = toggle.dataset.mode;   // the mode we're switching TO
        if (key && (mode === 'diff' || mode === 'full')) {
          captureState[key].viewMode = mode;
          notifyCapture(key);
        }
        return;
      }

      const pencil = e.target.closest('.gw-edit-pencil');
      if (!pencil) return;
      e.stopPropagation();
      const token  = pencil.dataset.edit;
      const rowIdx = pencil.dataset.rowidx != null ? parseInt(pencil.dataset.rowidx, 10) : null;
      switch (token) {
        case 'about':      openAboutEditor();          break;
        case 'experience': openExpEditor(rowIdx);      break;
        case 'education':  openEduEditor(rowIdx);      break;
        case 'activity':   openActEditor(rowIdx);      break;
      }
    });

    // ── Body renderers per section ─────────────────────────────────────────────
    function renderAboutBody(slot) {
      if (!slot.value) {
        return `
          <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px;">
            <div style="color:#94a3b8;font-style:italic;">No About section on this profile.</div>
            ${pencilHtml('about')}
          </div>`;
      }
      const text = slot.value.replace(/^About\n+/i, '').trim();
      return `
        <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px;">
          <div style="white-space:pre-wrap;max-height:240px;overflow-y:auto;padding-right:4px;flex:1;">${escHtml(text)}</div>
          ${pencilHtml('about')}
        </div>`;
    }

    function renderExpBody(slot) {
      const items = slot.value || [];
      if (items.length === 0) return `<div style="color:#94a3b8;font-style:italic;">No experience captured yet.</div>`;
      expDescMap.clear();
      return items.map((it, idx) => {
        const dates = formatDateRange(it.start_date, it.end_date, it.duration_months);
        const loc   = it.location ? ` · ${escHtml(it.location)}` : '';
        const desc  = (it.description || '').trim();
        const hasDesc    = desc.length > 0;
        const isLongDesc = desc.length > 180;
        const descPreview = isLongDesc ? desc.slice(0, 180) + '…' : desc;
        if (hasDesc) expDescMap.set(String(idx), desc);
        return `
          <div style="margin-bottom:9px;padding-bottom:8px;${idx < items.length - 1 ? 'border-bottom:1px dashed #E5E7EB;' : ''}">
            <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px;">
              <div style="flex:1;min-width:0;">
                <div style="font-weight:600;color:#1F2937;">${escHtml(it.title || '(no title)')}</div>
                <div style="color:#475569;">${escHtml(it.company || '(no company)')}${loc}</div>
                <div style="color:#94A3B8;font-size:10px;">${escHtml(dates)}</div>
                ${hasDesc ? `
                  <div class="gw-exp-desc" data-idx="${idx}" data-collapsed="${isLongDesc ? '1' : '0'}" style="margin-top:4px;color:#374151;font-size:10px;line-height:1.5;white-space:pre-wrap;">${escHtml(isLongDesc ? descPreview : desc)}</div>
                  ${isLongDesc ? `
                    <a class="gw-exp-toggle" data-idx="${idx}" style="display:inline-block;margin-top:2px;font-size:10px;color:${TEAL};cursor:pointer;text-decoration:none;">Show details ↓</a>
                  ` : ''}
                ` : ''}
              </div>
              ${pencilHtml('experience', idx)}
            </div>
          </div>`;
      }).join('');
    }

    function renderEduBody(slot) {
      const items = slot.value || [];
      if (items.length === 0) return `<div style="color:#94a3b8;font-style:italic;">No education captured.</div>`;
      return items.map((it, idx) => {
        const years = (it.start_year || it.end_year)
          ? `${it.start_year || '?'}\u2009–\u2009${it.end_year || '?'}`
          : '';
        const detail = [it.degree, it.field_of_study].filter(Boolean).join(', ');
        return `
          <div style="margin-bottom:7px;">
            <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px;">
              <div style="flex:1;min-width:0;">
                <div style="font-weight:600;color:#1F2937;">${escHtml(it.school || '(no school)')}</div>
                ${detail ? `<div style="color:#475569;">${escHtml(detail)}</div>` : ''}
                ${years   ? `<div style="color:#94A3B8;font-size:10px;">${escHtml(years)}</div>` : ''}
              </div>
              ${pencilHtml('education', idx)}
            </div>
          </div>`;
      }).join('');
    }

    function renderActBody(slot) {
      const items = slot.value || [];
      if (items.length === 0) return `<div style="color:#94a3b8;font-style:italic;">No activity captured yet. (Activity often loads only after scrolling near it.)</div>`;
      const visibleN = Math.min(items.length, 10);
      const rows = items.slice(0, visibleN).map((it, idx) => {
        const verb  = it.action ? `${it.action}` : it.kind;
        const time  = it.relative_time ? ` · ${escHtml(it.relative_time)}` : '';
        const text  = (it.text || '').slice(0, 200);
        const badge = activityBadgeHtml(it);
        const quotedNote = it.quoted_author
          ? `<div style="color:#94A3B8;font-size:9px;margin-top:2px;font-style:italic;">↳ from ${escHtml(it.quoted_author)}</div>`
          : '';
        const href  = it.source_url
          ? `<a href="${escHtml(it.source_url)}" target="_blank" style="color:${TEAL};text-decoration:none;font-size:10px;">view →</a>`
          : '';
        return `
          <div style="margin-bottom:7px;">
            <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px;">
              <div style="flex:1;min-width:0;">
                <div style="color:#94A3B8;font-size:10px;">${badge}${escHtml(verb)}${time}</div>
                ${text ? `<div style="color:#374151;">${escHtml(text)}</div>` : ''}
                ${quotedNote}
                ${href}
              </div>
              ${pencilHtml('activity', idx)}
            </div>
          </div>`;
      }).join('');

      // "Showing 10 of N" footer (NEW in v1.7.1). The panel only displays
      // the first 10 items to keep things scannable in a 290px sidebar,
      // but ALL items are still in captureState.activity.value and ALL
      // get sent to the server on Save. Without this footer, reps could
      // (and did) reasonably assume items 11+ were silently dropped.
      const overflow = items.length - visibleN;
      const more = overflow > 0
        ? `<div style="margin-top:6px;padding-top:6px;border-top:1px dashed #E5E7EB;color:#64748B;font-size:10px;text-align:center;">
             Showing ${visibleN} of ${items.length} · all ${items.length} will be saved
           </div>`
        : '';
      return rows + more;
    }

    // ── Diff body renderers (NEW in v1.7) ─────────────────────────────────────
    //
    // These render the section in "show me what's about to change" mode.
    // They're called instead of the normal renderAboutBody / renderExpBody
    // / renderEduBody / renderActBody when:
    //   1) the slot has a diff (state is 'updated' or 'new-data'), AND
    //   2) the user hasn't explicitly switched to 'full' mode for this row.
    //
    // Honest about the upsert merge semantics: items that exist in DB but
    // not in the live capture are shown as "removed (kept on file)" — the
    // server's section-level merge keeps them. Reps see the truth.
    //
    // Each diff renderer ends with a row footer that lets the user toggle
    // between diff and full views via a delegated click handler below.

    function diffFooter(key, mode) {
      const label = mode === 'diff'
        ? '↓ Show all live data'
        : '↑ Show changes only';
      return `<div style="margin-top:8px;padding-top:6px;border-top:1px dashed #E5E7EB;text-align:center;">
                <a class="gw-diff-toggle" data-key="${key}" data-mode="${mode === 'diff' ? 'full' : 'diff'}"
                   style="font-size:10px;color:${TEAL};cursor:pointer;text-decoration:none;font-weight:500;">
                  ${label}
                </a>
              </div>`;
    }

    // ── About diff ─────────────────────────────────────────────────────────────
    // Most About changes are small (a sentence about a Series B, a new
    // job blurb). We compute a coarse character-level signal and show
    // both versions stacked. For tiny changes (<60 char delta) we show
    // an inline "+45 chars" hint; for big rewrites (>50% of length
    // changed) we label it "rewritten" so the rep knows to read both.
    function renderAboutDiff(slot) {
      const live = (slot.value     || '').replace(/^About\n+/i, '').trim();
      const dbV  = (slot.dbValue   || '').replace(/^About\n+/i, '').trim();

      // Edge case: live empty, DB has content (shouldn't reach here
      // because diffSection would say 'on-file', but be defensive).
      if (!live) {
        return `<div style="color:#94a3b8;font-style:italic;">Live About is empty; existing About on file will be kept.</div>` +
               diffFooter('about', 'diff');
      }

      const delta = live.length - dbV.length;
      const big   = dbV.length > 0 && Math.abs(delta) / Math.max(dbV.length, 1) > 0.5;
      const tag   = !dbV
        ? '<span style="background:#D1FAE5;color:#065F46;font-size:9px;font-weight:700;padding:1px 5px;border-radius:8px;">NEW</span>'
        : big
          ? '<span style="background:#FEF3C7;color:#92400E;font-size:9px;font-weight:700;padding:1px 5px;border-radius:8px;">REWRITTEN</span>'
          : `<span style="background:#FEF3C7;color:#92400E;font-size:9px;font-weight:700;padding:1px 5px;border-radius:8px;">${delta > 0 ? '+' : ''}${delta} chars</span>`;

      // For visual scanning, the live version comes first (that's
      // what's about to be saved). DB version follows, dimmed, so the
      // rep can compare without scrolling.
      const dbBlock = dbV
        ? `<div style="margin-top:8px;padding:6px 8px;background:#F8FAFC;border-radius:5px;border-left:3px solid #CBD5E1;">
             <div style="font-size:9px;font-weight:700;color:#64748B;text-transform:uppercase;letter-spacing:0.04em;margin-bottom:3px;">Currently on file</div>
             <div style="white-space:pre-wrap;color:#64748B;font-size:10px;max-height:120px;overflow-y:auto;">${escHtml(dbV)}</div>
           </div>`
        : '';

      return `
        <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:5px;">
          <div style="font-size:10px;font-weight:700;color:#374151;text-transform:uppercase;letter-spacing:0.04em;">About to save ${tag}</div>
        </div>
        <div style="white-space:pre-wrap;max-height:200px;overflow-y:auto;padding:6px 8px;background:#FFFBEB;border-radius:5px;border-left:3px solid #F59E0B;">${escHtml(live)}</div>
        ${dbBlock}
        ${diffFooter('about', 'diff')}
      `;
    }

    // ── Experience / Education item matching ──────────────────────────────────
    //
    // For arrays of objects, we match items between live and DB by a
    // composite signature (same shape used by diffSection's signature
    // function). Returns three arrays: added (in live, not in DB),
    // removed (in DB, not in live), kept (matched on both sides — could
    // still differ in details, e.g. an end_date that filled in).
    //
    // For matched items we also compute a per-field changeset so the
    // diff view can highlight things like "end date now Mar 2024".
    function diffArrayItems(live, dbV, sigFn, fieldsToCompare) {
      const liveBySig = new Map();
      live.forEach((it, idx) => liveBySig.set(sigFn(it), { it, idx }));
      const dbBySig = new Map();
      dbV.forEach((it, idx)  => dbBySig.set(sigFn(it),   { it, idx }));

      const added   = [];
      const removed = [];
      const kept    = [];

      for (const [sig, { it: liveIt, idx }] of liveBySig) {
        if (!dbBySig.has(sig)) {
          added.push({ item: liveIt, idx });
        } else {
          const dbIt = dbBySig.get(sig).it;
          const fieldDiffs = [];
          for (const f of fieldsToCompare) {
            const lv = (liveIt[f] || '').toString().trim();
            const dv = (dbIt[f]   || '').toString().trim();
            if (lv !== dv) fieldDiffs.push({ field: f, live: lv, db: dv });
          }
          kept.push({ item: liveIt, dbItem: dbIt, idx, fieldDiffs });
        }
      }
      for (const [sig, { it: dbIt }] of dbBySig) {
        if (!liveBySig.has(sig)) removed.push({ item: dbIt });
      }
      return { added, removed, kept };
    }

    // ── Experience diff ────────────────────────────────────────────────────────
    function renderExpDiff(slot) {
      const live = slot.value   || [];
      const dbV  = slot.dbValue || [];
      const sig  = (x) => `${x.title||''}|${x.company||''}|${x.start_date||''}|${x.end_date||''}`;
      const { added, removed, kept } = diffArrayItems(
        live, dbV, sig,
        ['location', 'description', 'duration_months']
      );

      const changedKept = kept.filter(k => k.fieldDiffs.length > 0);

      // Summary line
      const parts = [];
      if (added.length)        parts.push(`<span style="color:#065F46;">+${added.length} new</span>`);
      if (removed.length)      parts.push(`<span style="color:#991B1B;">${removed.length} no longer on LinkedIn</span>`);
      if (changedKept.length)  parts.push(`<span style="color:#92400E;">${changedKept.length} updated</span>`);
      if (parts.length === 0)  parts.push(`<span style="color:#475569;">No structural changes</span>`);

      const itemRow = (badge, badgeColor, badgeBg, item, opts = {}) => {
        const dates = formatDateRange(item.start_date, item.end_date, item.duration_months);
        const loc   = item.location ? ` · ${escHtml(item.location)}` : '';
        const dim   = opts.dim ? 'opacity:0.55;text-decoration:line-through;text-decoration-color:#CBD5E1;' : '';
        return `
          <div style="margin-bottom:6px;padding:5px 7px;border-radius:5px;background:${badgeBg};${dim}">
            <div style="display:flex;align-items:center;gap:5px;margin-bottom:2px;">
              <span style="background:${badgeColor};color:#fff;font-size:8px;font-weight:700;padding:1px 5px;border-radius:8px;text-transform:uppercase;letter-spacing:0.04em;">${badge}</span>
              <span style="font-weight:600;color:#1F2937;font-size:11px;">${escHtml(item.title || '(no title)')}</span>
            </div>
            <div style="color:#475569;font-size:10px;">${escHtml(item.company || '(no company)')}${loc}</div>
            <div style="color:#94A3B8;font-size:9px;">${escHtml(dates)}</div>
            ${opts.fieldDiffs && opts.fieldDiffs.length ? `
              <div style="margin-top:3px;padding-top:3px;border-top:1px dashed #E5E7EB;">
                ${opts.fieldDiffs.map(fd => `
                  <div style="font-size:9px;color:#92400E;">
                    <strong>${escHtml(fd.field)}:</strong>
                    <span style="text-decoration:line-through;color:#94A3B8;">${escHtml(fd.db || '(empty)')}</span>
                    →
                    <span style="color:#065F46;">${escHtml(fd.live || '(empty)')}</span>
                  </div>
                `).join('')}
              </div>
            ` : ''}
          </div>`;
      };

      const sections = [];
      if (added.length) {
        sections.push(`<div style="margin-bottom:8px;">
          <div style="font-size:9px;font-weight:700;color:#065F46;text-transform:uppercase;letter-spacing:0.04em;margin-bottom:3px;">New experience</div>
          ${added.map(a => itemRow('NEW', '#10B981', '#ECFDF5', a.item)).join('')}
        </div>`);
      }
      if (changedKept.length) {
        sections.push(`<div style="margin-bottom:8px;">
          <div style="font-size:9px;font-weight:700;color:#92400E;text-transform:uppercase;letter-spacing:0.04em;margin-bottom:3px;">Updated</div>
          ${changedKept.map(k => itemRow('UPDATED', '#F59E0B', '#FFFBEB', k.item, { fieldDiffs: k.fieldDiffs })).join('')}
        </div>`);
      }
      if (removed.length) {
        sections.push(`<div style="margin-bottom:8px;">
          <div style="font-size:9px;font-weight:700;color:#991B1B;text-transform:uppercase;letter-spacing:0.04em;margin-bottom:3px;">No longer on LinkedIn</div>
          ${removed.map(r => itemRow('REMOVED', '#EF4444', '#FEF2F2', r.item, { dim: true })).join('')}
          <div style="font-size:9px;color:#94A3B8;font-style:italic;margin-top:3px;padding-left:2px;">
            These will stay in your CRM — refreshing won't delete them.
          </div>
        </div>`);
      }

      return `
        <div style="font-size:10px;font-weight:600;color:#374151;margin-bottom:6px;padding-bottom:4px;border-bottom:1px solid #F1F5F9;">
          ${parts.join(' · ')}
        </div>
        ${sections.join('') || '<div style="color:#94a3b8;font-style:italic;font-size:10px;">No changes detected.</div>'}
        ${diffFooter('experience', 'diff')}
      `;
    }

    // ── Education diff ─────────────────────────────────────────────────────────
    function renderEduDiff(slot) {
      const live = slot.value   || [];
      const dbV  = slot.dbValue || [];
      const sig  = (x) => `${x.school||''}|${x.degree||''}|${x.field_of_study||''}|${x.start_year||''}|${x.end_year||''}`;
      const { added, removed, kept } = diffArrayItems(live, dbV, sig, []);

      const parts = [];
      if (added.length)   parts.push(`<span style="color:#065F46;">+${added.length} new</span>`);
      if (removed.length) parts.push(`<span style="color:#991B1B;">${removed.length} no longer on LinkedIn</span>`);
      if (parts.length === 0) parts.push(`<span style="color:#475569;">No changes</span>`);

      const itemRow = (badge, badgeColor, badgeBg, it, opts = {}) => {
        const detail = [it.degree, it.field_of_study].filter(Boolean).join(', ');
        const years  = (it.start_year || it.end_year)
          ? `${it.start_year || '?'}\u2009–\u2009${it.end_year || '?'}` : '';
        const dim    = opts.dim ? 'opacity:0.55;text-decoration:line-through;text-decoration-color:#CBD5E1;' : '';
        return `
          <div style="margin-bottom:6px;padding:5px 7px;border-radius:5px;background:${badgeBg};${dim}">
            <div style="display:flex;align-items:center;gap:5px;margin-bottom:2px;">
              <span style="background:${badgeColor};color:#fff;font-size:8px;font-weight:700;padding:1px 5px;border-radius:8px;text-transform:uppercase;letter-spacing:0.04em;">${badge}</span>
              <span style="font-weight:600;color:#1F2937;font-size:11px;">${escHtml(it.school || '(no school)')}</span>
            </div>
            ${detail ? `<div style="color:#475569;font-size:10px;">${escHtml(detail)}</div>` : ''}
            ${years  ? `<div style="color:#94A3B8;font-size:9px;">${escHtml(years)}</div>` : ''}
          </div>`;
      };

      const sections = [];
      if (added.length) sections.push(added.map(a => itemRow('NEW', '#10B981', '#ECFDF5', a.item)).join(''));
      if (removed.length) {
        sections.push(removed.map(r => itemRow('REMOVED', '#EF4444', '#FEF2F2', r.item, { dim: true })).join(''));
        sections.push(`<div style="font-size:9px;color:#94A3B8;font-style:italic;margin-top:3px;padding-left:2px;">
          These will stay in your CRM — refreshing won't delete them.
        </div>`);
      }

      return `
        <div style="font-size:10px;font-weight:600;color:#374151;margin-bottom:6px;padding-bottom:4px;border-bottom:1px solid #F1F5F9;">
          ${parts.join(' · ')}
        </div>
        ${sections.join('') || '<div style="color:#94a3b8;font-style:italic;font-size:10px;">No changes detected.</div>'}
        ${diffFooter('education', 'diff')}
      `;
    }

    // ── Activity diff ──────────────────────────────────────────────────────────
    // Activity is server-side accumulated by ID, so the only meaningful
    // diff is "what's new since last capture." We don't show "removed"
    // because the server never removes activity rows on upsert.
    function renderActDiff(slot) {
      const live = slot.value   || [];
      const dbV  = slot.dbValue || [];
      const dbIds = new Set((dbV || []).map(x => x?.id).filter(Boolean));
      const newOnes = live.filter(x => x?.id && !dbIds.has(x.id));

      if (newOnes.length === 0) {
        return `<div style="color:#94a3b8;font-style:italic;font-size:10px;">No new activity since last save.</div>` +
               diffFooter('activity', 'diff');
      }

      const visibleN = Math.min(newOnes.length, 10);
      const overflow = newOnes.length - visibleN;
      const overflowNote = overflow > 0
        ? `<div style="margin-top:6px;padding-top:6px;border-top:1px dashed #E5E7EB;color:#64748B;font-size:10px;text-align:center;">
             Showing ${visibleN} of ${newOnes.length} new · all ${newOnes.length} will be added
           </div>`
        : '';

      return `
        <div style="font-size:10px;font-weight:600;color:#065F46;margin-bottom:6px;padding-bottom:4px;border-bottom:1px solid #F1F5F9;">
          ${newOnes.length} new activity item${newOnes.length === 1 ? '' : 's'} since last save · these will be added (existing items kept)
        </div>
        ${newOnes.slice(0, visibleN).map(it => {
          const verb = it.action ? `${it.action}` : it.kind;
          const time = it.relative_time ? ` · ${escHtml(it.relative_time)}` : '';
          const text = (it.text || '').slice(0, 200);
          const badge = activityBadgeHtml(it);
          return `
            <div style="margin-bottom:6px;padding:5px 7px;border-radius:5px;background:#ECFDF5;">
              <div style="display:flex;align-items:center;gap:5px;margin-bottom:2px;">
                <span style="background:#10B981;color:#fff;font-size:8px;font-weight:700;padding:1px 5px;border-radius:8px;text-transform:uppercase;letter-spacing:0.04em;">NEW</span>
                ${badge}
                <span style="color:#94A3B8;font-size:9px;">${escHtml(verb)}${time}</span>
              </div>
              ${text ? `<div style="color:#374151;font-size:10px;">${escHtml(text)}</div>` : ''}
            </div>`;
        }).join('')}
        ${overflowNote}
        ${diffFooter('activity', 'diff')}
      `;
    }

    function bodyFor(key, slot) {
      // Decide whether to render the diff view or the normal full view.
      // Default ('auto'): diff view when the slot has a meaningful diff,
      // full view otherwise. User can override via the toggle link in
      // the body footer (sets viewMode to 'diff' or 'full' explicitly).
      const d = diffSection(key, slot);
      const hasDiff = (d === 'updated' || d === 'new-data');

      let mode = slot.viewMode;
      if (mode === 'auto') {
        mode = hasDiff ? 'diff' : 'full';
      }
      // Don't show diff view if there's nothing to diff against.
      if (mode === 'diff' && !hasDiff) mode = 'full';

      if (mode === 'diff') {
        switch (key) {
          case 'about':      return renderAboutDiff(slot);
          case 'experience': return renderExpDiff(slot);
          case 'education':  return renderEduDiff(slot);
          case 'activity':   return renderActDiff(slot);
        }
      }

      // Full view — original renderers, plus a footer link to switch to
      // diff view (only shown when there's actually a diff to switch to).
      const fullBody = (() => {
        switch (key) {
          case 'about':      return renderAboutBody(slot);
          case 'experience': return renderExpBody(slot);
          case 'education':  return renderEduBody(slot);
          case 'activity':   return renderActBody(slot);
        }
      })();

      return hasDiff ? (fullBody + diffFooter(key, 'full')) : fullBody;
    }

    // ── Subscribe to capture state and re-render rows on update ───────────────
    // ── Delta pill rendering (NEW in v1.5) ────────────────────────────────────
    //
    // Each row carries a pill next to its label that summarizes how the
    // live capture compares to what's already in the linkedin_profiles
    // table for this org+slug:
    //
    //   • on-file        — DB has this section; live capture hasn't run yet
    //                      (or came back empty). Pill is grey. The pill text
    //                      includes the relative time so the rep knows how
    //                      stale the stored copy is.
    //   • unchanged      — Live capture exactly matches DB. Pill is grey.
    //                      Save button will be disabled (nothing to push).
    //   • updated        — Live capture differs from DB. Pill is amber.
    //                      Save button flips to "Refresh in GoWarmCRM".
    //   • new-data       — DB had nothing here, live captured something.
    //                      Pill is green ("new"). Save flips to "Save".
    //   • no-db          — No DB row at all (or section never seen). No pill.
    //
    // The pill is hidden until GET_LINKEDIN_PROFILE has resolved — there's
    // no point showing "no DB data" before we've even asked.
    function deltaPill(key, slot) {
      const d = diffSection(key, slot);
      if (!slot.dbHydrated || d === 'no-db') {
        return { show: false };
      }
      const ts = slot.dbCapturedAt ? formatRelative(slot.dbCapturedAt) : '';

      // Activity-specific pill text: the server appends rather than
      // overwrites, so "updated" is misleading — what's actually
      // happening is "+N new items will be added to your CRM record."
      // We compute N here so the rep sees the exact accumulation count
      // rather than a generic state word that means something different
      // for activity than it does for experience/education.
      if (key === 'activity' && d === 'updated') {
        const live  = slot.value   || [];
        const dbV   = slot.dbValue || [];
        const dbIds = new Set(dbV.map(x => x?.id).filter(Boolean));
        const newN  = live.filter(x => x?.id && !dbIds.has(x.id)).length;
        return {
          show: true,
          text: `+${newN} new`,
          bg: '#D1FAE5', fg: '#065F46',
        };
      }

      switch (d) {
        case 'on-file':
          return { show: true, text: ts ? `on file · ${ts}` : 'on file', bg: '#F1F5F9', fg: '#475569' };
        case 'unchanged':
          return { show: true, text: ts ? `synced · ${ts}` : 'synced',   bg: '#F1F5F9', fg: '#475569' };
        case 'updated':
          return { show: true, text: 'updated',                          bg: '#FEF3C7', fg: '#92400E' };
        case 'new-data':
          return { show: true, text: 'new',                              bg: '#D1FAE5', fg: '#065F46' };
        default:
          return { show: false };
      }
    }

    function refreshRow(key) {
      const def  = SECTIONS.find(s => s.key === key);
      if (!def) return;
      const slot = captureState[key];
      const els  = rowEls[key];
      if (!els) return;
      // The whole capture section may have been detached (e.g. renderProspect
      // re-rendered after Add). Skip silently — the new section's subscriber
      // will keep things up to date.
      if (!sec.isConnected) return;

      const count = def.countOf(slot);
      const countText = key === 'about'
        ? (slot.value ? '✓' : '')
        : (count > 0 ? `${count}` : '');
      const countEl = els.head.querySelector('.gw-cap-count');
      const badgeEl = els.head.querySelector('.gw-cap-status');
      const deltaEl = els.head.querySelector('.gw-cap-delta');
      if (!countEl || !badgeEl) return;
      countEl.textContent = countText;

      const badge = statusBadge(slot.status);
      badgeEl.textContent       = badge.text;
      badgeEl.style.background  = badge.bg;
      badgeEl.style.color       = badge.fg;

      // Delta pill — only meaningful once DB hydration has resolved.
      if (deltaEl) {
        const p = deltaPill(key, slot);
        if (p.show) {
          deltaEl.textContent      = p.text;
          deltaEl.style.background = p.bg;
          deltaEl.style.color      = p.fg;
          deltaEl.style.display    = 'inline-block';
        } else {
          deltaEl.style.display    = 'none';
        }
      }

      els.body.innerHTML = bodyFor(key, slot);

      // Any row update can change the aggregate delta state, so re-render
      // the save button label (cheap — just text + disabled toggle).
      refreshSaveBtn();
    }

    // Save button label + disabled state, derived from diffAll(). Called
    // on every row refresh; idempotent and trivially cheap.
    function refreshSaveBtn() {
      if (!btn) return;
      // Don't fight the user mid-save — if the button is showing "Saving…"
      // or "✓ Saved" we leave it alone until the next render cycle.
      if (btn.dataset.busy === '1') return;

      const { hasDb, anyChanges, anyOnFile, overall } = diffAll();

      if (overall === 'no-db') {
        // No DB row yet — first save. Standard "Save" button.
        btn.textContent          = 'Save to GoWarmCRM';
        btn.disabled             = false;
        btn.style.background     = ORANGE;
        btn.style.opacity        = '1';
        btn.style.cursor         = 'pointer';
      } else if (overall === 'unchanged') {
        // Profile on file and live matches — no point saving.
        btn.textContent          = '✓ Already up to date';
        btn.disabled             = true;
        btn.style.background     = '#94A3B8';
        btn.style.opacity        = '0.85';
        btn.style.cursor         = 'default';
      } else {
        // hasDb && anyChanges — refresh path.
        btn.textContent          = 'Refresh in GoWarmCRM';
        btn.disabled             = false;
        btn.style.background     = ORANGE;
        btn.style.opacity        = '1';
        btn.style.cursor         = 'pointer';
      }
    }

    SECTIONS.forEach(def => refreshRow(def.key));
    captureSubscribe(section => refreshRow(section));
    refreshSaveBtn();   // first render before any subscription fires

    // ── Save button (skipped entirely when hideSaveButton: true) ─────────────
    if (!btn) return;

    btn.addEventListener('click', async () => {
      // Reset transient feedback / warning
      feedback.style.display = 'none';
      warning.style.display  = 'none';

      const captured = captureFullProfile();

      // Warn if any section is still pending — i.e. the user hasn't scrolled
      // it into view yet. This is recoverable — they can confirm and continue.
      const pending = Object.entries(captured.progress)
        .filter(([_, st]) => st === 'pending' || st === 'loading')
        .map(([k]) => k);

      if (pending.length > 0 && !btn.dataset.confirmedIncomplete) {
        warning.style.display = 'block';
        warning.innerHTML = `
          <div style="margin-bottom:6px;"><strong>Capture is incomplete.</strong> These sections haven't loaded yet: ${escHtml(pending.join(', '))}.</div>
          <div style="display:flex;gap:6px;">
            <button id="gw-cap-cancel" style="flex:1;padding:5px;background:#fff;border:1px solid #D1D5DB;border-radius:4px;font-size:11px;cursor:pointer;">Cancel</button>
            <button id="gw-cap-continue" style="flex:1;padding:5px;background:${ORANGE};color:#fff;border:none;border-radius:4px;font-size:11px;font-weight:600;cursor:pointer;">Send anyway</button>
          </div>
        `;
        warning.querySelector('#gw-cap-cancel').addEventListener('click', () => {
          warning.style.display = 'none';
        });
        warning.querySelector('#gw-cap-continue').addEventListener('click', () => {
          btn.dataset.confirmedIncomplete = '1';
          warning.style.display = 'none';
          btn.click();
        });
        return;
      }

      // Validate that we have at least *something* to send.
      const c = captured.counts;
      const totalSignal = c.about + c.experience + c.education + c.activity;
      if (totalSignal === 0) {
        feedback.style.cssText = 'margin-top:6px;font-size:11px;display:block;color:#dc2626;';
        feedback.textContent = 'Nothing captured yet. Scroll the page to load profile sections, then try again.';
        return;
      }

      btn.disabled    = true;
      btn.dataset.busy = '1';   // pause refreshSaveBtn while we control the label
      btn.textContent = 'Saving…';

      try {
        const res = await bgMessage({
          type:        'UPSERT_LINKEDIN_PROFILE',
          linkedinUrl: captured.linkedin_url,
          fields:      captured.fields,
          linkTo: prospect ? { entity_type: 'prospects', entity_id: prospect.id } : null,
        });

        if (!res.ok) throw new Error(res.error);

        // ── Re-hydrate dbValue from the upsert response (NEW in v1.5) ────────
        // The server returns the merged row, so we use it as the new
        // baseline. After this, every section's diff flips to either
        // 'unchanged' (live matched what we sent) or 'on-file' if the
        // server's merge rules kept some prior data. The save button
        // will be re-evaluated by refreshSaveBtn() once we clear busy.
        if (res.profile) {
          hydrateFromDbProfile(res.profile);
        }

        // Refresh the debug-IDs strip with whatever the upsert returned.
        // Account id and prospect id may have been populated on init already;
        // we restate them along with the now-confirmed profile_id.
        renderDebugIds(panel, {
          profile_id:  res.profile_id || res.profile?.id || null,
          prospect_id: prospect?.id || null,
          account_id:  res.account_id || prospect?.account?.id || prospect?.account_id || null,
        });

        btn.style.background = '#059669';
        btn.textContent      = '✓ Saved';
        feedback.style.cssText = 'margin-top:6px;font-size:11px;display:block;color:#059669;';
        feedback.textContent   = prospect && diffAll().hasDb
          ? 'Profile refreshed in GoWarmCRM.'
          : 'Profile saved to GoWarmCRM.';

        // After a brief pause showing ✓ Saved, return the button to its
        // diff-derived state (will read 'Already up to date' since we
        // just synced).
        setTimeout(() => {
          delete btn.dataset.busy;
          btn.style.background = ORANGE;   // refreshSaveBtn will repaint
          refreshSaveBtn();
        }, 1500);
      } catch (err) {
        btn.disabled        = false;
        delete btn.dataset.busy;
        btn.style.background = ORANGE;
        // Let refreshSaveBtn pick the right label given current diff state.
        refreshSaveBtn();
        feedback.style.cssText = 'margin-top:6px;font-size:11px;display:block;color:#dc2626;';
        feedback.textContent = err.message;
      } finally {
        delete btn.dataset.confirmedIncomplete;
      }
    });
  }

  // Format helper used by experience body renderer.
  function formatDateRange(startDate, endDate, durationMonths) {
    function fmt(d) {
      if (!d) return null;
      try {
        const dt = new Date(d);
        return dt.toLocaleDateString(undefined, { year: 'numeric', month: 'short' });
      } catch (_) { return d; }
    }
    const s = fmt(startDate);
    const e = endDate ? fmt(endDate) : 'Present';
    const dur = durationMonths
      ? (() => {
          const y = Math.floor(durationMonths / 12);
          const m = durationMonths % 12;
          return `${y ? `${y}y ` : ''}${m ? `${m}mo` : ''}`.trim();
        })()
      : '';
    if (!s) return dur || '';
    return `${s} \u2013 ${e}${dur ? ` · ${dur}` : ''}`;
  }

  // ── Main prospect view ───────────────────────────────────────────────────────

  function renderProspect(panel, prospect) {
    const li          = prospect.channel_data?.linkedin || {};

    // ── Prospect strip ──
    const strip = document.createElement('div');
    strip.style.cssText = 'padding:8px 13px;border-bottom:1px solid #f1f5f9;display:flex;align-items:center;gap:8px;';
    const draftBadgeHtml = prospect.pendingDrafts > 0
      ? `<a href="https://app.gowarmcrm.com/prospecting?prospect=${prospect.id}" target="_blank"
           title="Open drafts in GoWarmCRM"
           style="display:inline-flex;align-items:center;gap:3px;font-size:10px;padding:2px 7px;
                  border-radius:10px;background:#FFF3E0;color:#E8630A;font-weight:600;
                  white-space:nowrap;text-decoration:none;border:1px solid #FBCF9D;">
           ✉️ ${prospect.pendingDrafts} draft${prospect.pendingDrafts > 1 ? 's' : ''} pending
         </a>`
      : '';

    strip.innerHTML = `
      <div style="flex:1;min-width:0;">
        <div style="font-size:11px;color:#64748b;">${escHtml(prospect.company_name || '')}</div>
      </div>
      ${draftBadgeHtml}
      <span style="font-size:10px;padding:2px 7px;border-radius:10px;background:#E6F1FB;color:#185FA5;font-weight:500;white-space:nowrap;">
        ${prospect.stage || 'target'}
      </span>
      ${prospect.linkedin_url ? `<a href="${escHtml(prospect.linkedin_url)}" target="_blank"
        style="font-size:10px;color:#0077B5;text-decoration:none;white-space:nowrap;">View ↗</a>` : ''}
    `;
    panel.appendChild(strip);

    // ── Capture section (NEW in v1.2) ──
    renderCaptureSection(panel, prospect);

    // ── Timeline (status steps only) ──
    const tlSection = document.createElement('div');
    tlSection.style.cssText = 'padding:10px 13px;border-bottom:1px solid #f1f5f9;';
    let tlHtml = `<div style="font-size:10px;font-weight:600;color:#94a3b8;letter-spacing:0.05em;text-transform:uppercase;margin-bottom:8px;">Timeline</div>`;

    TIMELINE_EVENTS.forEach((ev, idx) => {
      const done   = getStatusIdx(li.connection_status) >= getStatusIdx(ev.key) && getStatusIdx(ev.key) >= 0;
      const ts     = li[ev.tsField] ? formatDate(li[ev.tsField]) : '';
      const isLast = idx === TIMELINE_EVENTS.length - 1;

      let extra = '';
      if (ev.key === 'connection_accepted' && li.request_sent_at && li.connected_at) {
        const days = Math.round((new Date(li.connected_at) - new Date(li.request_sent_at)) / 86400000);
        extra = days === 0 ? ' · same day' : ` · ${days}d to accept`;
      }
      if (ev.key === 'message_sent' && li.message_count > 1) {
        extra = ` · ${li.message_count} messages`;
      }
      if (ev.key === 'reply_received' && li.last_reply_sentiment) {
        extra = ` · ${li.last_reply_sentiment}`;
      }

      tlHtml += `
        <div style="display:flex;gap:8px;align-items:flex-start;">
          <div style="display:flex;flex-direction:column;align-items:center;flex-shrink:0;padding-top:3px;">
            <div style="width:9px;height:9px;border-radius:50%;background:${done ? ev.color : 'transparent'};border:1.5px solid ${done ? ev.color : '#cbd5e1'};flex-shrink:0;"></div>
            ${!isLast ? `<div style="width:1px;height:18px;background:${done ? ev.color : '#e2e8f0'};margin-top:2px;opacity:0.4;"></div>` : ''}
          </div>
          <div style="padding-bottom:${isLast ? 0 : 8}px;">
            <div style="font-size:12px;color:${done ? '#1a202c' : '#94a3b8'};font-weight:${done ? 500 : 400};">${ev.label}</div>
            ${done && (ts || extra) ? `<div style="font-size:10px;color:#94a3b8;margin-top:1px;">${ts}${extra}</div>` : ''}
          </div>
        </div>`;
    });

    tlSection.innerHTML = tlHtml;
    panel.appendChild(tlSection);

    // ── Log form ──
    const formSection = document.createElement('div');
    formSection.style.cssText = 'padding:10px 13px;border-bottom:1px solid #f1f5f9;background:#f8fafc;';
    formSection.innerHTML = `
      <div style="font-size:10px;font-weight:600;color:#94a3b8;letter-spacing:0.05em;text-transform:uppercase;margin-bottom:8px;">Log event</div>
      <select id="gw-event-select" style="width:100%;font-size:12px;padding:5px 7px;border:1px solid #e2e8f0;border-radius:6px;background:#fff;color:#374151;margin-bottom:6px;">
        ${EVENTS.map(ev => `<option value="${ev.key}">${ev.label}</option>`).join('')}
      </select>
      <textarea id="gw-note" rows="2" placeholder="Message content, reply summary, or note…"
        style="width:100%;font-size:11px;padding:5px 7px;border:1px solid #e2e8f0;border-radius:6px;
               resize:none;color:#374151;font-family:inherit;margin-bottom:6px;box-sizing:border-box;"></textarea>
      <div id="gw-sentiment-wrap" style="display:none;margin-bottom:6px;">
        <select id="gw-sentiment" style="width:100%;font-size:11px;padding:5px 7px;border:1px solid #e2e8f0;border-radius:6px;background:#fff;color:#374151;">
          ${SENTIMENTS.map(s => `<option value="${s.value}">${s.label}</option>`).join('')}
        </select>
      </div>
      <div style="display:flex;gap:6px;">
        <button id="gw-save" style="flex:1;padding:6px;background:${TEAL};color:#fff;border:none;border-radius:6px;font-size:12px;font-weight:600;cursor:pointer;">Save</button>
      </div>
      <div id="gw-feedback" style="margin-top:6px;font-size:11px;display:none;"></div>
    `;
    panel.appendChild(formSection);

    const evSelect = formSection.querySelector('#gw-event-select');
    const sentWrap = formSection.querySelector('#gw-sentiment-wrap');
    evSelect.addEventListener('change', () => {
      sentWrap.style.display = evSelect.value === 'reply_received' ? 'block' : 'none';
    });

    formSection.querySelector('#gw-save').addEventListener('click', async () => {
      const eventKey  = evSelect.value;
      const note      = formSection.querySelector('#gw-note').value.trim();
      const sentiment = formSection.querySelector('#gw-sentiment')?.value || undefined;
      const saveBtn   = formSection.querySelector('#gw-save');
      const feedback  = formSection.querySelector('#gw-feedback');

      saveBtn.disabled    = true;
      saveBtn.textContent = 'Saving…';
      feedback.style.display = 'none';

      try {
        const res = await bgMessage({
          type:        'LOG_EVENT',
          prospectId:  prospect.id,
          event:       eventKey,
          note:        note || undefined,
          sentiment:   sentiment || undefined,
        });

        if (!res.ok) throw new Error(res.error);

        feedback.style.cssText = 'margin-top:6px;font-size:11px;display:block;color:#059669;';
        feedback.textContent   = `Saved: ${EVENTS.find(e => e.key === eventKey)?.label}`;
        formSection.querySelector('#gw-note').value = '';

        setTimeout(() => {
          const existing = panel.querySelectorAll('div:not(:first-child):not(:nth-child(2))');
          existing.forEach(el => el.remove());
          renderProspect(panel, { ...prospect, channel_data: res.data?.channelData || prospect.channel_data });
        }, 1000);

      } catch (err) {
        saveBtn.disabled    = false;
        saveBtn.textContent = 'Save';
        feedback.style.cssText = 'margin-top:6px;font-size:11px;display:block;color:#dc2626;';
        feedback.textContent   = err.message;
      }
    });

    // ── Stats bar ──
    if (li.connection_status) {
      const stats = document.createElement('div');
      stats.style.cssText = 'padding:8px 13px;display:flex;gap:14px;border-bottom:1px solid #f1f5f9;';
      const items = [
        li.message_count  && { label: 'messages',  value: li.message_count },
        li.inmail_count   && { label: 'inmails',   value: li.inmail_count  },
        li.reply_count    && { label: 'replies',   value: li.reply_count   },
      ].filter(Boolean);

      if (items.length) {
        stats.innerHTML = items.map(i =>
          `<div><span style="font-size:14px;font-weight:600;color:#1a202c;">${i.value}</span>
           <span style="font-size:10px;color:#94a3b8;margin-left:3px;">${i.label}</span></div>`
        ).join('');
        panel.appendChild(stats);
      }
    }

    // ── Footer ──
    const footer = document.createElement('div');
    footer.style.cssText = 'padding:8px 13px;background:#f8fafc;';
    footer.innerHTML = `<a href="https://app.gowarmcrm.com" target="_blank" style="font-size:11px;color:${TEAL};text-decoration:none;font-weight:500;">Open in GoWarmCRM ↗</a>`;
    panel.appendChild(footer);
  }

  // ── Init ─────────────────────────────────────────────────────────────────────

  async function init() {
    document.getElementById(PANEL_ID)?.remove();
    disposeCaptureObservers();           // start fresh for this profile
    lastDebugIds = {};                   // clear stale ids from previous profile

    const linkedinUrl = getCurrentLinkedInUrl();
    if (!linkedinUrl) return;

    // Read debug flag from chrome.storage.local. Best-effort; if storage
    // is unavailable, debugMode stays false (its default). Fire and forget —
    // the panel can render before this resolves; debug strip rendering is
    // deferred until IDs are known anyway.
    try {
      chrome.storage.local.get(['gowarm_debug'], (r) => {
        debugMode = r?.gowarm_debug === '1' || r?.gowarm_debug === true;
      });
    } catch (_) { /* swallow */ }

    // Reset captureState BEFORE extractProfileInfo() runs.
    //
    // Why this matters: extractProfileInfo() falls back to
    // getExperience() when the top card and headline don't yield a
    // company. getExperience() reads captureState.experience.value —
    // and on SPA navigation that value still holds the *previous*
    // profile's data (kept alive by the 1.7.5 clobber-protection).
    //
    // Without this reset, navigating from a profile where Experience
    // was captured to a new profile whose company can't be derived
    // from top card or headline would silently fill the form's
    // Company field with the previous profile's employer — exactly
    // the "Teleglobal leaking onto Mark Green" bug. Resetting here
    // makes getExperience() correctly fall through to a cold scrape
    // (which returns [] for Mark since experience hasn't loaded yet),
    // leaving the Company field empty rather than wrong.
    //
    // setupCaptureObservers() further down also resets captureState,
    // so this is redundant in the happy path — but the order matters:
    // reset must happen before extractProfileInfo, not after.
    captureState = makeCaptureState();

    const profileInfo = extractProfileInfo();
    const panel = buildPanel();
    renderHeader(panel, profileInfo.name, profileInfo.title);
    renderLoading(panel);
    document.body.appendChild(panel);

    // Kick off progressive capture immediately. Observers start populating
    // captureState in the background; the panel will subscribe once
    // renderCaptureSection mounts inside renderProspect / renderNotFound.
    setupCaptureObservers();

    // ── Identity (drives the panel header subline) ───────────────────────────
    // Fire-and-forget; if it fails we just skip the subline.
    bgMessage({ type: 'GET_IDENTITY' })
      .then(res => { if (res?.ok && res.identity) renderIdentitySubline(panel, res.identity); })
      .catch(() => { /* swallow */ });

    // ── Delta-refresh hydration (NEW in v1.5) ────────────────────────────────
    // Fire-and-forget; the prospect lookup below doesn't block on this.
    // When it returns we seed captureState.dbValue + dbCapturedAt for each
    // section so the panel can show "on file" badges and the diff.
    bgMessage({ type: 'GET_LINKEDIN_PROFILE', linkedinUrl })
      .then(res => {
        if (res?.ok) hydrateFromDbProfile(res.profile);
        else        hydrateFromDbProfile(null);   // mark hydrated-but-empty
        // Surface linkedin_profile.id in the debug strip as soon as we know it.
        if (res?.ok && res.profile?.id) {
          renderDebugIds(panel, { profile_id: res.profile.id });
        }
      })
      .catch(() => hydrateFromDbProfile(null));

    let res;
    try {
      res = await bgMessage({ type: 'LOOKUP_PROSPECT', linkedinUrl });
    } catch (_) {
      panel.lastChild?.remove();
      renderNotAuthenticated(panel);
      return;
    }

    panel.lastChild?.remove();

    if (!res.ok && res.error === 'NOT_AUTHENTICATED') {
      renderNotAuthenticated(panel);
    } else if (!res.ok || !res.prospect) {
      renderNotFound(panel, profileInfo);
    } else {
      renderProspect(panel, res.prospect);
      // Once we have a prospect, surface its id + account_id in the debug
      // strip. linkedin_profile.id may have already been set above; calling
      // renderDebugIds again replaces with the union (we pass all known ids).
      // The hydration call may race with this — whichever runs second wins,
      // and both have the prospect's profile data available.
      renderDebugIds(panel, {
        profile_id:  res.prospect.linkedin_profile_id || null,
        prospect_id: res.prospect.id,
        account_id:  res.prospect.account?.id || res.prospect.account_id || null,
      });
    }
  }

  // ── SPA navigation watcher ───────────────────────────────────────────────────
  let lastUrl = location.href;
  let initInProgress = false;

  // Context-validity guard. After an extension reload, the OLD content
  // script remains in the page but its connection to the extension is dead.
  // chrome.runtime.id becomes undefined and chrome.runtime.sendMessage()
  // throws "Extension context invalidated". When that happens, we stop
  // firing background work (init, mutation observer) — otherwise we
  // generate an endless flood of failed network requests until the user
  // refreshes the tab.
  function extensionAlive() {
    try {
      return !!(chrome && chrome.runtime && chrome.runtime.id);
    } catch (_) {
      return false;
    }
  }

  async function safeInit() {
    if (initInProgress) return;
    if (!extensionAlive()) return;
    initInProgress = true;
    try {
      await init();
    } finally {
      initInProgress = false;
    }
  }

  const navObserver = new MutationObserver(() => {
    if (!extensionAlive()) {
      // Extension was reloaded — disconnect ourselves and stop generating
      // failed requests.
      navObserver.disconnect();
      disposeCaptureObservers();
      document.getElementById(PANEL_ID)?.remove();
      return;
    }
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      if (/linkedin\.com\/in\//.test(location.href)) {
        setTimeout(safeInit, 1200);
      } else {
        disposeCaptureObservers();
        document.getElementById(PANEL_ID)?.remove();
      }
    }
  });
  navObserver.observe(document.body, { childList: true, subtree: true });

  setTimeout(safeInit, 1500);

  // ── Debug-mode keyboard shortcut ─────────────────────────────────────────────
  // Ctrl+Shift+D (Cmd+Shift+D on Mac) toggles debugMode on/off. The toggle
  // is persisted to chrome.storage.local so it survives page reloads.
  // Skips when the user is typing in an input, textarea, or contenteditable
  // element so it doesn't fire while writing a LinkedIn message or post.
  document.addEventListener('keydown', (e) => {
    // Match Ctrl+Shift+D on Win/Linux, Cmd+Shift+D on Mac.
    const isMod = e.ctrlKey || e.metaKey;
    if (!isMod || !e.shiftKey) return;
    if (e.key !== 'D' && e.key !== 'd') return;

    // Skip when focus is in an editable field — Ctrl+Shift+D is a common
    // text-editing combo (especially in LinkedIn's composer).
    const target = e.target;
    if (target && (
      target.tagName === 'INPUT'    ||
      target.tagName === 'TEXTAREA' ||
      target.isContentEditable
    )) return;

    e.preventDefault();
    debugMode = !debugMode;

    // Persist so the new state survives reload.
    try {
      if (debugMode) {
        chrome.storage.local.set({ gowarm_debug: '1' });
      } else {
        chrome.storage.local.remove(['gowarm_debug']);
      }
    } catch (_) { /* swallow — storage may be unavailable */ }

    // Re-render the debug strip on the current panel with cached IDs.
    const panel = document.getElementById(PANEL_ID);
    if (panel) {
      renderDebugIds(panel, {});
      showDebugToast(panel, debugMode ? 'Debug mode ON' : 'Debug mode OFF');
    }
  });

  // Brief toast at the top of the GoWarm panel. Used by the debug toggle to
  // confirm the change happened (state is otherwise silent when no IDs are
  // available to show). 1.4s lifetime; fades out via opacity transition.
  function showDebugToast(panel, message) {
    if (!panel) return;
    // Re-use an existing toast if one is already on-screen.
    let t = panel.querySelector('#gw-debug-toast');
    if (!t) {
      t = document.createElement('div');
      t.id = 'gw-debug-toast';
      t.style.cssText = `
        position: absolute; top: 8px; left: 50%; transform: translateX(-50%);
        background: #1F2937; color: #FEF3C7; font-size: 11px;
        padding: 4px 10px; border-radius: 12px; font-weight: 600;
        letter-spacing: 0.04em; pointer-events: none; z-index: 100;
        box-shadow: 0 2px 8px rgba(0,0,0,0.25);
        transition: opacity 200ms ease-out;
      `;
      // Panel itself has `overflow: hidden` set in buildPanel, which would
      // clip the toast — but since the toast sits inside the panel and we
      // position it at top:8px it's well within bounds.
      panel.appendChild(t);
    }
    t.textContent = message;
    t.style.opacity = '1';
    clearTimeout(t._fadeT);
    t._fadeT = setTimeout(() => {
      t.style.opacity = '0';
      setTimeout(() => { try { t.remove(); } catch (_) {} }, 250);
    }, 1400);
  }

  // ── DEBUG HOOKS (v1.2-debug) ─────────────────────────────────────────────────
  // Exposed on every linkedin.com/in/* page so you can call extraction from
  // DevTools console without clicking the Capture button. Safe to ship — only
  // attaches functions to window, doesn't change runtime behavior.
  //
  // Usage in DevTools console:
  //   __gowarmCapture()       → returns the payload that would be POSTed
  //   __gowarmCaptureDebug()  → returns a richer object with layout detection,
  //                              raw line samples, and per-section diagnostics
  //   copy(JSON.stringify(__gowarmCaptureDebug(), null, 2))   → copy to clipboard

  function debugCapture() {
    const errors = [];
    const safe = (label, fn) => {
      try { return fn(); }
      catch (e) {
        errors.push({ label, error: e.message, stack: e.stack });
        return null;
      }
    };

    // Layout detection
    const layout = {
      sdui_topcard:      !!document.querySelector('section[componentkey*="Topcard"]'),
      legacy_topcard:    !!document.querySelector('.pv-text-details__left-panel, .ph5.pb5'),
      artdeco_li_count:  document.querySelectorAll('li.artdeco-list__item').length,
      sdui_entity_count: document.querySelectorAll('div[data-view-name="profile-component-entity"]').length,
      data_test_exp:     document.querySelectorAll('li[data-test="experience-item"]').length,
      data_test_edu:     document.querySelectorAll('li[data-test="education-item"]').length,
      activity_urns:     document.querySelectorAll('div[urn^="urn:li:activity:"], div[data-urn^="urn:li:activity:"]').length,
    };

    // Per-section diagnostics
    const sections = {};
    const aboutSec = safe('findAbout', () => findSectionByHeading([/^about\b/i]));
    sections.about = {
      found:        !!aboutSec,
      heading_text: aboutSec?.querySelector('h2, h3, [role="heading"]')?.innerText?.trim() || null,
      text_sample:  aboutSec ? (aboutSec.innerText || '').slice(0, 300) : null,
    };

    const expSec = safe('findExperience', () => findSectionByHeading([/^experience$/i]));
    sections.experience = {
      found:        !!expSec,
      heading_text: expSec?.querySelector('h2, h3, [role="heading"]')?.innerText?.trim() || null,
      item_count_artdeco: expSec?.querySelectorAll('li.artdeco-list__item').length || 0,
      item_count_sdui:    expSec?.querySelectorAll('div[data-view-name="profile-component-entity"]').length || 0,
      item_count_dataTest: expSec?.querySelectorAll('li[data-test="experience-item"]').length || 0,
      first_item_lines: null,
    };
    if (expSec) {
      const firstItem = expSec.querySelector(
        'li.artdeco-list__item, li[data-test="experience-item"], div[data-view-name="profile-component-entity"]'
      );
      if (firstItem) {
        sections.experience.first_item_lines = [...firstItem.querySelectorAll('span[aria-hidden="true"], div')]
          .map(el => el.innerText?.trim())
          .filter(Boolean)
          .filter((t, i, arr) => arr.indexOf(t) === i)
          .filter(t => t.length < 250)
          .slice(0, 12);
      }
    }

    const eduSec = safe('findEducation', () => findSectionByHeading([/^education$/i]));
    sections.education = {
      found:        !!eduSec,
      heading_text: eduSec?.querySelector('h2, h3, [role="heading"]')?.innerText?.trim() || null,
      item_count_artdeco: eduSec?.querySelectorAll('li.artdeco-list__item').length || 0,
      item_count_sdui:    eduSec?.querySelectorAll('div[data-view-name="profile-component-entity"]').length || 0,
    };

    const actSec = safe('findActivity', () => findSectionByHeading([
      /^activity$/i,
      /(\bposts?\b|\bactivity\b).{0,30}\bfollowers?$/i,
      /\brecent activity\b/i,
    ]));
    sections.activity = {
      found:        !!actSec,
      heading_text: actSec?.querySelector('h2, h3, [role="heading"]')?.innerText?.trim() || null,
      item_count_li: actSec?.querySelectorAll('li').length || 0,
      item_count_urn: actSec?.querySelectorAll('div[data-urn^="urn:li:activity:"]').length || 0,
      first_item_text: null,
    };
    if (actSec) {
      const first = actSec.querySelector('li, div[data-urn^="urn:li:activity:"]');
      if (first) sections.activity.first_item_text = (first.innerText || '').slice(0, 400);
    }

    // Run the actual extractors
    const basics    = safe('extractProfileInfo', () => extractProfileInfo());
    const about     = safe('captureAboutText',   () => captureAboutText());
    const experience= safe('getExperience',      () => getExperience());
    const education = safe('captureEducation',   () => captureEducation());
    const activity  = safe('captureActivity',    () => captureActivity());
    const fullPayload = safe('captureFullProfile', () => captureFullProfile());

    return {
      url: location.href,
      timestamp: new Date().toISOString(),
      layout,
      sections,
      extracted: {
        basics,
        about_length: about ? about.length : 0,
        about_preview: about ? about.slice(0, 200) : null,
        experience,
        education,
        activity,
      },
      payload: fullPayload,    // exactly what would be POSTed to backend
      errors,
    };
  }

  // Idempotent: re-attach on every script run (LinkedIn SPA may inject content
  // script multiple times for the same tab).
  //
  // CRITICAL: content scripts run in an "isolated world" — assigning to
  // window.__gowarmCapture here would NOT be visible from the DevTools
  // console (which runs in the page's main world). Instead we listen for a
  // CustomEvent dispatched from page-world code, run extraction in this
  // isolated world (where the extractor functions are scoped), then
  // dispatch the result back as another CustomEvent.
  try {
    document.addEventListener('gowarm:capture-request', (ev) => {
      const requestId = ev.detail?.requestId;
      const mode      = ev.detail?.mode || 'payload';   // 'payload' | 'debug'
      let result;
      try {
        result = mode === 'debug' ? debugCapture() : captureFullProfile();
      } catch (e) {
        result = { error: e.message, stack: e.stack };
      }
      document.dispatchEvent(new CustomEvent('gowarm:capture-response', {
        detail: { requestId, result },
      }));
    });

    // Inject a small page-world helper that exposes window.__gowarmCapture()
    // and window.__gowarmCaptureDebug() via the event bridge above.
    //
    // We MUST load it as <script src=...> pointing at an extension file,
    // not as inline textContent — LinkedIn's Content Security Policy blocks
    // inline scripts ('script-src self ...' with no 'unsafe-inline' and no
    // matching nonce/hash). Extension files are allowed because the
    // chrome-extension://<id>/... origin is implicitly permitted, AND the
    // file is declared in manifest.json under web_accessible_resources.
    try {
      const s = document.createElement('script');
      s.src = chrome.runtime.getURL('inject.js');
      s.onload = () => s.remove();
      (document.head || document.documentElement).appendChild(s);
    } catch (e) {
      console.warn('[GoWarm] failed to inject page-world helpers:', e);
      console.warn(
        '[GoWarm] Fallback — paste this into DevTools console to install hooks manually:\n\n' +
        `function __gw_call(mode) {
  return new Promise((resolve) => {
    const requestId = 'req_' + Math.random().toString(36).slice(2);
    const handler = (e) => {
      if (e.detail?.requestId !== requestId) return;
      document.removeEventListener('gowarm:capture-response', handler);
      resolve(e.detail.result);
    };
    document.addEventListener('gowarm:capture-response', handler);
    document.dispatchEvent(new CustomEvent('gowarm:capture-request', { detail: { requestId, mode } }));
  });
}
window.__gowarmCapture      = () => __gw_call('payload');
window.__gowarmCaptureDebug = () => __gw_call('debug');`
      );
    }
  } catch (e) {
    console.warn('[GoWarm] failed to install debug bridge:', e);
  }

})();
