// content.js — injected into every linkedin.com/in/* page

(function () {
  'use strict';

  const TEAL    = '#0F9D8E';
  const ORANGE  = '#E8630A';   // GoWarmCRM brand
  const PANEL_ID = 'gowarm-li-panel';
  const FEED_ID  = 'gowarm-li-feed';
  const PILL_ID  = 'gowarm-li-pill';          // collapsed "minimized" bubble

  // Minimize state. When true the panel is collapsed to a small floating
  // pill instead of being shown in full. Persisted to chrome.storage.local
  // under MINIMIZED_KEY so it survives page reloads / new tabs, and held in
  // this module-level flag so SPA navigation between profiles re-applies it
  // synchronously (no flash of the full panel before it collapses).
  const MINIMIZED_KEY = 'gowarm_panel_minimized';
  let panelMinimized = false;

  // Debug mode — when set, the in-page panel shows a small strip with the
  // DB IDs (linkedin_profile_id, prospect_id, account_id) for test/debug
  // verification. Toggle via:
  //   Ctrl+Shift+D (Cmd+Shift+D on Mac) — keyboard shortcut, anywhere on a
  //     LinkedIn page (except while typing in an input or textarea).
  //   chrome.storage.local.set({ gowarm_debug: '1' })   — programmatic enable
  //   chrome.storage.local.remove(['gowarm_debug'])     — programmatic disable
  // Defaults to off. Read on init() and refreshed when the shortcut fires.
  let debugMode = false;

  // Last-known set of IDs for the current panel. Set by renderDebugIds() so
  // the keyboard-shortcut toggle can replay them without a re-fetch.
  // Reset on each init() (new profile = clear previous IDs).
  let lastDebugIds = {};

  const EVENTS = [
    { key: 'connection_request_sent', label: 'Connection request sent', tsField: 'request_sent_at',      statusStep: true,  color: '#185FA5', bg: '#E6F1FB', isOutreach: true  },
    { key: 'connection_accepted',     label: 'Connection accepted',     tsField: 'connected_at',         statusStep: true,  color: '#3B6D11', bg: '#EAF3DE', isOutreach: false },
    { key: 'message_sent',            label: 'Message sent',            tsField: 'last_message_at',      statusStep: true,  color: '#BA7517', bg: '#FAEEDA', isOutreach: true  },
    { key: 'inmail_sent',             label: 'InMail sent',             tsField: 'last_message_at',      statusStep: false, color: '#854F0B', bg: '#FAEEDA', isOutreach: true  },
    { key: 'reply_received',          label: 'Reply received',          tsField: 'last_reply_at',        statusStep: true,  color: '#0F6E56', bg: '#E1F5EE', isOutreach: false },
    { key: 'voice_note_sent',         label: 'Voice note sent',         tsField: 'last_voice_note_at',   statusStep: false, color: '#993C1D', bg: '#FAECE7', isOutreach: true  },
    { key: 'profile_viewed',          label: 'Profile viewed (noted)',  tsField: 'last_profile_view_at', statusStep: false, color: '#5F5E5A', bg: '#F1EFE8', isOutreach: false },
    { key: 'meeting_booked',          label: 'Meeting booked',          tsField: 'meeting_booked_at',    statusStep: true,  color: '#185FA5', bg: '#E6F1FB', isOutreach: false },
  ];

  const TIMELINE_EVENTS = EVENTS.filter(e => e.statusStep);

  const STATUS_ORDER = [
    'connection_request_sent', 'connection_accepted',
    'message_sent', 'reply_received', 'meeting_booked',
  ];

  const SENTIMENTS = [
    { value: '',                label: '— sentiment (optional) —' },
    { value: 'positive',        label: 'Positive — keen to learn more' },
    { value: 'neutral',         label: 'Neutral — polite, non-committal' },
    { value: 'negative',        label: 'Negative — not interested' },
    { value: 'follow_up_later', label: 'Asked to follow up later' },
  ];

  // ── Helpers ──────────────────────────────────────────────────────────────────

  function getCurrentLinkedInUrl() {
    const match = location.href.match(/https:\/\/www\.linkedin\.com\/in\/([^/?#]+)/);
    return match ? `https://www.linkedin.com/in/${match[1]}` : null;
  }

  // ── Profile-URN capture (v1.20) ──────────────────────────────────────────────
  // We need the page owner's stable fsd_profile URN. Two sources, both
  // owner-bound to the current /in/<slug> (publicIdentifier === slug), so a
  // wrong URN is never recorded — a miss yields null and the send path falls
  // back to a live resolve.
  //
  //  • PRIMARY (DOM): LinkedIn server-renders profile data into <code> blocks on
  //    initial load. content.js (document_idle, DOM-ready) deep-walks them for
  //    the entity whose publicIdentifier matches the slug and reads its
  //    fsd_profile entityUrn. Self-contained; no network-request timing to catch.
  //  • SECONDARY (network): li_net_capture.js (MAIN world) records the same from
  //    LinkedIn's own Voyager request and postMessages it here — covers SPA
  //    navigation, where no fresh <code> JSON is rendered.
  const profileUrnBySlug = Object.create(null);

  function slugFromPath() {
    try {
      const m = (location.pathname || '').match(/\/in\/([^/?#]+)/);
      return m ? decodeURIComponent(m[1]).toLowerCase() : null;
    } catch (_) { return null; }
  }

  // Deep-walk an arbitrary parsed object graph for the object that carries the
  // owner's publicIdentifier, and return the fsd_profile URN on that same object.
  // Structure-agnostic on purpose: LinkedIn's response/embedded shapes vary and
  // their queryId/decoration rotates, but the co-occurrence of publicIdentifier
  // + entityUrn on the profile entity is stable.
  function deepFindOwnerUrn(root, slug) {
    try {
      const stack = [root];
      let guard = 0;
      while (stack.length && guard < 200000) {
        guard++;
        const node = stack.pop();
        if (!node || typeof node !== 'object') continue;
        const pid = typeof node.publicIdentifier === 'string' ? node.publicIdentifier.toLowerCase() : null;
        if (pid === slug) {
          for (const k of Object.keys(node)) {
            const v = node[k];
            if (typeof v === 'string' && /^urn:li:fsd_profile:[A-Za-z0-9_-]+$/.test(v)) return v;
          }
        }
        for (const k of Object.keys(node)) {
          const v = node[k];
          if (v && typeof v === 'object') stack.push(v);
        }
      }
    } catch (_) {}
    return null;
  }

  // Scan the page's embedded JSON (<code> blocks) for the owner URN.
  function extractOwnerUrnFromDom(slug, diag) {
    if (!slug) return null;
    let codes;
    try { codes = document.querySelectorAll('code'); } catch (_) { return null; }
    let scanned = 0, withProfile = 0, withSlug = 0, parsed = 0;
    for (const c of codes) {
      const t = c.textContent || '';
      if (!t || t.length < 20) continue;
      scanned++;
      if (t.indexOf('fsd_profile') === -1) continue;
      withProfile++;
      if (t.toLowerCase().indexOf(slug) === -1) continue;
      withSlug++;
      let j; try { j = JSON.parse(t); parsed++; } catch (_) { continue; }
      const urn = deepFindOwnerUrn(j, slug);
      if (urn) { if (diag) diag.hit = true; return urn; }
    }
    if (diag) Object.assign(diag, { scanned, withProfile, withSlug, parsed });
    return null;
  }

  // Network bridge: consume URNs li_net_capture emits (SPA navigations).
  window.addEventListener('message', (ev) => {
    try {
      if (ev.source !== window) return;
      const d = ev.data;
      if (!d || d.__gowarm !== true || d.kind !== 'profile_urn') return;
      if (d.slug && d.urn) profileUrnBySlug[String(d.slug).toLowerCase()] = d.urn;
    } catch (_) {}
  });
  function requestProfileUrn() {
    try {
      const slug = slugFromPath();
      if (slug) window.postMessage({ __gowarm: true, kind: 'profile_urn_request', slug }, '*');
    } catch (_) {}
  }
  requestProfileUrn();
  setTimeout(requestProfileUrn, 1500);

  // ── queryId self-healing bridge ──────────────────────────────────────────────
  // li_net_capture (MAIN world) observes the current voyagerIdentityDashProfiles
  // queryId but can't reach chrome.storage. We persist it here (isolated world)
  // and seed it back on load, so a cached/SPA profile load that fires no identity
  // request still resolves, and so a freshly-rotated hash survives reloads.
  window.addEventListener('message', (ev) => {
    try {
      if (ev.source !== window) return;
      const d = ev.data;
      if (!d || d.__gowarm !== true || d.kind !== 'profile_queryid') return;
      if (d.queryId) chrome.storage.local.set({ gowarm_profile_queryid: d.queryId });
    } catch (_) {}
  });
  try {
    chrome.storage.local.get(['gowarm_profile_queryid'], (o) => {
      const qid = o && o.gowarm_profile_queryid;
      if (qid) window.postMessage({ __gowarm: true, kind: 'profile_queryid_seed', queryId: qid }, '*');
    });
  } catch (_) {}

  // Await a URN from li_net_capture (which resolves live on miss). Returns the
  // cached value immediately if present; otherwise round-trips to the MAIN world
  // and waits up to timeoutMs for the resolve reply.
  function requestProfileUrnAsync(timeoutMs) {
    const slug = slugFromPath();
    return new Promise((resolve) => {
      if (!slug) return resolve(null);
      if (profileUrnBySlug[slug]) return resolve(profileUrnBySlug[slug]);
      let done = false;
      const onMsg = (ev) => {
        if (ev.source !== window) return;
        const d = ev.data;
        if (!d || d.__gowarm !== true || d.kind !== 'profile_urn') return;
        if (String(d.slug).toLowerCase() === slug && d.urn) {
          profileUrnBySlug[slug] = d.urn;
          if (!done) { done = true; window.removeEventListener('message', onMsg); clearTimeout(timer); resolve(d.urn); }
        }
      };
      window.addEventListener('message', onMsg);
      window.postMessage({ __gowarm: true, kind: 'profile_urn_request', slug }, '*');
      const timer = setTimeout(() => {
        if (!done) { done = true; window.removeEventListener('message', onMsg); resolve(profileUrnBySlug[slug] || null); }
      }, timeoutMs || 3000);
    });
  }

  // The captured fsd_profile URN for the profile on screen, or null. ASYNC:
  //   1. cache (warmed on load), then
  //   2. embedded <code> JSON when present (instant, no network), then
  //   3. a live Voyager resolve via li_net_capture — the reliable path, since
  //      <code> hydration blocks are stripped after boot / absent on SPA nav.
  async function currentProfileMemberUrn() {
    const slug = slugFromPath();
    if (!slug) return null;
    if (profileUrnBySlug[slug]) return profileUrnBySlug[slug];

    const diag = {};
    const domUrn = extractOwnerUrnFromDom(slug, diag);
    if (domUrn) {
      profileUrnBySlug[slug] = domUrn;
      console.log('[GoWarm] profile URN captured (DOM):', slug, domUrn);
      return domUrn;
    }

    const resolved = await requestProfileUrnAsync(3000);
    if (resolved) console.log('[GoWarm] profile URN resolved (live):', slug, resolved);
    else console.log('[GoWarm] profile URN unresolved for', slug, diag);
    return resolved;
  }

  // Console helper: __gowarmUrnDebug() on a profile page reports what the DOM
  // extractor sees. (Runs in the content-script context; call from the page
  // console — content-script logs surface there.)
  try {
    window.__gowarmUrnDebug = function () {
      const slug = slugFromPath();
      const diag = {};
      const urn = extractOwnerUrnFromDom(slug, diag);
      const out = { slug, urn, cached: profileUrnBySlug[slug] || null, diag };
      console.log('[GoWarm] __gowarmUrnDebug:', out);
      return out;
    };
  } catch (_) {}

  function formatDate(iso) {
    if (!iso) return '';
    return new Date(iso).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  }

  // Full date + time, e.g. "Jun 3, 2026 · 4:32 PM". Used in the timeline
  // step-detail card so reps can track exactly when an action completed.
  function formatDateTime(iso) {
    if (!iso) return '';
    const d = new Date(iso);
    if (isNaN(d.getTime())) return '';
    const date = d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
    const time = d.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
    return `${date} · ${time}`;
  }

  // Produce a value string for <input type="datetime-local"> from a Date,
  // in the browser's LOCAL time (the input has no timezone). Round-trips via
  // `new Date(value).toISOString()` back to correct UTC on save.
  function localDatetimeValue(d = new Date()) {
    const pad = n => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}` +
           `T${pad(d.getHours())}:${pad(d.getMinutes())}`;
  }

  function escHtml(str) {
    return String(str || '')
      .replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  // Stable id for activity items derived from a URL/text. Same input → same id.
  function hashId(input) {
    let h = 0;
    const s = String(input || '');
    for (let i = 0; i < s.length; i++) {
      h = ((h << 5) - h) + s.charCodeAt(i);
      h |= 0;
    }
    return 'li_' + Math.abs(h).toString(36);
  }

  // ── Profile extraction (basics — name/title/company/location) ─────────────────
  // LinkedIn is rolling out a new SDUI-based profile layout alongside the old
  // classed-HTML layout. We try the new layout first and fall back to the old
  // one so the extension works for users on either variant.

  // Parse a company name out of a headline string. LinkedIn headlines
  // commonly name the employer after a preposition or delimiter:
  //   "Head of Product Engineering @ Replit | We're hiring!"
  //   "Founder at glByte, Inc · Investor"
  //   "Chief Executive Officer & Founder of Blockware"
  //   "CTO, Acme Corp"
  //   "CEO | Hyperglance, Inc."
  // We try several patterns in priority order. Returns '' when no
  // pattern matches.
  //
  // Corporate suffixes ("Inc.", "LLC", etc.) are never returned alone —
  // they are appendages to a real company name, not employers in
  // themselves. The check is applied to every pattern's output.
  function companyFromHeadline(headline) {
    if (!headline) return '';
    const h = String(headline);

    // Role keywords that genuinely precede a company name. Used by
    // Patterns 2 and 3.
    const ROLE_KW = '(?:founder|co-?founder|owner|director|head|vp|president|ceo|cto|cfo|coo|cmo|cro|chair|chairman|partner|principal|chief\\s+\\w+\\s+officer)';

    // Pattern 1: "@" or " at " — strongest signal. "Founder at Acme".
    let m = h.match(/(?:^|\s)(?:@|at)\s+(.+)$/i);

    // Pattern 2: "<role> of <company>". Restricted to genuine role
    // keywords to avoid "Master of Science", "Bachelor of Arts".
    if (!m) {
      m = h.match(new RegExp('\\b' + ROLE_KW + '\\s+of\\s+(.+)$', 'i'));
    }

    // Pattern 3: "<role>, <Company>" — requires the role keyword as an
    // anchor. Without this anchor we'd wrongly match "Hyperglance, Inc."
    // in "CEO | Hyperglance, Inc." and capture just "Inc.".
    //
    // The company segment ends at the next headline separator (| · — –) OR end
    // of string — NOT only end-of-string. The old `$`-only anchor failed on the
    // very common "Title, Company | tagline" shape (e.g. "Founding Partner,
    // Innovation Endeavors | I back founders…"): the pipe-excluding class could
    // never reach `$` past the trailing clause, so this pattern silently missed
    // and Pattern 4 grabbed the post-pipe tagline as the "company". The lazy
    // quantifier + lookahead stops the capture at the separator.
    if (!m) {
      m = h.match(new RegExp('\\b' + ROLE_KW + '\\b[^,|]*,\\s+([A-Z][^,|·—–]{1,80}?)(?=\\s*[|·—–]|$)', 'i'));
    }

    // Pattern 4: "<role-or-anything> | <Company>" — pipe is LinkedIn's
    // most common headline separator. Take the segment that looks most
    // company-shaped: starts with a capital letter, ≤ 80 chars, doesn't
    // contain phrases that look like role descriptions or taglines.
    if (!m) {
      const parts = h.split(/\s*\|\s*/).map(s => s.trim()).filter(Boolean);
      if (parts.length >= 2) {
        // Heuristic: company segments are short and start capitalized.
        // Skip the first part (usually the role/headline). Inspect the
        // rest for a company-shaped segment.
        for (let i = 1; i < parts.length; i++) {
          const part = parts[i];
          if (part.length > 80) continue;
          if (!/^[A-Z]/.test(part)) continue;
          // Reject obvious non-company phrases.
          if (/\b(hiring|we're|join us|opinions|views|building|helping|love|passionate|advisor|investor|speaker|author|former|ex-)\b/i.test(part)) continue;
          // Reject pure role descriptions (multi-word, no capitalized
          // noun other than the role itself).
          if (new RegExp('^' + ROLE_KW + '\\b', 'i').test(part)) continue;
          m = [null, part];
          break;
        }
      }
    }

    if (!m) return '';

    // Cut at the first separator that typically begins a new headline clause.
    let co = m[1].split(/\s*[|·—–]\s*/)[0].trim();
    // Drop a trailing employment-type suffix if present ("Replit · Full-time").
    co = co.split(/\s+·\s+/)[0].trim();

    // Strip past-company markers. Headlines often chain current and past
    // employers separated by commas:
    //   "Co-Founder & CEO @ Reloom, Ex-JP Morgan, Nestlé"
    //   "Director at Acme, formerly Google"
    //   "VP Eng @ Foo, prev. Stripe, ex-Square"
    // The current employer is everything BEFORE the first past-marker
    // comma-segment. We split on commas, keep segments that look like
    // corporate suffixes (Inc, LLC, etc) attached to the previous part,
    // and stop at the first segment starting with a past marker.
    const segments = co.split(/,\s*/);
    const PAST_MARKER = /^(ex[-\s]|former(ly)?\s|prev(iously)?\.?\s|prior(ly)?\s)/i;
    const CORP_SUFFIX = /^(inc\.?|llc\.?|ltd\.?|corp\.?|gmbh|b\.?v\.?|s\.?a\.?|s\.?r\.?l\.?|pty\.?(\s+ltd\.?)?|plc|ag|co\.?(\s+ltd\.?)?)$/i;
    const kept = [segments[0]];
    for (let i = 1; i < segments.length; i++) {
      const seg = segments[i].trim();
      if (PAST_MARKER.test(seg)) break;
      if (CORP_SUFFIX.test(seg)) { kept.push(seg); continue; }
      // A bare additional segment with no marker and not a suffix is
      // ambiguous — could be "Reloom, Nestlé" (past chain without "Ex-")
      // or a multi-word company name. We err on the side of stopping
      // here because chained past employers are far more common in
      // LinkedIn headlines than commas inside a single company name.
      break;
    }
    co = kept.join(', ').trim();

    // Guard against absurdly long captures — a real company name is short.
    if (co.length > 120) return '';

    // Reject standalone corporate suffixes — "Inc.", "LLC", "Ltd",
    // "Corp", "GmbH", "B.V.", "S.A." etc. These are appendages to a real
    // name, not employers. If we extracted just a suffix, the parse
    // missed the actual company name.
    if (/^(inc\.?|llc\.?|ltd\.?|corp\.?|gmbh|b\.?v\.?|s\.?a\.?|s\.?r\.?l\.?|pty\.?(\s+ltd\.?)?|plc|ag|co\.?(\s+ltd\.?)?)$/i.test(co)) {
      return '';
    }

    // Reject academic credentials and degrees ("PhD candidate",
    // "MBA student"). These show up after a role-comma pattern like
    // "VP, PhD candidate".
    if (/^(phd|md|mba|cpa|jd|esq|ms|ma|bs|ba|cfa|pmp)\b/i.test(co)) return '';

    // Reject location-like captures ("San Francisco Bay Area",
    // "Greater London", "Pacific Northwest"). These show up after
    // "Director, <location>" patterns.
    if (/\b(area|region|city|metro|county|district|valley|coast|northwest|northeast|southwest|southeast)\b/i.test(co)) {
      return '';
    }

    // Reject fields of study / academic subjects when matched by the
    // pipe pattern ("Master of Science | Computer Science").
    if (/^(computer science|data science|business administration|electrical engineering|mechanical engineering|civil engineering|chemical engineering|software engineering|information systems|public health|public policy|fine arts|liberal arts|finance|economics|mathematics|physics|chemistry|biology|psychology|sociology|history|philosophy|literature|linguistics|education|law|medicine|nursing|architecture)$/i.test(co)) {
      return '';
    }

    return co;
  }

  // Read the current employer from the topcard "company chip" — the small
  // card next to the profile name showing the company logo and name, with
  // an <a href="/company/<slug>/"> wrapping it. LinkedIn renders this on
  // most profiles where the person has a current employer with a LinkedIn
  // page, regardless of how their headline is written. Unlike the
  // headline-parse and experience-derived fallbacks, this anchor is
  // always visible at page load (no scroll-loading), making it the most
  // reliable company source when present.
  //
  // The challenge is picking the RIGHT /company/ link — the profile page
  // also contains many unrelated /company/ links (sidebar "More profiles
  // for you", "Pages you might like", ads, etc). The reliable signal is
  // PROXIMITY TO THE PROFILE NAME H1: the topcard chip sits in the same
  // DOM section as the name. We find the section containing the name,
  // then take the first /company/ link inside it (excluding any nested
  // experience section just in case).
  // Read the current employer from the topcard "company chip" — the small
  // card next to the profile name showing the company logo and name, with
  // an <a href="/company/<slug>/"> wrapping it. LinkedIn renders this on
  // most profiles where the person has a current employer with a LinkedIn
  // page, regardless of how their headline is written. Unlike the
  // headline-parse and experience-derived fallbacks, this anchor is
  // always visible at page load (no scroll-loading), making it the most
  // reliable company source when present.
  //
  // The challenge is picking the RIGHT /company/ link — the profile page
  // also contains many unrelated /company/ links (sidebar "More profiles
  // for you", "Pages you might like", ads, etc). The reliable signal is
  // PROXIMITY TO THE PROFILE NAME ELEMENT: the topcard chip sits in the
  // same DOM section as the name. We find the element holding the name,
  // walk up to its enclosing <section>, then take the /company/ link
  // closest to the name within that section.
  //
  // We DO NOT assume <h1> — LinkedIn's current layout renders the
  // profile name in <h2> on many profiles (e.g. Mason Jappa's profile
  // has no <h1> at all). Anchoring on the name TEXT directly is more
  // durable than chasing heading-tag changes.
  // Find the topcard region using multiple anchor strategies, in order of
  // reliability. Returns the smallest container that's clearly "the topcard"
  // (contains the profile photo + name + headline area), or null.
  //
  // Why multiple strategies: LinkedIn frequently changes both the topcard's
  // wrapper element (section vs div, classed vs componentkey) and the markers
  // we'd anchor on. As of mid-2026 the most reliable anchors are:
  //   1. `section[componentkey*="Topcard"]` — the SDUI marker
  //   2. The profile photo img/button with alt/aria-label containing the name
  //   3. The self-link `<a href="/in/<slug>/">` back to the rep's own URL
  //   4. The "Contact info" link (older layouts)
  // Each is tried; whichever matches first wins.
  function findTopcardRegion(name) {
    const main = document.querySelector('main') || document.body;

    // Strategy 1: SDUI componentkey marker.
    const sduiTopcard = main.querySelector('section[componentkey*="Topcard"]');
    if (sduiTopcard) return sduiTopcard;

    // Strategy 2: profile photo. The photo's alt or aria-label includes
    // the profile name. Walk up to the nearest section/div wrapper.
    if (name) {
      const photoSelectors = [
        `img[alt*="${cssEscape(name)}"]`,
        `button[aria-label*="${cssEscape(name)}"]`,
      ];
      for (const sel of photoSelectors) {
        try {
          const photo = main.querySelector(sel);
          if (photo) {
            const region = photo.closest('section') ||
                           photo.closest('div[class*="topcard" i]') ||
                           photo.closest('div[class]');
            if (region) return region;
          }
        } catch (_) { /* invalid selector — skip */ }
      }
    }

    // Strategy 3: self-link back to the rep's own /in/<slug>/ URL.
    const selfUrlMatch = location.pathname.match(/^\/in\/([^/?#]+)/);
    if (selfUrlMatch) {
      const slug = selfUrlMatch[1];
      const selfLink = main.querySelector(`a[href*="/in/${cssEscape(slug)}/"]`);
      if (selfLink) {
        const region = selfLink.closest('section') ||
                       selfLink.closest('div[class*="topcard" i]') ||
                       selfLink.closest('div[class]');
        if (region) return region;
      }
    }

    // Strategy 4: Contact info link (older layouts).
    const contactInfo = main.querySelector('a[href*="contact-info"], a[href*="/overlay/contact-info"]');
    if (contactInfo) {
      const region = contactInfo.closest('section') ||
                     contactInfo.closest('div[class]');
      if (region) return region;
    }

    return null;
  }

  // Minimal CSS-escape so we can build attribute selectors with arbitrary
  // strings safely. Native CSS.escape() escapes too aggressively for our
  // attribute-contains usage; this targets only the chars that break
  // selector parsing.
  function cssEscape(s) {
    return String(s || '').replace(/(["\\\]])/g, '\\$1');
  }

  function companyFromTopcardChip(name) {
    try {
      if (!name) return '';

      // 1. Find the primary topcard region (usually the name/headline side).
      const primary = findTopcardRegion(name);
      if (!primary) return '';

      // 2. Build the search scope: the primary region PLUS related
      //    topcard sections. As of late-2026, LinkedIn nests each topcard
      //    piece three levels deep:
      //
      //      <main>
      //        <div>                                ← topcard container
      //          <div class="_79a19588 ...">        ← grandparent (multiple children)
      //            <div class="_00f10b4e">          ← wrapper per piece
      //              <div class="_378672f6">        ← inner wrapper
      //                <section class="_1299a412">  ← primary (name side)
      //            <div class="_00f10b4e">          ← wrapper per piece
      //              <div>
      //                <section class="e4ac1c60">   ← chip row (Blockware)
      //            … 10 more sibling wrappers …
      //        … rest of profile (About, Experience…)
      //
      //    Strategy: walk up from primary until we find an ancestor with
      //    multiple children, then collect ALL its descendant <section>
      //    elements (the topcard pieces live at varying depths under
      //    those child wrappers). Cap depth at 4 ancestors and at 12
      //    sections to keep the search bounded.
      //
      //    Filter out sections whose own h2/h3 reads Experience/Education/
      //    About/Activity — those are full profile sections, not topcard
      //    pieces, and will sneak in if we walk too high.
      const scope = new Set([primary]);
      let ancestor = primary.parentElement;
      // Names of full profile sections (any locale-agnostic English variant).
      // Any section whose first significant heading matches one of these is
      // a profile section, not a topcard piece.
      const PROFILE_SECTION_NAMES = /^(experience|education|about|activity|featured|skills|recommendations|interests|languages|certifications|licenses\s*&?\s*certifications|honors|honors\s*&?\s*awards|publications|projects|courses|volunteering|volunteer\s*experience|services|organizations|test\s*scores|patents|posts|articles)$/i;

      // Helper: does this section have a heading marking it as a full
      // profile section? Searches up to 6 levels deep — LinkedIn nests
      // section headings inside multiple wrapper divs.
      const isProfileSection = (sec) => {
        // Look for any h2 or h3 inside the section's first ~6 levels.
        const headings = sec.querySelectorAll('h2, h3');
        for (const h of headings) {
          // Count ancestor depth between h and sec.
          let depth = 0, n = h.parentElement;
          while (n && n !== sec && depth < 6) { n = n.parentElement; depth++; }
          if (n !== sec) continue; // h is not a descendant within 6 levels
          const text = (h.innerText || '').trim();
          // Take the first line if heading has nested "see all" links etc.
          const firstLine = text.split('\n')[0].trim();
          if (PROFILE_SECTION_NAMES.test(firstLine)) return true;
        }
        return false;
      };

      for (let depth = 0; depth < 4 && ancestor && ancestor.tagName !== 'MAIN' && ancestor.tagName !== 'BODY'; depth++) {
        if (ancestor.children.length > 1) {
          // Found a level with multiple children — this is the topcard
          // container OR a wider profile-content container. Collect all
          // descendant sections, filter out profile sections by heading.
          const sections = ancestor.querySelectorAll('section');
          let added = 0;
          for (const sec of sections) {
            if (added >= 12) break;
            if (isProfileSection(sec)) continue;
            scope.add(sec);
            added++;
          }
          break;
        }
        ancestor = ancestor.parentElement;
      }

      // 3. Find the name element across the scope (used for distance
      //    ranking when multiple chips match).
      let nameEl = null;
      for (const region of scope) {
        const cands = region.querySelectorAll('h1, h2, h3, span, strong, p');
        for (const el of cands) {
          const ownText = [...el.childNodes]
            .filter(n => n.nodeType === Node.TEXT_NODE)
            .map(n => n.textContent).join('').trim();
          if (ownText === name) { nameEl = el; break; }
        }
        if (nameEl) break;
      }

      const isValidChipLink = (a) => {
        const href = a.getAttribute('href') || '';
        if (!href.includes('/company/')) return false;

        // Exclude links inside Experience / Education / any full profile
        // section. Uses isProfileSection() which scans nested headings —
        // LinkedIn nests section headings several wrappers deep, so a
        // shallow check would miss them and leak Experience company links.
        const enclosingSection = a.closest('section');
        if (enclosingSection && isProfileSection(enclosingSection)) return false;

        const text = (a.innerText || '').trim();
        if (!text || text.length > 120) return false;
        if (/^(see all|show all|view|mutual)/i.test(text)) return false;
        if (/\/company\/(setup|admin|new)\b/i.test(href)) return false;
        // Reject /posts/, /jobs/, /people/ suffixed company links — those
        // are deep-links from recommendation cards or "More profiles for
        // you" sidebar, not topcard chip links which point to bare
        // /company/<slug>/ or /company/<slug> URLs.
        if (/\/company\/[^/]+\/(posts|jobs|people|life|about|insights)\b/i.test(href)) return false;
        return true;
      };

      // Topcard chip detector: a chip link sits inside a UL row of
      // similar bare-link LIs. The row typically has 2-6 chips (current
      // company + 1-3 education/affiliation entries). LIs in this row
      // contain little besides the link itself — no profile photo IMG,
      // no headline P, no follow Button.
      //
      // Discriminator vs "More profiles for you" sidebar list (which
      // also uses UL>LI>A[href*=/company/]): sidebar LIs contain a
      // profile IMG, a name heading, a headline, and a follow button.
      // Topcard chip LIs are bare links with maybe a small inline logo.
      const isInsideChipRow = (a) => {
        const li = a.closest('li');
        if (!li) return false;
        const ul = li.parentElement;
        if (!ul || ul.tagName !== 'UL') return false;

        // The LI itself should be lightweight — no nested follow button,
        // no nested headline text. Heuristic: the LI's text content
        // should be roughly the link's text (allowing for a small logo
        // alt-text or single secondary line like "School").
        const liText = (li.innerText || '').trim();
        const aText = (a.innerText || '').trim();
        // Allow LI text to be up to 2x link text + some slack — chip
        // rows often include the school/company name plus a short
        // secondary line ("School", "Company").
        if (liText.length > aText.length * 3 + 30) return false;

        // No follow/connect buttons inside this LI = it's a chip, not a
        // recommendation card.
        if (li.querySelector('button')) return false;

        // Sibling LIs in the same UL should mostly also be chip-shaped
        // (similar size). If most siblings are giant cards, this UL is
        // a card list, not a chip row.
        const siblings = [...ul.children].filter(el => el.tagName === 'LI');
        if (siblings.length === 0) return false;
        const smallSiblings = siblings.filter(s => (s.innerText || '').length < 200);
        // Chip rows: most LIs are short. Card lists: most LIs are long.
        if (smallSiblings.length / siblings.length < 0.6) return false;

        return true;
      };

      // 4. Collect valid chip links from every region in scope, dedup'd.
      //    Two passes: first prefer links inside a chip-row UL, then
      //    fall back to any valid link if no chip-row link is found.
      let validLinks = [];
      const allCandidates = [];
      for (const region of scope) {
        const links = [...region.querySelectorAll('a[href*="/company/"]')]
          .filter(isValidChipLink);
        for (const l of links) {
          if (!allCandidates.includes(l)) allCandidates.push(l);
        }
      }
      // Pass 1: chip-row only.
      validLinks = allCandidates.filter(isInsideChipRow);
      // Pass 2: if no chip-row links found, fall back to all valid links.
      if (validLinks.length === 0) validLinks = allCandidates;

      // 5. Final fallback: walk up from the name element looking for
      //    chips at progressively wider scopes. This handles future
      //    DOM shapes where the chip isn't in a sibling section either.
      if (validLinks.length === 0 && nameEl) {
        let s = nameEl.parentElement;
        for (let i = 0; i < 8 && s && s !== document.body; i++) {
          const links = [...s.querySelectorAll('a[href*="/company/"]')]
            .filter(isValidChipLink);
          if (links.length > 0) {
            links.forEach(l => validLinks.push(l));
            break;
          }
          s = s.parentElement;
        }
      }

      if (validLinks.length === 0) return '';
      if (validLinks.length === 1) return (validLinks[0].innerText || '').trim();

      // Multiple chips found. Rank by DOM position relative to primary:
      // chips inside primary or in sections immediately adjacent to primary
      // win over chips further down the page. This protects against
      // Experience-section company links leaking through the heading
      // filter on profiles with unusual headings.
      //
      // Ranking key (lower = better):
      //   0: link is inside primary itself
      //   1: link is inside a section whose closest('section') parent
      //      chain reaches the primary's grandparent (a topcard cousin)
      //   2+: distance in document order from primary (Math.abs index diff)
      const allDocSections = [...document.querySelectorAll('section')];
      const primaryIdx = allDocSections.indexOf(primary);

      const positionScore = (a) => {
        if (primary.contains(a)) return 0;
        const linkSection = a.closest('section');
        if (!linkSection) return 1000;
        const linkIdx = allDocSections.indexOf(linkSection);
        if (linkIdx < 0) return 1000;
        // Distance in section-document-order from primary. Closer = better.
        return Math.abs(linkIdx - primaryIdx);
      };

      validLinks.sort((a, b) => positionScore(a) - positionScore(b));
      return (validLinks[0].innerText || '').trim();
    } catch (_) {
      return '';
    }
  }

  function extractProfileInfo() {
    const linkedinUrl = getCurrentLinkedInUrl();

    // Name is stable: document.title is always "Full Name | LinkedIn"
    const name = (document.title || '').split(' | ')[0].trim();

    // Try new SDUI layout first, fall back to old classed-HTML layout.
    let info;
    const sdui = extractFromSduiLayout(name);
    if (sdui && (sdui.title || sdui.company || sdui.location)) {
      info = { name, ...sdui, linkedinUrl };
    } else {
      const legacy = extractFromLegacyLayout(name);
      info = { name, ...legacy, linkedinUrl };
    }

    // Company fallback chain. The top-card extractors only find `company`
    // when LinkedIn renders a *separate* company line in the topcard — many
    // profiles don't (the employer lives only inside the headline, or in
    // a logo-card chip next to the name). When that happens `company` is
    // empty even though the page clearly shows it.
    //
    //   Fallback 1: parse it out of the headline ("Founder at Acme",
    //               "CTO @ Replit | ...", "Founder of Blockware"). This
    //               is fast, deterministic, and works on the ~70% of
    //               profiles where the headline encodes the employer.
    //               Promoted to first slot because LinkedIn now sometimes
    //               renders the topcard company chip inside a closed
    //               shadow root that content scripts cannot reach
    //               (observed Nov 2026 on /in/masonjappa/), making
    //               DOM-based chip extraction unreliable as a primary.
    //   Fallback 2: the topcard COMPANY CHIP — a small card next to the
    //               profile name with an <a href="/company/<slug>/">
    //               wrapping it. Works when the chip is in light DOM.
    //   Fallback 3: the current experience entry — authoritative when
    //               available but requires the Experience section to have
    //               loaded into the DOM.
    if (!info.company || !info.company.trim()) {
      const fromHeadline = companyFromHeadline(info.title);
      if (fromHeadline) {
        info.company = fromHeadline;
      } else {
        const fromTopcardChip = companyFromTopcardChip(name);
        if (fromTopcardChip) {
          info.company = fromTopcardChip;
        } else {
          try {
            const exp = getExperience();
            const isCurrent = (e) => {
              const ed = e?.end_date;
              if (ed == null) return true;
              const s = String(ed).trim().toLowerCase();
              return s === '' || s === 'present';
            };
            const current = exp.find(isCurrent) || exp[0];
            if (current?.company) info.company = current.company;
          } catch (_) { /* experience not available — leave company empty */ }
        }
      }
    }

    return info;
  }

  function extractFromSduiLayout(name) {
    // Primary: the SDUI componentkey marker. When LinkedIn renames or
    // drops the componentkey (which happens periodically), fall back to
    // the same robust topcard-region finder used by the chip extractor.
    // Without this fallback, an SDUI marker change silently empties the
    // headline/company/location across all profiles.
    let topCard = document.querySelector('section[componentkey*="Topcard"]');
    if (!topCard) topCard = findTopcardRegion(name);
    if (!topCard) return null;

    // Read the topcard's <p> elements in DOM order. The new SDUI layout puts
    // each profile field in its own <p>, in this rough order:
    //   1. Name (already known)
    //   2. Verification badge ("•")
    //   3. Connection degree badge ("· 2nd")
    //   4. Headline (e.g. "Founder at glByte, Inc")
    //   5. Company name (e.g. "glByte, Inc") — only on some profiles
    //   6. Location (e.g. "San Francisco Bay Area")
    //   7. "Contact info" (link)
    //   8. "X connections" / "X followers"
    //   9. Mutual connections, etc.
    //
    // We work in DOM order rather than guessing by content shape, because
    // headlines like "Founder at glByte, Inc" contain commas (so the old
    // "first line with a comma is location" heuristic mis-fired).
    // Only consider <p> elements that are actually rendered. LinkedIn ships
    // hidden duplicate topcards (responsive variants — e.g. a desktop layout
    // and a collapsed mobile layout in the same DOM) whose text otherwise
    // pollutes our DOM-order walk. A hidden "· 1st" or hidden
    // "<company> · <school>" row would otherwise be picked as the headline.
    const isVisible = (el) => {
      if (!el || el.offsetParent === null) return false;
      const r = el.getBoundingClientRect();
      return r.width > 0 && r.height > 0;
    };

    const ps = [...topCard.querySelectorAll('p')]
      .filter(isVisible)
      .map(p => (p.innerText || '').trim())
      .filter(Boolean);

    // Filter out junk elements that aren't profile data.
    const isJunk = s =>
      s === '·' || s === '•' ||
      /^·\s*(1st|2nd|3rd)$/i.test(s) ||           // degree badge
      /^(Contact info)$/i.test(s) ||
      /^\d[\d,]*\+?\s*(connections?|followers?|following)$/i.test(s) ||
      /\bmutual connections?\b/i.test(s) ||
      /^(Connect|Message|Follow|More|Save in Sales Navigator|Visit my website|Visit my)$/i.test(s) ||
      // Pronoun badge — LinkedIn renders "She/Her", "He/Him", "They/Them",
      // "Ze/Zir", and the more verbose "(He/Him)" form. These appear as their
      // own <p> in the topcard and were getting selected as the headline.
      /^\(?(she|he|they|ze|xe|ey|hir)\s*\/\s*(her|him|them|zir|xem|em|hirs)\)?$/i.test(s) ||
      // "Open to work" / "Hiring" badges
      /^(open to work|#opentowork|hiring)$/i.test(s) ||
      s === name;

    const clean = ps.filter(s => !isJunk(s));

    // Location detector — applied to short lines only. Recognises common
    // geo shapes; a line like "Founder at glByte, Inc" is rejected because
    // it contains the word "at" or has a corporate suffix.
    // (Defined at module scope below as `looksLikeLocation` so capture
    // functions can share it.)

    // Find location: prefer the last short line that looks geographic.
    // Walking backwards through `clean` works because location appears
    // late in the topcard, right before "Contact info" / connection counts
    // (which we've already filtered out).
    //
    // Some topcard layouts join the location with "Contact info" into a
    // single <p>: "New York, New York, United States · Contact info".
    // Splitting on " · " before testing handles that case.
    let location = '';
    for (let i = clean.length - 1; i >= 0; i--) {
      const line = clean[i];
      if (looksLikeLocation(line)) { location = line; break; }
      // Split-on-bullet fallback for joined "<location> · Contact info" rows.
      const parts = line.split(/\s+·\s+/).map(p => p.trim()).filter(Boolean);
      if (parts.length > 1) {
        const match = parts.find(looksLikeLocation);
        if (match) { location = match; break; }
      }
    }

    // Headline = first non-junk line that isn't the location.
    const title = clean.find(s => s !== location) || '';

    // Company = anything between headline and location that's short and
    // doesn't itself look like a location. On profiles where LinkedIn doesn't
    // surface a separate company line, this remains empty.
    const titleIdx = clean.indexOf(title);
    const locIdx   = location ? clean.indexOf(location) : clean.length;
    let company = '';
    for (let i = titleIdx + 1; i < locIdx; i++) {
      const s = clean[i];
      if (s.length > 200) continue;
      if (looksLikeLocation(s)) continue;
      // Strip employment-type suffix ("Acme · Full-time")
      company = s.split(/\s+·\s+/)[0].trim();
      break;
    }

    // Connection degree badge — look for "· 1st" / "· 2nd" / "· 3rd".
    const degreePs = [...topCard.querySelectorAll('p')]
      .filter(p => /·\s*(1st|2nd|3rd)/i.test(p.innerText || ''));
    const visibleDegreeP = degreePs.find(p => {
      if (p.offsetParent === null) return false;
      const r = p.getBoundingClientRect();
      return r.width > 0 && r.height > 0;
    }) || degreePs[0];
    const degreeMatch = visibleDegreeP?.innerText?.match(/·\s*([123])(st|nd|rd)/i);
    const degree = degreeMatch?.[1] || null;

    return { title, company, location, degree };
  }

  function extractFromLegacyLayout(name) {
    let title = '';
    let company = '';
    let location = '';

    const junk = ['save in sales navigator', 'connect', 'message', 'follow', 'more', 'more...'];

    const topCard = [...document.querySelectorAll('div')].find(d =>
      d.className?.includes('_23131edd') && d.textContent?.includes(name)
    );
    if (topCard) {
      const leaves = [...topCard.querySelectorAll('*')]
        .filter(el => el.children.length === 0)
        .map(el => el.textContent?.trim())
        .filter(t => t && t.length > 2)
        .filter((t, i, arr) => arr.indexOf(t) === i);

      title    = leaves[1] || '';
      company  = leaves[2] || '';
      location = leaves[3] || '';

      if (junk.includes(company.toLowerCase()))  company  = '';
      if (junk.includes(location.toLowerCase())) location = '';
    }

    if (!location) {
      const locEl = [...document.querySelectorAll('span, div, p')]
        .filter(el => el.children.length === 0)
        .find(el => {
          const t = el.textContent?.trim();
          return t && /metropolitan area|greater .+ area|, [A-Z][A-Z]$| area$|india|united states|telangana|hyderabad/i.test(t) && t.length < 80;
        });
      location = locEl?.textContent?.trim() || '';
    }

    const nameSpan = [...document.querySelectorAll('span[aria-hidden="true"]')]
      .find(s => s.textContent?.includes(name) && s.textContent?.includes('•'));
    const degreeMatch = nameSpan?.textContent?.match(/•\s*([123])(st|nd|rd)/);
    const degree = degreeMatch?.[1] || null;

    return { title, company, location, degree };
  }

  // ── NEW in v1.2: full-profile extraction ─────────────────────────────────────
  //
  // Best-effort scrapers for the About / Experience / Education / Activity
  // sections of the profile page the rep is currently viewing. LinkedIn's
  // markup is unstable across A/B tests and locales — every selector here is
  // tolerant: each function returns null/[] cleanly when it can't find data.
  //
  // What this captures depends on what the rep has scrolled into view and
  // expanded. We do NOT try to navigate to /detail/recent-activity/ pages
  // automatically — that's a content-script no-go (cross-origin nav, anti-bot).
  // The rep's flow is: scroll the page once, then click "Capture profile".

  // ── Module-scoped helpers ─────────────────────────────────────────────────
  //
  // Heuristic: does this line look like a geographic location?
  //
  // Used by both extractFromSduiLayout (top-card location) and
  // captureExperience (per-job location). Rejects corporate suffixes, "at"
  // and "of" (which appear in headlines like "Founder at glByte, Inc"),
  // and accepts common geo shapes: "X Area", "Metropolitan", "City, Region",
  // ", Country", or a single capitalized place name.
  function looksLikeLocation(s) {
    if (!s || s.length > 80) return false;
    if (/\b(Inc|LLC|Ltd|Corp|Corporation|Pvt|Limited|GmbH|Co\.)\b/i.test(s)) return false;
    if (/\b(at|of|for)\b/i.test(s)) return false;

    // Strong signal: an "Area" or "Metropolitan" mention, or "Greater <City>".
    if (/\barea\b|metropolitan|greater\s/i.test(s)) return true;

    // "City, Region" or "City, Region, Country" — at least one comma + matching
    // capitalisation pattern. This is the most reliable shape for LinkedIn
    // locations.
    if (/^[A-Z][\w.\s'-]+(,\s*[A-Z][\w.\s'-]+){1,2}$/.test(s)) return true;

    // Anchored country/state suffixes — covers "Berlin, Germany",
    // "Mumbai, MH", "Dallas, TX, USA". Useful when leading char isn't capital
    // (e.g. "iPhone, India" — rare but it happens).
    if (/,\s*(India|United States|USA|UK|United Kingdom|Canada|Australia|Germany|France|Singapore|UAE|Ireland|Netherlands|Spain|Italy|Brazil|Mexico|Japan|China|[A-Z]{2})$/.test(s)) return true;

    // Bare country / large-region names — LinkedIn now emits the location as
    // just the country on profiles where the person hasn't set a city.
    // Without this rule, "United States" on Michael Pierce's profile fell
    // through and got captured as the company. The list is restricted to
    // unambiguous country/sovereign names — "Georgia" is excluded because
    // it could be a US state or first name; "Jordan" likewise. Multi-word
    // entries and unambiguous one-word countries only.
    if (/^(United States|United Kingdom|United Arab Emirates|Saudi Arabia|South Africa|South Korea|North Korea|New Zealand|Sri Lanka|Hong Kong|Czech Republic|Dominican Republic|Costa Rica|Puerto Rico|El Salvador|India|Canada|Australia|Germany|France|Singapore|Ireland|Netherlands|Spain|Italy|Brazil|Mexico|Japan|China|Russia|Sweden|Norway|Finland|Denmark|Belgium|Poland|Portugal|Greece|Turkey|Egypt|Kenya|Nigeria|Argentina|Chile|Colombia|Peru|Vietnam|Thailand|Indonesia|Philippines|Malaysia|Pakistan|Bangladesh|Israel|Switzerland|Austria|Romania|Ukraine|Hungary)$/i.test(s)) return true;

    // Note: we deliberately do NOT have a single-capitalised-word fallback
    // here. Single words like "Clay" (a company), "Sphoorthy" (a school)
    // would slip through and get picked as locations. LinkedIn nearly always
    // emits multi-part locations; missing the rare single-word case
    // ("Hyderabad" alone) is a smaller cost than misclassifying companies.
    return false;
  }

  // Find a top-level <section> by heading text (works on both layouts).
  function findSectionByHeading(headingPatterns) {
    // Collect ALL sections whose first heading matches one of the
    // requested patterns. When LinkedIn nests a profile-content wrapper
    // section that itself contains the focused section, both will match —
    // we want the innermost (smallest) one. Picking the first match in
    // document order silently chose the giant wrapper on profiles with
    // this shape, breaking extractors that depend on a tightly-scoped
    // section (notably captureEducation, which fell over when handed a
    // 14k-char wrapper containing Education plus multiple unrelated
    // sections).
    const sections = document.querySelectorAll('section, div[componentkey*="Section"]');
    const matches = [];
    for (const sec of sections) {
      const hh = sec.querySelector('h2, h3, [role="heading"]');
      const text = (hh?.innerText || '').trim();
      if (!text) continue;
      for (const re of headingPatterns) {
        if (re.test(text)) { matches.push(sec); break; }
      }
    }
    if (matches.length === 0) return null;
    if (matches.length === 1) return matches[0];

    // Prefer the smallest matching section by innerText length. The
    // innermost (focused) section is always smaller than any wrapper
    // ancestor that contains it. Tiebreak on document order.
    matches.sort((a, b) => {
      const aLen = (a.innerText || '').length;
      const bLen = (b.innerText || '').length;
      return aLen - bLen;
    });
    return matches[0];
  }

  function captureAboutText() {
    // "About" section. Headings vary: "About", "About me".
    const sec = findSectionByHeading([/^about\b/i]);
    if (!sec) return null;

    // The About text is usually inside the first long <p> or <span>
    // (post-collapse, "see more" must have been clicked for full text).
    const candidates = [...sec.querySelectorAll('span[aria-hidden="true"], p, div')]
      .map(el => el.innerText?.trim())
      .filter(t => t && t.length > 60 && !/^see (more|less)$/i.test(t));

    // Take the longest candidate (the About text itself, not surrounding chrome)
    candidates.sort((a, b) => b.length - a.length);
    let text = candidates[0] || null;

    // Strip trailing truncation markers that LinkedIn appends inline:
    //   "...full text...\n\n… more"
    //   "...full text… more"
    if (text) {
      text = text
        .replace(/\s*…\s*more\s*$/i, '')
        .replace(/\s*\.\.\.\s*more\s*$/i, '')
        .replace(/\s*see more\s*$/i, '')
        .trim();
    }
    return text;
  }

  // Read the text "lines" of a profile-section item, in DOM order.
  // The new SDUI layout puts each line in its own <p>; older layouts used
  // <span aria-hidden="true">. We try both and dedupe.
  function readItemLines(item) {
    // 1) New SDUI: <p> tags directly inside the item.
    let lines = [...item.querySelectorAll('p')]
      .map(el => (el.innerText || '').trim())
      .filter(Boolean);

    // 2) Legacy: <span aria-hidden="true">. Only fall back if we didn't
    //    find <p> lines, otherwise we'd duplicate everything.
    if (lines.length === 0) {
      lines = [...item.querySelectorAll('span[aria-hidden="true"]')]
        .map(el => (el.innerText || '').trim())
        .filter(Boolean);
    }

    // Strip "…" and "more" truncation markers (they appear as separate <p>s
    // on collapsed long descriptions in SDUI).
    lines = lines
      .filter(l => l !== '…' && l !== 'more' && l !== '... more' && l !== '…more')
      .filter(l => l.length < 4000)
      .filter((t, i, arr) => arr.indexOf(t) === i);   // dedupe contiguous repeats

    return lines;
  }

  // ── Experience: per-position record builder ───────────────────────────────
  //
  // Shared by the standalone-role path and the grouped-company sub-role path.
  // `opts.companyOverride` / `opts.companyUrlOverride` are supplied by the
  // grouped path (company lives on the container, not the sub-role item);
  // when absent, company is inferred from the item's own lines (legacy/standalone
  // behaviour, unchanged).
  function companyUrlFromExpItem(item) {
    const a = item.querySelector('a[href*="/company/"]');
    if (!a) return null;
    const href = a.getAttribute('href') || a.href || '';
    const m = href.match(/\/company\/([A-Za-z0-9._-]+)/);
    if (!m) return null;
    const slug = m[1].toLowerCase();
    if (slug === 'setup' || slug === 'new' || slug === 'admin') return null;
    return `https://www.linkedin.com/company/${slug}`;
  }

  function buildExpRecord(item, lines, opts) {
    opts = opts || {};
    if (!lines || lines.length < 2) return null;

    const title = lines[0] || null;

    // Date line: "Feb 2019 - Present", "Jul 2018 - Feb 2020", optionally
    // followed by " · 2 yrs 3 mos".
    const isDateLine = l =>
      /\b(19|20)\d{2}\b/.test(l) && /\s[-–]\s|to/i.test(l);
    const dateLineIdx = lines.findIndex(isDateLine);
    const dateLine    = dateLineIdx >= 0 ? lines[dateLineIdx] : null;
    const { startDate, endDate, durationMonths } = parseDateRange(dateLine);

    // Company. Grouped sub-roles get it from the container (override). If the
    // override accidentally duplicates the role title (header extraction picked
    // up a role line rather than the company name), drop it and infer instead.
    let company = opts.companyOverride || null;
    if (company && title && company.trim() === title.trim()) company = null;

    let companyLine = null;
    if (!company) {
      // Standalone inference: company is the line between title and date.
      if (dateLineIdx > 1) {
        companyLine = lines[1];
      } else if (dateLineIdx === 1) {
        companyLine = null;   // company rolled into title (self-employment)
      } else if (dateLineIdx < 0) {
        companyLine = lines[1] && lines[1].length < 120 ? lines[1] : null;
      }
      company = companyLine ? companyLine.split(/\s+·\s+/)[0].trim() : null;
    }

    // Location: line right after the date line, geographic-shaped. May be
    // joined with a job-mode suffix ("Bengaluru, Karnataka, India · On-site").
    let location = null;
    if (dateLineIdx >= 0 && lines[dateLineIdx + 1]) {
      const candidate = lines[dateLineIdx + 1];
      if (looksLikeLocation(candidate)) {
        location = candidate;
      } else {
        const parts = candidate.split(/\s+·\s+/).map(p => p.trim()).filter(Boolean);
        const geoPart = parts.find(looksLikeLocation);
        if (geoPart) location = geoPart;
      }
    }

    // Description: longest remaining line after excluding the structural lines.
    // Exclude associated-company "Pages card" taglines, which LinkedIn renders
    // inside a role and which carry the " | " marketing-pipe signature
    // ("DataBank | Simplified Business Process Solutions"). Those are not the
    // person's role description and must never be stored as one.
    const used = new Set([title, companyLine, dateLine, location].filter(Boolean));
    const description = lines
      .filter(l => !used.has(l) && l.length > 60 && !l.includes(' | '))
      .sort((a, b) => b.length - a.length)[0] || null;

    const companyUrl = opts.companyUrlOverride || companyUrlFromExpItem(item);

    return {
      title,
      company,
      company_linkedin_url: companyUrl,
      location,
      start_date:      startDate,
      end_date:        endDate,
      duration_months: durationMonths,
      description,
    };
  }

  function captureExperience() {
    const SEL = '[componentkey^="entity-collection-item-"]';
    const sec = findSectionByHeading([/^experience$/i]);
    if (!sec) return [];

    let rawItems = [...sec.querySelectorAll(SEL)];
    const usingSdui = rawItems.length > 0;

    // ── Legacy layout ────────────────────────────────────────────────────────
    // Older artdeco/data-view markup never grouped multi-role companies the
    // way SDUI does, so keep the original outermost-wins behaviour verbatim.
    if (!usingSdui) {
      rawItems = [...sec.querySelectorAll(
        'li.artdeco-list__item, li[data-test="experience-item"], div[data-view-name="profile-component-entity"]'
      )];
      const filtered = [];
      rawItems.forEach(it => {
        const txt = (it.innerText || '').trim();
        if (txt.length < 10) return;
        if (filtered.some(prev => prev.contains(it))) return;   // skip nested dup
        filtered.push(it);
      });
      return filtered
        .map(it => buildExpRecord(it, readItemLines(it), {}))
        .filter(Boolean);
    }

    // ── SDUI layout — grouped multi-role companies ────────────────────────────
    // A multi-role company is ONE entity-collection-item whose roles are plain
    // <li>s inside a <ul> (NOT nested entity-collection-items — those don't
    // exist here; the only nested [componentkey] nodes are associated-company
    // "Pages cards"). So we detect a grouped company by finding >=2 date-bearing
    // role <li>s, read the company name/location from the header <p>s that sit
    // outside every role <li>, and emit one record per role with the company
    // carried down. Items with <2 date <li>s are standalone single roles and go
    // through the original whole-item path unchanged.

    // Collapse the inner-<a>-shares-parent-<div>'s-key duplicate: keep the
    // outermost node per componentkey.
    const keyOf = n => n.getAttribute('componentkey') || '';
    const topItems = rawItems.filter(it => {
      if ((it.innerText || '').trim().length < 2) return false;
      const k = keyOf(it);
      return !rawItems.some(o => o !== it && keyOf(o) === k && o.contains(it));
    });

    const hasDateStr = s => /\b(19|20)\d{2}\b/.test(s) && /\s[-–]\s|to/i.test(s);
    const hasDateTxt = el => hasDateStr(el.innerText || '');
    const isEmploymentType = l =>
      /^\s*(?:full-?time|part-?time|self-?employed|contract|internship|freelance|seasonal|apprenticeship|permanent)\b/i.test(l);
    const isTenureOnly = l =>
      /^\s*(?:·\s*)?\d+\s*(?:yrs?|mos?|years?|months?)\b/i.test(l) && !/\b(19|20)\d{2}\b/.test(l);

    const out = [];

    topItems.forEach(top => {
      const lis = [...top.querySelectorAll('li')];
      // innermost date-bearing <li>s = the individual roles
      const roleLis = lis
        .filter(hasDateTxt)
        .filter(li => !lis.some(o => o !== li && hasDateTxt(o) && li.contains(o)));

      if (roleLis.length >= 2) {
        // Grouped company. Header <p>s are those outside every role <li>.
        const headerLines = [...top.querySelectorAll('p')]
          .filter(p => !roleLis.some(li => li.contains(p)))
          .map(p => (p.innerText || '').trim())
          .filter(Boolean)
          .filter((t, i, a) => a.indexOf(t) === i);

        const companyHeader = headerLines.find(l =>
          l.length > 1 && !hasDateStr(l) &&
          !isEmploymentType(l) && !isTenureOnly(l)
        ) || headerLines[0] || null;
        const companyName  = companyHeader ? companyHeader.split(/\s+·\s+/)[0].trim() : null;
        const companyUrl   = companyUrlFromExpItem(top);
        const headerLocation = headerLines.find(looksLikeLocation) || null;

        roleLis.forEach(li => {
          const rec = buildExpRecord(li, readItemLines(li), {
            companyOverride:    companyName,
            companyUrlOverride: companyUrl,
          });
          if (!rec) return;
          // Some roles list no location of their own (the company-level header
          // carried it) — fall back to the header location rather than null.
          if (!rec.location && headerLocation) rec.location = headerLocation;
          out.push(rec);
        });
      } else {
        // Standalone single role — original whole-item path.
        const rec = buildExpRecord(top, readItemLines(top), {
          companyUrlOverride: companyUrlFromExpItem(top),
        });
        if (rec) out.push(rec);
      }
    });

    return out;
  }

  // Returns experience entries, preferring the already-captured value over
  // a fresh scrape.
  //
  // Why this exists: captureExperience() reads the experience <section>,
  // but LinkedIn lazy-renders that section — it isn't in the DOM until the
  // user scrolls near it. Calling captureExperience() "cold" (e.g. from the
  // Add-prospect form while the user is scrolled up at the top card)
  // therefore returns [] even on profiles that clearly have experience.
  //
  // The capture panel doesn't have this problem because its scroll-driven
  // IntersectionObserver runs captureExperience() at the moment the section
  // IS on screen, and stores the result in captureState.experience.value.
  //
  // So: trust that stored value first. Only fall back to a live scrape if
  // the observer hasn't captured anything yet (user added the prospect
  // before ever scrolling down). This makes every consumer — the company
  // name fallback, the ADD_PROSPECT company-URL resolver, and the debug
  // __gowarmCapture hook — robust to scroll position.
  function getExperience() {
    try {
      const slot = captureState && captureState.experience;
      if (slot && Array.isArray(slot.value) && slot.value.length > 0) {
        return slot.value;
      }
    } catch (_) { /* captureState not initialised yet — fall through */ }
    // Fallback: cold scrape. Works only if the section happens to be
    // rendered; returns [] otherwise (same as before this helper existed).
    try {
      return captureExperience() || [];
    } catch (_) {
      return [];
    }
  }

  // Guarantees experience data is available before the caller needs it.
  //
  // getExperience() returns the observer-captured value when the user has
  // already scrolled past the experience section. But a user can open a
  // profile and immediately click "Add" without ever scrolling — the
  // observer never fires, captureState.experience.value stays [], and the
  // cold-scrape fallback also fails because LinkedIn hasn't lazy-rendered
  // the section yet.
  //
  // This helper closes that gap: if experience hasn't been captured, it
  // scrolls the section into view, waits briefly for LinkedIn to hydrate
  // it, runs the capture, and stores the result in captureState so every
  // consumer (and the panel) sees it. It restores the original scroll
  // position afterward so the user isn't left somewhere unexpected.
  //
  // Returns the experience array (possibly still [] if the profile
  // genuinely has no experience section — callers handle that gracefully).
  async function ensureExperienceCaptured() {
    // Already have it — nothing to do, no scroll-jump.
    const existing = getExperience();
    if (existing && existing.length > 0) return existing;

    // Find the experience section. If it isn't in the DOM yet we still
    // try scrolling — LinkedIn renders it as the viewport approaches.
    const sec = findSectionByHeading([/^experience$/i]);
    if (!sec) {
      // No section node at all — best effort scrape, may be [].
      return getExperience();
    }

    const originalScrollY = window.scrollY;
    try {
      sec.scrollIntoView({ behavior: 'instant', block: 'center' });
    } catch (_) {
      // Older engines may not accept behavior:'instant' — fall back.
      try { sec.scrollIntoView(); } catch (_) { /* ignore */ }
    }

    // Wait for LinkedIn to lazy-render the section's entries. Poll a few
    // times rather than a single fixed sleep — finishes as soon as the
    // capture succeeds, so it's usually fast.
    let captured = [];
    for (let attempt = 0; attempt < 6; attempt++) {
      await new Promise(r => setTimeout(r, 250));
      try {
        captured = captureExperience() || [];
      } catch (_) {
        captured = [];
      }
      if (captured.length > 0) break;
    }

    // Store into captureState so the panel and getExperience() agree.
    try {
      if (captureState && captureState.experience && captured.length > 0) {
        captureState.experience.value         = captured;
        captureState.experience.status        = 'captured';
        captureState.experience.lastCapturedAt = Date.now();
        if (typeof notifyCapture === 'function') notifyCapture('experience');
      }
    } catch (_) { /* state not ready — the return value still works */ }

    // Restore the user's scroll position.
    try {
      window.scrollTo({ top: originalScrollY, behavior: 'instant' });
    } catch (_) {
      try { window.scrollTo(0, originalScrollY); } catch (_) { /* ignore */ }
    }

    return captured.length > 0 ? captured : getExperience();
  }

  // ── De-truncation + progressive hydration (v1.21) ─────────────────────────
  //
  // Two DOM-completeness passes, run ONLY on an explicit capture action (never
  // by the passive observers): hydrate the whole profile so LinkedIn's lazy
  // SDUI sections render, then expand every in-section "see more" so collapsed
  // descriptions read in full. Neither touches the parsers — they only make
  // more text exist in the DOM before a normal capture runs. The recapture step
  // is strictly additive: it never adopts a scrape smaller than what's already
  // held, so it cannot regress previously captured data.

  const sleep = (ms) => new Promise(r => setTimeout(r, ms));

  const SECTION_DEFS_FOR_RECAPTURE = () => ([
    { key: 'about',      capture: captureAboutText,  isEmpty: v => !v },
    { key: 'experience', capture: captureExperience,  isEmpty: v => !v?.length },
    { key: 'education',  capture: captureEducation,   isEmpty: v => !v?.length },
    { key: 'activity',   capture: captureActivity,    isEmpty: v => !v?.length },
  ]);

  // Scroll the page top→bottom in increments so LinkedIn lazy-renders every
  // section, then restore the original scroll position. Stops early once page
  // height stops growing; bounded by maxSteps so it can't run away.
  async function scrollHydrate({ step = 0.85, settle = 220, maxSteps = 30 } = {}) {
    const originalScrollY = window.scrollY;
    const inc = Math.max(300, Math.floor(window.innerHeight * step));
    const docHeight = () => Math.max(
      document.body.scrollHeight, document.documentElement.scrollHeight);
    let lastHeight = -1, stable = 0, y = 0;
    for (let i = 0; i < maxSteps; i++) {
      y = Math.min(y + inc, docHeight());
      try { window.scrollTo({ top: y, behavior: 'instant' }); }
      catch (_) { try { window.scrollTo(0, y); } catch (_) {} }
      await sleep(settle);
      const h = docHeight();
      if (h === lastHeight) { stable++; if (stable >= 2 && y >= h - 2) break; }
      else { stable = 0; }
      lastHeight = h;
    }
    try { window.scrollTo({ top: originalScrollY, behavior: 'instant' }); }
    catch (_) { try { window.scrollTo(0, originalScrollY); } catch (_) {} }
  }

  // Is this a real in-flow "see more" text toggle — NOT a navigation link, NOT
  // "show all N experiences", NOT a social/overflow button? Tightly scoped so
  // we can never click something that navigates away (which would blow away
  // captureState) or follows/connects.
  function isSeeMoreToggle(el) {
    if (!el) return false;
    if (el.tagName === 'A' || el.getAttribute('href')) return false;   // never anchors
    const r = el.getBoundingClientRect?.();
    if (r && (r.width === 0 || r.height === 0)) return false;          // visible only
    const name = (el.innerText || el.getAttribute('aria-label') || '')
      .replace(/\s+/g, ' ').trim().toLowerCase();
    if (!name) return false;
    // Hard-exclude anything that navigates, follows, or shows "all".
    if (/\b(all|experiences?|education|activit|skills?|follow|connect|message|save|endorse|recommend|option|menu|profile)\b/.test(name)) {
      return false;
    }
    // Accept only the canonical collapse toggles.
    return /^…?\s*see more$/.test(name) || name === '…more' || name === '...more';
  }

  // Click every see-more toggle inside `root` once, expanding collapsed text.
  // Returns the count expanded. Safe no-op when there are none.
  async function expandTruncatedText(root, { maxClicks = 60 } = {}) {
    if (!root) return 0;
    let clicked = 0;
    const candidates = [...root.querySelectorAll('button, [role="button"]')];
    for (const b of candidates) {
      if (clicked >= maxClicks) break;
      if (!isSeeMoreToggle(b)) continue;
      try { b.click(); clicked++; } catch (_) { /* ignore */ }
    }
    if (clicked > 0) await sleep(220);   // let LinkedIn inject the full text
    return clicked;
  }

  // Re-run every section's capture into captureState, mirroring runCapture's
  // safety rules AND adding a strictly-additive guard: never overwrite a
  // rep-edited slot, never adopt an empty scrape over a non-empty value, and
  // never adopt a scrape that's *smaller* (fewer items / less description text /
  // shorter About) than what we already hold. So a mid-pass re-virtualization
  // can only ever be ignored — it cannot shrink captured data.
  function recaptureAllSections() {
    const sizeOf = (v) => {
      if (Array.isArray(v)) {
        // Item count dominates; description richness breaks ties so that a
        // same-count rescrape with fuller descriptions is adopted, but a
        // same-count rescrape that LOST description text is not.
        let s = v.length * 100000;
        for (const e of v) s += (e && e.description ? String(e.description).length : 0);
        return s;
      }
      return v == null ? 0 : String(v).trim().length;
    };
    SECTION_DEFS_FOR_RECAPTURE().forEach(def => {
      try {
        const slot = captureState && captureState[def.key];
        if (!slot || slot.edited) return;
        let value;
        try { value = def.capture(); } catch (_) { return; }
        if (def.isEmpty(value)) return;                 // never empty over value
        const priorSize = sizeOf(slot.value);
        if (priorSize > 0 && sizeOf(value) < priorSize) return;   // never shrink
        slot.value          = value;
        slot.lastCapturedAt = Date.now();
        slot.status         = 'captured';
        slot.dbSeeded       = false;
        slot.viewMode       = 'auto';
        if (typeof notifyCapture === 'function') notifyCapture(def.key);
      } catch (_) { /* per-section best effort */ }
    });
  }

  // Full explicit-capture pass: hydrate the page, expand collapsed text within
  // each known section (scoped — never page-wide, so we can't reach navigation
  // chrome), then recapture all sections. Always restores scroll. Used by the
  // Add flow and the __gowarmCaptureHydrate() debug hook — never by observers.
  async function hydrateAndExpandProfile() {
    const originalScrollY = window.scrollY;
    try {
      await scrollHydrate();
      const roots = [
        findSectionByHeading([/^about\b/i]),
        findSectionByHeading([/^experience$/i]),
        findSectionByHeading([/^education$/i]),
      ].filter(Boolean);
      for (const root of roots) {
        try { await expandTruncatedText(root); } catch (_) {}
      }
      recaptureAllSections();
    } catch (_) {
      // Best effort — on any failure the prior captureState is left untouched.
    } finally {
      try { window.scrollTo({ top: originalScrollY, behavior: 'instant' }); }
      catch (_) { try { window.scrollTo(0, originalScrollY); } catch (_) {} }
    }
  }

  function captureEducation() {
    const sec = findSectionByHeading([/^education$/i]);
    if (!sec) return [];

    let items = [...sec.querySelectorAll('[componentkey^="entity-collection-item-"]')];
    if (items.length === 0) {
      items = [...sec.querySelectorAll(
        'li.artdeco-list__item, li[data-test="education-item"], div[data-view-name="profile-component-entity"]'
      )];
    }

    // Newer obfuscated layout (mid-2026): LinkedIn ships education entries
    // in fully class-obfuscated <div>s with no entity-collection-item,
    // no data-test, no data-view-name, no artdeco-list__item, and no
    // reliable per-entry attribute. Earlier versions of this fallback
    // anchored on the school's <a href="/school/...">, but that fails
    // for any education entry whose school doesn't have a LinkedIn page
    // (e.g. "Institute of Chartered Accountants of India") — those
    // entries have no school link at all.
    //
    // What IS consistent across every entry, linked or not: the school
    // name is rendered in a leaf-style <p> whose direct text content is
    // exactly the school name (no nested HTML).
    //
    // So the algorithm is:
    //   1) Find every <p> in the section whose own text (excluding
    //      descendants) is a plausible school-name string.
    //   2) For each, walk up to find the entry wrapper using SIZE-JUMP
    //      DETECTION: LinkedIn nests several near-identical wrapper
    //      <div>s around each entry, so textlen is stable across many
    //      levels (the "plateau") until you hit the multi-entry
    //      container, where it jumps significantly. The last ancestor
    //      whose textlen is still on the plateau is the entry wrapper.
    //   3) Dedupe wrappers — multiple anchors inside the same wrapper
    //      should yield it only once.
    if (items.length === 0) {
      // Step 1: candidate school-name anchors.
      const anchors = [];
      sec.querySelectorAll('p').forEach(p => {
        const ownText = [...p.childNodes]
          .filter(n => n.nodeType === Node.TEXT_NODE)
          .map(n => n.textContent).join('').trim();
        // Must be non-empty, not absurdly long, and not the section
        // heading or a date range. Date ranges contain a year and a
        // dash; school names typically don't.
        if (!ownText) return;
        if (ownText.length > 120) return;
        if (/^education$/i.test(ownText)) return;
        if (/^\s*(19|20)\d{2}\s*[-–—]\s*((19|20)\d{2}|present)/i.test(ownText)) return;
        anchors.push(p);
      });

      // Step 2: walk up from each anchor to find the entry wrapper.
      //
      // Algorithm:
      //   Climb upward; track text length at each level. The entry
      //   wrapper is the largest ancestor that's still "entry-sized"
      //   (not yet a multi-entry container).
      //
      //   "Entry-sized" ≈ at most ~60% of the full section's text. A
      //   multi-entry container would be ≥ section_len * (n-1)/n where
      //   n is the entry count — for 2 entries, ~50%. We pick 60% as a
      //   safe upper bound. When the climb lands on a level whose text
      //   length exceeds the cap, the previous level is the wrapper.
      //
      //   Why not the old "jump detection" alone: in flat DOMs (mid-2026
      //   shape), climb 0 from a leaf <p> jumps 2x because the parent
      //   div IS the entry wrapper (one div containing school + degree
      //   + date <p>s, ~80-170 chars). The old code interpreted any 1.6x
      //   jump as a multi-entry boundary and backed off to the anchor
      //   itself, yielding bare <p>s as "entries" with no extractable
      //   sub-lines. The size-cap check correctly recognizes that
      //   80-170 chars is still entry-sized.
      const secLen = (sec.innerText || '').trim().length;
      const entrySizeCap = Math.max(60, Math.floor(secLen * 0.6));

      const entryFor = (anchor) => {
        let node    = anchor.parentElement;
        let prev    = anchor;
        let prevLen = (anchor.innerText || '').trim().length;
        let climbs  = 0;
        const MAX_CLIMBS = 12;
        while (node && node !== sec && climbs < MAX_CLIMBS) {
          const txt = (node.innerText || '').trim();
          const len = txt.length;
          // If this ancestor exceeds the entry-size cap, it's a
          // multi-entry container. The previous ancestor was the
          // wrapper. Need to ensure prev is not the anchor itself (a
          // bare <p>) — accept only if we've climbed at least once.
          if (len > entrySizeCap) {
            return climbs > 0 ? prev : null;
          }
          prev    = node;
          prevLen = len;
          node    = node.parentElement;
          climbs++;
        }
        // No multi-entry container hit within budget. Use the largest
        // ancestor we walked to, provided we climbed at least once.
        return climbs > 0 ? prev : null;
      };

      // Step 3: collect and dedupe entries. Two anchors inside the
      // same wrapper (e.g. school name + degree + year all in <p>s)
      // resolve to the same wrapper — keep only one.
      const seen   = new Set();
      const byPara = [];
      anchors.forEach(p => {
        const entry = entryFor(p);
        if (!entry) return;
        if (seen.has(entry)) return;
        seen.add(entry);
        byPara.push(entry);
      });

      items = byPara;
    }

    // Drop nested duplicates the same way captureExperience does.
    const filtered = [];
    items.forEach(it => {
      const txt = (it.innerText || '').trim();
      if (txt.length < 5) return;
      if (filtered.some(prev => prev.contains(it))) return;
      filtered.push(it);
    });

    const out = [];
    filtered.forEach(item => {
      const lines = readItemLines(item);
      if (lines.length === 0) return;

      // Education item shape (confirmed on SDUI):
      //   line 0: school
      //   line 1: degree, field of study (may be combined as "BS, Computer Science")
      //   line 2: year range ("1986 – 1994" or "1986 - 1994")
      // On older layouts there can be extra activity lines after years —
      // we keep the regex scan for years so they're picked up regardless of position.
      const school = lines[0] || null;

      const dateLineIdx = lines.findIndex(l => /\b(19|20)\d{2}\b/.test(l));
      const dateLine    = dateLineIdx >= 0 ? lines[dateLineIdx] : null;
      const yearMatches = dateLine ? [...dateLine.matchAll(/\b(19|20)\d{2}\b/g)].map(m => parseInt(m[0], 10)) : [];
      const startYear   = yearMatches[0] || null;
      const endYear     = yearMatches[1] || null;

      // Degree/field: lines between school and date that aren't the date itself.
      let degree = null;
      let field  = null;
      const middleLines = lines.slice(1, dateLineIdx >= 0 ? dateLineIdx : lines.length);
      if (middleLines.length === 1) {
        // "ACS, Company Secretary" — split on first comma if present.
        const parts = middleLines[0].split(/,\s+/);
        degree = parts[0] || null;
        field  = parts.slice(1).join(', ') || null;
      } else if (middleLines.length >= 2) {
        degree = middleLines[0];
        field  = middleLines[1];
      }

      out.push({
        school,
        degree,
        field_of_study: field,
        start_year: startYear,
        end_year:   endYear,
      });
    });
    return out;
  }

  // Activity (recent posts/comments/reactions). On a profile page LinkedIn
  // shows a small preview of recent activity. We capture what's currently
  // rendered — the rep can navigate to the full activity tab to load more
  // before clicking Capture.
  function captureActivity() {
    const sec = findSectionByHeading([
      /^activity$/i,
      /(\bposts?\b|\bactivity\b).{0,30}\bfollowers?$/i,
      /\brecent activity\b/i,
    ]);
    if (!sec) return [];

    // Activity items are exposed in two different layouts depending on the
    // profile — and sometimes both at once:
    //
    //   Layout A — pillContent: simpler profiles render at most one wrapper
    //     per tab with componentkey="<slug>activity_<type>_pillContent",
    //     containing the highlighted post.
    //
    //   Layout B — carousel of individual cards: most profiles render a
    //     horizontal carousel of post/comment cards. Each card has a random
    //     UUID componentkey, no naming convention.
    //
    // The reliable signal across both is that every post links to
    // /feed/update/urn:li:activity:<id>/ via an <a href>. So we find every
    // such anchor, walk up to its enclosing card (the closest ancestor that
    // contains the activity URN AND substantial text), and dedupe by URN.
    //
    // LinkedIn has shipped layouts where the anchor href is NOT
    // /feed/update/... but a relative path that still embeds the
    // urn:li:activity: token, or where the URN is only on a container's
    // data-urn attribute with no anchor at all. We catch both: any <a> whose
    // href contains an activity URN, plus a fallback walk over
    // [data-urn^="urn:li:activity:"] containers.
    const anchors = [
      ...sec.querySelectorAll(
        'a[href*="urn:li:activity:"], a[href*="/feed/update/"], a[href*="/posts/"]'
      )
    ];
    const seenUrns  = new Set();
    const itemRoots = [];
    for (const a of anchors) {
      const urnMatch = (a.getAttribute('href') || '').match(/urn:li:activity:(\d+)/);
      if (!urnMatch) continue;
      const urn = urnMatch[1];
      if (seenUrns.has(urn)) continue;
      seenUrns.add(urn);

      // Find the smallest ancestor that contains exactly THIS URN and no
      // other activity URNs. By definition that's the card boundary —
      // higher containers (carousel rows, the whole Activity section) hold
      // multiple URNs and would be too coarse.
      const urnRegex = /urn:li:activity:(\d+)/g;
      function urnsInside(el) {
        const out = new Set();
        const html = el.innerHTML || '';
        let m;
        urnRegex.lastIndex = 0;
        while ((m = urnRegex.exec(html))) out.add(m[1]);
        return out;
      }

      let node = a.parentElement;
      while (node && node !== sec) {
        const urns = urnsInside(node);
        if (urns.size === 1 && urns.has(urn)) {
          // This ancestor contains exactly our URN — but make sure it
          // also has substantial card content (not just an <a> wrapping
          // the URN with no surrounding text).
          const t = (node.innerText || '').trim();
          if (t.length > 30) break;
        } else if (urns.size > 1) {
          // We've ascended past the card boundary into a multi-card
          // container. Descend back down to the smallest descendant that
          // still contains exactly our URN. A single-step "find child with
          // our URN" was insufficient — when the multi-URN ancestor is a
          // huge page container (e.g. <main>), its first matching child is
          // a giant column wrapper that also contains the topcard, About,
          // Experience, etc., so the card's `innerText` becomes the
          // entire profile column. We loop until no smaller child still
          // contains the URN.
          let descend = node;
          while (true) {
            const next = [...descend.children].find(c => urnsInside(c).has(urn));
            if (!next || next === descend) break;
            descend = next;
          }
          node = descend;
          break;
        }
        node = node.parentElement;
      }

      // If pillContent wrapper exists somewhere up the chain AND it
      // contains exactly our URN, prefer it for the kind classifier.
      let pillNode = node;
      while (pillNode && pillNode !== sec) {
        const ck = pillNode.getAttribute && pillNode.getAttribute('componentkey');
        if (ck && /activity_\w+_pillContent$/i.test(ck)) {
          if (urnsInside(pillNode).size === 1) node = pillNode;
          break;
        }
        pillNode = pillNode.parentElement;
      }

      if (node && node !== sec) {
        // Dedup: only add if this URN's chosen node isn't a parent or child
        // of one we already kept. (Different anchors for the same URN may
        // resolve to slightly different nesting levels.)
        if (!itemRoots.some(prev => prev.contains(node) || node.contains(prev))) {
          itemRoots.push(node);
        }
      }
    }

    // Second pass: pick up URNs that appear only via [data-urn]/[urn]
    // attributes on container divs (some carousel cards don't emit an <a>
    // wrapping the URN, only the container annotation).
    const urnContainers = [...sec.querySelectorAll(
      'div[data-urn^="urn:li:activity:"], div[urn^="urn:li:activity:"]'
    )];
    for (const node of urnContainers) {
      const attrUrn =
        node.getAttribute('data-urn') || node.getAttribute('urn') || '';
      const urnMatch = attrUrn.match(/urn:li:activity:(\d+)/);
      if (!urnMatch) continue;
      const urn = urnMatch[1];
      if (seenUrns.has(urn)) continue;
      const txt = (node.innerText || '').trim();
      if (txt.length < 20) continue;
      if (itemRoots.some(prev => prev.contains(node) || node.contains(prev))) continue;
      seenUrns.add(urn);
      itemRoots.push(node);
    }

    // Legacy fallback for layouts where no activity anchors are present.
    let items = itemRoots;
    if (items.length === 0) {
      items = [...sec.querySelectorAll(
        '[componentkey*="activity_"][componentkey$="_pillContent"], li, div[data-urn^="urn:li:activity:"], div[urn^="urn:li:activity:"]'
      )];
      // Re-apply nesting filter for the legacy path
      const filtered = [];
      items.forEach(it => {
        const txt = (it.innerText || '').trim();
        if (txt.length < 20) return;
        if (filtered.some(prev => prev.contains(it))) return;
        filtered.push(it);
      });
      items = filtered;
    }

    const out = [];
    // Activity classification.
    //
    // For each item we decide one of five outcomes:
    //   action = 'posted'          — original post authored by the prospect
    //   action = 'reposted'        — plain repost of someone else's post, no commentary
    //   action = 'quoted_repost'   — repost with the prospect's own commentary on top
    //   kind   = 'comment'         — commented on someone else's post
    //   kind   = 'reaction'        — liked/celebrated/supported/insightful
    //
    // For 'reposted' and 'quoted_repost' we also try to extract:
    //   quoted_author — the original author's display name
    //   quoted_text   — the original post body
    //   commentary    — only on quoted_repost: the prospect's words on top
    //
    // Repost detection uses two independent signals — either fires the
    // classification:
    //
    //   Signal A (verb header): the item's header text contains
    //     "<prospect> reposted this". LinkedIn renders this for repost cards
    //     that show the original inline with the embedded author block in
    //     the main item flow.
    //
    //   Signal B (nested URN): the item contains an inner reference to
    //     another post — urn:li:ugcPost: or urn:li:share: in a child element —
    //     distinct from the outer urn:li:activity: that wraps this item.
    //     LinkedIn uses this shape for quoted reposts where the original is
    //     shown in a bordered embedded card. The verb header may be absent
    //     in this case ("Jonathan Eide • 2nd" looks like an original post).
    //
    // After detecting a repost, commentary extraction decides plain vs quoted.
    items.forEach(item => {
      const componentKey = item.getAttribute('componentkey') || '';

      // Pull the activity URL — the <a> linking to /feed/update/urn:li:activity:...
      const anchor = [...item.querySelectorAll('a[href*="/feed/update/"], a[href*="/posts/"]')]
        .find(a => a.href);
      const url = anchor?.href || null;

      // Outer URN: the activity id this whole item represents (the prospect's
      // own action). For a plain or quoted repost, this is the wrapper URN.
      const outerUrnMatch = (url || '').match(/urn:li:activity:(\d+)/);
      const outerUrn = outerUrnMatch ? outerUrnMatch[1] : null;

      // Find ALL post URNs referenced anywhere inside this item. LinkedIn uses
      // three namespaces — activity:, ugcPost:, share: — and a quoted repost
      // typically wraps an outer activity: around an inner ugcPost: (or share:
      // on older posts). We collect every (namespace, id) pair, then exclude
      // the outer one to find any "inner" reference — the embedded original.
      const innerRefs = new Set();  // strings of form "namespace:id"
      const collectRefs = (str) => {
        if (!str) return;
        const re = /urn:li:(activity|ugcPost|share):(\d+)/g;
        let m;
        while ((m = re.exec(str))) innerRefs.add(`${m[1]}:${m[2]}`);
      };
      [...item.querySelectorAll('a[href*="/feed/update/"], a[href*="/posts/"]')]
        .forEach(a => collectRefs(a.getAttribute('href') || ''));
      [...item.querySelectorAll('[data-urn], [urn]')]
        .forEach(el => {
          collectRefs(el.getAttribute('data-urn') || '');
          collectRefs(el.getAttribute('urn') || '');
        });
      // Scan innerHTML once for any references we missed (defensive).
      collectRefs(item.innerHTML || '');
      if (outerUrn) innerRefs.delete(`activity:${outerUrn}`);
      const hasNestedRef = innerRefs.size > 0;

      // Read the lines as <p> first (new SDUI), fall back to aria-hidden spans.
      let lines = [...item.querySelectorAll('p')]
        .map(el => (el.innerText || '').trim())
        .filter(Boolean);
      if (lines.length === 0) {
        lines = (item.innerText || '').split('\n').map(s => s.trim()).filter(Boolean);
      }

      // First meaningful line is the action header: e.g.
      //   "<Name> commented on a post"
      //   "<Name> reposted this"
      //   "<Name> liked a post"
      //   "<Name> posted this"
      const firstLine = lines.find(l => /\b(commented|posted|reposted|liked|celebrated|supported|shared|reacted)\b/i.test(l)) || lines[0] || '';

      // Signal A: verb header says "reposted" (or "shared", which LinkedIn
      // uses for the same concept in some locales).
      const verbSaysRepost = /\b(reposted|shared)\b/i.test(firstLine);

      // Classify kind + initial action. Comments and reactions short-circuit;
      // posts go through repost detection.
      let kind = 'post';
      let actionVerb = null;
      let isRepost   = false;

      if (/comments_pillContent/i.test(componentKey) || /\bcommented\b/i.test(firstLine)) {
        kind = 'comment';
        actionVerb = 'commented';
      } else if (/reactions_pillContent/i.test(componentKey)) {
        kind = 'reaction';
        actionVerb = 'reacted';
      } else if (
        /\b(liked|celebrated|supported|insightful)\b/i.test(firstLine) &&
        !verbSaysRepost && !/\bposted\b/i.test(firstLine)
      ) {
        // Pure reaction header — exclude when "reposted/shared/posted" also
        // appears (some headers chain verbs).
        kind = 'reaction';
        const m = firstLine.match(/\b(liked|celebrated|supported|insightful)\b/i);
        actionVerb = m ? m[1].toLowerCase() : 'reacted';
      } else {
        // It's a post. Decide original vs repost using Signal A OR Signal B.
        kind = 'post';
        isRepost = verbSaysRepost || hasNestedRef;
        actionVerb = isRepost ? 'reposted' : 'posted';
        // 'reposted' is tentative — commentary extraction below may upgrade
        // it to 'quoted_repost'. 'posted' stays as-is.
      }

      // Relative timestamp: "1w", "3d", "5h", "2mo", "1y" — appears as its own
      // <p> in SDUI, often surrounded by "•" separators.
      const relTime = lines.find(l => /^[<•·\s]*(\d+)\s*([smhdwy]|mo|hr|min|sec)\b/i.test(l));

      // Body text: the longest non-header, non-time, non-bullet line.
      // For reposts this often picks up the original post body; commentary
      // extraction below pulls out the prospect's own commentary separately.
      const headerSet = new Set([firstLine, '•', '·', relTime].filter(Boolean));
      const bodyText = lines
        .filter(l => !headerSet.has(l))
        .filter(l => l.length > 5)
        .filter(l => !/^•\s*\d+[smhdwy]/i.test(l))   // "• 1w"
        .filter(l => l !== 'Show all' && l !== 'See more' && l !== 'See less')
        .sort((a, b) => b.length - a.length)[0] || null;

      // For reposts, try to split commentary vs quoted_text and extract the
      // original author. Two parallel strategies — whichever succeeds first
      // produces the card boundary.
      //
      //   Path 1 (URN-anchored): when there's an inner ugcPost:/share: URN,
      //     walk up from its anchor to find the smallest ancestor that
      //     contains the inner ref but not the outer activity: ref. That
      //     ancestor is the embedded card. Works for Satyajeet-style quoted
      //     reposts where the embedded original has its own URN.
      //
      //   Path 2 (verb-anchored): when only Signal A fired (verb header,
      //     no inner URN), the original author is rendered inline as the
      //     first <a href="/in/X/"> that ISN'T the prospect's own profile.
      //     The "card" is the subtree starting from that author link. Works
      //     for Travis/Aadil-style plain reposts.
      //
      // Both paths set quotedAuthor / quotedText. Commentary extraction is
      // then the same for both: any substantial text outside the card region.
      let commentary   = null;
      let quotedText   = null;
      let quotedAuthor = null;
      if (kind === 'post' && isRepost) {
        try {
          let cardNode = null;

          // ── Path 1: URN-anchored ────────────────────────────────────────
          if (hasNestedRef) {
            const innerAnchors = [...item.querySelectorAll('a[href*="/feed/update/"], a[href*="/posts/"]')]
              .filter(a => {
                const m = (a.getAttribute('href') || '').match(/urn:li:(activity|ugcPost|share):(\d+)/);
                if (!m) return false;
                const ref = `${m[1]}:${m[2]}`;
                // Inner = anything in our innerRefs set (we already excluded
                // the outer activity: ref). The outer is the only thing we
                // shouldn't follow back to a card.
                return innerRefs.has(ref);
              });
            for (const a of innerAnchors) {
              let node = a.parentElement;
              while (node && node !== item) {
                const html = node.innerHTML || '';
                const hasOuter = outerUrn ? html.includes(`urn:li:activity:${outerUrn}`) : false;
                const refCount = (html.match(/urn:li:(activity|ugcPost|share):\d+/g) || []).length;
                if (!hasOuter && refCount >= 1 && (node.innerText || '').trim().length > 20) {
                  cardNode = node;
                  break;
                }
                node = node.parentElement;
              }
              if (cardNode) break;
            }
          }

          // ── Path 2: verb-anchored ───────────────────────────────────────
          // Used when Signal A fired (verb says "reposted") but URN-anchoring
          // didn't find a card — i.e. plain reposts where the original is
          // shown inline without its own activity reference.
          if (!cardNode && verbSaysRepost) {
            // The prospect's own profile slug — used to exclude their own
            // profile link from the author candidates. Derived from the
            // page URL (we're on linkedin.com/in/<slug>/).
            const prospectSlug = (() => {
              const m = (location.pathname || '').match(/^\/in\/([^/]+)/);
              return m ? m[1].toLowerCase() : null;
            })();
            const profileLinks = [...item.querySelectorAll('a[href*="/in/"]')]
              .filter(a => {
                const href = a.getAttribute('href') || '';
                const m = href.match(/\/in\/([^/?#]+)/);
                if (!m) return false;
                const slug = m[1].toLowerCase();
                return prospectSlug ? slug !== prospectSlug : true;
              });
            // The first non-prospect profile link is the original author.
            // The card is its nearest ancestor that also contains the post
            // body — practically, walk up until the ancestor's text length
            // is meaningfully larger than just the author block.
            if (profileLinks.length > 0) {
              const authorLink = profileLinks[0];
              let node = authorLink.parentElement;
              while (node && node !== item) {
                if ((node.innerText || '').trim().length > 80) {
                  cardNode = node;
                  break;
                }
                node = node.parentElement;
              }
            }
          }

          if (cardNode) {
            const cardLines = [...cardNode.querySelectorAll('p')]
              .map(el => (el.innerText || '').trim())
              .filter(Boolean);
            const allCardLines = cardLines.length
              ? cardLines
              : (cardNode.innerText || '').split('\n').map(s => s.trim()).filter(Boolean);

            // Author candidate: first short capitalized non-sentence line.
            // Excludes phrases that show up in metadata rows.
            quotedAuthor = allCardLines.find(l =>
              l.length > 1 && l.length < 80 &&
              /^[A-Z]/.test(l) &&
              !/[.?!]/.test(l) &&
              !/^\d/.test(l) &&
              !/(followers|connections|reposted|posted|commented|likes?)/i.test(l)
            ) || null;

            // Quoted body: longest meaningful line in the card.
            quotedText = allCardLines
              .filter(l => l !== quotedAuthor)
              .filter(l => l.length > 10)
              .filter(l => !/^[<•·\s]*\d+\s*([smhdwy]|mo|hr|min|sec)\b/i.test(l))
              .filter(l => !/^(followers?|connections?|likes?|comments?|reposts?)\b/i.test(l))
              .sort((a, b) => b.length - a.length)[0] || null;

            // Commentary: substantial text in the item that ISN'T inside
            // the card AND ISN'T a header/timestamp. The prospect's own
            // words on top of the embedded original.
            const cardText = (cardNode.innerText || '').trim();
            const commentaryCandidates = lines.filter(l => {
              if (headerSet.has(l)) return false;
              if (l.length < 5) return false;
              if (cardText.includes(l)) return false;
              if (/^[<•·\s]*\d+\s*([smhdwy]|mo|hr|min|sec)\b/i.test(l)) return false;
              if (l === 'Show all' || l === 'See more' || l === 'See less') return false;
              return true;
            });
            commentary = commentaryCandidates.sort((a, b) => b.length - a.length)[0] || null;

            if (commentary && commentary.length >= 15) {
              actionVerb = 'quoted_repost';
            } else {
              actionVerb = 'reposted';
              commentary = null;
            }
          }
          // No card found — leave actionVerb as 'reposted', skip extraction.
        } catch (err) {
          // Defensive: any DOM exception leaves actionVerb as the tentative
          // 'reposted' (or 'posted' if isRepost was false from the start).
        }
      }

      // For comments/reactions, parent_post_summary = body of the post they
      // reacted to. In our captured DOM we only see the rep's comment, so
      // we use the body text as the summary too — it's the best signal we
      // have without navigating to the post page.
      let parentPostSummary = null;
      if (kind === 'comment' || kind === 'reaction') {
        parentPostSummary = bodyText;
      }

      // Stable id: prefer the activity URN out of the URL, fall back to a
      // hash of the visible content so re-captures don't duplicate.
      let id;
      const urnMatch = (url || '').match(/urn:li:activity:(\d+)/);
      if (urnMatch) id = `li_${urnMatch[1]}`;
      else          id = hashId(firstLine + (bodyText || '').slice(0, 120));

      const entry = {
        id,
        kind,
        // LinkedIn doesn't expose absolute timestamps; we record now() and
        // the relative-time string. Backend can convert "1w" → date-1w on insert.
        occurred_at: new Date().toISOString(),
        relative_time: relTime || null,
        text:        bodyText || firstLine || '',
        action:      actionVerb,
        source_url:  url,
      };
      if (parentPostSummary) entry.parent_post_summary = parentPostSummary;
      // Repost-detection detail fields. Only set when we successfully
      // extracted them — downstream consumers can safely null-check.
      if (commentary)   entry.commentary    = commentary;
      if (quotedText)   entry.quoted_text   = quotedText;
      if (quotedAuthor) entry.quoted_author = quotedAuthor;

      out.push(entry);
    });

    // De-dupe by id (we may have captured the same activity from multiple tabs).
    const seen = new Set();
    return out.filter(e => {
      if (seen.has(e.id)) return false;
      seen.add(e.id);
      return true;
    });
  }

  function parseDateRange(line) {
    if (!line) return { startDate: null, endDate: null, durationMonths: null };

    // Months map
    const months = {
      jan: '01', feb: '02', mar: '03', apr: '04', may: '05', jun: '06',
      jul: '07', aug: '08', sep: '09', oct: '10', nov: '11', dec: '12',
    };
    const parsePart = (raw) => {
      if (!raw) return null;
      // Strip trailing "· 1 yr 2 mos" / "· On-site" / etc. — anything after
      // the first " · " separator. Also handle "/" separators rarely used.
      const s = raw.split(/\s+·\s+|\s+\/\s+/)[0].trim();
      // "Mar 2026" / "March 2026"
      const m = s.match(/([A-Za-z]{3,9})\s+(\d{4})/);
      if (m) {
        const mm = months[m[1].slice(0, 3).toLowerCase()];
        if (mm) return `${m[2]}-${mm}-01`;
      }
      // Year-only — "2024" or "2025" (LinkedIn shows year-only when user
      // didn't enter a month)
      const y = s.match(/\b(19|20)\d{2}\b/);
      if (y) return `${y[0]}-01-01`;
      return null;
    };

    const parts = line.split(/\s+-\s+|\s+to\s+|\s+–\s+|\s+—\s+/i).map(s => s.trim());
    if (parts.length < 2) return { startDate: parsePart(parts[0] || ''), endDate: null, durationMonths: null };

    const startDate = parsePart(parts[0]);
    const endRaw    = parts[1];
    const endDate   = /present/i.test(endRaw) ? null : parsePart(endRaw);

    // Duration text after middle dot, e.g. "· 4 yrs 2 mos"
    const durMatch = line.match(/·\s*(?:(\d+)\s*yrs?)?\s*(?:(\d+)\s*mos?)?/i);
    const yrs  = parseInt(durMatch?.[1] || '0', 10);
    const mos  = parseInt(durMatch?.[2] || '0', 10);
    const durationMonths = (yrs * 12 + mos) || null;

    return { startDate, endDate, durationMonths };
  }

  // Aggregate all profile-section data into the shape expected by
  // POST /api/linkedin-profiles/upsert
  // ── Progressive capture state ────────────────────────────────────────────────
  //
  // Capture happens incrementally as the user scrolls the LinkedIn profile.
  // Each section has a status:
  //   'pending'  — section root not yet seen in viewport
  //   'loading'  — in viewport, waiting for LinkedIn lazy-load to populate
  //   'captured' — content read; `value` holds the result
  //   'empty'    — in viewport + populated, but section has no items
  //
  // Delta-refresh fields (v1.5):
  //   dbValue       — what the linkedin_profiles row holds for this section
  //                   (null until GET_LINKEDIN_PROFILE returns; null forever
  //                   if no row exists yet for this slug).
  //   dbCapturedAt  — last_*_captured_at timestamp from the DB row.
  //   dbHydrated    — true once GET_LINKEDIN_PROFILE has resolved, even
  //                   if it returned null. Lets the UI distinguish
  //                   "no data on file" from "still fetching".
  //
  // The state object is recreated for each profile (init() resets it). UI
  // subscribers (renderCaptureSection) listen for state changes via
  // captureSubscribe() and rerender just the row that changed.
  function makeCaptureState() {
    const slot = (emptyVal) => ({
      status:        'pending',
      value:         emptyVal,
      lastCapturedAt: null,
      edited:        false,
      dbValue:       null,
      dbCapturedAt:  null,
      dbHydrated:    false,
      // viewMode controls whether the expanded body shows the diff
      // view (default when a diff exists) or the full live data view.
      // Set to 'auto' so refreshRow picks the right default each time
      // based on the slot's current diff state. The user can override
      // by clicking "Show all live data" or "Show changes only" — that
      // sets viewMode to 'full' or 'diff' explicitly. Reset to 'auto'
      // when a fresh capture changes what's available to show.
      viewMode:      'auto',
      // v1.22 per-item merge bookkeeping (experience/education only).
      //   meta.items[key] = { locked_fields:[], suppressed:bool }
      //     — cumulative state, seeded from the DB row's capture_meta.
      //       Used for UI badges and to preserve rep values.
      //   pending = directives the rep performed THIS session, sent in the
      //       upsert `edits` block and cleared on success. Empty by default,
      //       so a profile with no rep actions behaves exactly as before.
      meta:          { items: {} },
      pending:       { lock: [], unlock: [], suppress: [], unsuppress: [] },
    });
    return {
      about:      slot(null),
      experience: slot([]),
      education:  slot([]),
      activity:   slot([]),
    };
  }

  let captureState = makeCaptureState();
  const captureSubscribers = new Set();
  let activeObservers = [];   // disposed on SPA nav

  function captureSubscribe(fn) {
    captureSubscribers.add(fn);
    return () => captureSubscribers.delete(fn);
  }

  function notifyCapture(section) {
    captureSubscribers.forEach(fn => {
      try { fn(section, captureState[section]); } catch (e) { /* swallow */ }
    });
  }

  function disposeCaptureObservers() {
    activeObservers.forEach(o => { try { o.disconnect(); } catch (_) {} });
    activeObservers = [];
    captureSubscribers.clear();
  }

  // ── Per-item merge identity (v1.22) ────────────────────────────────────────
  // MUST mirror the backend exactly (routes/linkedin-profiles.routes.js:
  // _norm / expItemKey / eduItemKey). The composite key identifies a captured
  // item across captures; client and server compute it the same way so locks
  // and suppressions always line up. Lockable (non-key) fields per section:
  //   experience: location, description, duration_months
  //   education:  field_of_study, end_year
  const liNorm = (s) => (s == null ? '' : String(s)).trim().toLowerCase().replace(/\s+/g, ' ');
  function expKeyFields(it) {
    return { company: it.company ?? null, title: it.title ?? null,
             start_date: it.start_date ?? null, end_date: it.end_date ?? null };
  }
  function eduKeyFields(it) {
    return { school: it.school ?? null, degree: it.degree ?? null,
             start_year: it.start_year ?? null };
  }
  function expKeyOf(it) {
    return [liNorm(it.company), liNorm(it.title), liNorm(it.start_date), liNorm(it.end_date)].join('|');
  }
  function eduKeyOf(it) {
    return [liNorm(it.school), liNorm(it.degree), liNorm(it.start_year)].join('|');
  }
  const SECTION_KEYERS = {
    experience: { keyOf: expKeyOf, keyFields: expKeyFields, lockable: ['location', 'description', 'duration_months'] },
    education:  { keyOf: eduKeyOf, keyFields: eduKeyFields, lockable: ['field_of_study', 'end_year'] },
  };

  // Look up (creating if needed) the per-item meta entry in a slot.
  function itemMeta(slot, key) {
    if (!slot.meta) slot.meta = { items: {} };
    if (!slot.meta.items[key]) slot.meta.items[key] = { locked_fields: [], suppressed: false };
    return slot.meta.items[key];
  }
  function isSuppressed(slot, key) {
    return !!(slot.meta && slot.meta.items[key] && slot.meta.items[key].suppressed);
  }
  function lockedFieldsFor(slot, key) {
    return (slot.meta && slot.meta.items[key] && slot.meta.items[key].locked_fields) || [];
  }

  // Record per-field locks when a rep edits a lockable (non-key) field. Editing
  // a KEY field (title/company/dates, school/degree/start_year) changes the
  // item's identity, so the union treats the result as a new role for the rep
  // to adjudicate — those aren't lockable. Mutates slot.pending + slot.meta.
  function recordEditLocks(slot, sectionKey, original, updated) {
    const cfg = SECTION_KEYERS[sectionKey];
    if (!cfg) return;
    const changed = cfg.lockable.filter(f => (original?.[f] ?? null) !== (updated?.[f] ?? null));
    if (!changed.length) return;
    const key = cfg.keyOf(updated);
    const m = itemMeta(slot, key);
    changed.forEach(f => { if (!m.locked_fields.includes(f)) m.locked_fields.push(f); });
    slot.pending.lock.push({ key: cfg.keyFields(updated), fields: changed });
  }

  // Rep removes a role from the panel → suppress it (excluded from the saved
  // array; never resurrected by a later scrape). Restore reverses it.
  function suppressItem(slot, sectionKey, item) {
    const cfg = SECTION_KEYERS[sectionKey]; if (!cfg) return;
    const key = cfg.keyOf(item);
    itemMeta(slot, key).suppressed = true;
    slot.pending.suppress.push(cfg.keyFields(item));
    slot.pending.unsuppress = slot.pending.unsuppress.filter(kf => cfg.keyOf(kf) !== key);
    slot.edited = true;
  }
  function restoreItem(slot, sectionKey, item) {
    const cfg = SECTION_KEYERS[sectionKey]; if (!cfg) return;
    const key = cfg.keyOf(item);
    itemMeta(slot, key).suppressed = false;
    slot.pending.unsuppress.push(cfg.keyFields(item));
    slot.pending.suppress = slot.pending.suppress.filter(kf => cfg.keyOf(kf) !== key);
    slot.edited = true;
  }
  // Rep clears a field lock → let future scrapes refresh it again.
  function unlockField(slot, sectionKey, item, field) {
    const cfg = SECTION_KEYERS[sectionKey]; if (!cfg) return;
    const key = cfg.keyOf(item);
    const m = itemMeta(slot, key);
    m.locked_fields = m.locked_fields.filter(f => f !== field);
    slot.pending.unlock.push({ key: cfg.keyFields(item), fields: [field] });
    slot.pending.lock = slot.pending.lock
      .map(d => cfg.keyOf(d.key) === key ? { ...d, fields: d.fields.filter(f => f !== field) } : d)
      .filter(d => d.fields.length);
    slot.edited = true;
  }

  // Build the `edits` payload block from this-session pending directives.
  // Empty when the rep took no lock/remove actions → identical to pre-v1.22.
  function buildEditsPayload() {
    const out = {};
    ['experience', 'education'].forEach(key => {
      const p = captureState[key] && captureState[key].pending;
      if (!p) return;
      const any = p.lock.length || p.unlock.length || p.suppress.length || p.unsuppress.length;
      if (any) out[key] = { lock: p.lock, unlock: p.unlock, suppress: p.suppress, unsuppress: p.unsuppress };
    });
    return Object.keys(out).length ? out : null;
  }
  function clearPendingEdits() {
    ['experience', 'education'].forEach(key => {
      if (captureState[key]) captureState[key].pending = { lock: [], unlock: [], suppress: [], unsuppress: [] };
    });
  }


  // hydrateFromDbProfile(profile) — pulls the captured fields off a
  // linkedin_profiles row (returned by GET_LINKEDIN_PROFILE) and merges
  // them into captureState as `dbValue` + `dbCapturedAt`. Crucially,
  // it ALSO seeds slot.value when the slot is still pending — so reps
  // can see "what's on file" before scrolling triggers a live scrape.
  //
  // Once a section's live-scrape has fired (status moves past pending),
  // we leave slot.value alone — live wins over stored. This keeps the
  // diff badge meaningful: stored = baseline, live = candidate.
  //
  // Idempotent and safe to call multiple times. After it runs, every
  // subscriber gets a single notify per section so the panel re-renders
  // its rows with the new dbValue context.
  function hydrateFromDbProfile(profile) {
    // Always mark every slot as hydrated, even if `profile` is null —
    // that's how the UI distinguishes "no profile on file yet" from
    // "we haven't asked the backend yet."
    const dbAbout    = profile?.about         ?? null;
    const dbExp      = Array.isArray(profile?.experience) ? profile.experience : [];
    const dbEdu      = Array.isArray(profile?.education)  ? profile.education  : [];
    const dbActivity = Array.isArray(profile?.activity)   ? profile.activity   : [];

    const seedSlot = (key, dbVal, dbTs) => {
      const slot = captureState[key];
      slot.dbValue      = dbVal;
      slot.dbCapturedAt = dbTs;
      slot.dbHydrated   = true;
      // Diff state is about to change (we have a new baseline). Reset
      // viewMode so bodyFor re-picks the right default. Without this,
      // a user's "Show all live data" choice would persist across
      // saves even though the diff that justified it is gone.
      slot.viewMode     = 'auto';
      // Only seed the live value if the live scrape hasn't started.
      // `pending` means the IntersectionObserver hasn't fired yet —
      // showing the DB content there is purely informational and will
      // be replaced by a real scrape as soon as the rep scrolls past.
      if (slot.status === 'pending' && !slot.edited) {
        const isEmpty =
          dbVal == null ||
          (Array.isArray(dbVal) && dbVal.length === 0);
        if (!isEmpty) {
          slot.value      = dbVal;
          slot.status     = 'captured';
          // Mark this value as a DB seed rather than a fresh live scrape.
          // diffSection() reads this so it can distinguish "we're showing
          // you what's on file" from "we just verified live === DB."
          // runCapture clears this flag the moment it overwrites .value.
          slot.dbSeeded   = true;
        }
      }
      notifyCapture(key);
    };

    seedSlot('about',      dbAbout,    profile?.last_about_captured_at    || null);
    seedSlot('experience', dbExp,      profile?.last_exp_captured_at      || null);
    seedSlot('education',  dbEdu,      profile?.last_edu_captured_at      || null);
    seedSlot('activity',   dbActivity, profile?.last_activity_captured_at || null);

    // v1.22: seed per-item merge meta (locks/suppressions) from the row's
    // capture_meta column so the panel shows locked/removed state and so a
    // re-save preserves the rep's prior decisions. Absent (older backend or
    // fresh row) → empty meta, i.e. nothing locked or suppressed. We do NOT
    // touch slot.pending here — that's strictly this-session rep actions.
    const cm = (profile && profile.capture_meta) || {};
    const seedMeta = (key) => {
      const items = (cm[key] && cm[key].items) || {};
      const clean = {};
      for (const k of Object.keys(items)) {
        clean[k] = {
          locked_fields: Array.isArray(items[k].locked_fields) ? [...items[k].locked_fields] : [],
          suppressed:    !!items[k].suppressed,
        };
      }
      captureState[key].meta = { items: clean };
    };
    seedMeta('experience');
    seedMeta('education');
  }

  // Compare current live (or seeded) value against the DB value for one
  // section. Returns one of:
  //   'no-db'      — no profile on file (or hydration not yet returned)
  //   'on-file'    — DB has it AND live capture has not produced anything
  //                  meaningfully different (or hasn't run yet)
  //   'unchanged'  — live capture matches DB exactly
  //   'updated'    — live capture differs from DB
  //   'new-data'   — DB had nothing here, live capture produced something
  //
  // For arrays we use length+shallow-key equality rather than deep equals;
  // a stricter compare would flag every cosmetic LinkedIn DOM tweak as a
  // change. The signature for each section is intentionally narrow so
  // false positives don't push reps into pointless re-saves.
  function diffSection(key, slot) {
    if (!slot.dbHydrated)  return 'no-db';

    const live = slot.value;
    const dbV  = slot.dbValue;

    const dbEmpty   = (dbV == null) || (Array.isArray(dbV) && dbV.length === 0);
    const liveEmpty = (live == null) || (Array.isArray(live) && live.length === 0);

    // No DB data at all
    if (dbEmpty) {
      return liveEmpty ? 'no-db' : 'new-data';
    }

    // We have DB data. If live capture hasn't produced anything yet
    // (still pending/loading and we seeded with DB), report on-file.
    if (slot.status === 'pending' || slot.status === 'loading') {
      return 'on-file';
    }
    // We promoted a pending slot to 'captured' by seeding it from DB —
    // value === dbValue trivially. Treat as on-file until a real live
    // scrape happens. Once the rep edits the slot (slot.edited), we
    // exit seed-state and fall through to the real comparison below.
    if (slot.dbSeeded && !slot.edited) {
      return 'on-file';
    }
    // Live ran but came back empty (rep blocked, parser miss): treat
    // as on-file rather than "updated to empty" — the upsert merge
    // rules wouldn't clear it anyway.
    if (liveEmpty) return 'on-file';

    // Both populated — compare.
    if (key === 'about') {
      return (String(live).trim() === String(dbV).trim()) ? 'unchanged' : 'updated';
    }

    if (key === 'experience') {
      if (live.length !== dbV.length) return 'updated';
      const sig = (x) => `${x.title||''}|${x.company||''}|${x.start_date||''}|${x.end_date||''}`;
      const liveSet = new Set(live.map(sig));
      for (const d of dbV) if (!liveSet.has(sig(d))) return 'updated';
      return 'unchanged';
    }

    if (key === 'education') {
      if (live.length !== dbV.length) return 'updated';
      const sig = (x) => `${x.school||''}|${x.degree||''}|${x.field_of_study||''}|${x.start_year||''}|${x.end_year||''}`;
      const liveSet = new Set(live.map(sig));
      for (const d of dbV) if (!liveSet.has(sig(d))) return 'updated';
      return 'unchanged';
    }

    if (key === 'activity') {
      // Activity is merged on the server by id, so any live items not
      // in DB count as new — even one is enough to mark "updated".
      const dbIds = new Set((dbV || []).map(x => x?.id).filter(Boolean));
      const newOnes = (live || []).filter(x => x?.id && !dbIds.has(x.id));
      return newOnes.length > 0 ? 'updated' : 'unchanged';
    }

    return 'unchanged';
  }

  // Aggregate diff across all four sections. Returns:
  //   { hasDb, anyChanges, overall }
  //   overall ∈ 'no-db' | 'unchanged' | 'updated'
  //
  // The Save button uses this to flip its label and disabled state.
  function diffAll() {
    const perSection = {};
    let hasDb       = false;
    let anyChanges  = false;
    let anyOnFile   = false;

    for (const key of ['about', 'experience', 'education', 'activity']) {
      const slot = captureState[key];
      const d    = diffSection(key, slot);
      perSection[key] = d;
      if (slot.dbHydrated && (slot.dbValue != null && (!Array.isArray(slot.dbValue) || slot.dbValue.length))) {
        hasDb = true;
      }
      if (d === 'updated' || d === 'new-data') anyChanges = true;
      if (d === 'on-file' || d === 'unchanged') anyOnFile = true;
    }

    let overall;
    if (!hasDb && !anyOnFile) overall = 'no-db';
    else if (anyChanges)      overall = 'updated';
    else                      overall = 'unchanged';

    return { hasDb, anyChanges, anyOnFile, overall, perSection };
  }

  // Set up the IntersectionObserver + per-section MutationObservers that
  // populate captureState as the user scrolls. Idempotent — safe to call
  // multiple times; previous observers are disposed first.
  function setupCaptureObservers() {
    disposeCaptureObservers();
    captureState = makeCaptureState();

    // About is usually visible at the top of the page — capture immediately
    // if it's already there, otherwise wait for it to render.
    const sectionDefs = [
      { key: 'about',      headings: [/^about\b/i],         capture: () => captureAboutText(),  isEmpty: v => !v },
      { key: 'experience', headings: [/^experience$/i],    capture: () => captureExperience(), isEmpty: v => !v?.length },
      { key: 'education',  headings: [/^education$/i],     capture: () => captureEducation(),  isEmpty: v => !v?.length },
      { key: 'activity',   headings: [
          /^activity$/i,
          /(\bposts?\b|\bactivity\b).{0,30}\bfollowers?$/i,
          /\brecent activity\b/i,
        ], capture: () => captureActivity(), isEmpty: v => !v?.length },
    ];

    const captureDebounce = {};   // per-key debounce timers

    function runCapture(def, reason) {
      if (!extensionAlive()) return;
      clearTimeout(captureDebounce[def.key]);
      const delay =
        reason === 'attach'    ? 200 :   // already-visible at attach: quick
        reason === 'intersect' ? 600 :   // freshly scrolled into view: brief
                                  800;   // mutation: longer debounce
      captureDebounce[def.key] = setTimeout(() => {
        const slot = captureState[def.key];
        // If the rep has manually edited this section, leave their values
        // intact — auto-recapture would overwrite their corrections.
        if (slot.edited) return;
        // Mark loading on first attempt
        if (slot.status === 'pending') {
          slot.status = 'loading';
          notifyCapture(def.key);
        }
        let value;
        try { value = def.capture(); }
        catch (e) {
          // Extraction threw. Treat as a failed attempt — but do NOT
          // wipe a value we successfully captured earlier. LinkedIn
          // re-virtualizes sections on scroll, so a later scrape can
          // throw even though the section's data is real and was
          // already captured. Clobbering it here is what caused
          // getExperience() to return [] after the panel had shown
          // entries. Keep the prior value; only mark empty if we never
          // had one.
          const hadValue = def.key === 'about'
            ? (slot.value != null && String(slot.value).trim() !== '')
            : (Array.isArray(slot.value) && slot.value.length > 0);
          if (!hadValue) {
            slot.status = 'empty';
            slot.value  = def.key === 'about' ? null : [];
          }
          notifyCapture(def.key);
          return;
        }

        // Guard against an empty scrape overwriting a good one. Same
        // reasoning as the catch block: a section that previously
        // captured N entries should not silently drop to 0 because a
        // later scroll-triggered scrape ran while the DOM was mid
        // re-render. If the new value is empty but we already hold a
        // non-empty value, keep what we have.
        const newIsEmpty = def.isEmpty(value);
        const hadValue = def.key === 'about'
          ? (slot.value != null && String(slot.value).trim() !== '')
          : (Array.isArray(slot.value) && slot.value.length > 0);
        if (newIsEmpty && hadValue) {
          // Keep the existing value/status; just acknowledge the attempt.
          notifyCapture(def.key);
          return;
        }

        slot.value           = value;
        slot.lastCapturedAt  = Date.now();
        slot.status          = newIsEmpty ? 'empty' : 'captured';
        // Live scrape just produced a value — it's no longer a DB seed.
        slot.dbSeeded        = false;
        // Reset viewMode: a fresh capture may have introduced a diff
        // the user hasn't seen yet. 'auto' lets bodyFor pick the right
        // default (diff if there's a diff, full otherwise).
        slot.viewMode        = 'auto';
        notifyCapture(def.key);
      }, delay);
    }

    // Try to find each section's <section> wrapper. If a section isn't yet
    // in the DOM, we'll retry on every body mutation until it appears.
    //
    // We also track which DOM node we attached to (`def.__attachedSec`) so
    // the body MutationObserver below can detect when LinkedIn has replaced
    // the section node out from under us (React re-renders the SDUI tree on
    // tab switches, scroll-triggered hydration, etc.) and re-attach to the
    // live node. Without re-attach, the IntersectionObserver keeps watching
    // a detached node and never fires — the symptom was Activity sitting on
    // status='pending' forever even after scrolling it into view.
    function tryAttach(def) {
      const sec = findSectionByHeading(def.headings);
      if (!sec) return false;

      // Already attached to this exact node? Nothing to do.
      if (def.__attachedSec === sec) return true;

      def.__attachedSec = sec;

      // IntersectionObserver: triggers initial capture when the section
      // enters the viewport. Standard browser behavior is to fire the
      // callback once on observe() with the current intersection state,
      // so sections already in the viewport at attach time will be
      // captured immediately.
      const io = new IntersectionObserver((entries) => {
        for (const e of entries) {
          if (e.isIntersecting) runCapture(def, 'intersect');
        }
      }, { root: null, rootMargin: '200px', threshold: 0 });
      io.observe(sec);
      activeObservers.push(io);

      // Belt-and-braces: also fire capture immediately if the section
      // bounding rect is already on screen. Some layouts have caused the
      // initial IntersectionObserver callback to be skipped.
      const rect = sec.getBoundingClientRect();
      const inView = rect.top < window.innerHeight && rect.bottom > 0;
      if (inView) runCapture(def, 'attach');

      // MutationObserver: re-captures when items are added/removed in the
      // section (e.g. LinkedIn populating lazy-loaded entries, user expanding
      // "see more" which appends a longer text node, switching the Activity
      // tab strip). We deliberately don't observe characterData because it
      // fires constantly during page interactions; childList is enough to
      // catch the cases we care about.
      const mo = new MutationObserver(() => runCapture(def, 'mutation'));
      mo.observe(sec, { childList: true, subtree: true });
      activeObservers.push(mo);

      // Watchdog: if 3 seconds after attach the slot is still on its
      // initial 'pending' status (meaning runCapture has never fired —
      // neither IntersectionObserver nor inView path triggered) AND the
      // section is currently visible, force a capture. This catches the
      // case where IO never fires on a section that's already past the
      // root margin (e.g. very tall pages where the section was mounted
      // but the IO's initial callback was skipped on a stale node).
      setTimeout(() => {
        if (!extensionAlive()) return;
        if (def.__attachedSec !== sec) return;   // re-attached elsewhere
        const slot = captureState[def.key];
        if (!slot || slot.status !== 'pending') return;
        if (slot.edited) return;
        const r = sec.getBoundingClientRect();
        const visible = r.bottom > 0 && r.top < window.innerHeight && r.width > 0;
        if (visible) runCapture(def, 'watchdog');
      }, 3000);

      return true;
    }

    // Attach what we can right now…
    sectionDefs.forEach(def => tryAttach(def));

    // …and watch the body for late-arriving OR re-mounted sections. We
    // re-run tryAttach for every def on each body mutation: tryAttach is
    // a no-op for defs already pointing at the live node, and re-attaches
    // for defs whose section was swapped out by a React re-render. This
    // is more aggressive than the original "splice off once attached"
    // approach but the cost is low — debounced + cheap fast-path — and
    // the resilience is worth it.
    let bodyObsTimer = null;
    const bodyObs = new MutationObserver(() => {
      if (bodyObsTimer) return;   // already scheduled
      bodyObsTimer = setTimeout(() => {
        bodyObsTimer = null;
        if (!extensionAlive()) return;
        sectionDefs.forEach(def => {
          // Fast path: tracked node still connected and still has its
          // heading — nothing to do.
          if (def.__attachedSec && def.__attachedSec.isConnected) {
            const stillHasHeading = def.__attachedSec.querySelector(
              'h2, h3, [role="heading"]'
            );
            if (stillHasHeading) return;
          }
          tryAttach(def);
        });
      }, 400);
    });
    bodyObs.observe(document.body, { childList: true, subtree: true });
    activeObservers.push(bodyObs);
  }

  // Extract the company slug from a LinkedIn company URL, normalised for
  // comparison. Returns null when the URL isn't a /company/<slug>/ link.
  function companySlugFromUrl(url) {
    if (!url) return null;
    const m = String(url).match(/\/company\/([^/?#]+)/i);
    return m ? m[1].toLowerCase().replace(/\/+$/, '') : null;
  }

  // The prospect's current-employer slug from the topcard company chip — the
  // /company/<slug>/ link LinkedIn renders next to the name/headline. This is
  // the most reliable source when the experience entry didn't capture a
  // company link. Returns null when the chip isn't reachable in light DOM.
  function companySlugFromTopcardChip(name) {
    try {
      const region = (typeof findTopcardRegion === 'function' && name) ? findTopcardRegion(name) : null;
      const scope  = region || document;
      for (const a of scope.querySelectorAll('a[href*="/company/"]')) {
        const href = a.getAttribute('href') || a.href || '';
        const m = href.match(/\/company\/([A-Za-z0-9._-]+)/);
        if (!m) continue;
        const slug = m[1].toLowerCase();
        if (/^(setup|admin|new)$/.test(slug)) continue;   // not a real company page
        return slug;
      }
    } catch (_) { /* shadow DOM / not found — fall through */ }
    return null;
  }

  // The set of slugs that count as the prospect's OWN (current) employer.
  // Gathered from every URL-based source so a single missed scrape doesn't
  // blank the whole flag: (1) experience entries whose company name matches
  // the current role's company, and (2) the topcard company chip. Strictly
  // URL-derived — no name-to-slug guessing — so membership stays a guarantee.
  function deriveOwnCompanySlugs(name, experience) {
    const slugs = new Set();
    const exp = experience || [];
    const currentName = ((exp[0] && exp[0].company) || '').trim().toLowerCase();
    exp.forEach(e => {
      const s = companySlugFromUrl(e.company_linkedin_url);
      if (s && currentName && ((e.company || '').trim().toLowerCase() === currentName)) slugs.add(s);
    });
    const chip = companySlugFromTopcardChip(name);
    if (chip) slugs.add(chip);
    return slugs;
  }

  function captureFullProfile() {
    const basics     = extractProfileInfo();
    // Exclude rep-suppressed items from the SAVED arrays (they stay in
    // slot.value for the panel's "removed — Restore" row, but must not be
    // written). The companion `edits.suppress` directive tells the server to
    // record the suppression so a later scrape can't resurrect them.
    const expSlot    = captureState.experience;
    const eduSlot    = captureState.education;
    const experience = (expSlot.value || []).filter(it => !isSuppressed(expSlot, expKeyOf(it)));
    const education  = (eduSlot.value || []).filter(it => !isSuppressed(eduSlot, eduKeyOf(it)));
    const activity   = captureState.activity.value   || [];

    // Slugs that count as the prospect's current employer (see helper above).
    const ownSlugs = deriveOwnCompanySlugs(basics.name, experience);

    // is_own_company is tri-state:
    //   true     — source is a company page whose slug is the current employer (guaranteed same)
    //   false    — source is a company page whose slug is NOT the employer (guaranteed different)
    //   'unknown'— can't tell: no company slug in source_url (person/feed reposts,
    //              authored posts), or no own-employer slug could be resolved at all.
    const activityEnriched = activity.map(a => {
      const srcSlug = companySlugFromUrl(a.source_url);
      let isOwn;
      if (!srcSlug || ownSlugs.size === 0) isOwn = 'unknown';
      else isOwn = ownSlugs.has(srcSlug);
      return { ...a, source_company_slug: srcSlug || null, is_own_company: isOwn };
    });

    // Per-item merge directives from this session's rep actions (v1.22).
    // null when the rep took no lock/remove actions → payload identical to before.
    const edits = buildEditsPayload();

    return {
      linkedin_url: basics.linkedinUrl,
      fields: {
        full_name:  basics.name     || null,
        headline:   basics.title    || null,
        location:   basics.location || null,
        about:      captureState.about.value      || null,
        experience: experience,
        education:  education,
        activity:   activityEnriched,
      },
      edits,
      counts: {
        about:      captureState.about.value ? 1 : 0,
        experience: experience.length,
        education:  education.length,
        activity:   activityEnriched.length,
      },
      // A snapshot of capture progress, so callers can warn the user about
      // sections that haven't loaded yet.
      progress: {
        about:      captureState.about.status,
        experience: captureState.experience.status,
        education:  captureState.education.status,
        activity:   captureState.activity.status,
      },
    };
  }

  // ── Profile export (v1.15) ───────────────────────────────────────────────────
  // Turn the captured profile (captureFullProfile() shape) into a human-readable
  // text block or a tidy long-format CSV the rep can drop into a sheet. This is
  // the "export individual signals" step; company-level signals live elsewhere.

  function csvEscape(v) {
    const s = String(v == null ? '' : v);
    return /[",\n\r]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
  }

  function profileToText(p) {
    const f = p.fields || {};
    const L = [];
    L.push(`LinkedIn Profile — ${f.full_name || 'Unknown'}`);
    if (f.headline) L.push(f.headline);
    if (f.location) L.push(f.location);
    if (p.linkedin_url) L.push(p.linkedin_url);
    L.push(`Exported ${new Date().toLocaleString()}`);
    L.push('');
    if (f.about) { L.push('ABOUT'); L.push(String(f.about).trim()); L.push(''); }

    const exp = f.experience || [];
    if (exp.length) {
      L.push(`EXPERIENCE (${exp.length})`);
      exp.forEach(e => {
        const dates = [e.start_date, e.end_date].filter(Boolean).join(' – ');
        const dur = e.duration_months
          ? ` (${Math.floor(e.duration_months / 12)}y ${e.duration_months % 12}m)` : '';
        L.push(`• ${[e.title, e.company].filter(Boolean).join(' @ ')}${dates ? ' — ' + dates : ''}${dur}`);
        if (e.location) L.push(`  ${e.location}`);
        if (e.description) L.push('  ' + String(e.description).trim().replace(/\n/g, '\n  '));
      });
      L.push('');
    }

    const edu = f.education || [];
    if (edu.length) {
      L.push(`EDUCATION (${edu.length})`);
      edu.forEach(e => {
        const yrs = [e.start_year, e.end_year].filter(Boolean).join(' – ');
        const deg = [e.degree, e.field_of_study].filter(Boolean).join(', ');
        L.push(`• ${e.school || ''}${deg ? ' — ' + deg : ''}${yrs ? ' (' + yrs + ')' : ''}`);
      });
      L.push('');
    }

    const act = f.activity || [];
    if (act.length) {
      // Engagement-type label from kind/action — makes liked vs reposted vs
      // commented vs authored unmistakable.
      const engLabel = a => {
        if (a.kind === 'comment') return 'Commented';
        if (a.kind === 'reaction') return a.action && a.action !== 'reacted' ? `Reacted (${a.action})` : 'Reacted / Liked';
        if (a.action === 'quoted_repost') return 'Reposted with own comment';
        if (a.action === 'reposted') return 'Reposted';
        return 'Posted (authored)';
      };
      // At-a-glance breakdown so the reader sees the posture immediately.
      const tally = {};
      act.forEach(a => { const l = engLabel(a); tally[l] = (tally[l] || 0) + 1; });
      const summary = Object.entries(tally).map(([k, n]) => `${n} ${k.toLowerCase()}`).join(', ');
      L.push(`ACTIVITY (${act.length}) — ${summary}`);
      L.push('');

      act.forEach(a => {
        const when = a.relative_time ? ` · ${a.relative_time}` : '';
        // Whose post is being amplified, when we can tell for certain.
        let origin = '';
        if (a.is_own_company === true)  origin = ' — own employer';
        else if (a.is_own_company === false) origin = a.source_company_slug ? ` — other company (${a.source_company_slug})` : ' — other company';
        else if (a.source_company_slug) origin = ` — from company ${a.source_company_slug} (own-employer match undetermined)`;
        else if (a.action === 'reposted' || a.kind === 'reaction' || a.action === 'quoted_repost') origin = ' — source company unknown';
        L.push(`• ${engLabel(a)}${when}${origin}`);
        if (a.action === 'quoted_repost') {
          if (a.commentary) L.push(`  Their words: ${String(a.commentary).trim()}`);
          const shared = a.quoted_text || a.text;
          if (shared) L.push(`  Shared post${a.quoted_author ? ' from ' + a.quoted_author : ''} (NOT their words): ${String(shared).trim()}`);
        } else if (a.action === 'reposted' || a.kind === 'reaction') {
          if (a.text) L.push(`  Shared/engaged content${a.quoted_author ? ' from ' + a.quoted_author : ''} (NOT their words): ${String(a.text).trim()}`);
        } else if (a.kind === 'comment') {
          if (a.text) L.push(`  Their comment: ${String(a.text).trim()}`);
          if (a.parent_post_summary && a.parent_post_summary !== a.text) L.push(`  On post: ${String(a.parent_post_summary).trim()}`);
        } else {
          if (a.text) L.push(`  ${String(a.text).trim()}`);
        }
        if (a.source_url) L.push(`  ${a.source_url}`);
      });
      L.push('');
    }
    return L.join('\n');
  }

  // Long/tidy CSV: section,index,field,value — flattens any shape, imports
  // anywhere, and is easy to eyeball for verification.
  function profileToCSV(p) {
    const f = p.fields || {};
    const rows = [['section', 'index', 'field', 'value']];
    const add = (section, index, field, value) => {
      if (value == null || value === '') return;
      rows.push([section, String(index), field, String(value)]);
    };
    add('profile', '', 'full_name', f.full_name);
    add('profile', '', 'headline', f.headline);
    add('profile', '', 'location', f.location);
    add('profile', '', 'linkedin_url', p.linkedin_url);
    add('profile', '', 'about', f.about);
    (f.experience || []).forEach((e, i) =>
      ['title', 'company', 'company_linkedin_url', 'location', 'start_date', 'end_date', 'duration_months', 'description']
        .forEach(k => add('experience', i + 1, k, e[k])));
    (f.education || []).forEach((e, i) =>
      ['school', 'degree', 'field_of_study', 'start_year', 'end_year']
        .forEach(k => add('education', i + 1, k, e[k])));
    (f.activity || []).forEach((a, i) =>
      ['kind', 'action', 'is_own_company', 'source_company_slug', 'relative_time', 'text', 'quoted_author', 'quoted_text', 'parent_post_summary', 'source_url']
        .forEach(k => add('activity', i + 1, k, a[k])));
    return rows.map(r => r.map(csvEscape).join(',')).join('\r\n');
  }

  function profileBasename(p) {
    const f = p.fields || {};
    let base = String(f.full_name || '').trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
    if (!base) { const m = (p.linkedin_url || '').match(/\/in\/([^/?#]+)/); base = m ? m[1] : 'prospect'; }
    return base + '-linkedin';
  }

  function downloadProfileFile(filename, text, mime) {
    try {
      const blob = new Blob([text], { type: mime + ';charset=utf-8' });
      const url  = URL.createObjectURL(blob);
      const a    = document.createElement('a');
      a.href = url; a.download = filename; a.style.display = 'none';
      document.body.appendChild(a); a.click();
      setTimeout(() => { a.remove(); URL.revokeObjectURL(url); }, 1500);
      return true;
    } catch (_) { return false; }
  }

  async function copyTextToClipboard(text) {
    try { await navigator.clipboard.writeText(text); return true; }
    catch (_) {
      try {
        const ta = document.createElement('textarea');
        ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
        document.body.appendChild(ta); ta.select();
        const ok = document.execCommand('copy'); ta.remove(); return ok;
      } catch (__) { return false; }
    }
  }

  // ── bg messaging helper ──────────────────────────────────────────────────────

  function bgMessage(payload) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(payload, response => {
        if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
        else resolve(response);
      });
    });
  }

  function getStatusIdx(status) {
    return STATUS_ORDER.indexOf(status || '');
  }

  // ── Push-defaults helpers (v1.8) ─────────────────────────────────────────────
  //
  // Mirror of the popup-side helpers. Both files read/write the same key
  // (`gw_push_defaults_<orgId>`) directly via chrome.storage.local — no
  // message round-trip needed. Per-org scoping matters: a rep who has
  // multiple workspaces under one Chrome profile shouldn't see one org's
  // campaign id leak into another.
  //
  // Names are resolved separately via a cached list fetch (see
  // ensurePickerLists below). We don't store names alongside ids in
  // defaults because campaigns and sequences can be renamed in the web
  // app and we'd rather show the current name than a stale one.

  const PUSH_DEFAULTS_KEY_PREFIX = 'gw_push_defaults_';

  function pushDefaultsStorageKey(orgId) {
    return orgId ? `${PUSH_DEFAULTS_KEY_PREFIX}${orgId}` : null;
  }

  function readPushDefaults(orgId) {
    return new Promise(resolve => {
      const key = pushDefaultsStorageKey(orgId);
      if (!key) return resolve({ campaignId: null, sequenceId: null });
      chrome.storage.local.get([key], result => {
        const v = result[key] || {};
        resolve({
          campaignId: v.campaignId || null,
          sequenceId: v.sequenceId || null,
        });
      });
    });
  }

  // org_id is small + stable enough to cache for the lifetime of this
  // content-script instance. GET_IDENTITY is itself cached for 10
  // minutes by the background worker so even a cache miss here is cheap,
  // but storing it avoids re-asking on every render.
  let _orgIdCache = null;
  async function getOrgIdCached() {
    if (_orgIdCache != null) return _orgIdCache;
    try {
      const res = await bgMessage({ type: 'GET_IDENTITY' });
      _orgIdCache = res?.identity?.org_id || null;
    } catch (_) {
      _orgIdCache = null;
    }
    return _orgIdCache;
  }

  // Campaign + sequence lists, fetched lazily on first need (whichever
  // comes first: rendering a target badge that needs names, or opening
  // the inline override). Cached for the lifetime of this LinkedIn page
  // — they're stable enough that a freshly published campaign won't
  // appear until the rep navigates to a new profile, which is fine.
  let _pickerListsCache = null;
  let _pickerListsPromise = null;
  function ensurePickerLists() {
    if (_pickerListsCache) return Promise.resolve(_pickerListsCache);
    if (_pickerListsPromise) return _pickerListsPromise;
    _pickerListsPromise = bgMessage({ type: 'LIST_CAMPAIGNS_AND_SEQUENCES' })
      .then(res => {
        if (res?.ok) {
          _pickerListsCache = {
            campaigns: res.campaigns || [],
            sequences: res.sequences || [],
          };
        } else {
          _pickerListsCache = { campaigns: [], sequences: [], error: res?.error || 'load failed' };
        }
        return _pickerListsCache;
      })
      .catch(err => {
        _pickerListsCache = { campaigns: [], sequences: [], error: err.message };
        return _pickerListsCache;
      });
    return _pickerListsPromise;
  }

  function lookupCampaignName(id) {
    if (!_pickerListsCache || !id) return null;
    return _pickerListsCache.campaigns.find(c => String(c.id) === String(id))?.name || null;
  }
  function lookupSequenceName(id) {
    if (!_pickerListsCache || !id) return null;
    return _pickerListsCache.sequences.find(s => String(s.id) === String(id))?.name || null;
  }

  // ── Build panel shell ────────────────────────────────────────────────────────

  function buildPanel() {
    const el = document.createElement('div');
    el.id = PANEL_ID;
    el.style.cssText = `
      position: fixed; top: 72px; right: 16px; width: 290px;
      background: #ffffff; border: 1px solid #e2e8f0;
      border-radius: 10px; box-shadow: 0 4px 20px rgba(0,0,0,0.10);
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      font-size: 13px; color: #1a202c; z-index: 9999; overflow: hidden;
      max-height: calc(100vh - 90px); overflow-y: auto;
    `;
    return el;
  }

  function renderHeader(panel, name, title) {
    const header = document.createElement('div');
    header.style.cssText = `background:${TEAL};padding:9px 13px;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:10;`;
    const iconUrl = safeGetURL('icons/gw-flame.png');
    header.innerHTML = `
      <div style="display:flex;align-items:center;gap:6px;">
        ${iconUrl
          ? `<img src="${iconUrl}" alt="" width="16" height="16" style="display:block;width:16px;height:16px;border-radius:3px;" />`
          : `<span style="background:#fff;color:${TEAL};font-size:9px;font-weight:700;padding:1px 5px;border-radius:3px;">GW</span>`}
        <span style="color:#fff;font-size:12px;font-weight:600;">GoWarmCRM</span>
      </div>
      <div style="display:flex;align-items:center;gap:2px;">
        <button id="gw-min" title="Minimize" aria-label="Minimize" style="background:none;border:none;color:#fff;font-size:18px;cursor:pointer;line-height:1;padding:0 4px;opacity:0.85;">–</button>
        <button id="gw-close" title="Close" aria-label="Close" style="background:none;border:none;color:#fff;font-size:18px;cursor:pointer;line-height:1;padding:0 2px 0 0;opacity:0.85;">×</button>
      </div>
    `;
    panel.appendChild(header);

    // Identity subline — populated asynchronously by renderIdentitySubline().
    // Reserved here so it sits between the header and the name row even
    // before /verify resolves. Hidden until populated.
    const idLine = document.createElement('div');
    idLine.id = 'gw-identity-subline';
    idLine.style.cssText = 'display:none;padding:5px 13px;background:#F0FDFA;border-bottom:1px solid #CCFBF1;font-size:10px;color:#0F766E;line-height:1.3;';
    panel.appendChild(idLine);

    // Debug IDs strip — populated by renderDebugIds() once we have IDs to
    // show AND the debug flag is on. Sits between the identity subline and
    // the name row so it's visible without scrolling. Hidden by default;
    // takes zero space when not shown.
    const dbgLine = document.createElement('div');
    dbgLine.id = 'gw-debug-ids';
    dbgLine.style.cssText = 'display:none;padding:4px 13px;background:#FEF3C7;border-bottom:1px solid #FDE68A;font-size:10px;color:#78350F;line-height:1.3;font-family:ui-monospace,SFMono-Regular,Menlo,monospace;letter-spacing:0.02em;';
    panel.appendChild(dbgLine);

    const nameRow = document.createElement('div');
    nameRow.style.cssText = 'padding:10px 13px 8px;border-bottom:1px solid #f1f5f9;';
    nameRow.innerHTML = `
      <div style="font-weight:600;font-size:14px;">${escHtml(name)}</div>
      ${title ? `<div style="font-size:11px;color:#64748b;margin-top:1px;">${escHtml(title)}</div>` : ''}
    `;
    panel.appendChild(nameRow);

    panel.querySelector('#gw-close').addEventListener('click', () => { document.getElementById(FEED_ID)?.remove(); panel.remove(); });
    panel.querySelector('#gw-min').addEventListener('click', () => minimizePanel(panel));
  }

  // ── Minimize / restore ───────────────────────────────────────────────────────
  // Collapses the panel to a small floating pill (and hides any open feed
  // overlay) without tearing down the panel's state. Clicking the pill — or
  // navigating while minimized and clicking it again — restores the panel.
  // The state is remembered for the session and across reloads via
  // chrome.storage.local, so once minimized the extension stays out of the
  // way as the rep browses profiles, until they choose to bring it back.

  function minimizePanel(panel) {
    panelMinimized = true;
    try { chrome.storage.local.set({ [MINIMIZED_KEY]: '1' }); } catch (_) { /* swallow */ }
    if (panel) panel.style.display = 'none';
    const feed = document.getElementById(FEED_ID);
    if (feed) feed.style.display = 'none';
    showPill();
  }

  function restorePanel() {
    panelMinimized = false;
    try { chrome.storage.local.remove([MINIMIZED_KEY]); } catch (_) { /* swallow */ }
    document.getElementById(PILL_ID)?.remove();
    const panel = document.getElementById(PANEL_ID);
    if (panel) panel.style.display = '';   // back to the cssText-defined block
    const feed = document.getElementById(FEED_ID);
    if (feed) feed.style.display = '';
  }

  // Builds (once) the collapsed pill that lives where the panel header would
  // be. Idempotent — if a pill is already on-screen this is a no-op.
  function showPill() {
    if (document.getElementById(PILL_ID)) return;
    const pill = document.createElement('div');
    pill.id = PILL_ID;
    pill.title = 'Open GoWarmCRM';
    pill.setAttribute('role', 'button');
    pill.setAttribute('aria-label', 'Open GoWarmCRM panel');
    pill.style.cssText = `
      position: fixed; top: 72px; right: 16px; z-index: 9999;
      display: flex; align-items: center; gap: 6px;
      background: ${TEAL}; color: #fff; cursor: pointer;
      padding: 7px 11px; border-radius: 18px;
      box-shadow: 0 4px 14px rgba(0,0,0,0.18);
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      font-size: 12px; font-weight: 600; line-height: 1; user-select: none;
      transition: box-shadow 120ms ease, transform 120ms ease;
    `;
    const iconUrl = safeGetURL('icons/gw-flame.png');
    pill.innerHTML = `
      ${iconUrl
        ? `<img src="${iconUrl}" alt="" width="18" height="18" style="display:block;width:18px;height:18px;border-radius:4px;" />`
        : `<span style="background:#fff;color:${TEAL};font-size:9px;font-weight:700;padding:1px 5px;border-radius:3px;">GW</span>`}
      <span>GoWarmCRM</span>
    `;
    pill.addEventListener('mouseenter', () => { pill.style.boxShadow = '0 6px 18px rgba(0,0,0,0.24)'; pill.style.transform = 'translateY(-1px)'; });
    pill.addEventListener('mouseleave', () => { pill.style.boxShadow = '0 4px 14px rgba(0,0,0,0.18)'; pill.style.transform = 'none'; });
    pill.addEventListener('click', restorePanel);
    document.body.appendChild(pill);
  }

  // Populates the identity subline below the header. Called from init()
  // once GET_IDENTITY returns. Shows "Saving to <org> · <email>" so a
  // rep with multiple workspaces can tell at a glance which one their
  // capture will land in.
  function renderIdentitySubline(panel, identity) {
    const el = panel.querySelector('#gw-identity-subline');
    if (!el || !identity) return;
    const org   = identity.org_name || (identity.org_id ? `Org #${identity.org_id}` : 'Unknown workspace');
    const email = identity.email    || '';
    el.textContent = `Saving to ${org}${email ? ` · ${email}` : ''}`;
    el.title       = email;
    el.style.display = 'block';
  }

  // Populates the debug-IDs strip below the identity subline. Called
  // anywhere DB IDs become available (on prospect lookup, on upsert
  // response). Only renders if debugMode is true; otherwise the strip
  // stays hidden and the strip element is invisible (display:none).
  //
  // ids: { profile_id, prospect_id, account_id } — any subset is fine;
  //      keys with null/undefined values are omitted from the rendered
  //      strip. If all three are null, the strip stays hidden.
  //
  // The most recent non-empty `ids` is also cached in lastDebugIds so
  // the Ctrl+Shift+D shortcut can replay them on toggle without a
  // re-fetch. Empty calls do not overwrite the cache.
  function renderDebugIds(panel, ids) {
    if (!panel) return;
    const el = panel.querySelector('#gw-debug-ids');
    if (!el) return;
    // Merge new ids over the cache so partial calls (e.g. just profile_id
    // from GET_LINKEDIN_PROFILE) don't lose previously-known prospect_id
    // and account_id from the LOOKUP_PROSPECT response.
    if (ids && (ids.profile_id != null || ids.prospect_id != null || ids.account_id != null)) {
      lastDebugIds = {
        profile_id:  ids.profile_id  != null ? ids.profile_id  : lastDebugIds.profile_id,
        prospect_id: ids.prospect_id != null ? ids.prospect_id : lastDebugIds.prospect_id,
        account_id:  ids.account_id  != null ? ids.account_id  : lastDebugIds.account_id,
      };
    }
    if (!debugMode) {
      el.style.display = 'none';
      return;
    }
    const parts = [];
    if (lastDebugIds.profile_id   != null) parts.push(`profile: ${lastDebugIds.profile_id}`);
    if (lastDebugIds.prospect_id  != null) parts.push(`prospect: ${lastDebugIds.prospect_id}`);
    if (lastDebugIds.account_id   != null) parts.push(`account: ${lastDebugIds.account_id}`);
    if (parts.length === 0) {
      el.style.display = 'none';
      return;
    }
    el.textContent   = `DEBUG · ${parts.join(' · ')}`;
    el.style.display = 'block';
  }

  // Format a stored timestamp as "3 days ago", "just now", "Mar 14".
  // Used to show last-captured times in the delta-refresh badges.
  function formatRelative(iso) {
    if (!iso) return '';
    const then = new Date(iso);
    if (isNaN(then.getTime())) return '';
    const diffSec = Math.floor((Date.now() - then.getTime()) / 1000);
    if (diffSec < 60)        return 'just now';
    if (diffSec < 3600)      return `${Math.floor(diffSec / 60)}m ago`;
    if (diffSec < 86400)     return `${Math.floor(diffSec / 3600)}h ago`;
    if (diffSec < 86400 * 7) return `${Math.floor(diffSec / 86400)}d ago`;
    if (diffSec < 86400 * 30) return `${Math.floor(diffSec / (86400 * 7))}w ago`;
    return then.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
  }

  // ── State views ──────────────────────────────────────────────────────────────

  function renderLoading(panel) {
    const d = document.createElement('div');
    d.style.cssText = 'padding:20px;text-align:center;color:#94a3b8;font-size:12px;';
    d.textContent = 'Looking up prospect…';
    panel.appendChild(d);
  }

  function renderNotFound(panel, profileInfo) {
    const { name = '', title = '', company = '', location = '', degree = null } = profileInfo || {};
    const linkedinUrl = getCurrentLinkedInUrl();

    const nameParts  = name.trim().split(/\s+/);
    const firstName  = nameParts[0] || '';
    const lastName   = nameParts.slice(1).join(' ') || '';

    const d = document.createElement('div');
    d.style.cssText = 'padding:14px 13px;';

    const inp = (id, label, val = '') => `
      <div style="margin-bottom:7px;">
        <label style="font-size:10px;color:#64748b;display:block;margin-bottom:2px;">${label}</label>
        <input id="${id}" value="${escHtml(val)}" style="width:100%;padding:5px 7px;border:1px solid #e2e8f0;border-radius:5px;font-size:12px;color:#1a202c;box-sizing:border-box;" />
      </div>
    `;

    // Inputs first, then a placeholder for the target badge (filled in
    // asynchronously once we've resolved orgId + defaults + list names),
    // then the Add button. The badge placeholder reserves layout space
    // so the button doesn't jump on async fill — a small grey
    // "Resolving target…" line until the real badge renders.
    d.innerHTML = `
      <div style="font-size:11px;color:#94a3b8;margin-bottom:10px;">Not in your CRM. Add prospect:</div>
      ${inp('gw-add-firstname', 'First name *', firstName)}
      ${inp('gw-add-lastname',  'Last name',    lastName)}
      ${inp('gw-add-headline',  'LinkedIn Headline', title)}
      ${inp('gw-add-company',   'Company name', company)}
      ${inp('gw-add-email',     'Work email',   '')}
      ${inp('gw-add-location',  'Location',     location)}
      <div id="gw-target-slot" style="margin-top:10px;margin-bottom:7px;font-size:11px;color:#94a3b8;">Resolving target…</div>
      <button id="gw-add-btn" style="width:100%;padding:7px;background:${TEAL};color:#fff;border:none;border-radius:6px;font-size:12px;font-weight:600;cursor:pointer;margin-top:6px;">Add to GoWarmCRM</button>
      <div id="gw-add-feedback" style="margin-top:6px;font-size:11px;display:none;"></div>
    `;
    panel.appendChild(d);

    // Show progressive capture rows below the add form (no separate save
    // button — the "Add to GoWarmCRM" button below handles both: it creates
    // the prospect AND upserts the captured profile data linked to it).
    renderCaptureSection(panel, /* prospect */ null, { hideSaveButton: true });

    const btn       = d.querySelector('#gw-add-btn');
    const feedback  = d.querySelector('#gw-add-feedback');
    const targetSlot = d.querySelector('#gw-target-slot');

    setTimeout(() => {
      const focusEl = company ? '#gw-add-email' : '#gw-add-company';
      d.querySelector(focusEl)?.focus();
    }, 50);

    // ── Per-form target state ────────────────────────────────────────────────
    // Mutable state describing where this prospect will be pushed. Starts
    // as null/null and is filled by the async init below from the rep's
    // push-defaults. Inline override can change it without touching the
    // stored defaults — those are settings-only.
    const target = {
      campaignId: null,
      sequenceId: null,
      // 'default' = inherited from settings; 'override' = user changed it
      // on this form. We track this so the badge can show a small hint
      // when the rep has deviated from their defaults ("one-off").
      source:     'default',
    };

    (async () => {
      const orgId = await getOrgIdCached();
      const defaults = await readPushDefaults(orgId);
      target.campaignId = defaults.campaignId;
      target.sequenceId = defaults.sequenceId;
      // We need names to render the badge — kick off list fetch in
      // parallel with rendering a name-less skeleton, then re-render
      // when names are available. Most reps hit profiles repeatedly so
      // the second render is the common path.
      renderTargetBadge();
      if (target.campaignId || target.sequenceId) {
        await ensurePickerLists();
        renderTargetBadge();
      }
    })();

    // Renders the badge (or the inline override panel, depending on
    // mode) into the slot. Called on initial load, after defaults
    // resolve, and after the rep cancels/confirms the override.
    function renderTargetBadge() {
      const campName = target.campaignId ? (lookupCampaignName(target.campaignId) || `#${target.campaignId}`) : null;
      const seqName  = target.sequenceId ? (lookupSequenceName(target.sequenceId) || `#${target.sequenceId}`) : null;

      // Three flavors:
      //   1. Both set → teal "Will add to" badge with campaign + sequence
      //   2. Just campaign set → teal badge with "no sequence" subtitle
      //   3. Neither set → gray "standalone prospect" badge
      // (We don't have a "just sequence, no campaign" variant separately
      // styled — it falls under flavor 1 with the campaign line blank.)
      if (campName || seqName) {
        const oneOffHint = target.source === 'override'
          ? `<span style="font-size:9px;color:#92400e;background:#FEF3C7;padding:1px 5px;border-radius:8px;margin-left:6px;vertical-align:1px;">one-off</span>`
          : '';
        targetSlot.innerHTML = `
          <div style="background:#F0FDFA;border:1px solid #CCFBF1;border-radius:5px;padding:7px 9px;">
            <div style="font-size:9px;color:#0F766E;text-transform:uppercase;letter-spacing:0.05em;margin-bottom:3px;">
              Will add to${oneOffHint}
            </div>
            <div style="font-size:11px;color:#134E4A;line-height:1.4;">
              ${campName ? `<div><strong style="font-weight:600;">${escHtml(campName)}</strong></div>` : `<div style="color:#64748b;font-style:italic;">No campaign</div>`}
              ${seqName  ? `<div style="color:#0F766E;">↳ ${escHtml(seqName)}</div>` : `<div style="color:#64748b;font-style:italic;">↳ No sequence</div>`}
            </div>
            <div style="margin-top:5px;">
              <a id="gw-target-change" style="font-size:10px;color:#0F766E;text-decoration:underline;cursor:pointer;">change</a>
            </div>
          </div>
        `;
      } else {
        targetSlot.innerHTML = `
          <div style="background:#F8FAFC;border:1px solid #E2E8F0;border-radius:5px;padding:7px 9px;">
            <div style="font-size:11px;color:#64748b;line-height:1.4;">
              Will save as a <strong style="color:#334155;font-weight:600;">standalone prospect</strong>
            </div>
            <div style="margin-top:5px;">
              <a id="gw-target-change" style="font-size:10px;color:#0F766E;text-decoration:underline;cursor:pointer;">add to campaign / sequence</a>
            </div>
          </div>
        `;
      }
      targetSlot.querySelector('#gw-target-change')?.addEventListener('click', openOverride);
    }

    // Replaces the badge with an inline override panel. Two dropdowns,
    // Cancel + Use these buttons. Override is local — it does NOT change
    // the saved defaults (those live in Settings).
    async function openOverride() {
      // Show loading state immediately, then upgrade once lists are in.
      targetSlot.innerHTML = `<div style="font-size:11px;color:#94a3b8;">Loading campaigns + sequences…</div>`;
      const lists = await ensurePickerLists();

      if (lists.error && !lists.campaigns.length && !lists.sequences.length) {
        targetSlot.innerHTML = `
          <div style="background:#FEF2F2;border:1px solid #FECACA;border-radius:5px;padding:7px 9px;font-size:11px;color:#991B1B;">
            Could not load campaigns/sequences. <a id="gw-target-back" style="color:#991B1B;text-decoration:underline;cursor:pointer;">Back</a>
          </div>`;
        targetSlot.querySelector('#gw-target-back')?.addEventListener('click', renderTargetBadge);
        return;
      }

      const orgId = await getOrgIdCached();
      const defaults = await readPushDefaults(orgId);

      // Mark each option to indicate which one is the saved default so
      // the rep can tell what "back to default" would mean. The label
      // suffix is the minimum-noise approach (vs a separate row of
      // "(default)" badges).
      const campOpts = ['<option value="">No campaign</option>']
        .concat(lists.campaigns.map(c => {
          const isDefault = String(c.id) === String(defaults.campaignId);
          return `<option value="${c.id}"${String(c.id) === String(target.campaignId) ? ' selected' : ''}>${escHtml(c.name)}${isDefault ? ' — default' : ''}</option>`;
        }));
      const seqOpts = ['<option value="">No sequence</option>']
        .concat(lists.sequences.map(s => {
          const isDefault = String(s.id) === String(defaults.sequenceId);
          const stepLabel = s.step_count ? ` (${s.step_count} step${s.step_count === 1 ? '' : 's'})` : '';
          return `<option value="${s.id}"${String(s.id) === String(target.sequenceId) ? ' selected' : ''}>${escHtml(s.name)}${stepLabel}${isDefault ? ' — default' : ''}</option>`;
        }));

      targetSlot.innerHTML = `
        <div style="background:#FFFBEB;border:1px solid #FDE68A;border-radius:5px;padding:9px 10px;">
          <div style="font-size:9px;color:#78350F;text-transform:uppercase;letter-spacing:0.05em;margin-bottom:7px;">
            One-off for this prospect
          </div>
          <div style="margin-bottom:7px;">
            <label style="font-size:10px;color:#64748b;display:block;margin-bottom:2px;">Campaign</label>
            <select id="gw-override-camp" style="width:100%;padding:4px 6px;border:1px solid #e2e8f0;border-radius:4px;font-size:11px;background:#fff;">${campOpts.join('')}</select>
          </div>
          <div style="margin-bottom:8px;">
            <label style="font-size:10px;color:#64748b;display:block;margin-bottom:2px;">Sequence</label>
            <select id="gw-override-seq" style="width:100%;padding:4px 6px;border:1px solid #e2e8f0;border-radius:4px;font-size:11px;background:#fff;">${seqOpts.join('')}</select>
          </div>
          <div style="display:flex;gap:6px;">
            <button id="gw-override-cancel" style="flex:1;padding:5px;background:#fff;border:1px solid #e2e8f0;border-radius:4px;font-size:10px;cursor:pointer;color:#334155;">Cancel</button>
            <button id="gw-override-apply" style="flex:1;padding:5px;background:${TEAL};color:#fff;border:none;border-radius:4px;font-size:10px;cursor:pointer;font-weight:600;">Use these</button>
          </div>
          <div style="font-size:10px;color:#78350F;margin-top:6px;line-height:1.3;">
            Your saved defaults aren't changed. To change them everywhere, use the popup's Settings.
          </div>
        </div>
      `;

      const campEl = targetSlot.querySelector('#gw-override-camp');
      const seqEl  = targetSlot.querySelector('#gw-override-seq');

      // Auto-sync: picking a campaign suggests its default sequence,
      // matching the Settings UX. We don't track "user manually picked
      // sequence" in this short-lived override panel — it's open for
      // seconds at most and the rep is actively making choices.
      campEl.addEventListener('change', () => {
        const picked = lists.campaigns.find(c => String(c.id) === campEl.value);
        const defSeqId = picked?.default_sequence_id;
        if (defSeqId && lists.sequences.some(s => String(s.id) === String(defSeqId))) {
          seqEl.value = String(defSeqId);
        }
      });

      targetSlot.querySelector('#gw-override-cancel').addEventListener('click', renderTargetBadge);
      targetSlot.querySelector('#gw-override-apply').addEventListener('click', () => {
        const newCamp = campEl.value ? parseInt(campEl.value, 10) : null;
        const newSeq  = seqEl.value  ? parseInt(seqEl.value, 10)  : null;
        // Mark as override only if the rep actually changed something
        // away from the defaults. Picking the same campaign/sequence as
        // the default isn't an override — it's just a re-confirmation.
        const isOverride = (newCamp || null) !== (defaults.campaignId || null)
                        || (newSeq  || null) !== (defaults.sequenceId || null);
        target.campaignId = newCamp;
        target.sequenceId = newSeq;
        target.source     = isOverride ? 'override' : 'default';
        renderTargetBadge();
      });
    }

    btn.addEventListener('click', async () => {
      const fn = d.querySelector('#gw-add-firstname').value.trim();
      const ln = d.querySelector('#gw-add-lastname').value.trim();
      let   co = d.querySelector('#gw-add-company').value.trim();
      const em = d.querySelector('#gw-add-email').value.trim();

      if (!fn) {
        feedback.style.cssText = 'font-size:11px;display:block;color:#dc2626;margin-top:4px;';
        feedback.textContent = 'First name is required';
        return;
      }

      btn.disabled    = true;
      btn.textContent = 'Adding…';
      feedback.style.display = 'none';

      // Make sure experience data is captured before we resolve the
      // company URL from it. If the user clicked Add without scrolling
      // down, this scrolls the experience section into view, waits for
      // LinkedIn to render it, captures, and restores scroll position.
      // No-op (and no scroll-jump) if experience was already captured.
      //
      // v1.21: first run the full completeness pass — hydrate every lazy
      // section and expand collapsed "see more" descriptions — so the
      // captured profile is as complete as possible. It writes captureState
      // directly (strictly additive: never shrinks existing data), which
      // makes the ensureExperienceCaptured() call below a fast no-op.
      try { await hydrateAndExpandProfile(); } catch (_) { /* best effort */ }
      await ensureExperienceCaptured();

      // If the company field is still empty, experience may now have
      // arrived via the auto-scroll above even though it was missing when
      // the form was first rendered (common on profiles whose headline
      // names no employer — e.g. "Investor"). Backfill from the current
      // experience entry so both the payload and the visible field show
      // the company.
      if (!co) {
        try {
          const exp = getExperience();
          const isCurrentEntry = (e) => {
            const ed = e?.end_date;
            if (ed == null) return true;
            const s = String(ed).trim().toLowerCase();
            return s === '' || s === 'present';
          };
          const cur = exp.find(isCurrentEntry) || exp[0];
          if (cur?.company) {
            co = cur.company.trim();
            const field = d.querySelector('#gw-add-company');
            if (field && !field.value.trim()) field.value = co;
          }
        } catch (_) { /* leave co empty — backend still gets the rest */ }
      }

      // Resolve the employer's LinkedIn company URL from the experience
      // section. By this point experience has been captured if it exists
      // on the profile at all (see ensureExperienceCaptured above).
      //
      // A profile can have MULTIPLE concurrent roles (end_date null) — e.g.
      // a CEO who is also a board member elsewhere. Picking "first current
      // entry in DOM order" is unstable and frequently picks the wrong
      // company (or one with no company_linkedin_url at all, which then
      // creates a catchall account with no identifier for enrichment).
      //
      // Instead, anchor on `co` — the company name in the form, which is
      // pre-filled from the profile top card (LinkedIn's notion of the
      // person's PRIMARY company) and may have been corrected by the user.
      // Among current entries, prefer the one whose company name matches
      // `co`. Fall back through progressively looser strategies so we still
      // send *something* sensible when there's no clean match.
      let currentCompanyLinkedInUrl;
      try {
        const exp = getExperience();
        const isCurrent = (e) => {
          const ed = e?.end_date;
          if (ed == null) return true;
          const s = String(ed).trim().toLowerCase();
          return s === '' || s === 'present';
        };

        // Normalize for comparison: lowercase, trim, drop common corporate
        // suffixes and punctuation so "VitalEdge Technologies" matches
        // "VitalEdge Technologies, Inc." etc.
        const normCo = (s) => String(s || '')
          .toLowerCase()
          .replace(/[.,]/g, ' ')
          .replace(/\b(inc|llc|ltd|limited|corp|corporation|co|gmbh|plc|technologies|technology)\b/g, ' ')
          .replace(/\s+/g, ' ')
          .trim();

        const currentEntries = exp.filter(isCurrent);
        const coNorm         = normCo(co);

        // Strategy 1: a current entry whose company name matches the form's
        // company AND that actually has a company URL.
        let chosen = coNorm
          ? currentEntries.find(e => e.company_linkedin_url && normCo(e.company) === coNorm)
          : null;

        // Strategy 2: any current entry matching the company name (even if
        // it has no URL — at least it's the right company).
        if (!chosen && coNorm) {
          chosen = currentEntries.find(e => normCo(e.company) === coNorm);
        }

        // Strategy 3: the first current entry that at least HAS a URL —
        // better than an entry we know is URL-less.
        if (!chosen || !chosen.company_linkedin_url) {
          chosen = currentEntries.find(e => e.company_linkedin_url) || chosen;
        }

        // Strategy 4: original behavior — first current, else first overall.
        if (!chosen) {
          chosen = currentEntries[0] || exp[0];
        }

        currentCompanyLinkedInUrl = chosen?.company_linkedin_url || undefined;
      } catch (_) {
        currentCompanyLinkedInUrl = undefined;
      }

      try {
        const memberUrn = await currentProfileMemberUrn();   // v1.20: live-resolved fsd_profile URN
        const res = await bgMessage({
          type:               'ADD_PROSPECT',
          firstName:          fn,
          lastName:           ln,
          linkedinHeadline:   d.querySelector('#gw-add-headline')?.value?.trim() || undefined,
          companyName:        co || undefined,
          companyLinkedInUrl: currentCompanyLinkedInUrl,
          email:              em || undefined,
          linkedinUrl:        linkedinUrl,
          location:           d.querySelector('#gw-add-location')?.value?.trim() || undefined,
          source:             'linkedin_extension',
          // v1.20: durable fsd_profile URN (live-resolved from LinkedIn by
          // publicId). Backend stores on prospects.member_urn and dedups
          // URN-first. undefined when unresolved — send path resolves live.
          memberUrn:          memberUrn || undefined,
          // The chosen target — either inherited from defaults or
          // overridden inline. Backend treats both as nullable and
          // enrolls into the sequence in the same request when set.
          campaignId:         target.campaignId,
          sequenceId:         target.sequenceId,
        });

        if (!res.ok) throw new Error(res.error);

        // Also upsert whatever profile data has been captured so far,
        // linked to the new prospect. Best-effort — failures here don't
        // block the "Added successfully" feedback for the prospect itself.
        const captured = captureFullProfile();
        if ((captured.counts.about + captured.counts.experience +
             captured.counts.education + captured.counts.activity) > 0 || captured.edits) {
          bgMessage({
            type:        'UPSERT_LINKEDIN_PROFILE',
            linkedinUrl: captured.linkedin_url,
            fields:      captured.fields,
            edits:       captured.edits || undefined,
            linkTo:      { entity_type: 'prospects', entity_id: res.prospect.id },
            memberUrn:   memberUrn || undefined,
          })
            .then((upsertRes) => {
              // Refresh the debug-IDs strip with the now-confirmed IDs.
              if (upsertRes?.ok) {
                clearPendingEdits();   // server persisted them — reset session directives
                renderDebugIds(panel, {
                  profile_id:  upsertRes.profile_id || upsertRes.profile?.id || null,
                  prospect_id: res.prospect.id,
                  account_id:  upsertRes.account_id || res.prospect.account?.id || res.prospect.account_id || null,
                });
              }
            })
            .catch(() => { /* non-fatal */ });
        } else {
          // No profile data to upsert, but we still have a new prospect.
          // Surface its IDs in the debug strip without waiting for upsert.
          renderDebugIds(panel, {
            prospect_id: res.prospect.id,
            account_id:  res.prospect.account?.id || res.prospect.account_id || null,
          });
        }

        // Success feedback distinguishes three cases:
        //   1. No sequence requested        → "Added successfully!"
        //   2. Sequence requested + enrolled → "Added · enrolled in <name>"
        //   3. Sequence requested + failed   → "Added (enrollment failed: …)"
        // Failures are surfaced amber inline (not thrown) because the
        // prospect insert IS the primary action — losing it because
        // enrollment failed would be worse than continuing without it.
        let successMsg = 'Added successfully!';
        let successColor = '#059669';
        if (target.sequenceId) {
          if (res.enrollment) {
            const seqName = lookupSequenceName(target.sequenceId) || 'sequence';
            successMsg = `Added · enrolled in "${seqName}"`;
          } else if (res.enrollmentError) {
            successMsg = `Added (enrollment failed: ${res.enrollmentError})`;
            successColor = '#b45309';
          } else {
            // No enrollment row and no error — most likely already
            // enrolled (ON CONFLICT DO NOTHING). Rare for a brand-new
            // prospect; surface it honestly anyway.
            successMsg = 'Added (sequence enrollment skipped)';
            successColor = '#b45309';
          }
        }
        feedback.style.cssText = `font-size:11px;display:block;color:${successColor};margin-top:4px;`;
        feedback.textContent   = successMsg;

        // Re-render as a found prospect after short delay
        setTimeout(() => {
          // Clear the not-found form and capture rows; renderProspect will
          // rebuild including its own capture section.
          while (panel.children.length > 2) panel.lastChild.remove();
          renderProspect(panel, res.prospect);
        }, 1000);

      } catch (err) {
        btn.disabled    = false;
        btn.textContent = 'Add to GoWarmCRM';
        feedback.style.cssText = 'font-size:11px;display:block;color:#dc2626;margin-top:4px;';
        feedback.textContent   = err.message;
      }
    });
  }

  function renderNotAuthenticated(panel) {
    const d = document.createElement('div');
    d.style.cssText = 'padding:16px 13px;text-align:center;';
    d.innerHTML = `
      <div style="color:#94a3b8;font-size:12px;margin-bottom:10px;">Sign in to GoWarmCRM first</div>
      <a href="https://app.gowarmcrm.com" target="_blank"
        style="display:block;padding:7px;background:${TEAL};color:#fff;
               border-radius:6px;font-size:12px;font-weight:600;text-decoration:none;">
        Go to GoWarmCRM ↗
      </a>`;
    panel.appendChild(d);
  }

  // ── Render: lookup error (v1.8.2) ─────────────────────────────────────────
  // Shown when the LOOKUP_PROSPECT call to the backend errored out
  // (network failure, 5xx, etc) — NOT when the backend returned a clean
  // "no match" response. Crucial that these two cases are visually
  // distinct: a transient lookup failure showing the "Add prospect" form
  // would lead reps to create duplicates of prospects who are already in
  // CRM but whose lookup just failed.
  //
  // The retry runs the full init() again. We can't call init directly here
  // (it's defined later in this IIFE) so we re-trigger by clearing the
  // panel and calling safeInit via the cached reference set up at IIFE
  // bottom. To keep this self-contained, we just remove the panel and
  // let the navigation-watcher re-fire — but that watcher only fires on
  // URL change. So we do the simplest thing: hard-reload the panel by
  // dispatching a synthetic re-init.
  function renderLookupError(panel, profileInfo, errMsg) {
    const d = document.createElement('div');
    d.style.cssText = 'padding:16px 13px;';
    d.innerHTML = `
      <div style="background:#FEF2F2;border:1px solid #FECACA;border-radius:6px;padding:10px 12px;">
        <div style="font-size:12px;color:#991B1B;font-weight:600;margin-bottom:4px;">
          Couldn't check GoWarmCRM
        </div>
        <div style="font-size:11px;color:#7F1D1D;line-height:1.4;margin-bottom:8px;">
          The lookup failed, so we don't know whether this person is already
          in your CRM. <strong>Don't add them yet</strong> — you might create
          a duplicate. Retry first.
        </div>
        <div style="font-size:10px;color:#7F1D1D;font-family:ui-monospace,SFMono-Regular,Menlo,monospace;background:#FEE2E2;padding:4px 6px;border-radius:3px;margin-bottom:8px;word-break:break-word;">
          ${escHtml(errMsg)}
        </div>
        <button id="gw-lookup-retry" style="width:100%;padding:7px;background:${TEAL};color:#fff;border:none;border-radius:5px;font-size:12px;font-weight:600;cursor:pointer;">
          Retry lookup
        </button>
      </div>
    `;
    panel.appendChild(d);
    d.querySelector('#gw-lookup-retry').addEventListener('click', () => {
      // Tear down and re-init from scratch. The nav watcher won't fire
      // (URL hasn't changed), so we trigger the lifecycle ourselves.
      panel.remove();
      // safeInit is hoisted by virtue of being declared with `async function`
      // later in this IIFE. If for some reason it's not in scope (extreme
      // edge case), the user can always refresh the tab.
      try { safeInit(); } catch (_) { location.reload(); }
    });
  }

  // ── Capture-profile section (progressive, v1.3) ──────────────────────────────
  //
  // Renders four expandable rows — About, Experience, Education, Activity —
  // each showing live capture status and counts. Subscribes to capture state
  // updates so it re-renders rows as the user scrolls and sections populate.
  // The "Save to GoWarmCRM" button at the bottom posts the current state;
  // if any section is still pending (not yet seen), the user is warned first.
  //
  // options.hideSaveButton: when true, only the rows render — the parent
  // (e.g. renderNotFound) is expected to handle saving via its own button.
  function renderCaptureSection(panel, prospect, options = {}) {
    const { hideSaveButton = false } = options;
    const sec = document.createElement('div');
    sec.style.cssText = 'padding:10px 13px;border-bottom:1px solid #f1f5f9;background:#FFF8F1;';

    const SECTIONS = [
      { key: 'about',      label: 'About',      countOf: s => s.value ? 1 : 0 },
      { key: 'experience', label: 'Experience', countOf: s => (s.value || []).length },
      { key: 'education',  label: 'Education',  countOf: s => (s.value || []).length },
      { key: 'activity',   label: 'Activity',   countOf: s => (s.value || []).length },
    ];

    sec.innerHTML = `
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;">
        <div style="font-size:10px;font-weight:600;color:${ORANGE};letter-spacing:0.05em;text-transform:uppercase;">Profile capture</div>
        <div id="gw-cap-hint" style="font-size:10px;color:#94a3b8;">Scroll to load all sections</div>
      </div>
      <div id="gw-cap-rows" style="background:#fff;border:1px solid #FBCF9D;border-radius:6px;overflow:hidden;margin-bottom:8px;"></div>
      <div id="gw-cap-export" style="display:flex;align-items:center;gap:5px;margin-bottom:8px;flex-wrap:wrap;">
        <span style="font-size:10px;color:#94a3b8;font-weight:600;text-transform:uppercase;letter-spacing:0.04em;">Export</span>
        <button id="gw-exp-copy" style="font-size:10px;padding:3px 7px;border:1px solid #FBCF9D;background:#fff;color:#9A3412;border-radius:5px;cursor:pointer;font-weight:600;">Copy text</button>
        <button id="gw-exp-txt"  style="font-size:10px;padding:3px 7px;border:1px solid #FBCF9D;background:#fff;color:#9A3412;border-radius:5px;cursor:pointer;font-weight:600;">.txt</button>
        <button id="gw-exp-csv"  style="font-size:10px;padding:3px 7px;border:1px solid #FBCF9D;background:#fff;color:#9A3412;border-radius:5px;cursor:pointer;font-weight:600;">.csv</button>
        <span id="gw-exp-fb" style="font-size:10px;margin-left:auto;"></span>
      </div>
      ${hideSaveButton ? '' : `
        <button id="gw-capture-btn"
          style="width:100%;padding:7px;background:${ORANGE};color:#fff;border:none;border-radius:6px;
                 font-size:12px;font-weight:600;cursor:pointer;">
          Save to GoWarmCRM
        </button>
        <div id="gw-capture-feedback" style="margin-top:6px;font-size:11px;display:none;"></div>
        <div id="gw-capture-warning" style="display:none;margin-top:6px;padding:7px 8px;background:#FFFBEB;border:1px solid #FCD34D;border-radius:5px;font-size:11px;color:#78350F;"></div>
      `}
    `;
    panel.appendChild(sec);

    const rowsRoot = sec.querySelector('#gw-cap-rows');
    const btn      = sec.querySelector('#gw-capture-btn');
    const feedback = sec.querySelector('#gw-capture-feedback');
    const warning  = sec.querySelector('#gw-capture-warning');

    // ── Export handlers ─────────────────────────────────────────────────────────
    const expFb = sec.querySelector('#gw-exp-fb');
    const expFlash = (msg, color) => {
      expFb.style.color = color || '#059669';
      expFb.textContent = msg;
      setTimeout(() => { if (expFb.textContent === msg) expFb.textContent = ''; }, 2500);
    };
    sec.querySelector('#gw-exp-copy').addEventListener('click', async () => {
      const ok = await copyTextToClipboard(profileToText(captureFullProfile()));
      expFlash(ok ? 'Copied ✓' : 'Copy failed', ok ? '#059669' : '#dc2626');
    });
    sec.querySelector('#gw-exp-txt').addEventListener('click', () => {
      const p = captureFullProfile();
      const ok = downloadProfileFile(profileBasename(p) + '.txt', profileToText(p), 'text/plain');
      expFlash(ok ? 'Downloaded ✓' : 'Failed', ok ? '#059669' : '#dc2626');
    });
    sec.querySelector('#gw-exp-csv').addEventListener('click', () => {
      const p = captureFullProfile();
      const ok = downloadProfileFile(profileBasename(p) + '.csv', profileToCSV(p), 'text/csv');
      expFlash(ok ? 'Downloaded ✓' : 'Failed', ok ? '#059669' : '#dc2626');
    });

    // ── Row construction ───────────────────────────────────────────────────────
    const rowEls = {};   // { about: { row, head, status, count, body, expanded } }

    // Closure-scoped store for full experience descriptions, used by the
    // "Show details ↓" toggle. Populated by renderExpBody on each render;
    // referenced by the delegated click handler defined inside the
    // SECTIONS.forEach below. Declared up here so the closure is valid.
    const expDescMap = new Map();

    SECTIONS.forEach((def, idx) => {
      const row = document.createElement('div');
      row.style.cssText = `border-bottom:${idx < SECTIONS.length - 1 ? '1px solid #FEF3E0' : 'none'};`;

      const head = document.createElement('div');
      head.style.cssText = 'display:flex;align-items:center;justify-content:space-between;padding:7px 9px;cursor:pointer;font-size:11px;user-select:none;';
      head.innerHTML = `
        <div style="display:flex;align-items:center;gap:6px;">
          <span class="gw-cap-caret" style="font-size:9px;color:#94a3b8;width:8px;display:inline-block;">▸</span>
          <span style="font-weight:600;color:#374151;">${escHtml(def.label)}</span>
          <!-- Delta pill: "on file 3d ago", "+2 new", "updated", etc.
               Populated by refreshRow once GET_LINKEDIN_PROFILE has hydrated. -->
          <span class="gw-cap-delta" style="font-size:9px;padding:1px 5px;border-radius:8px;display:none;"></span>
        </div>
        <div style="display:flex;align-items:center;gap:6px;">
          <span class="gw-cap-count" style="font-size:11px;color:#64748b;"></span>
          <span class="gw-cap-status" style="font-size:9px;padding:1px 5px;border-radius:8px;"></span>
        </div>
      `;
      row.appendChild(head);

      const body = document.createElement('div');
      body.style.cssText = 'display:none;padding:6px 9px 8px;background:#fffaf3;font-size:11px;color:#475569;line-height:1.5;border-top:1px solid #FEF3E0;';
      row.appendChild(body);

      head.addEventListener('click', () => {
        const expanded = body.style.display !== 'none';
        body.style.display = expanded ? 'none' : 'block';
        head.querySelector('.gw-cap-caret').textContent = expanded ? '▸' : '▾';
      });

      // Delegated click handler for "Show details ↓" toggles inside any
      // experience-row description. Survives body innerHTML re-renders
      // because it's attached to the wrapper, not the toggle itself.
      // Full description text is held in expDescMap (defined below) keyed
      // by item index — safer than embedding multi-line text in DOM attrs.
      if (def.key === 'experience') {
        body.addEventListener('click', (e) => {
          const a = e.target.closest('.gw-exp-toggle');
          if (!a) return;
          e.stopPropagation();
          const idx     = a.dataset.idx;
          const descEl  = body.querySelector(`.gw-exp-desc[data-idx="${idx}"]`);
          const fullText = expDescMap.get(idx);
          if (!descEl || !fullText) return;
          const collapsed = descEl.dataset.collapsed === '1';
          if (collapsed) {
            descEl.textContent = fullText;
            descEl.dataset.collapsed = '0';
            a.textContent = 'Show less ↑';
          } else {
            descEl.textContent = fullText.length > 180 ? fullText.slice(0, 180) + '…' : fullText;
            descEl.dataset.collapsed = '1';
            a.textContent = 'Show details ↓';
          }
        });
      }

      rowEls[def.key] = { row, head, body };
      rowsRoot.appendChild(row);
    });

    // ── Status badges ──────────────────────────────────────────────────────────
    function statusBadge(status) {
      switch (status) {
        case 'pending':  return { text: 'pending',    bg: '#F1F5F9', fg: '#64748B' };
        case 'loading':  return { text: 'capturing…', bg: '#FEF3C7', fg: '#92400E' };
        case 'captured': return { text: 'captured',   bg: '#D1FAE5', fg: '#065F46' };
        case 'empty':    return { text: 'none',       bg: '#F1F5F9', fg: '#64748B' };
        default:         return { text: status,        bg: '#F1F5F9', fg: '#64748B' };
      }
    }

    // ── Inline edit machinery ──────────────────────────────────────────────────
    //
    // The rep can correct any displayed field by clicking a pencil icon. Edits
    // live entirely client-side and are wiped only by full re-init (SPA nav).
    // The "Save to GoWarmCRM" button picks up edited values via captureState,
    // so the same upsert flow ships them.
    //
    // Editing a section also flips slot.edited = true, which suppresses
    // automatic re-capture of that section (see runCapture). Without this,
    // a stray scroll could re-fire the IntersectionObserver and clobber
    // the rep's corrections.

    // Track which row currently has an open editor so a second pencil click
    // closes the previous one. { sectionKey, rowIdx, container } | null
    let openEditor = null;

    function closeOpenEditor() {
      if (!openEditor) return;
      // Restore any container the editor mutated by triggering the parent
      // section's refresh. The refresh path is idempotent.
      const { sectionKey } = openEditor;
      openEditor = null;
      refreshRow(sectionKey);
    }

    // Remove (suppress) control — a small ✕ shown next to the pencil. Marks
    // the role removed so it won't be saved and won't be resurrected by a
    // later scrape. data-* mirror the pencil dispatch convention.
    function removeHtml(section, rowIdx) {
      return `<span class="gw-remove-role" data-section="${section}" data-rowidx="${rowIdx}"
        title="Remove this role"
        style="display:inline-flex;align-items:center;justify-content:center;
               width:18px;height:18px;border-radius:3px;cursor:pointer;
               color:#94A3B8;flex-shrink:0;"
        onmouseover="this.style.background='#FEE2E2';this.style.color='#DC2626';"
        onmouseout="this.style.background='';this.style.color='#94A3B8';">
        <svg width="11" height="11" viewBox="0 0 24 24" fill="none"
             stroke="currentColor" stroke-width="2.4" stroke-linecap="round"
             stroke-linejoin="round" aria-hidden="true">
          <path d="M18 6 6 18M6 6l12 12"/>
        </svg>
      </span>`;
    }

    // Lock badges — one per locked field; clicking unlocks that field so future
    // scrapes can refresh it again. Returns '' when nothing is locked.
    function lockBadgesHtml(section, rowIdx, lockedFields) {
      if (!lockedFields || !lockedFields.length) return '';
      return `<div style="margin-top:3px;display:flex;flex-wrap:wrap;gap:3px;">` +
        lockedFields.map(f => `
          <span class="gw-unlock-field" data-section="${section}" data-rowidx="${rowIdx}" data-field="${escHtml(f)}"
            title="Edited by you — locked from auto-capture. Click to unlock."
            style="display:inline-flex;align-items:center;gap:2px;padding:0 5px;height:15px;
                   border-radius:8px;background:#FEF3E0;color:#9A3412;font-size:8px;
                   font-weight:700;letter-spacing:0.03em;cursor:pointer;">
            🔒 ${escHtml(String(f).toUpperCase())}
          </span>`).join('') +
        `</div>`;
    }

    // Compact "removed" row shown in place of a suppressed item, with Restore.
    function suppressedRowHtml(section, rowIdx, label) {
      return `
        <div style="margin-bottom:9px;padding-bottom:8px;display:flex;justify-content:space-between;
                    align-items:center;gap:8px;opacity:0.7;">
          <div style="flex:1;min-width:0;color:#9CA3AF;font-size:11px;">
            <span style="text-decoration:line-through;">${escHtml(label)}</span>
            <span style="margin-left:6px;font-style:italic;">removed — won't be saved</span>
          </div>
          <a class="gw-restore-role" data-section="${section}" data-rowidx="${rowIdx}"
             style="font-size:10px;color:${TEAL};cursor:pointer;text-decoration:none;font-weight:600;flex-shrink:0;">Restore</a>
        </div>`;
    }

    // Pencil icon SVG. data-edit is an opaque token the click handler uses
    // to dispatch to the right editor. data-rowidx narrows it to a specific
    // row inside multi-row sections (experience/education/activity).
    function pencilHtml(editToken, rowIdx) {
      const idxAttr = rowIdx != null ? ` data-rowidx="${rowIdx}"` : '';
      return `<span class="gw-edit-pencil" data-edit="${editToken}"${idxAttr}
        title="Edit"
        style="display:inline-flex;align-items:center;justify-content:center;
               width:18px;height:18px;border-radius:3px;cursor:pointer;
               color:#94A3B8;flex-shrink:0;"
        onmouseover="this.style.background='#FEF3E0';this.style.color='#E8630A';"
        onmouseout="this.style.background='';this.style.color='#94A3B8';">
        <svg width="11" height="11" viewBox="0 0 24 24" fill="none"
             stroke="currentColor" stroke-width="2.2" stroke-linecap="round"
             stroke-linejoin="round" aria-hidden="true">
          <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
          <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
        </svg>
      </span>`;
    }

    // Activity row badge. Visual signal for whether the activity was an
    // original post, plain repost, quoted repost (commentary on someone
    // else's post), comment, or reaction. Helps verify the classifier did
    // what we expect. Returns '' when the row has no useful classification
    // (e.g. legacy items captured before this code shipped, which have
    // null action and render as a neutral POST badge).
    function activityBadgeHtml(item) {
      if (!item) return '';
      const action = (item.action || '').toLowerCase();
      const kind   = (item.kind   || '').toLowerCase();
      // Pick a label + color per classification.
      let label, bg, fg;
      if (action === 'quoted_repost') {
        label = 'QUOTED REPOST'; bg = '#FEF3E0'; fg = '#9A3412';
      } else if (action === 'reposted') {
        label = 'REPOST';        bg = '#F3E8FF'; fg = '#581C87';
      } else if (action === 'posted' || (kind === 'post' && !action)) {
        // No-action posts are very likely originals from new captures; for
        // legacy data they're ambiguous. Same label either way — UI honest.
        label = action === 'posted' ? 'ORIGINAL' : 'POST'; bg = '#DCFCE7'; fg = '#14532D';
      } else if (kind === 'comment') {
        label = 'COMMENT';       bg = '#DBEAFE'; fg = '#1E3A8A';
      } else if (kind === 'reaction') {
        label = (action || 'reacted').toUpperCase(); bg = '#F3F4F6'; fg = '#374151';
      } else {
        return '';
      }
      return `<span style="display:inline-block;padding:1px 5px;border-radius:8px;
                            font-size:8px;font-weight:700;letter-spacing:0.04em;
                            background:${bg};color:${fg};margin-right:4px;
                            vertical-align:middle;">${escHtml(label)}</span>`;
    }

    // Render an inline editor block. Replaces a row's displayed content while
    // editing. fields = [{ key, label, value, type: 'text'|'textarea' }].
    function renderEditor(fields) {
      const inputs = fields.map((f, i) => {
        const safe = escHtml(f.value || '');
        if (f.type === 'textarea') {
          return `
            <div style="margin-bottom:6px;">
              <label style="display:block;font-size:9px;color:#64748B;margin-bottom:2px;font-weight:600;text-transform:uppercase;letter-spacing:0.05em;">${escHtml(f.label)}</label>
              <textarea data-field="${escHtml(f.key)}" data-fidx="${i}"
                style="width:100%;padding:5px 7px;border:1px solid #FBCF9D;border-radius:4px;
                       font-size:11px;font-family:inherit;line-height:1.5;
                       min-height:60px;max-height:200px;resize:vertical;box-sizing:border-box;"
              >${safe}</textarea>
            </div>`;
        }
        return `
          <div style="margin-bottom:6px;">
            <label style="display:block;font-size:9px;color:#64748B;margin-bottom:2px;font-weight:600;text-transform:uppercase;letter-spacing:0.05em;">${escHtml(f.label)}</label>
            <input type="text" data-field="${escHtml(f.key)}" data-fidx="${i}" value="${safe}"
              style="width:100%;padding:5px 7px;border:1px solid #FBCF9D;border-radius:4px;
                     font-size:11px;font-family:inherit;box-sizing:border-box;" />
          </div>`;
      }).join('');
      return `
        <div class="gw-editor" style="background:#FFFAF3;border:1px solid #FBCF9D;border-radius:5px;padding:8px 9px;">
          ${inputs}
          <div style="display:flex;gap:5px;margin-top:6px;">
            <button class="gw-edit-save"
              style="flex:1;padding:5px 8px;background:#E8630A;color:#fff;border:none;border-radius:4px;
                     font-size:11px;font-weight:600;cursor:pointer;">✓ Save</button>
            <button class="gw-edit-cancel"
              style="flex:1;padding:5px 8px;background:#fff;color:#64748B;border:1px solid #D1D5DB;
                     border-radius:4px;font-size:11px;cursor:pointer;">✗ Cancel</button>
          </div>
          <div style="margin-top:4px;font-size:9px;color:#94A3B8;">Enter to save · Esc to cancel</div>
        </div>`;
    }

    // Brief flash of green on a freshly-saved row, so the rep sees feedback.
    function flashSaved(el) {
      if (!el) return;
      const prevBg = el.style.background;
      el.style.transition = 'background 250ms ease';
      el.style.background = '#D1FAE5';
      setTimeout(() => { el.style.background = prevBg; }, 600);
    }

    // Wire keyboard handlers on the editor that just got mounted, plus the
    // Save/Cancel buttons. onSave receives a { fieldKey: value } map.
    function bindEditorEvents(container, onSave, onCancel) {
      const inputs = container.querySelectorAll('[data-field]');
      const saveBtn   = container.querySelector('.gw-edit-save');
      const cancelBtn = container.querySelector('.gw-edit-cancel');

      function commit() {
        const out = {};
        inputs.forEach(el => { out[el.dataset.field] = el.value.trim(); });
        onSave(out);
      }
      function cancel() { onCancel(); }

      saveBtn.addEventListener('click',   commit);
      cancelBtn.addEventListener('click', cancel);

      inputs.forEach(el => {
        el.addEventListener('keydown', (e) => {
          if (e.key === 'Escape') { e.preventDefault(); cancel(); return; }
          if (e.key === 'Enter') {
            // In textareas, plain Enter inserts newline; Shift+Enter or
            // Cmd/Ctrl+Enter forces commit. In inputs, plain Enter commits.
            if (el.tagName === 'TEXTAREA') {
              if (e.shiftKey || e.metaKey || e.ctrlKey) {
                e.preventDefault(); commit();
              }
            } else {
              e.preventDefault(); commit();
            }
          }
        });
      });

      // Focus the first input.
      const first = container.querySelector('[data-field]');
      if (first) {
        first.focus();
        if (first.select) first.select();
      }
    }

    // Open the about editor inline.
    function openAboutEditor() {
      closeOpenEditor();
      const slot = captureState.about;
      const els  = rowEls.about;
      if (!els) return;
      const current = (slot.value || '').replace(/^About\n+/i, '').trim();
      els.body.innerHTML = renderEditor([
        { key: 'text', label: 'About', value: current, type: 'textarea' },
      ]);
      const container = els.body.querySelector('.gw-editor');
      openEditor = { sectionKey: 'about', container };
      bindEditorEvents(container,
        ({ text }) => {
          slot.value  = text || null;
          slot.edited = true;
          slot.status = text ? 'captured' : 'empty';
          openEditor = null;
          notifyCapture('about');
          flashSaved(els.body);
        },
        () => closeOpenEditor()
      );
    }

    // Open the experience-row editor inline.
    function openExpEditor(rowIdx) {
      closeOpenEditor();
      const slot = captureState.experience;
      const items = slot.value || [];
      const it = items[rowIdx];
      if (!it) return;
      const els = rowEls.experience;
      if (!els) return;

      // Replace just this row's element with the editor; leave other rows alone.
      // We re-render the whole body but mark which index is in edit mode.
      els.body.innerHTML = items.map((row, i) => {
        if (i === rowIdx) {
          return `<div data-edit-row="${i}" style="margin-bottom:9px;padding-bottom:8px;${i < items.length - 1 ? 'border-bottom:1px dashed #E5E7EB;' : ''}"></div>`;
        }
        // Compact display of the non-edited rows so the editor stands out.
        const dates = formatDateRange(row.start_date, row.end_date, row.duration_months);
        const loc   = row.location ? ` · ${escHtml(row.location)}` : '';
        return `
          <div style="margin-bottom:9px;padding-bottom:8px;${i < items.length - 1 ? 'border-bottom:1px dashed #E5E7EB;' : ''};opacity:0.55;">
            <div style="font-weight:600;color:#1F2937;">${escHtml(row.title || '(no title)')}</div>
            <div style="color:#475569;">${escHtml(row.company || '(no company)')}${loc}</div>
            <div style="color:#94A3B8;font-size:10px;">${escHtml(dates)}</div>
          </div>`;
      }).join('');

      const editorMount = els.body.querySelector(`[data-edit-row="${rowIdx}"]`);
      editorMount.innerHTML = renderEditor([
        { key: 'title',       label: 'Title',       value: it.title       || '', type: 'text' },
        { key: 'company',     label: 'Company',     value: it.company     || '', type: 'text' },
        { key: 'location',    label: 'Location',    value: it.location    || '', type: 'text' },
        { key: 'description', label: 'Description', value: it.description || '', type: 'textarea' },
      ]);
      const container = editorMount.querySelector('.gw-editor');
      openEditor = { sectionKey: 'experience', container };

      bindEditorEvents(container,
        (vals) => {
          const updated = {
            ...it,
            title:       vals.title       || null,
            company:     vals.company     || null,
            location:    vals.location    || null,
            description: vals.description || null,
          };
          recordEditLocks(slot, 'experience', it, updated);
          items[rowIdx] = updated;
          slot.value  = items;
          slot.edited = true;
          openEditor = null;
          notifyCapture('experience');
          flashSaved(els.body);
        },
        () => closeOpenEditor()
      );
    }

    // Open the education-row editor inline.
    function openEduEditor(rowIdx) {
      closeOpenEditor();
      const slot = captureState.education;
      const items = slot.value || [];
      const it = items[rowIdx];
      if (!it) return;
      const els = rowEls.education;
      if (!els) return;

      els.body.innerHTML = items.map((row, i) => {
        if (i === rowIdx) {
          return `<div data-edit-row="${i}" style="margin-bottom:7px;"></div>`;
        }
        const years = (row.start_year || row.end_year)
          ? `${row.start_year || '?'}\u2009–\u2009${row.end_year || '?'}` : '';
        const detail = [row.degree, row.field_of_study].filter(Boolean).join(', ');
        return `
          <div style="margin-bottom:7px;opacity:0.55;">
            <div style="font-weight:600;color:#1F2937;">${escHtml(row.school || '(no school)')}</div>
            ${detail ? `<div style="color:#475569;">${escHtml(detail)}</div>` : ''}
            ${years   ? `<div style="color:#94A3B8;font-size:10px;">${escHtml(years)}</div>` : ''}
          </div>`;
      }).join('');

      const editorMount = els.body.querySelector(`[data-edit-row="${rowIdx}"]`);
      editorMount.innerHTML = renderEditor([
        { key: 'school',         label: 'School',         value: it.school || '',         type: 'text' },
        { key: 'degree',         label: 'Degree',         value: it.degree || '',         type: 'text' },
        { key: 'field_of_study', label: 'Field of study', value: it.field_of_study || '', type: 'text' },
      ]);
      const container = editorMount.querySelector('.gw-editor');
      openEditor = { sectionKey: 'education', container };

      bindEditorEvents(container,
        (vals) => {
          const updated = {
            ...it,
            school:         vals.school || null,
            degree:         vals.degree || null,
            field_of_study: vals.field_of_study || null,
          };
          recordEditLocks(slot, 'education', it, updated);
          items[rowIdx] = updated;
          slot.value  = items;
          slot.edited = true;
          openEditor  = null;
          notifyCapture('education');
          flashSaved(els.body);
        },
        () => closeOpenEditor()
      );
    }

    // Open the activity-item editor inline.
    function openActEditor(rowIdx) {
      closeOpenEditor();
      const slot = captureState.activity;
      const items = slot.value || [];
      const it = items[rowIdx];
      if (!it) return;
      const els = rowEls.activity;
      if (!els) return;

      els.body.innerHTML = items.slice(0, 10).map((row, i) => {
        if (i === rowIdx) {
          return `<div data-edit-row="${i}" style="margin-bottom:7px;"></div>`;
        }
        const verb  = row.action ? row.action : row.kind;
        const time  = row.relative_time ? ` · ${escHtml(row.relative_time)}` : '';
        const text  = (row.text || '').slice(0, 200);
        const badge = activityBadgeHtml(row);
        return `
          <div style="margin-bottom:7px;opacity:0.55;">
            <div style="color:#94A3B8;font-size:10px;">${badge}${escHtml(verb)}${time}</div>
            ${text ? `<div style="color:#374151;">${escHtml(text)}</div>` : ''}
          </div>`;
      }).join('');

      const editorMount = els.body.querySelector(`[data-edit-row="${rowIdx}"]`);
      editorMount.innerHTML = renderEditor([
        { key: 'text', label: 'Text', value: it.text || '', type: 'textarea' },
      ]);
      const container = editorMount.querySelector('.gw-editor');
      openEditor = { sectionKey: 'activity', container };

      bindEditorEvents(container,
        (vals) => {
          items[rowIdx] = { ...it, text: vals.text || '' };
          slot.value  = items;
          slot.edited = true;
          openEditor  = null;
          notifyCapture('activity');
          flashSaved(els.body);
        },
        () => closeOpenEditor()
      );
    }

    // Single delegated click handler at the rows-root level. Catches every
    // pencil click in any of the four section bodies and dispatches.
    rowsRoot.addEventListener('click', (e) => {
      // ── Diff/full toggle (NEW in v1.7) ───────────────────────────────────
      // Catches "Show all live data ↓" / "Show changes only ↑" links in
      // the body footer. Flips the slot's viewMode and re-renders just
      // that row. We handle this BEFORE the pencil branch so the toggle
      // never gets misclassified as an edit click.
      const toggle = e.target.closest('.gw-diff-toggle');
      if (toggle) {
        e.stopPropagation();
        const key  = toggle.dataset.key;
        const mode = toggle.dataset.mode;   // the mode we're switching TO
        if (key && (mode === 'diff' || mode === 'full')) {
          captureState[key].viewMode = mode;
          notifyCapture(key);
        }
        return;
      }

      // ── Remove / restore / unlock (v1.22) ────────────────────────────────
      // Handled before the pencil branch so these never read as edit clicks.
      const removeEl = e.target.closest('.gw-remove-role');
      if (removeEl) {
        e.stopPropagation();
        const section = removeEl.dataset.section;
        const idx     = parseInt(removeEl.dataset.rowidx, 10);
        const slot    = captureState[section];
        const item    = slot && (slot.value || [])[idx];
        if (item) { suppressItem(slot, section, item); notifyCapture(section); }
        return;
      }
      const restoreEl = e.target.closest('.gw-restore-role');
      if (restoreEl) {
        e.stopPropagation();
        const section = restoreEl.dataset.section;
        const idx     = parseInt(restoreEl.dataset.rowidx, 10);
        const slot    = captureState[section];
        const item    = slot && (slot.value || [])[idx];
        if (item) { restoreItem(slot, section, item); notifyCapture(section); }
        return;
      }
      const unlockEl = e.target.closest('.gw-unlock-field');
      if (unlockEl) {
        e.stopPropagation();
        const section = unlockEl.dataset.section;
        const idx     = parseInt(unlockEl.dataset.rowidx, 10);
        const field   = unlockEl.dataset.field;
        const slot    = captureState[section];
        const item    = slot && (slot.value || [])[idx];
        if (item && field) { unlockField(slot, section, item, field); notifyCapture(section); }
        return;
      }

      const pencil = e.target.closest('.gw-edit-pencil');
      if (!pencil) return;
      e.stopPropagation();
      const token  = pencil.dataset.edit;
      const rowIdx = pencil.dataset.rowidx != null ? parseInt(pencil.dataset.rowidx, 10) : null;
      switch (token) {
        case 'about':      openAboutEditor();          break;
        case 'experience': openExpEditor(rowIdx);      break;
        case 'education':  openEduEditor(rowIdx);      break;
        case 'activity':   openActEditor(rowIdx);      break;
      }
    });

    // ── Body renderers per section ─────────────────────────────────────────────
    function renderAboutBody(slot) {
      if (!slot.value) {
        return `
          <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px;">
            <div style="color:#94a3b8;font-style:italic;">No About section on this profile.</div>
            ${pencilHtml('about')}
          </div>`;
      }
      const text = slot.value.replace(/^About\n+/i, '').trim();
      return `
        <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px;">
          <div style="white-space:pre-wrap;max-height:240px;overflow-y:auto;padding-right:4px;flex:1;">${escHtml(text)}</div>
          ${pencilHtml('about')}
        </div>`;
    }

    function renderExpBody(slot) {
      const items = slot.value || [];
      if (items.length === 0) return `<div style="color:#94a3b8;font-style:italic;">No experience captured yet.</div>`;
      expDescMap.clear();
      return items.map((it, idx) => {
        const key       = expKeyOf(it);
        const suppressed = isSuppressed(slot, key);
        if (suppressed) {
          return suppressedRowHtml('experience', idx,
            `${it.title || '(no title)'}${it.company ? ' · ' + it.company : ''}`);
        }
        const locked = lockedFieldsFor(slot, key);
        const dates = formatDateRange(it.start_date, it.end_date, it.duration_months);
        const loc   = it.location ? ` · ${escHtml(it.location)}` : '';
        const desc  = (it.description || '').trim();
        const hasDesc    = desc.length > 0;
        const isLongDesc = desc.length > 180;
        const descPreview = isLongDesc ? desc.slice(0, 180) + '…' : desc;
        if (hasDesc) expDescMap.set(String(idx), desc);
        return `
          <div style="margin-bottom:9px;padding-bottom:8px;${idx < items.length - 1 ? 'border-bottom:1px dashed #E5E7EB;' : ''}">
            <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px;">
              <div style="flex:1;min-width:0;">
                <div style="font-weight:600;color:#1F2937;">${escHtml(it.title || '(no title)')}</div>
                <div style="color:#475569;">${escHtml(it.company || '(no company)')}${loc}</div>
                <div style="color:#94A3B8;font-size:10px;">${escHtml(dates)}</div>
                ${hasDesc ? `
                  <div class="gw-exp-desc" data-idx="${idx}" data-collapsed="${isLongDesc ? '1' : '0'}" style="margin-top:4px;color:#374151;font-size:10px;line-height:1.5;white-space:pre-wrap;">${escHtml(isLongDesc ? descPreview : desc)}</div>
                  ${isLongDesc ? `
                    <a class="gw-exp-toggle" data-idx="${idx}" style="display:inline-block;margin-top:2px;font-size:10px;color:${TEAL};cursor:pointer;text-decoration:none;">Show details ↓</a>
                  ` : ''}
                ` : ''}
                ${lockBadgesHtml('experience', idx, locked)}
              </div>
              <div style="display:flex;align-items:flex-start;gap:1px;flex-shrink:0;">
                ${pencilHtml('experience', idx)}
                ${removeHtml('experience', idx)}
              </div>
            </div>
          </div>`;
      }).join('');
    }

    function renderEduBody(slot) {
      const items = slot.value || [];
      if (items.length === 0) return `<div style="color:#94a3b8;font-style:italic;">No education captured.</div>`;
      return items.map((it, idx) => {
        const key        = eduKeyOf(it);
        const suppressed = isSuppressed(slot, key);
        if (suppressed) {
          return suppressedRowHtml('education', idx,
            `${it.school || '(no school)'}${it.degree ? ' · ' + it.degree : ''}`);
        }
        const locked = lockedFieldsFor(slot, key);
        const years = (it.start_year || it.end_year)
          ? `${it.start_year || '?'}\u2009–\u2009${it.end_year || '?'}`
          : '';
        const detail = [it.degree, it.field_of_study].filter(Boolean).join(', ');
        return `
          <div style="margin-bottom:7px;">
            <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px;">
              <div style="flex:1;min-width:0;">
                <div style="font-weight:600;color:#1F2937;">${escHtml(it.school || '(no school)')}</div>
                ${detail ? `<div style="color:#475569;">${escHtml(detail)}</div>` : ''}
                ${years   ? `<div style="color:#94A3B8;font-size:10px;">${escHtml(years)}</div>` : ''}
                ${lockBadgesHtml('education', idx, locked)}
              </div>
              <div style="display:flex;align-items:flex-start;gap:1px;flex-shrink:0;">
                ${pencilHtml('education', idx)}
                ${removeHtml('education', idx)}
              </div>
            </div>
          </div>`;
      }).join('');
    }

    function renderActBody(slot) {
      const items = slot.value || [];
      if (items.length === 0) return `<div style="color:#94a3b8;font-style:italic;">No activity captured yet. (Activity often loads only after scrolling near it.)</div>`;
      const visibleN = Math.min(items.length, 10);
      const rows = items.slice(0, visibleN).map((it, idx) => {
        const verb  = it.action ? `${it.action}` : it.kind;
        const time  = it.relative_time ? ` · ${escHtml(it.relative_time)}` : '';
        const text  = (it.text || '').slice(0, 200);
        const badge = activityBadgeHtml(it);
        const quotedNote = it.quoted_author
          ? `<div style="color:#94A3B8;font-size:9px;margin-top:2px;font-style:italic;">↳ from ${escHtml(it.quoted_author)}</div>`
          : '';
        const href  = it.source_url
          ? `<a href="${escHtml(it.source_url)}" target="_blank" style="color:${TEAL};text-decoration:none;font-size:10px;">view →</a>`
          : '';
        return `
          <div style="margin-bottom:7px;">
            <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px;">
              <div style="flex:1;min-width:0;">
                <div style="color:#94A3B8;font-size:10px;">${badge}${escHtml(verb)}${time}</div>
                ${text ? `<div style="color:#374151;">${escHtml(text)}</div>` : ''}
                ${quotedNote}
                ${href}
              </div>
              ${pencilHtml('activity', idx)}
            </div>
          </div>`;
      }).join('');

      // "Showing 10 of N" footer (NEW in v1.7.1). The panel only displays
      // the first 10 items to keep things scannable in a 290px sidebar,
      // but ALL items are still in captureState.activity.value and ALL
      // get sent to the server on Save. Without this footer, reps could
      // (and did) reasonably assume items 11+ were silently dropped.
      const overflow = items.length - visibleN;
      const more = overflow > 0
        ? `<div style="margin-top:6px;padding-top:6px;border-top:1px dashed #E5E7EB;color:#64748B;font-size:10px;text-align:center;">
             Showing ${visibleN} of ${items.length} · all ${items.length} will be saved
           </div>`
        : '';
      return rows + more;
    }

    // ── Diff body renderers (NEW in v1.7) ─────────────────────────────────────
    //
    // These render the section in "show me what's about to change" mode.
    // They're called instead of the normal renderAboutBody / renderExpBody
    // / renderEduBody / renderActBody when:
    //   1) the slot has a diff (state is 'updated' or 'new-data'), AND
    //   2) the user hasn't explicitly switched to 'full' mode for this row.
    //
    // Honest about the upsert merge semantics: items that exist in DB but
    // not in the live capture are shown as "removed (kept on file)" — the
    // server's section-level merge keeps them. Reps see the truth.
    //
    // Each diff renderer ends with a row footer that lets the user toggle
    // between diff and full views via a delegated click handler below.

    function diffFooter(key, mode) {
      const label = mode === 'diff'
        ? '↓ Show all live data'
        : '↑ Show changes only';
      return `<div style="margin-top:8px;padding-top:6px;border-top:1px dashed #E5E7EB;text-align:center;">
                <a class="gw-diff-toggle" data-key="${key}" data-mode="${mode === 'diff' ? 'full' : 'diff'}"
                   style="font-size:10px;color:${TEAL};cursor:pointer;text-decoration:none;font-weight:500;">
                  ${label}
                </a>
              </div>`;
    }

    // ── About diff ─────────────────────────────────────────────────────────────
    // Most About changes are small (a sentence about a Series B, a new
    // job blurb). We compute a coarse character-level signal and show
    // both versions stacked. For tiny changes (<60 char delta) we show
    // an inline "+45 chars" hint; for big rewrites (>50% of length
    // changed) we label it "rewritten" so the rep knows to read both.
    function renderAboutDiff(slot) {
      const live = (slot.value     || '').replace(/^About\n+/i, '').trim();
      const dbV  = (slot.dbValue   || '').replace(/^About\n+/i, '').trim();

      // Edge case: live empty, DB has content (shouldn't reach here
      // because diffSection would say 'on-file', but be defensive).
      if (!live) {
        return `<div style="color:#94a3b8;font-style:italic;">Live About is empty; existing About on file will be kept.</div>` +
               diffFooter('about', 'diff');
      }

      const delta = live.length - dbV.length;
      const big   = dbV.length > 0 && Math.abs(delta) / Math.max(dbV.length, 1) > 0.5;
      const tag   = !dbV
        ? '<span style="background:#D1FAE5;color:#065F46;font-size:9px;font-weight:700;padding:1px 5px;border-radius:8px;">NEW</span>'
        : big
          ? '<span style="background:#FEF3C7;color:#92400E;font-size:9px;font-weight:700;padding:1px 5px;border-radius:8px;">REWRITTEN</span>'
          : `<span style="background:#FEF3C7;color:#92400E;font-size:9px;font-weight:700;padding:1px 5px;border-radius:8px;">${delta > 0 ? '+' : ''}${delta} chars</span>`;

      // For visual scanning, the live version comes first (that's
      // what's about to be saved). DB version follows, dimmed, so the
      // rep can compare without scrolling.
      const dbBlock = dbV
        ? `<div style="margin-top:8px;padding:6px 8px;background:#F8FAFC;border-radius:5px;border-left:3px solid #CBD5E1;">
             <div style="font-size:9px;font-weight:700;color:#64748B;text-transform:uppercase;letter-spacing:0.04em;margin-bottom:3px;">Currently on file</div>
             <div style="white-space:pre-wrap;color:#64748B;font-size:10px;max-height:120px;overflow-y:auto;">${escHtml(dbV)}</div>
           </div>`
        : '';

      return `
        <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:5px;">
          <div style="font-size:10px;font-weight:700;color:#374151;text-transform:uppercase;letter-spacing:0.04em;">About to save ${tag}</div>
        </div>
        <div style="white-space:pre-wrap;max-height:200px;overflow-y:auto;padding:6px 8px;background:#FFFBEB;border-radius:5px;border-left:3px solid #F59E0B;">${escHtml(live)}</div>
        ${dbBlock}
        ${diffFooter('about', 'diff')}
      `;
    }

    // ── Experience / Education item matching ──────────────────────────────────
    //
    // For arrays of objects, we match items between live and DB by a
    // composite signature (same shape used by diffSection's signature
    // function). Returns three arrays: added (in live, not in DB),
    // removed (in DB, not in live), kept (matched on both sides — could
    // still differ in details, e.g. an end_date that filled in).
    //
    // For matched items we also compute a per-field changeset so the
    // diff view can highlight things like "end date now Mar 2024".
    function diffArrayItems(live, dbV, sigFn, fieldsToCompare) {
      const liveBySig = new Map();
      live.forEach((it, idx) => liveBySig.set(sigFn(it), { it, idx }));
      const dbBySig = new Map();
      dbV.forEach((it, idx)  => dbBySig.set(sigFn(it),   { it, idx }));

      const added   = [];
      const removed = [];
      const kept    = [];

      for (const [sig, { it: liveIt, idx }] of liveBySig) {
        if (!dbBySig.has(sig)) {
          added.push({ item: liveIt, idx });
        } else {
          const dbIt = dbBySig.get(sig).it;
          const fieldDiffs = [];
          for (const f of fieldsToCompare) {
            const lv = (liveIt[f] || '').toString().trim();
            const dv = (dbIt[f]   || '').toString().trim();
            if (lv !== dv) fieldDiffs.push({ field: f, live: lv, db: dv });
          }
          kept.push({ item: liveIt, dbItem: dbIt, idx, fieldDiffs });
        }
      }
      for (const [sig, { it: dbIt }] of dbBySig) {
        if (!liveBySig.has(sig)) removed.push({ item: dbIt });
      }
      return { added, removed, kept };
    }

    // ── Experience diff ────────────────────────────────────────────────────────
    function renderExpDiff(slot) {
      const live = slot.value   || [];
      const dbV  = slot.dbValue || [];
      const sig  = (x) => `${x.title||''}|${x.company||''}|${x.start_date||''}|${x.end_date||''}`;
      const { added, removed, kept } = diffArrayItems(
        live, dbV, sig,
        ['location', 'description', 'duration_months']
      );

      const changedKept = kept.filter(k => k.fieldDiffs.length > 0);

      // Summary line
      const parts = [];
      if (added.length)        parts.push(`<span style="color:#065F46;">+${added.length} new</span>`);
      if (removed.length)      parts.push(`<span style="color:#991B1B;">${removed.length} no longer on LinkedIn</span>`);
      if (changedKept.length)  parts.push(`<span style="color:#92400E;">${changedKept.length} updated</span>`);
      if (parts.length === 0)  parts.push(`<span style="color:#475569;">No structural changes</span>`);

      const itemRow = (badge, badgeColor, badgeBg, item, opts = {}) => {
        const dates = formatDateRange(item.start_date, item.end_date, item.duration_months);
        const loc   = item.location ? ` · ${escHtml(item.location)}` : '';
        const dim   = opts.dim ? 'opacity:0.55;text-decoration:line-through;text-decoration-color:#CBD5E1;' : '';
        return `
          <div style="margin-bottom:6px;padding:5px 7px;border-radius:5px;background:${badgeBg};${dim}">
            <div style="display:flex;align-items:center;gap:5px;margin-bottom:2px;">
              <span style="background:${badgeColor};color:#fff;font-size:8px;font-weight:700;padding:1px 5px;border-radius:8px;text-transform:uppercase;letter-spacing:0.04em;">${badge}</span>
              <span style="font-weight:600;color:#1F2937;font-size:11px;">${escHtml(item.title || '(no title)')}</span>
            </div>
            <div style="color:#475569;font-size:10px;">${escHtml(item.company || '(no company)')}${loc}</div>
            <div style="color:#94A3B8;font-size:9px;">${escHtml(dates)}</div>
            ${opts.fieldDiffs && opts.fieldDiffs.length ? `
              <div style="margin-top:3px;padding-top:3px;border-top:1px dashed #E5E7EB;">
                ${opts.fieldDiffs.map(fd => `
                  <div style="font-size:9px;color:#92400E;">
                    <strong>${escHtml(fd.field)}:</strong>
                    <span style="text-decoration:line-through;color:#94A3B8;">${escHtml(fd.db || '(empty)')}</span>
                    →
                    <span style="color:#065F46;">${escHtml(fd.live || '(empty)')}</span>
                  </div>
                `).join('')}
              </div>
            ` : ''}
          </div>`;
      };

      const sections = [];
      if (added.length) {
        sections.push(`<div style="margin-bottom:8px;">
          <div style="font-size:9px;font-weight:700;color:#065F46;text-transform:uppercase;letter-spacing:0.04em;margin-bottom:3px;">New experience</div>
          ${added.map(a => itemRow('NEW', '#10B981', '#ECFDF5', a.item)).join('')}
        </div>`);
      }
      if (changedKept.length) {
        sections.push(`<div style="margin-bottom:8px;">
          <div style="font-size:9px;font-weight:700;color:#92400E;text-transform:uppercase;letter-spacing:0.04em;margin-bottom:3px;">Updated</div>
          ${changedKept.map(k => itemRow('UPDATED', '#F59E0B', '#FFFBEB', k.item, { fieldDiffs: k.fieldDiffs })).join('')}
        </div>`);
      }
      if (removed.length) {
        sections.push(`<div style="margin-bottom:8px;">
          <div style="font-size:9px;font-weight:700;color:#991B1B;text-transform:uppercase;letter-spacing:0.04em;margin-bottom:3px;">No longer on LinkedIn</div>
          ${removed.map(r => itemRow('REMOVED', '#EF4444', '#FEF2F2', r.item, { dim: true })).join('')}
          <div style="font-size:9px;color:#94A3B8;font-style:italic;margin-top:3px;padding-left:2px;">
            These will stay in your CRM — refreshing won't delete them.
          </div>
        </div>`);
      }

      return `
        <div style="font-size:10px;font-weight:600;color:#374151;margin-bottom:6px;padding-bottom:4px;border-bottom:1px solid #F1F5F9;">
          ${parts.join(' · ')}
        </div>
        ${sections.join('') || '<div style="color:#94a3b8;font-style:italic;font-size:10px;">No changes detected.</div>'}
        ${diffFooter('experience', 'diff')}
      `;
    }

    // ── Education diff ─────────────────────────────────────────────────────────
    function renderEduDiff(slot) {
      const live = slot.value   || [];
      const dbV  = slot.dbValue || [];
      const sig  = (x) => `${x.school||''}|${x.degree||''}|${x.field_of_study||''}|${x.start_year||''}|${x.end_year||''}`;
      const { added, removed, kept } = diffArrayItems(live, dbV, sig, []);

      const parts = [];
      if (added.length)   parts.push(`<span style="color:#065F46;">+${added.length} new</span>`);
      if (removed.length) parts.push(`<span style="color:#991B1B;">${removed.length} no longer on LinkedIn</span>`);
      if (parts.length === 0) parts.push(`<span style="color:#475569;">No changes</span>`);

      const itemRow = (badge, badgeColor, badgeBg, it, opts = {}) => {
        const detail = [it.degree, it.field_of_study].filter(Boolean).join(', ');
        const years  = (it.start_year || it.end_year)
          ? `${it.start_year || '?'}\u2009–\u2009${it.end_year || '?'}` : '';
        const dim    = opts.dim ? 'opacity:0.55;text-decoration:line-through;text-decoration-color:#CBD5E1;' : '';
        return `
          <div style="margin-bottom:6px;padding:5px 7px;border-radius:5px;background:${badgeBg};${dim}">
            <div style="display:flex;align-items:center;gap:5px;margin-bottom:2px;">
              <span style="background:${badgeColor};color:#fff;font-size:8px;font-weight:700;padding:1px 5px;border-radius:8px;text-transform:uppercase;letter-spacing:0.04em;">${badge}</span>
              <span style="font-weight:600;color:#1F2937;font-size:11px;">${escHtml(it.school || '(no school)')}</span>
            </div>
            ${detail ? `<div style="color:#475569;font-size:10px;">${escHtml(detail)}</div>` : ''}
            ${years  ? `<div style="color:#94A3B8;font-size:9px;">${escHtml(years)}</div>` : ''}
          </div>`;
      };

      const sections = [];
      if (added.length) sections.push(added.map(a => itemRow('NEW', '#10B981', '#ECFDF5', a.item)).join(''));
      if (removed.length) {
        sections.push(removed.map(r => itemRow('REMOVED', '#EF4444', '#FEF2F2', r.item, { dim: true })).join(''));
        sections.push(`<div style="font-size:9px;color:#94A3B8;font-style:italic;margin-top:3px;padding-left:2px;">
          These will stay in your CRM — refreshing won't delete them.
        </div>`);
      }

      return `
        <div style="font-size:10px;font-weight:600;color:#374151;margin-bottom:6px;padding-bottom:4px;border-bottom:1px solid #F1F5F9;">
          ${parts.join(' · ')}
        </div>
        ${sections.join('') || '<div style="color:#94a3b8;font-style:italic;font-size:10px;">No changes detected.</div>'}
        ${diffFooter('education', 'diff')}
      `;
    }

    // ── Activity diff ──────────────────────────────────────────────────────────
    // Activity is server-side accumulated by ID, so the only meaningful
    // diff is "what's new since last capture." We don't show "removed"
    // because the server never removes activity rows on upsert.
    function renderActDiff(slot) {
      const live = slot.value   || [];
      const dbV  = slot.dbValue || [];
      const dbIds = new Set((dbV || []).map(x => x?.id).filter(Boolean));
      const newOnes = live.filter(x => x?.id && !dbIds.has(x.id));

      if (newOnes.length === 0) {
        return `<div style="color:#94a3b8;font-style:italic;font-size:10px;">No new activity since last save.</div>` +
               diffFooter('activity', 'diff');
      }

      const visibleN = Math.min(newOnes.length, 10);
      const overflow = newOnes.length - visibleN;
      const overflowNote = overflow > 0
        ? `<div style="margin-top:6px;padding-top:6px;border-top:1px dashed #E5E7EB;color:#64748B;font-size:10px;text-align:center;">
             Showing ${visibleN} of ${newOnes.length} new · all ${newOnes.length} will be added
           </div>`
        : '';

      return `
        <div style="font-size:10px;font-weight:600;color:#065F46;margin-bottom:6px;padding-bottom:4px;border-bottom:1px solid #F1F5F9;">
          ${newOnes.length} new activity item${newOnes.length === 1 ? '' : 's'} since last save · these will be added (existing items kept)
        </div>
        ${newOnes.slice(0, visibleN).map(it => {
          const verb = it.action ? `${it.action}` : it.kind;
          const time = it.relative_time ? ` · ${escHtml(it.relative_time)}` : '';
          const text = (it.text || '').slice(0, 200);
          const badge = activityBadgeHtml(it);
          return `
            <div style="margin-bottom:6px;padding:5px 7px;border-radius:5px;background:#ECFDF5;">
              <div style="display:flex;align-items:center;gap:5px;margin-bottom:2px;">
                <span style="background:#10B981;color:#fff;font-size:8px;font-weight:700;padding:1px 5px;border-radius:8px;text-transform:uppercase;letter-spacing:0.04em;">NEW</span>
                ${badge}
                <span style="color:#94A3B8;font-size:9px;">${escHtml(verb)}${time}</span>
              </div>
              ${text ? `<div style="color:#374151;font-size:10px;">${escHtml(text)}</div>` : ''}
            </div>`;
        }).join('')}
        ${overflowNote}
        ${diffFooter('activity', 'diff')}
      `;
    }

    function bodyFor(key, slot) {
      // Decide whether to render the diff view or the normal full view.
      // Default ('auto'): diff view when the slot has a meaningful diff,
      // full view otherwise. User can override via the toggle link in
      // the body footer (sets viewMode to 'diff' or 'full' explicitly).
      const d = diffSection(key, slot);
      const hasDiff = (d === 'updated' || d === 'new-data');

      let mode = slot.viewMode;
      if (mode === 'auto') {
        mode = hasDiff ? 'diff' : 'full';
      }
      // Don't show diff view if there's nothing to diff against.
      if (mode === 'diff' && !hasDiff) mode = 'full';

      if (mode === 'diff') {
        switch (key) {
          case 'about':      return renderAboutDiff(slot);
          case 'experience': return renderExpDiff(slot);
          case 'education':  return renderEduDiff(slot);
          case 'activity':   return renderActDiff(slot);
        }
      }

      // Full view — original renderers, plus a footer link to switch to
      // diff view (only shown when there's actually a diff to switch to).
      const fullBody = (() => {
        switch (key) {
          case 'about':      return renderAboutBody(slot);
          case 'experience': return renderExpBody(slot);
          case 'education':  return renderEduBody(slot);
          case 'activity':   return renderActBody(slot);
        }
      })();

      return hasDiff ? (fullBody + diffFooter(key, 'full')) : fullBody;
    }

    // ── Subscribe to capture state and re-render rows on update ───────────────
    // ── Delta pill rendering (NEW in v1.5) ────────────────────────────────────
    //
    // Each row carries a pill next to its label that summarizes how the
    // live capture compares to what's already in the linkedin_profiles
    // table for this org+slug:
    //
    //   • on-file        — DB has this section; live capture hasn't run yet
    //                      (or came back empty). Pill is grey. The pill text
    //                      includes the relative time so the rep knows how
    //                      stale the stored copy is.
    //   • unchanged      — Live capture exactly matches DB. Pill is grey.
    //                      Save button will be disabled (nothing to push).
    //   • updated        — Live capture differs from DB. Pill is amber.
    //                      Save button flips to "Refresh in GoWarmCRM".
    //   • new-data       — DB had nothing here, live captured something.
    //                      Pill is green ("new"). Save flips to "Save".
    //   • no-db          — No DB row at all (or section never seen). No pill.
    //
    // The pill is hidden until GET_LINKEDIN_PROFILE has resolved — there's
    // no point showing "no DB data" before we've even asked.
    function deltaPill(key, slot) {
      const d = diffSection(key, slot);
      if (!slot.dbHydrated || d === 'no-db') {
        return { show: false };
      }
      const ts = slot.dbCapturedAt ? formatRelative(slot.dbCapturedAt) : '';

      // Activity-specific pill text: the server appends rather than
      // overwrites, so "updated" is misleading — what's actually
      // happening is "+N new items will be added to your CRM record."
      // We compute N here so the rep sees the exact accumulation count
      // rather than a generic state word that means something different
      // for activity than it does for experience/education.
      if (key === 'activity' && d === 'updated') {
        const live  = slot.value   || [];
        const dbV   = slot.dbValue || [];
        const dbIds = new Set(dbV.map(x => x?.id).filter(Boolean));
        const newN  = live.filter(x => x?.id && !dbIds.has(x.id)).length;
        return {
          show: true,
          text: `+${newN} new`,
          bg: '#D1FAE5', fg: '#065F46',
        };
      }

      switch (d) {
        case 'on-file':
          return { show: true, text: ts ? `on file · ${ts}` : 'on file', bg: '#F1F5F9', fg: '#475569' };
        case 'unchanged':
          return { show: true, text: ts ? `synced · ${ts}` : 'synced',   bg: '#F1F5F9', fg: '#475569' };
        case 'updated':
          return { show: true, text: 'updated',                          bg: '#FEF3C7', fg: '#92400E' };
        case 'new-data':
          return { show: true, text: 'new',                              bg: '#D1FAE5', fg: '#065F46' };
        default:
          return { show: false };
      }
    }

    function refreshRow(key) {
      const def  = SECTIONS.find(s => s.key === key);
      if (!def) return;
      const slot = captureState[key];
      const els  = rowEls[key];
      if (!els) return;
      // The whole capture section may have been detached (e.g. renderProspect
      // re-rendered after Add). Skip silently — the new section's subscriber
      // will keep things up to date.
      if (!sec.isConnected) return;

      const count = def.countOf(slot);
      const countText = key === 'about'
        ? (slot.value ? '✓' : '')
        : (count > 0 ? `${count}` : '');
      const countEl = els.head.querySelector('.gw-cap-count');
      const badgeEl = els.head.querySelector('.gw-cap-status');
      const deltaEl = els.head.querySelector('.gw-cap-delta');
      if (!countEl || !badgeEl) return;
      countEl.textContent = countText;

      const badge = statusBadge(slot.status);
      badgeEl.textContent       = badge.text;
      badgeEl.style.background  = badge.bg;
      badgeEl.style.color       = badge.fg;

      // Delta pill — only meaningful once DB hydration has resolved.
      if (deltaEl) {
        const p = deltaPill(key, slot);
        if (p.show) {
          deltaEl.textContent      = p.text;
          deltaEl.style.background = p.bg;
          deltaEl.style.color      = p.fg;
          deltaEl.style.display    = 'inline-block';
        } else {
          deltaEl.style.display    = 'none';
        }
      }

      els.body.innerHTML = bodyFor(key, slot);

      // Any row update can change the aggregate delta state, so re-render
      // the save button label (cheap — just text + disabled toggle).
      refreshSaveBtn();
    }

    // Save button label + disabled state, derived from diffAll(). Called
    // on every row refresh; idempotent and trivially cheap.
    function refreshSaveBtn() {
      if (!btn) return;
      // Don't fight the user mid-save — if the button is showing "Saving…"
      // or "✓ Saved" we leave it alone until the next render cycle.
      if (btn.dataset.busy === '1') return;

      const { hasDb, anyChanges, anyOnFile, overall } = diffAll();

      if (overall === 'no-db') {
        // No DB row yet — first save. Standard "Save" button.
        btn.textContent          = 'Save to GoWarmCRM';
        btn.disabled             = false;
        btn.style.background     = ORANGE;
        btn.style.opacity        = '1';
        btn.style.cursor         = 'pointer';
      } else if (overall === 'unchanged') {
        // Profile on file and live matches — no point saving.
        btn.textContent          = '✓ Already up to date';
        btn.disabled             = true;
        btn.style.background     = '#94A3B8';
        btn.style.opacity        = '0.85';
        btn.style.cursor         = 'default';
      } else {
        // hasDb && anyChanges — refresh path.
        btn.textContent          = 'Refresh in GoWarmCRM';
        btn.disabled             = false;
        btn.style.background     = ORANGE;
        btn.style.opacity        = '1';
        btn.style.cursor         = 'pointer';
      }
    }

    SECTIONS.forEach(def => refreshRow(def.key));
    captureSubscribe(section => refreshRow(section));
    refreshSaveBtn();   // first render before any subscription fires

    // ── Save button (skipped entirely when hideSaveButton: true) ─────────────
    if (!btn) return;

    btn.addEventListener('click', async () => {
      // Reset transient feedback / warning
      feedback.style.display = 'none';
      warning.style.display  = 'none';

      const captured = captureFullProfile();

      // Warn if any section is still pending — i.e. the user hasn't scrolled
      // it into view yet. This is recoverable — they can confirm and continue.
      const pending = Object.entries(captured.progress)
        .filter(([_, st]) => st === 'pending' || st === 'loading')
        .map(([k]) => k);

      if (pending.length > 0 && !btn.dataset.confirmedIncomplete) {
        warning.style.display = 'block';
        warning.innerHTML = `
          <div style="margin-bottom:6px;"><strong>Capture is incomplete.</strong> These sections haven't loaded yet: ${escHtml(pending.join(', '))}.</div>
          <div style="display:flex;gap:6px;">
            <button id="gw-cap-cancel" style="flex:1;padding:5px;background:#fff;border:1px solid #D1D5DB;border-radius:4px;font-size:11px;cursor:pointer;">Cancel</button>
            <button id="gw-cap-continue" style="flex:1;padding:5px;background:${ORANGE};color:#fff;border:none;border-radius:4px;font-size:11px;font-weight:600;cursor:pointer;">Send anyway</button>
          </div>
        `;
        warning.querySelector('#gw-cap-cancel').addEventListener('click', () => {
          warning.style.display = 'none';
        });
        warning.querySelector('#gw-cap-continue').addEventListener('click', () => {
          btn.dataset.confirmedIncomplete = '1';
          warning.style.display = 'none';
          btn.click();
        });
        return;
      }

      // Validate that we have at least *something* to send. A rep action with
      // no captured sections (e.g. removing a stale role) still has `edits` to
      // persist, so allow that through too.
      const c = captured.counts;
      const totalSignal = c.about + c.experience + c.education + c.activity;
      if (totalSignal === 0 && !captured.edits) {
        feedback.style.cssText = 'margin-top:6px;font-size:11px;display:block;color:#dc2626;';
        feedback.textContent = 'Nothing captured yet. Scroll the page to load profile sections, then try again.';
        return;
      }

      btn.disabled    = true;
      btn.dataset.busy = '1';   // pause refreshSaveBtn while we control the label
      btn.textContent = 'Saving…';

      try {
        const memberUrn = await currentProfileMemberUrn();   // v1.20: live-resolved fsd_profile URN
        const res = await bgMessage({
          type:        'UPSERT_LINKEDIN_PROFILE',
          linkedinUrl: captured.linkedin_url,
          fields:      captured.fields,
          edits:       captured.edits || undefined,
          linkTo: prospect ? { entity_type: 'prospects', entity_id: prospect.id } : null,
          memberUrn:   memberUrn || undefined,
        });

        if (!res.ok) throw new Error(res.error);

        // ── Re-hydrate dbValue from the upsert response (NEW in v1.5) ────────
        // The server returns the merged row, so we use it as the new
        // baseline. After this, every section's diff flips to either
        // 'unchanged' (live matched what we sent) or 'on-file' if the
        // server's merge rules kept some prior data. The save button
        // will be re-evaluated by refreshSaveBtn() once we clear busy.
        if (res.profile) {
          hydrateFromDbProfile(res.profile);
        }
        // Session directives are now persisted in the row's capture_meta
        // (and re-seeded into slot.meta by hydrateFromDbProfile above), so
        // reset the pending set to avoid re-sending them on the next save.
        clearPendingEdits();

        // Refresh the debug-IDs strip with whatever the upsert returned.
        // Account id and prospect id may have been populated on init already;
        // we restate them along with the now-confirmed profile_id.
        renderDebugIds(panel, {
          profile_id:  res.profile_id || res.profile?.id || null,
          prospect_id: prospect?.id || null,
          account_id:  res.account_id || prospect?.account?.id || prospect?.account_id || null,
        });

        btn.style.background = '#059669';
        btn.textContent      = '✓ Saved';
        feedback.style.cssText = 'margin-top:6px;font-size:11px;display:block;color:#059669;';
        feedback.textContent   = prospect && diffAll().hasDb
          ? 'Profile refreshed in GoWarmCRM.'
          : 'Profile saved to GoWarmCRM.';

        // After a brief pause showing ✓ Saved, return the button to its
        // diff-derived state (will read 'Already up to date' since we
        // just synced).
        setTimeout(() => {
          delete btn.dataset.busy;
          btn.style.background = ORANGE;   // refreshSaveBtn will repaint
          refreshSaveBtn();
        }, 1500);
      } catch (err) {
        btn.disabled        = false;
        delete btn.dataset.busy;
        btn.style.background = ORANGE;
        // Let refreshSaveBtn pick the right label given current diff state.
        refreshSaveBtn();
        feedback.style.cssText = 'margin-top:6px;font-size:11px;display:block;color:#dc2626;';
        feedback.textContent = err.message;
      } finally {
        delete btn.dataset.confirmedIncomplete;
      }
    });
  }

  // Format helper used by experience body renderer.
  function formatDateRange(startDate, endDate, durationMonths) {
    function fmt(d) {
      if (!d) return null;
      try {
        const dt = new Date(d);
        return dt.toLocaleDateString(undefined, { year: 'numeric', month: 'short' });
      } catch (_) { return d; }
    }
    const s = fmt(startDate);
    const e = endDate ? fmt(endDate) : 'Present';
    const dur = durationMonths
      ? (() => {
          const y = Math.floor(durationMonths / 12);
          const m = durationMonths % 12;
          return `${y ? `${y}y ` : ''}${m ? `${m}mo` : ''}`.trim();
        })()
      : '';
    if (!s) return dur || '';
    return `${s} \u2013 ${e}${dur ? ` · ${dur}` : ''}`;
  }

  // ── Main prospect view ───────────────────────────────────────────────────────

  // ── Smart-suggest helper (v1.8) ───────────────────────────────────────────
  // Renders the amber "Not in your current campaign" prompt for found
  // prospects whose campaign_id and/or sequence enrollment doesn't
  // match the rep's defaults. Empty (no DOM appended) when:
  //   - rep has no defaults set
  //   - prospect is already in the default campaign AND enrolled in the
  //     default sequence
  //   - lists fail to load
  //
  // The "Add to <campaign> → <sequence>" link calls PUSH_PROSPECT_TO_TARGET,
  // which assigns campaign + enrolls in sequence atomically (well, with
  // the same partial-failure semantics as the new-prospect path).
  async function renderSmartSuggest(slot, prospect) {
    const orgId = await getOrgIdCached();
    const defaults = await readPushDefaults(orgId);

    // No defaults → nothing to suggest.
    if (!defaults.campaignId && !defaults.sequenceId) return;

    // Only prompt for prospects who aren't being worked ANYWHERE yet. A prospect
    // already in a campaign and/or enrolled in a sequence is "targeted" — even if
    // it isn't the rep's push-default. Nagging those to move to the default is
    // wrong when a different campaign is actively being run (the prior behaviour
    // flagged a correctly-enrolled CRO-Dogfood prospect as "not in target" just
    // because the default sequence was something else).
    const hasCampaign = !!prospect.campaign_id;
    const hasSequence = (prospect.activeSequenceIds || []).length > 0;
    if (hasCampaign || hasSequence) return;

    // Need names to render the prompt. Skip silently if list fetch fails
    // — the rep can still see the prospect's existing state, just no
    // suggestion overlay.
    const lists = await ensurePickerLists();
    if (lists.error && !lists.campaigns.length && !lists.sequences.length) return;

    const campName = defaults.campaignId
      ? (lookupCampaignName(defaults.campaignId) || `campaign #${defaults.campaignId}`)
      : null;
    const seqName  = defaults.sequenceId
      ? (lookupSequenceName(defaults.sequenceId) || `sequence #${defaults.sequenceId}`)
      : null;

    // Untargeted prospect — offer to drop them into the rep's defaults.
    let suggestionText;
    if (campName && seqName) {
      suggestionText = `Add to <strong>${escHtml(campName)}</strong> → enroll in <strong>${escHtml(seqName)}</strong>?`;
    } else if (campName) {
      suggestionText = `Add to <strong>${escHtml(campName)}</strong>?`;
    } else {
      suggestionText = `Enroll in <strong>${escHtml(seqName)}</strong>?`;
    }

    slot.innerHTML = `
      <div style="margin:8px 13px;padding:8px 10px;background:#FFFBEB;border:1px solid #FDE68A;border-radius:5px;">
        <div style="font-size:11px;color:#78350F;line-height:1.4;">
          Not in any campaign or sequence yet.<br>
          <a id="gw-smart-suggest-link" style="color:#0F766E;text-decoration:underline;cursor:pointer;font-size:11px;">${suggestionText}</a>
          <a id="gw-smart-suggest-dismiss" style="color:#94a3b8;text-decoration:underline;cursor:pointer;font-size:10px;margin-left:8px;">dismiss</a>
        </div>
        <div id="gw-smart-suggest-feedback" style="font-size:10px;margin-top:4px;display:none;"></div>
      </div>
    `;

    const link = slot.querySelector('#gw-smart-suggest-link');
    const dismiss = slot.querySelector('#gw-smart-suggest-dismiss');
    const fb = slot.querySelector('#gw-smart-suggest-feedback');

    dismiss.addEventListener('click', () => { slot.innerHTML = ''; });

    link.addEventListener('click', async () => {
      link.style.pointerEvents = 'none';
      link.style.opacity = '0.5';
      fb.style.cssText = 'font-size:10px;margin-top:4px;display:block;color:#78350F;';
      fb.textContent = 'Adding…';

      // This prompt only renders for prospects in NO campaign and NO
      // sequence (the hasCampaign/hasSequence guard above returns early
      // otherwise), so both default fields always need setting. Send
      // whatever defaults the rep has configured.
      const payload = { prospectId: prospect.id };
      if (defaults.campaignId) payload.campaignId = defaults.campaignId;
      if (defaults.sequenceId) payload.sequenceId = defaults.sequenceId;

      try {
        const res = await bgMessage({ type: 'PUSH_PROSPECT_TO_TARGET', ...payload });
        if (!res.ok) throw new Error(res.error);

        if (res.enrollmentError) {
          // Campaign updated but enrollment failed — partial success.
          // Keep the prompt visible so the rep can retry the sequence
          // piece, but say what happened.
          fb.style.color = '#b45309';
          fb.textContent = `Campaign set. Enrollment failed: ${res.enrollmentError}`;
          link.style.pointerEvents = '';
          link.style.opacity = '';
          return;
        }

        fb.style.color = '#059669';
        fb.textContent = '✓ Done';
        setTimeout(() => { slot.innerHTML = ''; }, 1200);
      } catch (err) {
        fb.style.color = '#dc2626';
        fb.textContent = err.message || 'Failed';
        link.style.pointerEvents = '';
        link.style.opacity = '';
      }
    });
  }

  // ── Full activity feed (chronological) ───────────────────────────────────────
  // Opens a slide-over panel layered above the main one, showing every recorded
  // activity for this prospect (LinkedIn events, stage changes, etc.) pulled
  // from /prospects/:id/activities. Timestamps render in the reader's local
  // timezone; the captured note text is shown inline where present.

  // Derive a colour, clean label, and note text for one activity row.
  function activityVisual(a) {
    let md = a.metadata || {};
    if (typeof md === 'string') { try { md = JSON.parse(md); } catch { md = {}; } }

    if (a.activity_type === 'linkedin_event') {
      const ev = EVENTS.find(e => e.key === md.event);
      let label = ev ? ev.label : (a.description || 'LinkedIn activity');
      if (md.sentiment) label += ` · ${md.sentiment}`;
      return { color: ev ? ev.color : '#5F5E5A', label, note: md.note || '', md };
    }
    const TYPE_COLOR = {
      stage_change:   '#185FA5',
      account_linked: '#0F6E56',
      contact_linked: '#0F6E56',
      import:         '#5F5E5A',
      enrichment:     '#854F0B',
    };
    return {
      color: TYPE_COLOR[a.activity_type] || '#5F5E5A',
      label: a.description || (a.activity_type || 'Activity').replace(/_/g, ' '),
      note:  md.note || '',
      md,
    };
  }

  // Build the expandable detail body for one activity: any text fields
  // (message/note/reply/summary) as quoted blocks, plus the remaining metadata
  // as a labelled list. Returns '' when there's nothing beyond the row header,
  // so the caller can skip the expand affordance for those rows.
  function activityDetailHtml(a, v) {
    const md    = v.md || {};
    const color = v.color;
    const blocks = [];

    // Full description, if it carries more than the row label already shows.
    if (a.description && a.description !== v.label) {
      blocks.push(`<div style="font-size:11px;color:#475569;margin-bottom:2px;line-height:1.4;">${escHtml(a.description)}</div>`);
    }

    const quoted = (label, text) =>
      `<div style="margin-top:6px;padding:6px 8px;background:#fff;border:1px solid #e2e8f0;border-left:3px solid ${color};border-radius:0 6px 6px 0;">` +
        `<div style="font-size:8px;letter-spacing:0.04em;text-transform:uppercase;color:#94a3b8;font-weight:600;margin-bottom:3px;">${escHtml(label)}</div>` +
        `<div style="font-size:11px;color:#374151;white-space:pre-wrap;word-break:break-word;line-height:1.4;">${escHtml(text)}</div>` +
      `</div>`;

    const seen = new Set();
    const pushText = (label, val) => {
      if (val && typeof val === 'string' && val.trim() && !seen.has(val.trim())) {
        seen.add(val.trim());
        blocks.push(quoted(label, val));
      }
    };

    // LinkedIn events label their note by event type (Message / Reply / etc.).
    const LI_NOTE_LABEL = {
      connection_request_sent: 'Connection note', message_sent: 'Message',
      inmail_sent: 'InMail', reply_received: 'Reply', meeting_booked: 'Meeting note',
    };
    if (a.activity_type === 'linkedin_event' && md.note) {
      pushText(LI_NOTE_LABEL[md.event] || 'Note', md.note);
    }
    // Generic text fields written by other subsystems (sequence sends, etc.).
    [['note', 'Note'], ['message', 'Message'], ['message_body', 'Message'], ['body', 'Message'],
     ['rendered_body', 'Message'], ['reply', 'Reply'], ['reply_text', 'Reply'], ['summary', 'Summary'],
    ].forEach(([k, lab]) => pushText(lab, md[k]));

    // Remaining scalar metadata as a labelled list.
    const META_LABELS = {
      channel: 'Channel', sentiment: 'Sentiment', step: 'Step', stepNumber: 'Step', step_number: 'Step',
      sequenceName: 'Sequence', sequence: 'Sequence', campaignName: 'Campaign', campaign: 'Campaign',
      stage: 'Stage', actionCount: 'Actions created', playbookId: 'Playbook', time_source: 'Logged',
    };
    const SKIP = new Set(['note', 'message', 'message_body', 'body', 'rendered_body', 'reply',
      'reply_text', 'summary', 'event', 'occurred_at', 'logged_at']);
    const metaRows = [];
    Object.keys(md).forEach(k => {
      if (SKIP.has(k)) return;
      const val = md[k];
      if (val == null || val === '' || typeof val === 'object') return;
      const label = META_LABELS[k] || k.replace(/_/g, ' ');
      let display = String(val);
      if (k === 'time_source') display = val === 'manual' ? 'manually entered' : 'auto-stamped';
      metaRows.push(
        `<div style="display:flex;gap:8px;font-size:10px;margin-top:3px;">` +
          `<span style="color:#94a3b8;min-width:66px;text-transform:capitalize;flex-shrink:0;">${escHtml(label)}</span>` +
          `<span style="color:#475569;word-break:break-word;">${escHtml(display)}</span>` +
        `</div>`);
    });
    if (metaRows.length) blocks.push(`<div style="margin-top:6px;">${metaRows.join('')}</div>`);

    return blocks.join('');
  }

  function renderFeedList(bodyEl, activities, newestFirst) {
    // The endpoint returns newest-first; reverse for true chronological order.
    const list = newestFirst ? activities : activities.slice().reverse();
    if (!list.length) {
      bodyEl.innerHTML = '<div style="padding:18px 14px;text-align:center;color:#94a3b8;font-size:12px;">No activity recorded with this prospect yet.</div>';
      return;
    }
    let html = '';
    list.forEach((a, i) => {
      const v       = activityVisual(a);
      const when    = formatDateTime(a.created_at);
      const who     = [a.user_first_name, a.user_last_name].filter(Boolean).join(' ');
      const isLast  = i === list.length - 1;
      const manual  = v.md && v.md.time_source === 'manual' && v.md.logged_at;
      const detail  = activityDetailHtml(a, v);
      const hasDet  = !!detail;
      html += `
        <div style="display:flex;gap:9px;padding:0 14px;">
          <div style="display:flex;flex-direction:column;align-items:center;flex-shrink:0;padding-top:4px;">
            <div style="width:9px;height:9px;border-radius:50%;background:${v.color};flex-shrink:0;"></div>
            ${!isLast ? `<div style="width:1px;flex:1;min-height:16px;background:#e2e8f0;margin-top:2px;"></div>` : ''}
          </div>
          <div style="padding-bottom:${isLast ? 4 : 14}px;min-width:0;flex:1;">
            <div class="gw-feed-row" data-idx="${i}" style="display:flex;align-items:flex-start;gap:6px;${hasDet ? 'cursor:pointer;' : ''}">
              <div style="flex:1;min-width:0;">
                <div style="font-size:12px;color:#1a202c;font-weight:500;line-height:1.35;">${escHtml(v.label)}</div>
                <div style="font-size:10px;color:#94a3b8;margin-top:1px;">${escHtml(when)}${who ? ' · ' + escHtml(who) : ''}</div>
                ${manual ? `<div style="font-size:9px;color:#b45309;margin-top:1px;">back-dated · logged ${escHtml(formatDateTime(v.md.logged_at))}</div>` : ''}
              </div>
              ${hasDet ? `<span class="gw-feed-chev" style="color:#cbd5e1;font-size:11px;flex-shrink:0;transition:transform .15s ease;padding-top:2px;">▸</span>` : ''}
            </div>
            ${hasDet ? `<div class="gw-feed-detail" data-idx="${i}" style="display:none;margin-top:5px;">${detail}</div>` : ''}
          </div>
        </div>`;
    });
    bodyEl.innerHTML = html;

    // Wire expand/collapse (re-attached on every render, incl. sort toggle).
    bodyEl.querySelectorAll('.gw-feed-row').forEach(rowEl => {
      const idx  = rowEl.dataset.idx;
      const det  = bodyEl.querySelector(`.gw-feed-detail[data-idx="${idx}"]`);
      if (!det) return;
      const chev = rowEl.querySelector('.gw-feed-chev');
      rowEl.addEventListener('click', () => {
        const open = det.style.display !== 'none';
        det.style.display = open ? 'none' : 'block';
        if (chev) {
          chev.style.transform = open ? 'rotate(0deg)' : 'rotate(90deg)';
          chev.style.color     = open ? '#cbd5e1' : '#64748b';
        }
      });
    });
  }

  // Run the individual-segmentation skill and present the result in a slide-over.
  function openSegmentation(prospect) {
    document.getElementById(FEED_ID)?.remove();
    const ov = document.createElement('div');
    ov.id = FEED_ID;
    ov.style.cssText = 'position:fixed;top:72px;right:16px;width:300px;max-height:calc(100vh - 96px);background:#fff;border:1px solid #e2e8f0;border-radius:10px;box-shadow:0 6px 24px rgba(0,0,0,0.16);z-index:2147483646;display:flex;flex-direction:column;overflow:hidden;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;';
    const name = (prospect && (prospect.first_name || prospect.full_name)) || 'prospect';
    ov.innerHTML = `
      <div style="background:${TEAL};padding:9px 13px;display:flex;align-items:center;justify-content:space-between;flex-shrink:0;">
        <div style="display:flex;align-items:center;gap:6px;min-width:0;">
          <button id="gw-seg-back" style="background:none;border:none;color:#fff;font-size:20px;cursor:pointer;line-height:1;padding:0 2px 0 0;">‹</button>
          <span style="color:#fff;font-size:12px;font-weight:600;white-space:nowrap;">Segmentation · ${escHtml(String(name))}</span>
        </div>
      </div>
      <div id="gw-seg-body" style="overflow-y:auto;padding:14px;flex:1 1 auto;font-size:12px;color:#475569;">
        <div style="display:flex;align-items:center;gap:8px;color:#64748b;"><span class="gw-seg-spin" style="display:inline-block;width:13px;height:13px;border:2px solid #cbd5e1;border-top-color:${TEAL};border-radius:50%;animation:gwspin 0.7s linear infinite;"></span> Analysing signals…</div>
        <div style="font-size:10px;color:#94a3b8;margin-top:8px;">Running the individual-segmentation skill on the saved profile.</div>
      </div>
      <style>@keyframes gwspin{to{transform:rotate(360deg)}}</style>`;
    document.body.appendChild(ov);
    ov.querySelector('#gw-seg-back').addEventListener('click', () => ov.remove());
    const body = ov.querySelector('#gw-seg-body');

    bgMessage({ type: 'RUN_SEGMENTATION', prospectId: prospect.id })
      .then(resp => {
        if (!resp || !resp.ok) {
          body.innerHTML = `<div style="color:#dc2626;font-size:12px;">Couldn't run segmentation.</div><div style="font-size:10px;color:#94a3b8;margin-top:6px;">${escHtml((resp && resp.error) || 'Unknown error')}</div>`;
          return;
        }
        const r = resp.result || {};
        if (r.ok === false || !r.output) {
          body.innerHTML = `<div style="color:#b45309;font-size:12px;">The skill ran but returned no parseable segmentation${r.status ? ' (' + escHtml(r.status) + ')' : ''}.</div>`;
          return;
        }
        body.innerHTML = renderSegmentation(r.output);
      })
      .catch(err => {
        body.innerHTML = `<div style="color:#dc2626;font-size:12px;">Couldn't run segmentation.</div><div style="font-size:10px;color:#94a3b8;margin-top:6px;">${escHtml(err.message || String(err))}</div>`;
      });
  }

  // Render the segmentation JSON (segments + verifiable attributes).
  function renderSegmentation(out) {
    const CONF = { high: '#059669', medium: '#BA7517', low: '#94a3b8' };
    const cap = s => String(s || '').replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
    let html = '';

    const segs = out.segments || {};
    Object.keys(segs).forEach(key => {
      const s = segs[key] || {};
      const cc = CONF[s.confidence] || '#94a3b8';
      html += `<div style="margin-bottom:9px;">
        <div style="display:flex;align-items:baseline;justify-content:space-between;gap:6px;">
          <span style="font-size:9px;text-transform:uppercase;letter-spacing:0.04em;color:#94a3b8;font-weight:600;">${escHtml(cap(key))}</span>
          <span style="font-size:8px;color:${cc};font-weight:600;text-transform:uppercase;">${escHtml(s.confidence || '')}</span>
        </div>
        <div style="font-size:13px;color:#1a202c;font-weight:600;">${escHtml(cap(s.value))}</div>`;
      if (Array.isArray(s.evidence) && s.evidence.length) {
        html += `<div style="margin-top:2px;">` + s.evidence.map(e =>
          `<div style="font-size:10px;color:#64748b;line-height:1.35;">· ${escHtml(e)}</div>`).join('') + `</div>`;
      }
      if (s.attributes && typeof s.attributes === 'object') {
        const a = Object.entries(s.attributes).filter(([, v]) => v != null && v !== '')
          .map(([k, v]) => `${cap(k)}: ${escHtml(String(v))}`).join(' · ');
        if (a) html += `<div style="font-size:9px;color:#94a3b8;margin-top:2px;">${a}</div>`;
      }
      html += `</div>`;
    });

    const pm = out.icp_persona_match;
    if (pm && pm.matched !== undefined) {
      const col = pm.matched === true ? '#059669' : (pm.matched === false ? '#dc2626' : '#94a3b8');
      html += `<div style="margin:10px 0;padding:7px 9px;background:#f8fafc;border:1px solid #f1f5f9;border-left:3px solid ${col};border-radius:0 6px 6px 0;">
        <div style="font-size:9px;text-transform:uppercase;letter-spacing:0.04em;color:#94a3b8;font-weight:600;">ICP persona match</div>
        <div style="font-size:12px;color:#1a202c;font-weight:600;margin-top:1px;">${escHtml(String(pm.matched))}${pm.persona ? ' · ' + escHtml(pm.persona) : ''}</div>
        ${pm.rationale ? `<div style="font-size:10px;color:#64748b;margin-top:2px;line-height:1.4;">${escHtml(pm.rationale)}</div>` : ''}
      </div>`;
    }

    const va = out.verify_attributes;
    if (va && typeof va === 'object') {
      const rows = Object.entries(va).filter(([, v]) => v != null && v !== '' && !(Array.isArray(v) && !v.length))
        .map(([k, v]) => `<div style="display:flex;gap:8px;font-size:10px;margin-top:3px;"><span style="color:#94a3b8;min-width:88px;flex-shrink:0;">${escHtml(cap(k))}</span><span style="color:#475569;word-break:break-word;">${escHtml(Array.isArray(v) ? v.join(', ') : String(v))}</span></div>`).join('');
      if (rows) html += `<div style="margin-top:10px;border-top:1px solid #f1f5f9;padding-top:8px;"><div style="font-size:9px;text-transform:uppercase;letter-spacing:0.04em;color:#94a3b8;font-weight:600;margin-bottom:2px;">Verify against</div>${rows}</div>`;
    }

    const list = (title, arr, color) => {
      if (!Array.isArray(arr) || !arr.length) return '';
      return `<div style="margin-top:10px;"><div style="font-size:9px;text-transform:uppercase;letter-spacing:0.04em;color:${color};font-weight:600;margin-bottom:2px;">${escHtml(title)}</div>` +
        arr.map(x => `<div style="font-size:10px;color:#64748b;line-height:1.4;">· ${escHtml(String(x))}</div>`).join('') + `</div>`;
    };
    html += list('Missing individual signals', out.missing_signals, '#94a3b8');
    html += list('Company signals needed (captured elsewhere)', out.company_signals_needed, '#854F0B');

    if (out.confidence_overall) {
      html += `<div style="margin-top:10px;font-size:10px;color:#94a3b8;">Overall confidence: <strong style="color:${CONF[out.confidence_overall] || '#64748b'};">${escHtml(out.confidence_overall)}</strong></div>`;
    }
    if (out.notes) html += `<div style="margin-top:6px;font-size:10px;color:#94a3b8;line-height:1.4;">${escHtml(out.notes)}</div>`;
    return html || '<div style="color:#94a3b8;font-size:12px;">No segmentation returned.</div>';
  }

  function openActivityFeed(prospect) {
    document.getElementById(FEED_ID)?.remove();
    const firstName = prospect.first_name || prospect.firstName || '';

    const overlay = document.createElement('div');
    overlay.id = FEED_ID;
    overlay.style.cssText = `
      position:fixed; top:72px; right:16px; width:290px;
      background:#ffffff; border:1px solid #e2e8f0; border-radius:10px;
      box-shadow:0 6px 24px rgba(0,0,0,0.16);
      font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
      font-size:13px; color:#1a202c; z-index:10000; overflow:hidden;
      max-height:calc(100vh - 90px); display:flex; flex-direction:column;`;
    overlay.innerHTML = `
      <div style="background:${TEAL};padding:9px 13px;display:flex;align-items:center;justify-content:space-between;flex-shrink:0;">
        <div style="display:flex;align-items:center;gap:6px;min-width:0;">
          <button id="gw-feed-back" title="Back" style="background:none;border:none;color:#fff;font-size:20px;cursor:pointer;line-height:1;padding:0 2px 0 0;">‹</button>
          <span style="color:#fff;font-size:12px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">Activity${firstName ? ' · ' + escHtml(firstName) : ''}</span>
        </div>
        <button id="gw-feed-sort" style="background:rgba(255,255,255,0.18);border:none;color:#fff;font-size:9px;font-weight:600;cursor:pointer;padding:3px 7px;border-radius:4px;white-space:nowrap;">Newest</button>
      </div>
      <div id="gw-feed-body" style="overflow-y:auto;padding:13px 0;flex:1 1 auto;">
        <div style="padding:18px 14px;text-align:center;color:#94a3b8;font-size:12px;">Loading activity…</div>
      </div>`;
    document.body.appendChild(overlay);

    const body    = overlay.querySelector('#gw-feed-body');
    const sortBtn = overlay.querySelector('#gw-feed-sort');
    let newestFirst = true;
    let activities  = [];

    overlay.querySelector('#gw-feed-back').addEventListener('click', () => overlay.remove());
    sortBtn.addEventListener('click', () => {
      newestFirst = !newestFirst;
      sortBtn.textContent = newestFirst ? 'Newest' : 'Oldest';
      renderFeedList(body, activities, newestFirst);
    });

    bgMessage({ type: 'GET_ACTIVITIES', prospectId: prospect.id })
      .then(res => {
        if (!res.ok) throw new Error(res.error || 'Failed to load activity');
        activities = res.activities || [];
        renderFeedList(body, activities, newestFirst);
      })
      .catch(err => {
        body.innerHTML = `<div style="padding:18px 14px;text-align:center;color:#dc2626;font-size:12px;">${escHtml(err.message)}</div>`;
      });
  }

  function renderProspect(panel, prospect) {
    const li          = prospect.channel_data?.linkedin || {};

    // ── Prospect strip ──
    const strip = document.createElement('div');
    strip.style.cssText = 'padding:8px 13px;border-bottom:1px solid #f1f5f9;display:flex;align-items:center;gap:8px;';
    const draftBadgeHtml = prospect.pendingDrafts > 0
      ? `<a href="https://app.gowarmcrm.com/#/prospecting/${prospect.id}" target="_blank"
           title="Open drafts in GoWarmCRM"
           style="display:inline-flex;align-items:center;gap:3px;font-size:10px;padding:2px 7px;
                  border-radius:10px;background:#FFF3E0;color:#E8630A;font-weight:600;
                  white-space:nowrap;text-decoration:none;border:1px solid #FBCF9D;">
           ✉️ ${prospect.pendingDrafts} draft${prospect.pendingDrafts > 1 ? 's' : ''} pending
         </a>`
      : '';

    strip.innerHTML = `
      <div style="flex:1;min-width:0;">
        <div style="font-size:11px;color:#64748b;">${escHtml(prospect.company_name || '')}</div>
      </div>
      ${draftBadgeHtml}
      <span style="font-size:10px;padding:2px 7px;border-radius:10px;background:#E6F1FB;color:#185FA5;font-weight:500;white-space:nowrap;">
        ${prospect.stage || 'target'}
      </span>
      ${prospect.linkedin_url ? `<a href="${escHtml(prospect.linkedin_url)}" target="_blank"
        style="font-size:10px;color:#0077B5;text-decoration:none;white-space:nowrap;">View ↗</a>` : ''}
    `;
    panel.appendChild(strip);

    // ── Current target badge (v1.8.1) ────────────────────────────────────────
    // Informational, always-on. Shows the prospect's actual campaign and
    // active sequence enrollments (blank where there isn't one). This is
    // independent of the rep's defaults — the rep wants to see where THIS
    // person sits, not where new captures would go.
    //
    // Multiple active sequences are possible (one row per (sequence_id,
    // prospect_id)). We show the first two by name and "+N more" beyond
    // that to keep the strip compact. The strip is borderless and uses
    // a quieter grey so it doesn't fight the colored amber smart-suggest
    // prompt that may appear right below it.
    // Mutable view of the prospect's current targeting, updated in place after
    // a successful add so the strip reflects the change without a full reload.
    let curCamp = prospect.campaign || null;
    let curSeqs = Array.isArray(prospect.activeSequences) ? prospect.activeSequences.slice() : [];
    const targetStrip = document.createElement('div');
    targetStrip.style.cssText = 'padding:7px 13px;border-bottom:1px solid #f1f5f9;display:flex;gap:12px;font-size:10px;color:#64748b;line-height:1.4;align-items:center;';

    function renderTargetStrip() {
      const campLabel = curCamp
        ? `<strong style="color:#1F2937;font-weight:600;">${escHtml(curCamp.name)}</strong>`
        : `<span style="color:#94a3b8;font-style:italic;">none</span>`;

      let seqLabel;
      if (curSeqs.length === 0) {
        seqLabel = `<span style="color:#94a3b8;font-style:italic;">none</span>`;
      } else if (curSeqs.length <= 2) {
        seqLabel = curSeqs.map(s => `<strong style="color:#1F2937;font-weight:600;">${escHtml(s.name)}</strong>`).join(', ');
      } else {
        const shown = curSeqs.slice(0, 2).map(s => `<strong style="color:#1F2937;font-weight:600;">${escHtml(s.name)}</strong>`).join(', ');
        seqLabel = `${shown} <span style="color:#94a3b8;">+${curSeqs.length - 2} more</span>`;
      }

      targetStrip.innerHTML = `
        <div style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">
          <span style="text-transform:uppercase;letter-spacing:0.05em;font-size:9px;color:#94a3b8;">Campaign · </span>${campLabel}
        </div>
        <div style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">
          <span style="text-transform:uppercase;letter-spacing:0.05em;font-size:9px;color:#94a3b8;">Sequence · </span>${seqLabel}
        </div>
        <a id="gw-target-edit" style="font-size:10px;color:#0F766E;text-decoration:underline;cursor:pointer;white-space:nowrap;flex-shrink:0;">${curCamp ? 'change' : '+ campaign'}</a>
      `;
      targetStrip.querySelector('#gw-target-edit')?.addEventListener('click', openTargetPicker);
    }

    renderTargetStrip();
    panel.appendChild(targetStrip);

    // ── Inline add/move-to-campaign picker (v1.18) ───────────────────────────
    // Existing prospects previously had no way to be (re-)added to a campaign
    // from the panel — the picker only existed on the "add new prospect" form,
    // and the one-click smart-suggest below is suppressed once the prospect has
    // any campaign or sequence. This slot exposes the same campaign + sequence
    // lists and routes the choice through PUSH_PROSPECT_TO_TARGET.
    const targetPickerSlot = document.createElement('div');
    panel.appendChild(targetPickerSlot);

    async function openTargetPicker() {
      targetPickerSlot.innerHTML = `<div style="padding:8px 13px;font-size:11px;color:#94a3b8;border-bottom:1px solid #f1f5f9;">Loading campaigns + sequences…</div>`;
      const lists = await ensurePickerLists();
      if (lists.error && !lists.campaigns.length && !lists.sequences.length) {
        targetPickerSlot.innerHTML = `
          <div style="padding:8px 13px;border-bottom:1px solid #f1f5f9;">
            <div style="background:#FEF2F2;border:1px solid #FECACA;border-radius:5px;padding:7px 9px;font-size:11px;color:#991B1B;">
              Could not load campaigns/sequences. <a id="gw-tp-cancel" style="color:#991B1B;text-decoration:underline;cursor:pointer;">Close</a>
            </div>
          </div>`;
        targetPickerSlot.querySelector('#gw-tp-cancel')?.addEventListener('click', () => { targetPickerSlot.innerHTML = ''; });
        return;
      }

      const curCampId = curCamp ? curCamp.id : '';
      const curSeqId  = curSeqs.length ? curSeqs[0].id : '';
      const campOpts = ['<option value="">— No campaign —</option>']
        .concat(lists.campaigns.map(c => `<option value="${c.id}" ${String(c.id) === String(curCampId) ? 'selected' : ''}>${escHtml(c.name)}</option>`))
        .join('');
      const seqOpts = ['<option value="">— No sequence —</option>']
        .concat(lists.sequences.map(s => `<option value="${s.id}" ${String(s.id) === String(curSeqId) ? 'selected' : ''}>${escHtml(s.name)}</option>`))
        .join('');

      targetPickerSlot.innerHTML = `
        <div style="padding:9px 13px;border-bottom:1px solid #f1f5f9;background:#F8FAFC;">
          <div style="margin-bottom:6px;">
            <label style="font-size:9px;color:#64748b;text-transform:uppercase;letter-spacing:0.05em;display:block;margin-bottom:2px;">Campaign</label>
            <select id="gw-tp-camp" style="width:100%;padding:5px 7px;border:1px solid #e2e8f0;border-radius:5px;font-size:12px;background:#fff;">${campOpts}</select>
          </div>
          <div style="margin-bottom:8px;">
            <label style="font-size:9px;color:#64748b;text-transform:uppercase;letter-spacing:0.05em;display:block;margin-bottom:2px;">Sequence</label>
            <select id="gw-tp-seq" style="width:100%;padding:5px 7px;border:1px solid #e2e8f0;border-radius:5px;font-size:12px;background:#fff;">${seqOpts}</select>
          </div>
          <div id="gw-tp-fb" style="font-size:11px;margin-bottom:6px;display:none;"></div>
          <div style="display:flex;gap:6px;">
            <button id="gw-tp-add" style="flex:1;padding:6px;background:${TEAL};color:#fff;border:none;border-radius:5px;font-size:12px;font-weight:600;cursor:pointer;">Add to campaign</button>
            <button id="gw-tp-cancel" style="padding:6px 12px;background:#fff;color:#64748b;border:1px solid #e2e8f0;border-radius:5px;font-size:12px;cursor:pointer;">Cancel</button>
          </div>
        </div>
      `;

      const campEl = targetPickerSlot.querySelector('#gw-tp-camp');
      const seqEl  = targetPickerSlot.querySelector('#gw-tp-seq');
      const fb     = targetPickerSlot.querySelector('#gw-tp-fb');
      const addBtn = targetPickerSlot.querySelector('#gw-tp-add');

      targetPickerSlot.querySelector('#gw-tp-cancel')?.addEventListener('click', () => { targetPickerSlot.innerHTML = ''; });

      addBtn.addEventListener('click', async () => {
        const campaignId = campEl.value ? parseInt(campEl.value, 10) : null;
        const sequenceId = seqEl.value ? parseInt(seqEl.value, 10) : null;
        if (!campaignId && !sequenceId) {
          fb.style.display = 'block'; fb.style.color = '#991B1B';
          fb.textContent = 'Pick a campaign and/or sequence.';
          return;
        }
        addBtn.disabled = true; addBtn.textContent = 'Adding…';
        fb.style.display = 'none';
        try {
          const payload = { type: 'PUSH_PROSPECT_TO_TARGET', prospectId: prospect.id };
          if (campaignId) payload.campaignId = campaignId;
          if (sequenceId) payload.sequenceId = sequenceId;
          const res = await bgMessage(payload);
          if (!res.ok) throw new Error(res.error || 'Failed');
          // Optimistically reflect the new targeting in the strip.
          if (campaignId) curCamp = { id: campaignId, name: lookupCampaignName(campaignId) || `#${campaignId}` };
          if (sequenceId && !curSeqs.some(s => String(s.id) === String(sequenceId))) {
            curSeqs.unshift({ id: sequenceId, name: lookupSequenceName(sequenceId) || `#${sequenceId}` });
          }
          renderTargetStrip();
          targetPickerSlot.innerHTML = `<div style="padding:8px 13px;border-bottom:1px solid #f1f5f9;font-size:11px;color:#0F766E;">✓ Added${res.enrollmentError ? ` — sequence enroll failed: ${escHtml(res.enrollmentError)}` : ''}</div>`;
          setTimeout(() => { targetPickerSlot.innerHTML = ''; }, 4000);
        } catch (err) {
          addBtn.disabled = false; addBtn.textContent = 'Add to campaign';
          fb.style.display = 'block'; fb.style.color = '#991B1B';
          fb.textContent = err.message || 'Failed to add';
        }
      });
    }

    // ── Smart-suggest target prompt (v1.8) ─────────────────────────────────
    // When this found prospect ISN'T already in the rep's default campaign
    // or sequence, show a small amber prompt offering to add them in one
    // click. Quietest possible UX — no prompt if the prospect is already
    // where the rep would put them, and nothing if the rep hasn't set any
    // defaults. The slot is appended empty and filled async after the
    // defaults + names resolve.
    const suggestSlot = document.createElement('div');
    panel.appendChild(suggestSlot);
    renderSmartSuggest(suggestSlot, prospect);

    // ── Capture section (NEW in v1.2) ──
    renderCaptureSection(panel, prospect);

    // ── Timeline — horizontal progression bar (v1.11) ──
    // A left→right stepper. The connecting track fills (teal) up to the
    // current stage; each completed step shows its date right on the bar.
    // Tapping any step expands a detail card with the exact date + TIME and
    // any context (same-day accept, message count, reply sentiment) so reps
    // can track precisely when each action completed.
    const tlSection = document.createElement('div');
    tlSection.style.cssText = 'padding:10px 13px;border-bottom:1px solid #f1f5f9;';

    const reachedIdx = getStatusIdx(li.connection_status); // -1 if no status yet
    const N = TIMELINE_EVENTS.length;
    const SHORT = {
      connection_request_sent: 'Request',
      connection_accepted:     'Accepted',
      message_sent:            'Message',
      reply_received:          'Reply',
      meeting_booked:          'Meeting',
    };

    // Maps each timeline step to the channel_data.linkedin field that holds
    // the captured text (the note the rep typed when logging). connection_accepted
    // has no associated text. Only the most recent message/reply is retained.
    const TEXT_FIELD = {
      connection_request_sent: 'request_note',
      message_sent:            'last_message_text',
      reply_received:          'last_reply_text',
      meeting_booked:          'meeting_note',
    };
    const TEXT_LABEL = {
      connection_request_sent: 'Connection note',
      message_sent:            'Message sent',
      reply_received:          'Their reply',
      meeting_booked:          'Meeting note',
    };

    // Precompute per-step data the click handler reads from.
    const tlSteps = TIMELINE_EVENTS.map((ev, idx) => {
      const done = reachedIdx >= 0 && reachedIdx >= idx;
      const iso  = li[ev.tsField] || '';
      let extra = '';
      if (ev.key === 'connection_accepted' && li.request_sent_at && li.connected_at) {
        const days = Math.round((new Date(li.connected_at) - new Date(li.request_sent_at)) / 86400000);
        extra = days === 0 ? 'Accepted same day' : `${days} day${days === 1 ? '' : 's'} to accept`;
      }
      if (ev.key === 'message_sent' && li.message_count > 1) extra = `${li.message_count} messages sent`;
      if (ev.key === 'reply_received' && li.last_reply_sentiment) extra = `Sentiment: ${li.last_reply_sentiment}`;
      const textField = TEXT_FIELD[ev.key];
      return {
        label: ev.label, short: SHORT[ev.key] || ev.label, color: ev.color, done,
        dateShort: iso ? formatDate(iso) : '',
        dateFull:  iso ? formatDateTime(iso) : '',
        extra,
        text:      textField ? (li[textField] || '') : '',
        textLabel: TEXT_LABEL[ev.key] || '',
      };
    });

    // Dot centres sit at 10%..90% of the row (equal flex columns); the fill
    // line spans that 80% range, scaled to how far the prospect has progressed.
    const fillPct = reachedIdx > 0 ? (Math.min(reachedIdx, N - 1) / (N - 1)) * 80 : 0;

    let dotsHtml = '';
    tlSteps.forEach((s, idx) => {
      const tip = `${s.label}${s.done ? (s.dateFull ? ' — ' + s.dateFull : '') : ' — not yet'}`;
      dotsHtml += `
        <div class="gw-tl-step" data-idx="${idx}" title="${escHtml(tip)}"
             style="flex:1;display:flex;flex-direction:column;align-items:center;cursor:pointer;min-width:0;">
          <div class="gw-tl-dot" style="width:12px;height:12px;border-radius:50%;background:${s.done ? s.color : '#ffffff'};border:2px solid ${s.done ? s.color : '#cbd5e1'};box-sizing:border-box;transition:transform .12s ease;"></div>
          <div style="font-size:10px;font-weight:600;margin-top:5px;color:${s.done ? s.color : '#cbd5e1'};white-space:nowrap;">${s.dateShort || '—'}</div>
          <div style="font-size:8px;letter-spacing:0.03em;text-transform:uppercase;margin-top:1px;color:${s.done ? '#64748b' : '#cbd5e1'};white-space:nowrap;">${escHtml(s.short)}</div>
        </div>`;
    });

    tlSection.innerHTML = `
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:11px;">
        <span style="font-size:10px;font-weight:600;color:#94a3b8;letter-spacing:0.05em;text-transform:uppercase;">Timeline</span>
        <button id="gw-open-feed" style="background:none;border:none;padding:0;font-size:10px;color:${TEAL};font-weight:600;cursor:pointer;">Full activity ›</button>
      </div>
      <div style="position:relative;">
        <div style="position:absolute;left:10%;right:10%;top:5px;height:2px;background:#e2e8f0;border-radius:2px;"></div>
        <div style="position:absolute;left:10%;top:5px;height:2px;width:${fillPct}%;background:${TEAL};border-radius:2px;transition:width .25s ease;"></div>
        <div style="position:relative;display:flex;justify-content:space-between;">${dotsHtml}</div>
      </div>
      <div id="gw-tl-detail" style="margin-top:11px;font-size:11px;color:#94a3b8;background:#f8fafc;border:1px solid #f1f5f9;border-radius:6px;padding:7px 9px;line-height:1.45;">
        Tap a step above to see its exact date &amp; time.
      </div>`;
    panel.appendChild(tlSection);

    // ── Segmentation entry point (v1.15) ──────────────────────────────────────
    // Runs the individual-segmentation skill on the SAVED prospect record and
    // opens the result in a slide-over. Requires the prospect to exist server-
    // side (the skill reads the DB record), so it's only shown for saved
    // prospects — unlike Export, which works on the in-memory capture.
    const segSection = document.createElement('div');
    segSection.style.cssText = 'padding:10px 13px;border-bottom:1px solid #f1f5f9;';
    segSection.innerHTML = `
      <button id="gw-run-seg" style="width:100%;padding:7px;background:#fff;border:1px solid ${TEAL};color:${TEAL};border-radius:6px;font-size:12px;font-weight:600;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:6px;">
        <span>◈</span> Suggest segmentation
      </button>`;
    panel.appendChild(segSection);
    segSection.querySelector('#gw-run-seg').addEventListener('click', () => openSegmentation(prospect));

    tlSection.querySelector('#gw-open-feed').addEventListener('click', () => openActivityFeed(prospect));
    const tlDetail = tlSection.querySelector('#gw-tl-detail');
    const tlDots   = tlSection.querySelectorAll('.gw-tl-dot');
    let tlSelected = -1;
    const tlResetDots = () => tlDots.forEach(d => { d.style.transform = 'scale(1)'; });
    tlSection.querySelectorAll('.gw-tl-step').forEach(el => {
      el.addEventListener('click', () => {
        const idx = +el.dataset.idx;
        if (idx === tlSelected) {
          tlSelected = -1;
          tlResetDots();
          tlDetail.style.color = '#94a3b8';
          tlDetail.innerHTML = 'Tap a step above to see its exact date &amp; time.';
          return;
        }
        tlSelected = idx;
        tlResetDots();
        tlDots[idx].style.transform = 'scale(1.35)';
        const s = tlSteps[idx];
        tlDetail.style.color = '#64748b';
        if (s.done) {
          let html =
            `<div style="font-weight:600;color:${s.color};margin-bottom:2px;">${escHtml(s.label)}</div>` +
            `<div style="color:#334155;">${escHtml(s.dateFull) || 'Date not recorded'}</div>` +
            (s.extra ? `<div style="color:#94a3b8;margin-top:3px;">${escHtml(s.extra)}</div>` : '');
          if (s.text) {
            html +=
              `<div style="margin-top:7px;padding:6px 8px;background:#fff;border:1px solid #e2e8f0;border-left:3px solid ${s.color};border-radius:0 6px 6px 0;">` +
                `<div style="font-size:8px;letter-spacing:0.04em;text-transform:uppercase;color:#94a3b8;font-weight:600;margin-bottom:3px;">${escHtml(s.textLabel)}</div>` +
                `<div style="color:#374151;white-space:pre-wrap;word-break:break-word;">${escHtml(s.text)}</div>` +
              `</div>`;
          }
          tlDetail.innerHTML = html;
        } else {
          tlDetail.innerHTML =
            `<div style="font-weight:600;color:#94a3b8;margin-bottom:2px;">${escHtml(s.label)}</div>` +
            `<div style="color:#94a3b8;">Not completed yet.</div>`;
        }
      });
    });

    // ── Log form ──
    const formSection = document.createElement('div');
    formSection.style.cssText = 'padding:10px 13px;border-bottom:1px solid #f1f5f9;background:#f8fafc;';
    formSection.innerHTML = `
      <div style="font-size:10px;font-weight:600;color:#94a3b8;letter-spacing:0.05em;text-transform:uppercase;margin-bottom:8px;">Log event</div>
      <select id="gw-event-select" style="width:100%;font-size:12px;padding:5px 7px;border:1px solid #e2e8f0;border-radius:6px;background:#fff;color:#374151;margin-bottom:6px;">
        ${EVENTS.map(ev => `<option value="${ev.key}">${ev.label}</option>`).join('')}
      </select>
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:3px;">
        <label for="gw-when" style="font-size:10px;font-weight:600;color:#94a3b8;letter-spacing:0.03em;text-transform:uppercase;">When did this happen?</label>
        <button id="gw-when-now" type="button" style="background:none;border:none;padding:0;font-size:10px;color:${TEAL};font-weight:600;cursor:pointer;">↻ Now</button>
      </div>
      <input id="gw-when" type="datetime-local" value="${localDatetimeValue()}"
        style="width:100%;font-size:11px;padding:5px 7px;border:1px solid #e2e8f0;border-radius:6px;color:#374151;font-family:inherit;margin-bottom:6px;box-sizing:border-box;background:#fff;">
      <textarea id="gw-note" rows="4" placeholder="Message content, reply summary, or note…"
        style="width:100%;font-size:11px;padding:6px 7px;border:1px solid #e2e8f0;border-radius:6px;
               resize:vertical;min-height:64px;color:#374151;font-family:inherit;line-height:1.4;margin-bottom:6px;box-sizing:border-box;"></textarea>
      <div id="gw-sentiment-wrap" style="display:none;margin-bottom:6px;">
        <select id="gw-sentiment" style="width:100%;font-size:11px;padding:5px 7px;border:1px solid #e2e8f0;border-radius:6px;background:#fff;color:#374151;">
          ${SENTIMENTS.map(s => `<option value="${s.value}">${s.label}</option>`).join('')}
        </select>
      </div>
      <div style="display:flex;gap:6px;">
        <button id="gw-save" style="flex:1;padding:6px;background:${TEAL};color:#fff;border:none;border-radius:6px;font-size:12px;font-weight:600;cursor:pointer;">Save</button>
      </div>
      <div id="gw-feedback" style="margin-top:6px;font-size:11px;display:none;"></div>
    `;
    panel.appendChild(formSection);

    const evSelect = formSection.querySelector('#gw-event-select');
    const sentWrap = formSection.querySelector('#gw-sentiment-wrap');
    const whenInput = formSection.querySelector('#gw-when');
    // The timestamp defaults to live now() at save time. It only becomes a
    // manual override once the rep actually edits the field — guarding against
    // a stale render-time value if the panel has been sitting open.
    let whenTouched = false;
    evSelect.addEventListener('change', () => {
      sentWrap.style.display = evSelect.value === 'reply_received' ? 'block' : 'none';
    });
    whenInput.addEventListener('input', () => { whenTouched = true; });
    formSection.querySelector('#gw-when-now').addEventListener('click', () => {
      whenInput.value = localDatetimeValue();
      whenTouched = false;            // explicit "use now" — clears the override
    });

    formSection.querySelector('#gw-save').addEventListener('click', async () => {
      const eventKey  = evSelect.value;
      const note      = formSection.querySelector('#gw-note').value.trim();
      const sentiment = formSection.querySelector('#gw-sentiment')?.value || undefined;
      const saveBtn   = formSection.querySelector('#gw-save');
      const feedback  = formSection.querySelector('#gw-feedback');

      // Untouched → live now() at save time (always UTC). Edited → the rep's
      // chosen local time, converted to UTC. The field captures to the minute.
      let occurredAt;
      if (whenTouched && whenInput.value) {
        const d = new Date(whenInput.value);
        if (isNaN(d.getTime())) {
          feedback.style.cssText = 'margin-top:6px;font-size:11px;display:block;color:#dc2626;';
          feedback.textContent   = 'That date/time looks invalid — please re-enter it.';
          return;
        }
        occurredAt = d.toISOString();
      } else {
        occurredAt = new Date().toISOString();
      }

      saveBtn.disabled    = true;
      saveBtn.textContent = 'Saving…';
      feedback.style.display = 'none';

      try {
        const res = await bgMessage({
          type:        'LOG_EVENT',
          prospectId:  prospect.id,
          event:       eventKey,
          note:        note || undefined,
          sentiment:   sentiment || undefined,
          occurredAt:  occurredAt,
        });

        if (!res.ok) throw new Error(res.error);

        feedback.style.cssText = 'margin-top:6px;font-size:11px;display:block;color:#059669;';
        feedback.textContent   = `Saved: ${EVENTS.find(e => e.key === eventKey)?.label} · ${formatDateTime(occurredAt)}`;
        formSection.querySelector('#gw-note').value = '';
        whenInput.value = localDatetimeValue();
        whenTouched = false;

        setTimeout(() => {
          const existing = panel.querySelectorAll('div:not(:first-child):not(:nth-child(2))');
          existing.forEach(el => el.remove());
          renderProspect(panel, { ...prospect, channel_data: res.data?.channelData || prospect.channel_data });
        }, 1000);

      } catch (err) {
        saveBtn.disabled    = false;
        saveBtn.textContent = 'Save';
        feedback.style.cssText = 'margin-top:6px;font-size:11px;display:block;color:#dc2626;';
        feedback.textContent   = err.message;
      }
    });

    // ── Stats bar ──
    if (li.connection_status) {
      const stats = document.createElement('div');
      stats.style.cssText = 'padding:8px 13px;display:flex;gap:14px;border-bottom:1px solid #f1f5f9;';
      const items = [
        li.message_count  && { label: 'messages',  value: li.message_count },
        li.inmail_count   && { label: 'inmails',   value: li.inmail_count  },
        li.reply_count    && { label: 'replies',   value: li.reply_count   },
      ].filter(Boolean);

      if (items.length) {
        stats.innerHTML = items.map(i =>
          `<div><span style="font-size:14px;font-weight:600;color:#1a202c;">${i.value}</span>
           <span style="font-size:10px;color:#94a3b8;margin-left:3px;">${i.label}</span></div>`
        ).join('');
        panel.appendChild(stats);
      }
    }

    // ── Footer ──
    const footer = document.createElement('div');
    footer.style.cssText = 'padding:8px 13px;background:#f8fafc;';
    // Deep-link straight to this prospect's drawer in the app. The app is a
    // hash-routed SPA: ProspectingView reads #/prospecting/<id> on mount and
    // opens ProspectDetailPanel for that id. prospect.id is the prospects-table
    // PK (same id the app's list matches on), so the drawer opens for the rep's
    // own in-pipeline prospects. Falls back to the app root if id is missing.
    const openHref = prospect?.id
      ? `https://app.gowarmcrm.com/#/prospecting/${prospect.id}`
      : 'https://app.gowarmcrm.com';
    footer.innerHTML = `<a href="${openHref}" target="_blank" style="font-size:11px;color:${TEAL};text-decoration:none;font-weight:500;">Open in GoWarmCRM ↗</a>`;
    panel.appendChild(footer);
  }

  // ── Init ─────────────────────────────────────────────────────────────────────

  async function init() {
    document.getElementById(PANEL_ID)?.remove();
    document.getElementById(FEED_ID)?.remove();
    document.getElementById(PILL_ID)?.remove();
    disposeCaptureObservers();           // start fresh for this profile
    lastDebugIds = {};                   // clear stale ids from previous profile

    const linkedinUrl = getCurrentLinkedInUrl();
    if (!linkedinUrl) return;

    // Read debug flag from chrome.storage.local. Best-effort; if storage
    // is unavailable, debugMode stays false (its default). Fire and forget —
    // the panel can render before this resolves; debug strip rendering is
    // deferred until IDs are known anyway.
    try {
      chrome.storage.local.get(['gowarm_debug'], (r) => {
        debugMode = r?.gowarm_debug === '1' || r?.gowarm_debug === true;
      });
    } catch (_) { /* swallow */ }

    // Reset captureState BEFORE extractProfileInfo() runs.
    //
    // Why this matters: extractProfileInfo() falls back to
    // getExperience() when the top card and headline don't yield a
    // company. getExperience() reads captureState.experience.value —
    // and on SPA navigation that value still holds the *previous*
    // profile's data (kept alive by the 1.7.5 clobber-protection).
    //
    // Without this reset, navigating from a profile where Experience
    // was captured to a new profile whose company can't be derived
    // from top card or headline would silently fill the form's
    // Company field with the previous profile's employer — exactly
    // the "Teleglobal leaking onto Mark Green" bug. Resetting here
    // makes getExperience() correctly fall through to a cold scrape
    // (which returns [] for Mark since experience hasn't loaded yet),
    // leaving the Company field empty rather than wrong.
    //
    // setupCaptureObservers() further down also resets captureState,
    // so this is redundant in the happy path — but the order matters:
    // reset must happen before extractProfileInfo, not after.
    captureState = makeCaptureState();

    const profileInfo = extractProfileInfo();
    const panel = buildPanel();
    renderHeader(panel, profileInfo.name, profileInfo.title);
    renderLoading(panel);
    document.body.appendChild(panel);

    // If the rep previously minimized the panel, keep it collapsed for this
    // profile too. Done synchronously off the in-memory flag so the full
    // panel never flashes before collapsing on SPA navigation.
    if (panelMinimized) minimizePanel(panel);

    // Kick off progressive capture immediately. Observers start populating
    // captureState in the background; the panel will subscribe once
    // renderCaptureSection mounts inside renderProspect / renderNotFound.
    setupCaptureObservers();

    // ── Identity (drives the panel header subline) ───────────────────────────
    // Fire-and-forget; if it fails we just skip the subline.
    bgMessage({ type: 'GET_IDENTITY' })
      .then(res => { if (res?.ok && res.identity) renderIdentitySubline(panel, res.identity); })
      .catch(() => { /* swallow */ });

    // ── Delta-refresh hydration (NEW in v1.5) ────────────────────────────────
    // Fire-and-forget; the prospect lookup below doesn't block on this.
    // When it returns we seed captureState.dbValue + dbCapturedAt for each
    // section so the panel can show "on file" badges and the diff.
    bgMessage({ type: 'GET_LINKEDIN_PROFILE', linkedinUrl })
      .then(res => {
        if (res?.ok) hydrateFromDbProfile(res.profile);
        else        hydrateFromDbProfile(null);   // mark hydrated-but-empty
        // Surface linkedin_profile.id in the debug strip as soon as we know it.
        if (res?.ok && res.profile?.id) {
          renderDebugIds(panel, { profile_id: res.profile.id });
        }
      })
      .catch(() => hydrateFromDbProfile(null));

    let res;
    try {
      res = await bgMessage({ type: 'LOOKUP_PROSPECT', linkedinUrl });
    } catch (err) {
      // Background-channel failure (extension reload, etc). Distinct
      // from a successful message that came back with ok:false.
      console.warn('[GoWarmCRM] LOOKUP_PROSPECT message channel failed:', err.message);
      panel.lastChild?.remove();
      renderNotAuthenticated(panel);
      return;
    }

    // Always log the lookup outcome at debug level so we can diagnose
    // panel state quickly from devtools without needing to instrument
    // again. Single one-line summary — verbose enough to be useful,
    // small enough not to spam the console.
    console.debug('[GoWarmCRM] LOOKUP_PROSPECT for', linkedinUrl, '→',
      res?.ok
        ? (res.prospect ? `found id=${res.prospect.id}` : 'no match')
        : `error: ${res?.error || 'unknown'}`);

    panel.lastChild?.remove();

    if (!res.ok && res.error === 'NOT_AUTHENTICATED') {
      renderNotAuthenticated(panel);
    } else if (!res.ok) {
      // Lookup actually FAILED (network, 5xx, etc). Previously this branch
      // collapsed into renderNotFound which silently showed the "Add
      // prospect" form — disastrous because the rep could happily fill it
      // in and create a duplicate of an existing prospect whose lookup
      // just transiently failed. Now we surface the error explicitly with
      // a retry, so the rep knows the panel is uncertain rather than
      // confidently wrong.
      //
      // Why this matters: the backend's by-linkedin-url endpoint returns
      // 200 with {prospect: null} for genuine no-match. The only way to
      // reach !res.ok is a real error (5xx, network drop, parsing error).
      // Treating those as "not in CRM" was a bug.
      renderLookupError(panel, profileInfo, res.error || 'Lookup failed');
    } else if (!res.prospect) {
      // Real not-found — show the add-prospect form.
      renderNotFound(panel, profileInfo);
    } else {
      renderProspect(panel, res.prospect);
      // Once we have a prospect, surface its id + account_id in the debug
      // strip. linkedin_profile.id may have already been set above; calling
      // renderDebugIds again replaces with the union (we pass all known ids).
      // The hydration call may race with this — whichever runs second wins,
      // and both have the prospect's profile data available.
      renderDebugIds(panel, {
        profile_id:  res.prospect.linkedin_profile_id || null,
        prospect_id: res.prospect.id,
        account_id:  res.prospect.account?.id || res.prospect.account_id || null,
      });
    }
  }

  // ── SPA navigation watcher ───────────────────────────────────────────────────
  let lastUrl = location.href;
  let initInProgress = false;

  // Context-validity guard. After an extension reload, the OLD content
  // script remains in the page but its connection to the extension is dead.
  // chrome.runtime.id becomes undefined and chrome.runtime.sendMessage()
  // throws "Extension context invalidated". When that happens, we stop
  // firing background work (init, mutation observer) — otherwise we
  // generate an endless flood of failed network requests until the user
  // refreshes the tab.
  function extensionAlive() {
    try {
      return !!(chrome && chrome.runtime && chrome.runtime.id);
    } catch (_) {
      return false;
    }
  }

  // Resolve an extension resource URL SAFELY. Critical subtlety: after an
  // extension reload, chrome.runtime.getURL() does NOT throw — it returns the
  // dead string "chrome-extension://invalid/…". A plain try/catch therefore
  // never fires, and the caller hands a broken URL to <img src>/<script src>,
  // which floods the console with `GET chrome-extension://invalid/ ERR_FAILED`.
  // Returning '' here lets every caller fall back to its no-URL branch instead.
  function safeGetURL(path) {
    try {
      if (!extensionAlive()) return '';
      const u = chrome.runtime.getURL(path);
      return (!u || u.indexOf('://invalid/') !== -1) ? '' : u;
    } catch (_) {
      return '';
    }
  }

  async function safeInit() {
    if (initInProgress) return;
    if (!extensionAlive()) return;
    initInProgress = true;
    try {
      await init();
    } finally {
      initInProgress = false;
    }
  }

  // Single idempotent teardown for the orphaned-after-reload case. Disconnects
  // observers, removes our injected UI, and stops the watchdog below. Safe to
  // call repeatedly. Referenced by both the nav observer and the watchdog.
  let orphanWatch = null;
  function tearDownOrphan() {
    try { navObserver.disconnect(); } catch (_) {}
    try { disposeCaptureObservers(); } catch (_) {}
    document.getElementById(PANEL_ID)?.remove();
    document.getElementById(FEED_ID)?.remove();
    document.getElementById(PILL_ID)?.remove();
    if (orphanWatch) { clearInterval(orphanWatch); orphanWatch = null; }
  }

  const navObserver = new MutationObserver(() => {
    if (!extensionAlive()) {
      // Extension was reloaded — disconnect ourselves and stop generating
      // failed requests.
      tearDownOrphan();
      return;
    }
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      if (/linkedin\.com\/in\//.test(location.href)) {
        setTimeout(safeInit, 1200);
      } else {
        disposeCaptureObservers();
        document.getElementById(PANEL_ID)?.remove();
    document.getElementById(FEED_ID)?.remove();
    document.getElementById(PILL_ID)?.remove();
      }
    }
  });
  navObserver.observe(document.body, { childList: true, subtree: true });

  // Watchdog: the nav observer above only fires on a DOM mutation, so on an
  // idle page an orphaned context could linger (and keep emitting failed
  // resource loads) until the next mutation. This cheap 1s check guarantees we
  // tear down promptly after a reload even with no DOM activity. It is a no-op
  // while the context is alive, and clears ITSELF on teardown — so it can never
  // become a runaway loop.
  orphanWatch = setInterval(() => {
    if (!extensionAlive()) tearDownOrphan();
  }, 1000);

  // Restore the persisted minimize preference once at startup so the very
  // first profile (e.g. after a full page reload) honours it without a flash.
  // safeInit is delayed 1500ms below, so this async read resolves well before
  // the first panel is built.
  try {
    chrome.storage.local.get([MINIMIZED_KEY], (r) => {
      panelMinimized = r?.[MINIMIZED_KEY] === '1' || r?.[MINIMIZED_KEY] === true;
    });
  } catch (_) { /* swallow — storage may be unavailable; defaults to expanded */ }

  setTimeout(safeInit, 1500);

  // ── Debug-mode keyboard shortcut ─────────────────────────────────────────────
  // Ctrl+Shift+D (Cmd+Shift+D on Mac) toggles debugMode on/off. The toggle
  // is persisted to chrome.storage.local so it survives page reloads.
  // Skips when the user is typing in an input, textarea, or contenteditable
  // element so it doesn't fire while writing a LinkedIn message or post.
  document.addEventListener('keydown', (e) => {
    // Match Ctrl+Shift+D on Win/Linux, Cmd+Shift+D on Mac.
    const isMod = e.ctrlKey || e.metaKey;
    if (!isMod || !e.shiftKey) return;
    if (e.key !== 'D' && e.key !== 'd') return;

    // Skip when focus is in an editable field — Ctrl+Shift+D is a common
    // text-editing combo (especially in LinkedIn's composer).
    const target = e.target;
    if (target && (
      target.tagName === 'INPUT'    ||
      target.tagName === 'TEXTAREA' ||
      target.isContentEditable
    )) return;

    e.preventDefault();
    debugMode = !debugMode;

    // Persist so the new state survives reload.
    try {
      if (debugMode) {
        chrome.storage.local.set({ gowarm_debug: '1' });
      } else {
        chrome.storage.local.remove(['gowarm_debug']);
      }
    } catch (_) { /* swallow — storage may be unavailable */ }

    // Re-render the debug strip on the current panel with cached IDs.
    const panel = document.getElementById(PANEL_ID);
    if (panel) {
      renderDebugIds(panel, {});
      showDebugToast(panel, debugMode ? 'Debug mode ON' : 'Debug mode OFF');
    }
  });

  // Brief toast at the top of the GoWarm panel. Used by the debug toggle to
  // confirm the change happened (state is otherwise silent when no IDs are
  // available to show). 1.4s lifetime; fades out via opacity transition.
  function showDebugToast(panel, message) {
    if (!panel) return;
    // Re-use an existing toast if one is already on-screen.
    let t = panel.querySelector('#gw-debug-toast');
    if (!t) {
      t = document.createElement('div');
      t.id = 'gw-debug-toast';
      t.style.cssText = `
        position: absolute; top: 8px; left: 50%; transform: translateX(-50%);
        background: #1F2937; color: #FEF3C7; font-size: 11px;
        padding: 4px 10px; border-radius: 12px; font-weight: 600;
        letter-spacing: 0.04em; pointer-events: none; z-index: 100;
        box-shadow: 0 2px 8px rgba(0,0,0,0.25);
        transition: opacity 200ms ease-out;
      `;
      // Panel itself has `overflow: hidden` set in buildPanel, which would
      // clip the toast — but since the toast sits inside the panel and we
      // position it at top:8px it's well within bounds.
      panel.appendChild(t);
    }
    t.textContent = message;
    t.style.opacity = '1';
    clearTimeout(t._fadeT);
    t._fadeT = setTimeout(() => {
      t.style.opacity = '0';
      setTimeout(() => { try { t.remove(); } catch (_) {} }, 250);
    }, 1400);
  }

  // ── DEBUG HOOKS (v1.2-debug) ─────────────────────────────────────────────────
  // Exposed on every linkedin.com/in/* page so you can call extraction from
  // DevTools console without clicking the Capture button. Safe to ship — only
  // attaches functions to window, doesn't change runtime behavior.
  //
  // Usage in DevTools console:
  //   __gowarmCapture()       → returns the payload that would be POSTed
  //   __gowarmCaptureDebug()  → returns a richer object with layout detection,
  //                              raw line samples, and per-section diagnostics
  //   copy(JSON.stringify(__gowarmCaptureDebug(), null, 2))   → copy to clipboard

  function debugCapture() {
    const errors = [];
    const safe = (label, fn) => {
      try { return fn(); }
      catch (e) {
        errors.push({ label, error: e.message, stack: e.stack });
        return null;
      }
    };

    // Layout detection
    const layout = {
      sdui_topcard:      !!document.querySelector('section[componentkey*="Topcard"]'),
      legacy_topcard:    !!document.querySelector('.pv-text-details__left-panel, .ph5.pb5'),
      artdeco_li_count:  document.querySelectorAll('li.artdeco-list__item').length,
      sdui_entity_count: document.querySelectorAll('div[data-view-name="profile-component-entity"]').length,
      data_test_exp:     document.querySelectorAll('li[data-test="experience-item"]').length,
      data_test_edu:     document.querySelectorAll('li[data-test="education-item"]').length,
      activity_urns:     document.querySelectorAll('div[urn^="urn:li:activity:"], div[data-urn^="urn:li:activity:"]').length,
    };

    // Per-section diagnostics
    const sections = {};
    const aboutSec = safe('findAbout', () => findSectionByHeading([/^about\b/i]));
    sections.about = {
      found:        !!aboutSec,
      heading_text: aboutSec?.querySelector('h2, h3, [role="heading"]')?.innerText?.trim() || null,
      text_sample:  aboutSec ? (aboutSec.innerText || '').slice(0, 300) : null,
    };

    const expSec = safe('findExperience', () => findSectionByHeading([/^experience$/i]));
    sections.experience = {
      found:        !!expSec,
      heading_text: expSec?.querySelector('h2, h3, [role="heading"]')?.innerText?.trim() || null,
      item_count_artdeco: expSec?.querySelectorAll('li.artdeco-list__item').length || 0,
      item_count_sdui:    expSec?.querySelectorAll('div[data-view-name="profile-component-entity"]').length || 0,
      item_count_dataTest: expSec?.querySelectorAll('li[data-test="experience-item"]').length || 0,
      first_item_lines: null,
    };
    if (expSec) {
      const firstItem = expSec.querySelector(
        'li.artdeco-list__item, li[data-test="experience-item"], div[data-view-name="profile-component-entity"]'
      );
      if (firstItem) {
        sections.experience.first_item_lines = [...firstItem.querySelectorAll('span[aria-hidden="true"], div')]
          .map(el => el.innerText?.trim())
          .filter(Boolean)
          .filter((t, i, arr) => arr.indexOf(t) === i)
          .filter(t => t.length < 250)
          .slice(0, 12);
      }
    }

    const eduSec = safe('findEducation', () => findSectionByHeading([/^education$/i]));
    sections.education = {
      found:        !!eduSec,
      heading_text: eduSec?.querySelector('h2, h3, [role="heading"]')?.innerText?.trim() || null,
      item_count_artdeco: eduSec?.querySelectorAll('li.artdeco-list__item').length || 0,
      item_count_sdui:    eduSec?.querySelectorAll('div[data-view-name="profile-component-entity"]').length || 0,
    };

    const actSec = safe('findActivity', () => findSectionByHeading([
      /^activity$/i,
      /(\bposts?\b|\bactivity\b).{0,30}\bfollowers?$/i,
      /\brecent activity\b/i,
    ]));
    sections.activity = {
      found:        !!actSec,
      heading_text: actSec?.querySelector('h2, h3, [role="heading"]')?.innerText?.trim() || null,
      item_count_li: actSec?.querySelectorAll('li').length || 0,
      item_count_urn: actSec?.querySelectorAll('div[data-urn^="urn:li:activity:"]').length || 0,
      first_item_text: null,
    };
    if (actSec) {
      const first = actSec.querySelector('li, div[data-urn^="urn:li:activity:"]');
      if (first) sections.activity.first_item_text = (first.innerText || '').slice(0, 400);
    }

    // Run the actual extractors
    const basics    = safe('extractProfileInfo', () => extractProfileInfo());
    const about     = safe('captureAboutText',   () => captureAboutText());
    const experience= safe('getExperience',      () => getExperience());
    const education = safe('captureEducation',   () => captureEducation());
    const activity  = safe('captureActivity',    () => captureActivity());
    const fullPayload = safe('captureFullProfile', () => captureFullProfile());

    return {
      url: location.href,
      timestamp: new Date().toISOString(),
      layout,
      sections,
      extracted: {
        basics,
        about_length: about ? about.length : 0,
        about_preview: about ? about.slice(0, 200) : null,
        experience,
        education,
        activity,
      },
      payload: fullPayload,    // exactly what would be POSTed to backend
      errors,
    };
  }

  // Idempotent: re-attach on every script run (LinkedIn SPA may inject content
  // script multiple times for the same tab).
  //
  // CRITICAL: content scripts run in an "isolated world" — assigning to
  // window.__gowarmCapture here would NOT be visible from the DevTools
  // console (which runs in the page's main world). Instead we listen for a
  // CustomEvent dispatched from page-world code, run extraction in this
  // isolated world (where the extractor functions are scoped), then
  // dispatch the result back as another CustomEvent.
  try {
    document.addEventListener('gowarm:capture-request', async (ev) => {
      const requestId = ev.detail?.requestId;
      const mode      = ev.detail?.mode || 'payload';   // 'payload' | 'debug' | 'hydrate'
      let result;
      try {
        if (mode === 'hydrate') {
          // Explicit completeness pass: hydrate lazy sections + expand "see
          // more", store into captureState, then return the debug view so the
          // result reflects exactly what production capture would now see.
          await hydrateAndExpandProfile();
          result = debugCapture();
        } else if (mode === 'debug') {
          result = debugCapture();
        } else {
          result = captureFullProfile();
        }
      } catch (e) {
        result = { error: e.message, stack: e.stack };
      }
      document.dispatchEvent(new CustomEvent('gowarm:capture-response', {
        detail: { requestId, result },
      }));
    });

    // Inject a small page-world helper that exposes window.__gowarmCapture()
    // and window.__gowarmCaptureDebug() via the event bridge above.
    //
    // We MUST load it as <script src=...> pointing at an extension file,
    // not as inline textContent — LinkedIn's Content Security Policy blocks
    // inline scripts ('script-src self ...' with no 'unsafe-inline' and no
    // matching nonce/hash). Extension files are allowed because the
    // chrome-extension://<id>/... origin is implicitly permitted, AND the
    // file is declared in manifest.json under web_accessible_resources.
    try {
      const injUrl = safeGetURL('inject.js');
      if (injUrl) {
        const s = document.createElement('script');
        s.src = injUrl;
        s.onload = () => s.remove();
        (document.head || document.documentElement).appendChild(s);
      }
    } catch (e) {
      console.warn('[GoWarm] failed to inject page-world helpers:', e);
      console.warn(
        '[GoWarm] Fallback — paste this into DevTools console to install hooks manually:\n\n' +
        `function __gw_call(mode) {
  return new Promise((resolve) => {
    const requestId = 'req_' + Math.random().toString(36).slice(2);
    const handler = (e) => {
      if (e.detail?.requestId !== requestId) return;
      document.removeEventListener('gowarm:capture-response', handler);
      resolve(e.detail.result);
    };
    document.addEventListener('gowarm:capture-response', handler);
    document.dispatchEvent(new CustomEvent('gowarm:capture-request', { detail: { requestId, mode } }));
  });
}
window.__gowarmCapture       = () => __gw_call('payload');
window.__gowarmCaptureDebug  = () => __gw_call('debug');
window.__gowarmCaptureHydrate = () => __gw_call('hydrate');`
      );
    }
  } catch (e) {
    console.warn('[GoWarm] failed to install debug bridge:', e);
  }

})();
