// company_content.js — injected into linkedin.com/company/* pages (v1.23, P10)
//
// READS the company page the rep is ALREADY viewing (top card + About +
// Jobs module + latest post date — the People tab is deliberately out of
// scope) and, on an EXPLICIT tap, saves one capture to GoWarmCRM where it
// becomes account-level signals. Rep-present, visible-page-only, no
// crawling, no auto-navigation, no background harvesting — the same posture
// as content.js on /in/* pages.
//
// EXTRACTION STRATEGY (SDUI-resilient, mirrors content.js v1.20):
//   PRIMARY — LinkedIn server-renders entity JSON into <code> blocks on
//   initial page load. We deep-walk them for the organization entity whose
//   universalName matches the /company/<slug> in the URL (owner-bound: a
//   wrong company is never captured; a miss yields null).
//   SECONDARY — targeted DOM text reads with forgiving regexes for the two
//   things the hydration JSON often lacks by the time we run: the Jobs
//   module count ("See all 12 jobs") and the latest feed post's relative
//   timestamp ("2w"). Every extractor degrades to null — the backend's
//   ingest never writes a blank (unknown-never-false starts on this page).
//
// NO FABRICATION: headcount is captured ONLY from a real "associated
// members" style count; the "51-200 employees" range is shown in the panel
// for the rep's eyes but never sent as a number.
//
// Test hook: window.__gowarmCompanyTest exposes the pure extraction
// functions when the page sets window.__GOWARM_TEST__ = true BEFORE this
// script runs (used by the JSDOM harness; inert in production).

(function () {
  'use strict';

  const TEAL     = '#0F9D8E';
  const ORANGE   = '#E8630A';
  const PANEL_ID = 'gowarm-li-company-panel';

  // ── Helpers ────────────────────────────────────────────────────────────────

  function extensionAlive() {
    try { return !!(chrome && chrome.runtime && chrome.runtime.id); }
    catch (_) { return false; }
  }

  function getCompanySlug(href) {
    const m = String(href || location.href).match(/linkedin\.com\/company\/([^/?#]+)/);
    return m ? decodeURIComponent(m[1]).toLowerCase() : null;
  }

  function companyUrlFor(slug) {
    return slug ? `https://www.linkedin.com/company/${slug}` : null;
  }

  function cleanDomain(website) {
    if (!website) return null;
    try {
      const u = new URL(/^https?:\/\//i.test(website) ? website : `https://${website}`);
      const host = u.hostname.replace(/^www\./i, '').toLowerCase();
      return host.includes('.') ? host : null;
    } catch (_) { return null; }
  }

  const toInt = (v) => {
    if (v === null || v === undefined || v === '') return null;
    const n = Number(String(v).replace(/[,\s]/g, ''));
    return Number.isInteger(n) && n >= 0 ? n : null;
  };

  // "2w" / "3d" / "5h" / "1mo" — and (v1.23.3) the long forms LinkedIn's job
  // cards use: "8 hours ago" / "4 days ago" / "30+ days ago" ("30+" reads
  // conservatively as exactly 30). → ISO date; whole units back from now.
  function parseRelativeTime(text, now) {
    if (!text) return null;
    const m = String(text).trim().match(/^(\d+)\+?\s*(hours?|hrs?|h|days?|d|weeks?|w|months?|mos?|mo|m|years?|yrs?|yr|y)\b/i);
    if (!m) return null;
    const n = parseInt(m[1], 10);
    if (!Number.isInteger(n) || n < 0) return null;
    const unit = m[2].toLowerCase();
    const MS =
      /^h/.test(unit) ? 3600e3
      : /^d/.test(unit) ? 86400e3
      : /^w/.test(unit) ? 7 * 86400e3
      : /^(mo|month)/.test(unit) ? 30 * 86400e3
      : unit === 'm' ? 30 * 86400e3
      : /^y/.test(unit) ? 365 * 86400e3
      : null;
    if (!MS) return null;
    const base = (now && typeof now.getTime === 'function') ? now.getTime() : Date.now();
    return new Date(base - n * MS).toISOString();
  }

  // ── PRIMARY: <code>-block organization entity (owner-bound to the slug) ────
  //
  // v1.23.1 (P10 fix round): live SDUI carries several fields as URN
  // REFERENCES rather than inline values — industry is typically
  // `*industry: ["urn:li:fsd_industry:..."]` with the NAME on a separate
  // included Industry entity, and follower data hangs off `*followingState`.
  // So the walk now also builds a URN→entity index of the SAME JSON document
  // and resolves references through it. Tagline (the headline under the
  // company name), employeeCountRange, foundedOn, specialities and phone are
  // read from their observed shapes. Every miss is still a null, never a
  // guess.

  function _urnIndexFrom(json) {
    const index = new Map();
    (function walk(node, depth) {
      if (!node || depth > 14) return;
      if (Array.isArray(node)) { for (const x of node) walk(x, depth + 1); return; }
      if (typeof node !== 'object') return;
      if (typeof node.entityUrn === 'string') index.set(node.entityUrn, node);
      for (const k in node) {
        if (Object.prototype.hasOwnProperty.call(node, k)) walk(node[k], depth + 1);
      }
    })(json, 0);
    return index;
  }

  function _resolveRef(org, index, ...fields) {
    // Accepts both `field` (inline) and `*field` (URN ref, string or array).
    for (const f of fields) {
      const ref = org['*' + f] ?? org[f + 'Urn'] ?? org[f + 'Urns'];
      const urns = Array.isArray(ref) ? ref : (typeof ref === 'string' ? [ref] : []);
      for (const u of urns) {
        const ent = index.get(u);
        if (ent) return ent;
      }
    }
    return null;
  }

  function extractOrgFromCodeBlocks(slug, doc) {
    const d = doc || document;
    let codes;
    try { codes = d.querySelectorAll('code'); } catch (_) { return null; }
    if (!codes || !codes.length || !slug) return null;

    let found = null;
    let index = null;

    function walk(node, depth) {
      if (found || !node || depth > 12) return;
      if (Array.isArray(node)) {
        for (const item of node) { walk(item, depth + 1); if (found) return; }
        return;
      }
      if (typeof node !== 'object') return;
      const uni = node.universalName || node.universal_name;
      if (typeof uni === 'string' && uni.toLowerCase() === slug) {
        found = node;
        return;
      }
      for (const k in node) {
        if (Object.prototype.hasOwnProperty.call(node, k)) {
          walk(node[k], depth + 1);
          if (found) return;
        }
      }
    }

    for (const code of codes) {
      let text = code.textContent;
      if (!text || text.length < 50 || text.indexOf(slug) === -1) continue;
      let json;
      try { json = JSON.parse(text); } catch (_) { continue; }
      walk(json, 0);
      if (found) { index = _urnIndexFrom(json); break; }
    }
    if (!found) return null;

    const org = found;
    const idx = index || new Map();
    const name = typeof org.name === 'string' ? org.name.trim() || null : null;

    // Industry: inline string / array / object / taxonomy / URN reference.
    let industry = null;
    if (typeof org.industry === 'string') industry = org.industry;
    else if (Array.isArray(org.industries) && typeof org.industries[0] === 'string') industry = org.industries[0];
    else if (org.industry && typeof org.industry === 'object' && typeof org.industry.name === 'string') industry = org.industry.name;
    else if (org.industryV2Taxonomy) {
      const t = Array.isArray(org.industryV2Taxonomy) ? org.industryV2Taxonomy[0] : org.industryV2Taxonomy;
      if (t && typeof t.name === 'string') industry = t.name;
    }
    if (!industry) {
      const ent = _resolveRef(org, idx, 'industry', 'industryV2Taxonomy');
      if (ent && typeof ent.name === 'string') industry = ent.name;
    }
    industry = industry ? String(industry).trim() || null : null;

    // Headline / tagline — the one-liner under the company name.
    const tagline = typeof org.tagline === 'string' ? org.tagline.trim() || null : null;

    const hq = org.headquarter || org.headquarters || null;
    const hqAddr = hq && typeof hq === 'object' ? (hq.address && typeof hq.address === 'object' ? hq.address : hq) : null;
    const hqCity    = hqAddr && typeof hqAddr.city === 'string' ? hqAddr.city.trim() || null : null;
    const hqCountryRaw = hqAddr ? (hqAddr.country || hqAddr.countryCode || null) : null;
    const hqCountry = typeof hqCountryRaw === 'string' ? hqCountryRaw.trim() || null : null;

    const description = typeof org.description === 'string' ? org.description.trim() || null : null;

    // Real member count only; ranges are display-only, never a number.
    const memberCount = toInt(org.staffCount ?? org.staff_count ?? org.employeeCount);
    let sizeRange = null;
    const scr = org.staffCountRange || org.staff_count_range || org.employeeCountRange;
    if (typeof scr === 'string') sizeRange = scr;
    else if (scr && typeof scr === 'object') {
      const lo = scr.start ?? scr.min, hi = scr.end ?? scr.max;
      // Comma-format to match LinkedIn's rendered spelling ("1,001-5,000
      // employees") so the company_size_range signal value is IDENTICAL
      // whichever layer (entity / About dl / top card) supplied it —
      // one_of targeting must not fragment on formatting.
      const fmt = (n) => Number(n).toLocaleString('en-US');
      if (lo != null) sizeRange = hi != null ? `${fmt(lo)}-${fmt(hi)} employees` : `${fmt(lo)}+ employees`;
    }

    // Followers: inline or via the *followingState reference.
    let followers = toInt(org.followerCount ?? org.followersCount);
    if (followers === null) {
      const fs = (org.followingState && typeof org.followingState === 'object')
        ? org.followingState
        : _resolveRef(org, idx, 'followingState');
      if (fs) followers = toInt(fs.followerCount ?? fs.followersCount);
    }

    // Founded: {year} shapes or a plain year.
    const foundedYear = toInt(
      (org.foundedOn && org.foundedOn.year)
      ?? (org.foundedDate && org.foundedDate.year)
      ?? (org.founded && typeof org.founded === 'object' ? org.founded.year : org.founded)
      ?? org.foundedYear
    );

    // Specialties — LinkedIn spells it "specialities" in Voyager.
    let specialties = null;
    const specRaw = org.specialities || org.specialties;
    if (Array.isArray(specRaw)) {
      const arr = specRaw.map((x) => (typeof x === 'string' ? x.trim() : null)).filter(Boolean);
      if (arr.length) specialties = [...new Set(arr)].slice(0, 50);
    }

    // Phone — { number } shapes.
    const phone = (org.phone && typeof org.phone === 'object' && typeof org.phone.number === 'string')
      ? org.phone.number.trim() || null
      : (typeof org.phone === 'string' ? org.phone.trim() || null
        : (org.phoneNumber && typeof org.phoneNumber.number === 'string' ? org.phoneNumber.number.trim() || null : null));

    const websiteDomain = cleanDomain(
      typeof org.websiteUrl === 'string' ? org.websiteUrl
        : (typeof org.website === 'string' ? org.website
          : (org.website && typeof org.website === 'object' ? org.website.url : null))
    );

    return { name, industry, tagline, hqCity, hqCountry, description, memberCount, sizeRange,
             followers, foundedYear, specialties, phone, websiteDomain };
  }

  // ── SECONDARY: DOM fallbacks for jobs count + latest post time ─────────────

  // Follower text like "496 followers" / "1,227 followers" / "10K followers".
  function parseFollowerCount(text) {
    if (!text) return null;
    const m = String(text).match(/([\d][\d,.]*)\s*([KkMm])?\s*followers/);
    if (!m) return null;
    let n = Number(m[1].replace(/,/g, ''));
    if (!Number.isFinite(n)) return null;
    if (m[2]) n = n * (m[2].toLowerCase() === 'k' ? 1e3 : 1e6);
    n = Math.round(n);
    return n >= 0 ? n : null;
  }

  // ── SECONDARY (v1.23.1): About-tab definition list ──────────────────────────
  // The /about page renders a <dl> of labeled facts (Website / Phone /
  // Industry / Company size / Headquarters / Founded / Specialties). Labels
  // are matched in ENGLISH — reps on localized LinkedIn fall back to the
  // entity JSON + top-card layers. Values degrade to null, never a guess.
  function extractAboutDl(doc) {
    const d = doc || document;
    const out = {};
    let dts;
    try { dts = d.querySelectorAll('dl dt'); } catch (_) { return out; }
    for (const dt of dts) {
      const label = (dt.textContent || '').trim().toLowerCase();
      // The value can span SEVERAL consecutive <dd> siblings (live example:
      // Company size renders the range in one dd and "1,131 associated
      // members" in a second) — collect them all until the next <dt>.
      const parts = [];
      let sib = dt.nextElementSibling;
      while (sib && sib.tagName !== 'DT') {
        if (sib.tagName === 'DD') parts.push(sib);
        sib = sib.nextElementSibling;
      }
      if (!parts.length) continue;
      const dd = parts[0]; // first dd — anchors/links live here
      const text = parts.map((el) => (el.textContent || '')).join(' ').replace(/\s+/g, ' ').trim();
      if (!text) continue;

      if (label === 'website') {
        const a = dd.querySelector('a[href]');
        out.websiteDomain = cleanDomain(a ? a.getAttribute('href') : text) || out.websiteDomain || null;
      } else if (label === 'phone') {
        // dd often carries "+1 555 010 1234 Phone number is +1 …" — take the
        // tel: href when present, else the leading number-ish run.
        const a = dd.querySelector('a[href^="tel:"]');
        const raw = a ? a.getAttribute('href').replace(/^tel:/, '') : (text.match(/^[+()\d][\d\s().-]{5,24}/) || [null])[0];
        if (raw) out.phone = raw.trim();
      } else if (label === 'industry') {
        out.industry = text;
      } else if (label === 'company size') {
        // "2-10 employees" (range line) and sometimes a second
        // "N associated members" line — the range is display-only; a real
        // member count is a number.
        const range = text.match(/([\d,]+)\s*-\s*([\d,]+)\s+employees|([\d,]+)\+\s+employees/);
        if (range) out.sizeRange = range[0];
        const assoc = text.match(/([\d,]+)\s+associated members/);
        if (assoc) out.memberCount = toInt(assoc[1]);
      } else if (label === 'headquarters') {
        const parts = text.split(',').map((s) => s.trim()).filter(Boolean);
        if (parts[0]) out.hqCity = parts[0];
        if (parts.length > 1) out.hqCountry = parts[parts.length - 1];
      } else if (label === 'founded') {
        const y = toInt((text.match(/\b(1[89]\d{2}|20\d{2})\b/) || [null])[0]);
        if (y) out.foundedYear = y;
      } else if (label === 'specialties' || label === 'specialities') {
        const arr = text.split(/[,、]/).map((s) => s.trim().replace(/\band\s+/i, '')).filter(Boolean);
        if (arr.length) out.specialties = [...new Set(arr)].slice(0, 50);
      }
    }
    return out;
  }

  // ── SECONDARY (v1.23.2): the full Overview text ─────────────────────────────
  // The entity JSON often carries a TRUNCATED description (~300 chars with a
  // trailing ellipsis) — the FULL text is rendered as the Overview paragraph
  // on the /about page. Read it and let buildCapture prefer the longest
  // description available.
  function extractAboutOverview(doc) {
    const d = doc || document;
    let headings;
    try { headings = d.querySelectorAll('h1, h2, h3'); } catch (_) { return null; }
    for (const h of headings) {
      if ((h.textContent || '').trim().toLowerCase() !== 'overview') continue;
      // The overview body is the paragraph(s) following the heading, within
      // the same section — stop at the next heading or labeled <dl> block.
      const texts = [];
      let sib = h.nextElementSibling;
      let hops = 0;
      while (sib && hops < 8) {
        const tag = sib.tagName;
        if (/^H[1-6]$/.test(tag) || tag === 'DL') break;
        if (tag === 'P' || tag === 'DIV') {
          const t = (sib.textContent || '').replace(/\s+/g, ' ').trim();
          if (t) texts.push(t);
        }
        sib = sib.nextElementSibling;
        hops++;
      }
      const full = texts.join('\n\n').trim();
      if (full.length >= 40) return full.slice(0, 5000);
    }
    return null;
  }

  // ── SECONDARY (v1.23.1): top-card summary line + tagline ────────────────────
  // Under the company name: "<tagline>" then a dotted line like
  // "E-Learning Providers · 496 followers · 2-10 employees". Followers is the
  // anchor (the one unambiguous token); industry is the non-numeric segment
  // before it; the employees range is its own segment.
  function extractTopCard(doc) {
    const d = doc || document;
    const out = {};
    let candidates;
    try {
      // Search small text blocks near the top card; forgiving on class churn.
      candidates = d.querySelectorAll('section p, section div, h1 ~ p, h1 ~ div');
    } catch (_) { return out; }

    for (const el of candidates) {
      if (el.children.length > 3) continue; // summary line is a leaf-ish node
      const text = (el.textContent || '').replace(/\s+/g, ' ').trim();
      if (!text || text.length > 220 || !/followers/.test(text)) continue;
      const followers = parseFollowerCount(text);
      if (followers === null) continue;
      out.followers = followers;
      const segments = text.split('·').map((s) => s.trim()).filter(Boolean);
      for (const seg of segments) {
        if (/followers/.test(seg)) continue;
        if (/employees/.test(seg)) { out.sizeRange = out.sizeRange || seg; continue; }
        if (!out.industry && seg.length <= 60 && !/^\d/.test(seg)) out.industry = seg;
      }
      // The tagline is usually the previous meaningful sibling of this line.
      let prev = el.previousElementSibling;
      while (prev && !(prev.textContent || '').trim()) prev = prev.previousElementSibling;
      if (prev) {
        const t = (prev.textContent || '').replace(/\s+/g, ' ').trim();
        if (t && t.length >= 8 && t.length <= 300 && !/followers|employees/.test(t)) out.tagline = t;
      }
      break;
    }
    return out;
  }

  function extractJobOpenings(doc) {
    const d = doc || document;
    // Anchors into the jobs surface carry text like "See all 12 jobs" /
    // "12 job openings". Scan hrefs first (tight), then a bounded text scan.
    let candidates;
    try {
      candidates = d.querySelectorAll('a[href*="/jobs"], a[href*="currentCompany"]');
    } catch (_) { candidates = []; }
    const RE = /([\d][\d,]*)\s*(?:job(?:s)?(?:\s+opening(?:s)?)?)\b/i;
    for (const a of candidates) {
      const m = (a.textContent || '').match(RE);
      if (m) { const n = toInt(m[1]); if (n !== null) return n; }
    }
    return null;
  }

  function extractLatestPostAt(doc, now) {
    const d = doc || document;
    // Feed update cards carry a relative timestamp near the poster line;
    // <time> elements when present, else short "2w"-style spans. We take the
    // FIRST match in document order (newest post renders first) and stay
    // conservative: unparseable → null.
    try {
      const t = d.querySelector('.feed-shared-update-v2 time, [data-urn*="activity"] time');
      if (t) {
        const dt = t.getAttribute('datetime');
        if (dt) { const parsed = new Date(dt); if (!Number.isNaN(parsed.getTime())) return parsed.toISOString(); }
        const rel = parseRelativeTime(t.textContent, now);
        if (rel) return rel;
      }
    } catch (_) {}
    try {
      const spans = d.querySelectorAll('.feed-shared-update-v2 span[aria-hidden="true"], .update-components-actor__sub-description span[aria-hidden="true"]');
      for (const s of spans) {
        const rel = parseRelativeTime((s.textContent || '').trim(), now);
        if (rel) return rel;
      }
    } catch (_) {}
    return null;
  }

  // ── SECONDARY (v1.23.3): newest job-posting age ─────────────────────────────
  // The Jobs tab often states NO total ("See More Jobs", no count) — but every
  // job card carries a posted-age line ("8 hours ago" / "4 days ago" /
  // "30+ days ago"). The NEWEST one is a stated fact and the real why-now:
  // "hiring right now". We scan leaf-ish text nodes for the ago-pattern near
  // job links and take the smallest age (= most recent). Counting visible
  // cards as a total would be fabrication (pagination hides the rest) — the
  // true count comes from enrichment (P9) or pages that state one.
  function extractLatestJobPostedAt(doc, now) {
    const d = doc || document;
    // Only meaningful when the page shows job cards at all.
    let hasJobSurface = false;
    try {
      hasJobSurface = !!d.querySelector('a[href*="/jobs/view"], a[href*="/jobs/"], li[class*="job-card"], div[class*="job-card-square"], div[class*="job-card-container"]');
    } catch (_) {}
    if (!hasJobSurface) return null;

    let nodes;
    try { nodes = d.querySelectorAll('time, span, div, li'); } catch (_) { return null; }
    const AGO = /^(\d+)\+?\s*(hours?|hrs?|days?|weeks?|months?|mos?|minutes?|mins?)\s+ago$/i;
    let bestMs = null;
    const base = (now && typeof now.getTime === 'function') ? now.getTime() : Date.now();
    for (const el of nodes) {
      if (el.children.length > 0) continue; // leaf nodes only
      const t = (el.textContent || '').replace(/\s+/g, ' ').trim();
      if (!t || t.length > 24) continue;
      const m = t.match(AGO);
      if (!m) continue;
      const iso = /min/i.test(m[2])
        ? new Date(base - parseInt(m[1], 10) * 60e3).toISOString()
        : parseRelativeTime(t, now);
      if (!iso) continue;
      const ms = new Date(iso).getTime();
      if (bestMs === null || ms > bestMs) bestMs = ms; // newest = largest timestamp
    }
    return bestMs === null ? null : new Date(bestMs).toISOString();
  }

  // ── SECONDARY (v1.23.4): the visible job cards themselves ──────────────────
  // Not the total (never fabricated) — the LIST of what's visibly posted:
  // title from each /jobs/view link, plus a best-effort location and posted
  // age from the same card. Card boundaries via closest('li') falling back to
  // the link's parent chain. Lines that are the company name, connection
  // blurbs ("1 school alum works here"), or the ago-line are filtered; the
  // first remaining short text line is taken as the location. Dedupe by job
  // id, cap 10. Everything degrades to nulls, never guesses.
  function extractRecentJobs(doc, now, companyName) {
    const d = doc || document;
    let links;
    try { links = d.querySelectorAll('a[href*="/jobs/view"]'); } catch (_) { return null; }
    if (!links || !links.length) return null;

    const AGO = /^(\d+)\+?\s*(hours?|hrs?|days?|weeks?|months?|mos?|minutes?|mins?)\s+ago$/i;
    const NOISE = /alum|connection|works here|follow|promoted|easy apply|actively recruiting|be an early applicant|verified|with verification/i;
    const nameLC = (companyName || '').trim().toLowerCase();
    const seen = new Set();
    const jobs = [];

    for (const a of links) {
      if (jobs.length >= 25) break;
      const href = a.getAttribute('href') || '';
      const idM = href.match(/\/jobs\/view\/(\d+)/);
      const id = idM ? idM[1] : href;
      if (seen.has(id)) continue;

      const title = jobTitleFrom(a);
      if (!title || title.length < 3 || title.length > 140) continue;
      if (/^see\b|jobs?$/i.test(title)) continue; // "See More Jobs" style links
      seen.add(id);

      // Card container: nearest li, else walk up a few parents.
      let card = null;
      try { card = a.closest('li'); } catch (_) {}
      if (!card) {
        card = a.parentElement;
        for (let i = 0; i < 3 && card && card.parentElement; i++) {
          if ((card.textContent || '').length > title.length + 10) break;
          card = card.parentElement;
        }
      }

      let location = null;
      let postedAt = null;
      if (card) {
        let leaves;
        try { leaves = card.querySelectorAll('span, div, time, p'); } catch (_) { leaves = []; }
        for (const el of leaves) {
          if (el.children.length > 0) continue;
          const t = (el.textContent || '').replace(/\s+/g, ' ').trim();
          if (!t) continue;
          if (!postedAt) {
            const m = t.match(AGO);
            if (m) {
              postedAt = /min/i.test(m[2])
                ? new Date(((now && now.getTime) ? now.getTime() : Date.now()) - parseInt(m[1], 10) * 60e3).toISOString()
                : parseRelativeTime(t, now);
              continue;
            }
          }
          if (!location) {
            if (t === title || t.toLowerCase() === nameLC) continue;
            if (t.length > 60 || NOISE.test(t) || AGO.test(t)) continue;
            if (!/[a-z]/i.test(t)) continue;
            location = t;
          }
        }
      }
      jobs.push({ id, title, location, postedAt });
    }
    return jobs.length ? jobs : null;
  }

  /** textContent with screen-reader duplicates stripped — LinkedIn renders
   *  titles twice (aria-hidden span + .visually-hidden copy); reading the
   *  raw textContent doubles them ("Quote AnalystQuote Analyst"). */
  function visibleText(el) {
    if (!el) return '';
    try {
      const clone = el.cloneNode(true);
      for (const hid of clone.querySelectorAll('.visually-hidden, [class*="visually-hidden"]')) hid.remove();
      return (clone.textContent || '').replace(/\s+/g, ' ').trim();
    } catch (_) {
      return (el.textContent || '').replace(/\s+/g, ' ').trim();
    }
  }

  /** v1.23.10 — canonical job-title cleaner. LinkedIn's HOME-page jobs module
   *  differs from the Jobs tab: the screen-reader duplicate span carries NO
   *  visually-hidden class (→ doubled titles), the ✓ badge contributes a
   *  literal "Verified"/"with verification", and the matched wrapper can
   *  swallow sibling lines. Cleaning: collapse whitespace → halve an exact
   *  self-doubling ("X X" where both halves match) → strip badge residue. */
  function cleanJobTitle(raw) {
    let t = String(raw || '').replace(/\s+/g, ' ').trim();
    if (!t) return '';
    // Exact self-doubling: "Senior Manager, AI R&T Senior Manager, AI R&T".
    if (t.length >= 6 && t.length % 2 === 1) {
      const half = (t.length - 1) / 2;
      if (t.slice(0, half) === t.slice(half + 1) && t[half] === ' ') t = t.slice(0, half);
    }
    // Badge residue, wherever the badge landed.
    t = t.replace(/\s*\bwith verification\b\s*/gi, ' ')
         .replace(/\s*\bverified\b\s*$/i, ' ')
         .replace(/\s+/g, ' ').trim();
    // Second-chance halving after residue removal.
    if (t.length >= 6 && t.length % 2 === 1) {
      const half = (t.length - 1) / 2;
      if (t.slice(0, half) === t.slice(half + 1) && t[half] === ' ') t = t.slice(0, half);
    }
    return t;
  }

  /** Title text from a title-ish element: PREFER the aria-hidden="true" span
   *  (the visual copy — excludes SR duplicates regardless of their class and
   *  excludes the badge, which sits outside it), else stripped visibleText. */
  function jobTitleFrom(el) {
    if (!el) return '';
    let vis = null;
    try { vis = el.querySelector('[aria-hidden="true"]'); } catch (_) {}
    const raw = vis ? (vis.textContent || '') : visibleText(el);
    return cleanJobTitle(raw);
  }

  /** Best-effort job id off a card: data attributes, jobPosting URNs, any
   *  jobs-ish href with a long number, else a title-keyed fallback (still
   *  dedupes the same role across pagination re-renders). */
  function _jobIdFromCard(card, title) {
    try {
      const attrEl = card.matches('[data-job-id],[data-occludable-job-id],[data-entity-urn],[data-chameleon-result-urn]')
        ? card
        : card.querySelector('[data-job-id],[data-occludable-job-id],[data-entity-urn],[data-chameleon-result-urn]');
      if (attrEl) {
        for (const attr of ['data-job-id', 'data-occludable-job-id', 'data-entity-urn', 'data-chameleon-result-urn']) {
          const v = attrEl.getAttribute(attr);
          if (!v) continue;
          const m = String(v).match(/(\d{6,})/);
          if (m) return m[1];
        }
      }
      const a = card.querySelector('a[href*="jobs"], a[href*="currentJobId"]');
      if (a) {
        const m = (a.getAttribute('href') || '').match(/(?:jobs\/view\/|currentJobId=)(\d+)|\/(\d{8,})(?:[/?#]|$)/);
        if (m) return m[1] || m[2];
      }
    } catch (_) {}
    return 't:' + String(title || '').toLowerCase();
  }

  /** v1.23.6 — SDUI card shape (observed live on company Jobs tabs): the card
   *  is a [class*="job-card"] container whose title sits in an
   *  artdeco-entity-lockup__title / *__title element with NO /jobs/view
   *  anchor. Same filters as the anchor path; degrades to null. */
  function extractRecentJobsFromCards(doc, now, companyName) {
    const d = doc || document;
    let cards;
    try {
      cards = d.querySelectorAll('li[class*="job-card"], div[class*="job-card-square"], div[class*="job-card-container"]');
    } catch (_) { return null; }
    if (!cards || !cards.length) return null;

    const AGO = /^(\d+)\+?\s*(hours?|hrs?|days?|weeks?|months?|mos?|minutes?|mins?)\s+ago$/i;
    const NOISE = /alum|connection|works here|follow|promoted|easy apply|actively recruiting|be an early applicant|show all|see more|verified|with verification/i;
    const nameLC = (companyName || '').trim().toLowerCase();
    const seen = new Set();
    const processedEls = new Set();
    const jobs = [];

    for (const rawCard of cards) {
      if (jobs.length >= 25) break;
      // The class-stem match may land on an INNER element (live example: the
      // outer li is `occludable-update`, only the title div carries
      // `job-card-square`) — ascend to the enclosing <li> as the card
      // boundary so data attributes, location and age (siblings of the title)
      // are in scope. Element-level dedupe: outer li + inner div matching the
      // same card process once.
      const card = (rawCard.closest && rawCard.closest('li')) || rawCard;
      if (processedEls.has(card)) continue;
      processedEls.add(card);
      let titleEl = null;
      try {
        titleEl = card.querySelector('[class*="artdeco-entity-lockup__title"], [class*="job-card"][class*="__title"], [class*="job-card"][class*="title"]');
      } catch (_) {}
      if (!titleEl) continue;
      const title = jobTitleFrom(titleEl);
      if (!title || title.length < 3 || title.length > 140 || NOISE.test(title)) continue;
      if (nameLC && title.toLowerCase() === nameLC) continue;

      const id = _jobIdFromCard(card, title);
      if (seen.has(id)) continue;
      seen.add(id);

      let location = null;
      let postedAt = null;
      let leaves;
      try { leaves = card.querySelectorAll('span, div, time, p'); } catch (_) { leaves = []; }
      for (const el of leaves) {
        if (el.children.length > 0) continue;
        try { if (el.closest('[class*="visually-hidden"]')) continue; } catch (_) {}
        const t = (el.textContent || '').replace(/\s+/g, ' ').trim();
        if (!t) continue;
        if (!postedAt) {
          const m = t.match(AGO);
          if (m) {
            postedAt = /min/i.test(m[2])
              ? new Date(((now && now.getTime) ? now.getTime() : Date.now()) - parseInt(m[1], 10) * 60e3).toISOString()
              : parseRelativeTime(t, now);
            continue;
          }
        }
        if (!location) {
          if (t === title || t.toLowerCase() === nameLC) continue;
          if (t.length > 60 || NOISE.test(t) || AGO.test(t)) continue;
          if (!/[a-z]/i.test(t)) continue;
          location = t;
        }
      }
      jobs.push({ id, title, location, postedAt });
    }
    return jobs.length ? jobs : null;
  }

  // ── Assemble one capture (pure given slug/doc/now — the JSDOM test entry) ──
  // Merge precedence per field: entity JSON → About-tab <dl> → top card.
  // First non-null wins; blanks never write (the backend enforces it again).

  function buildCapture(slug, doc, now) {
    const org   = extractOrgFromCodeBlocks(slug, doc) || {};
    const about = extractAboutDl(doc);
    const top   = extractTopCard(doc);
    const pick = (...vals) => {
      for (const v of vals) if (v !== null && v !== undefined && v !== '') return v;
      return null;
    };
    // Description: the entity's copy is often TRUNCATED (~300 chars + '…');
    // the /about Overview paragraph is the full text — take the LONGEST.
    const overview = extractAboutOverview(doc);
    const description = [org.description || null, overview]
      .filter(Boolean)
      .sort((a, b) => b.length - a.length)[0] || null;
    return {
      slug,
      linkedinCompanyUrl: companyUrlFor(slug),
      name:          org.name || null,
      tagline:       pick(org.tagline, top.tagline),
      industry:      pick(org.industry, about.industry, top.industry),
      hqCity:        pick(org.hqCity, about.hqCity),
      hqCountry:     pick(org.hqCountry, about.hqCountry),
      description,
      memberCount:   pick(org.memberCount, about.memberCount),   // real counts only
      sizeRange:     pick(org.sizeRange, about.sizeRange, top.sizeRange), // display only — never a number
      followers:     pick(org.followers, top.followers),
      foundedYear:   pick(org.foundedYear, about.foundedYear),
      specialties:   pick(org.specialties, about.specialties),
      phone:         pick(org.phone, about.phone),
      websiteDomain: pick(org.websiteDomain, about.websiteDomain),
      jobOpenings:   extractJobOpenings(doc),
      recentJobs:    (function () {
        const merged = mergeJobs(
          extractRecentJobs(doc, now, org.name || null) || [],
          extractRecentJobsFromCards(doc, now, org.name || null) || [],
          25
        );
        return merged.length ? merged : null;
      })(),
      latestJobPostedAt: extractLatestJobPostedAt(doc, now),
      latestPostAt:  extractLatestPostAt(doc, now),
    };
  }

  // Test hook (inert unless the harness set the flag before injection).
  try {
    if (typeof window !== 'undefined' && window.__GOWARM_TEST__) {
      window.__gowarmCompanyTest = {
        getCompanySlug, parseRelativeTime, cleanDomain, parseFollowerCount,
        extractOrgFromCodeBlocks, extractAboutDl, extractTopCard, extractAboutOverview,
        extractJobOpenings, extractRecentJobs, extractRecentJobsFromCards, extractLatestJobPostedAt, extractLatestPostAt, buildCapture, mergeJobs, visibleText, cleanJobTitle, jobTitleFrom,
      };
    }
  } catch (_) {}

  // In the harness there's no chrome runtime — stop before any UI/network.
  if (!extensionAlive()) return;

  // ── Panel ───────────────────────────────────────────────────────────────────

  // ── v1.23.5: job accumulator — the rep clicks Next, we stop forgetting ─────
  // Pagination re-renders the card list; instead of replacing the capture's
  // job list each time, cards accumulate PER COMPANY as the rep browses
  // (deduped by job id, newest-first, cap 25). Reset when the slug changes.
  // Strictly rep-viewed content — the extension never clicks or navigates.
  const JOBS_CAP = 25;

  /** Pure merge: existing[] + incoming[] → deduped, newest-first, capped.
   *  v1.23.9 two-tier dedupe: primary by job id; secondary by normalized
   *  title+location — the two extraction paths can capture the SAME job
   *  under different keys (one sees the numeric id, the other falls back to
   *  't:title'), so a title/location match where AT LEAST ONE side carries a
   *  fallback key collapses into one record (numeric id wins, details
   *  merged). Two DISTINCT numeric ids with identical titles stay separate —
   *  a genuinely reposted role is two postings, not a duplicate. */
  function mergeJobs(existing, incoming, cap) {
    const isFallbackId = (id) => typeof id === 'string' && id.startsWith('t:');
    const normKey = (j) => (cleanJobTitle(j.title || '').toLowerCase()
      + '|' + String(j.location || '').toLowerCase().replace(/\s+/g, ' ').trim());
    const mergeRec = (a, b) => ({
      id: isFallbackId(a.id) && b.id && !isFallbackId(b.id) ? b.id : a.id,
      title: b.title || a.title,
      location: b.location || a.location,
      postedAt: b.postedAt || a.postedAt,
    });

    const map = new Map();       // id → job
    const byTitleLoc = new Map(); // normKey → id (for fallback reconciliation)

    const add = (j) => {
      if (!j || !j.id) return;
      const prev = map.get(j.id);
      if (prev) {
        map.set(j.id, mergeRec(prev, j));
        return;
      }
      // Secondary: same title+location already present, and one side is a
      // fallback key → the same job seen by two extraction paths.
      const key = normKey(j);
      const twinId = byTitleLoc.get(key);
      if (twinId !== undefined && map.has(twinId)) {
        const twin = map.get(twinId);
        if (isFallbackId(twin.id) || isFallbackId(j.id)) {
          const merged = mergeRec(twin, j);
          if (merged.id !== twinId) map.delete(twinId); // upgrade t: → numeric
          map.set(merged.id, merged);
          byTitleLoc.set(key, merged.id);
          return;
        }
        // Both numeric & different → genuinely distinct postings; fall through.
      }
      map.set(j.id, j);
      if (twinId === undefined) byTitleLoc.set(key, j.id);
    };

    for (const j of (Array.isArray(existing) ? existing : [])) add(j);
    for (const j of (Array.isArray(incoming) ? incoming : [])) add(j);

    const arr = [...map.values()];
    arr.sort((a, b) => {
      const ta = a.postedAt ? new Date(a.postedAt).getTime() : 0;
      const tb = b.postedAt ? new Date(b.postedAt).getTime() : 0;
      return tb - ta; // newest first; undated sink to the end
    });
    return arr.slice(0, cap || 25); // literal default: harness calls this
                                    // before JOBS_CAP initializes (TDZ)
  }

  const jobAccumulator = { slug: null, jobs: [] };

  function accumulateJobs(slug, incoming) {
    if (jobAccumulator.slug !== slug) {
      jobAccumulator.slug = slug;
      jobAccumulator.jobs = [];
    }
    jobAccumulator.jobs = mergeJobs(jobAccumulator.jobs, incoming, JOBS_CAP);
    return jobAccumulator.jobs.length ? jobAccumulator.jobs : null;
  }

  let currentSlug = null;
  let capture = null;
  // v1.23.8 — panel expanders (roles / specialties); state survives re-renders,
  // resets when the company changes.
  const expanded = { roles: false, specialties: false };
  let matchInfo = null;   // { accountId, accountName, matchedBy }
  let saving = false;

  function removePanel() { document.getElementById(PANEL_ID)?.remove(); }

  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (ch) => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]
  ));

  function factRow(label, value, clip = 140) {
    if (value === null || value === undefined || value === '') return '';
    const shown = String(value);
    const clipped = shown.length > clip ? shown.slice(0, clip) + '…' : shown;
    return `<div style="display:flex;gap:6px;font-size:11px;line-height:1.5;">
      <span style="color:#94a3b8;min-width:86px;flex:none;">${esc(label)}</span>
      <span style="color:#1f2937;word-break:break-word;">${esc(clipped)}</span>
    </div>`;
  }

  function renderPanel() {
    removePanel();
    if (!capture) return;

    const wrap = document.createElement('div');
    wrap.id = PANEL_ID;
    wrap.style.cssText = `position:fixed;top:84px;right:16px;width:300px;z-index:99999;
      background:#fff;border:1px solid #e2e8f0;border-radius:10px;
      box-shadow:0 8px 24px rgba(15,23,42,.14);font-family:-apple-system,'Segoe UI',Roboto,sans-serif;overflow:hidden;`;

    const postAgo = capture.latestPostAt
      ? `${Math.max(0, Math.round((Date.now() - new Date(capture.latestPostAt).getTime()) / 86400000))}d ago`
      : null;

    const matchLine = !matchInfo
      ? `<span style="color:#94a3b8;">Matching account…</span>`
      : matchInfo.accountId
        ? `<span style="color:#166534;">✓ ${esc(matchInfo.accountName)}</span>
           <span style="color:#94a3b8;"> (by ${matchInfo.matchedBy === 'linkedin_url' ? 'LinkedIn URL' : 'domain'})</span>`
        : `<span style="color:#b45309;">No matching account in GoWarm</span>`;

    const canSave = matchInfo && matchInfo.accountId;
    const canCreate = matchInfo && !matchInfo.accountId && capture.name;

    wrap.innerHTML = `
      <div style="display:flex;align-items:center;justify-content:space-between;padding:8px 12px;background:${TEAL};">
        <span style="color:#fff;font-size:12px;font-weight:700;">🔥 GoWarm — Company signals</span>
        <button id="gw-cp-close" style="background:none;border:none;color:#fff;font-size:14px;cursor:pointer;line-height:1;">✕</button>
      </div>
      <div style="padding:10px 12px;display:flex;flex-direction:column;gap:4px;max-height:calc(100vh - 180px);overflow-y:auto;">
        <div style="font-size:12px;font-weight:700;color:#111827;margin-bottom:2px;">${esc(capture.name || currentSlug)}</div>
        ${factRow('Headline', capture.tagline)}
        ${factRow('Industry', capture.industry)}
        ${factRow('HQ', [capture.hqCity, capture.hqCountry].filter(Boolean).join(', ') || null)}
        ${factRow('Members', capture.memberCount)}
        ${capture.memberCount === null ? factRow('Size (range)', capture.sizeRange ? capture.sizeRange + ' — shown only, not saved as a number' : null) : factRow('Size (range)', capture.sizeRange)}
        ${factRow('Followers', capture.followers)}
        ${factRow('Founded', capture.foundedYear)}
        ${factRow('Open roles', capture.jobOpenings)}
        ${factRow('Last job post', capture.latestJobPostedAt ? Math.max(0, Math.round((Date.now() - new Date(capture.latestJobPostedAt).getTime()) / 3600000)) + 'h ago' : null)}
        ${Array.isArray(capture.recentJobs) && capture.recentJobs.length ? (
          expanded.roles
            ? `<div style="display:flex;gap:6px;font-size:11px;line-height:1.5;">
                 <span style="color:#94a3b8;min-width:86px;flex:none;">Posted roles (${capture.recentJobs.length})</span>
                 <div style="color:#1f2937;">
                   ${capture.recentJobs.map(j => {
                     const age = j.postedAt ? Math.max(0, Math.round((Date.now() - new Date(j.postedAt).getTime()) / 86400000)) + 'd' : null;
                     return `<div style="margin-bottom:2px;">• ${esc(j.title)}${j.location ? ' · ' + esc(j.location) : ''}${age ? ' · ' + age : ''}</div>`;
                   }).join('')}
                   <button data-gw-toggle="roles" style="border:none;background:none;color:${TEAL};cursor:pointer;font-size:11px;padding:0;">Show less ▴</button>
                 </div>
               </div>`
            : `<div style="display:flex;gap:6px;font-size:11px;line-height:1.5;">
                 <span style="color:#94a3b8;min-width:86px;flex:none;">Posted roles (${capture.recentJobs.length})</span>
                 <div style="color:#1f2937;word-break:break-word;">
                   ${esc(capture.recentJobs.slice(0, 3).map(j => j.title).join('; '))}
                   ${capture.recentJobs.length > 3 ? `&nbsp;<button data-gw-toggle="roles" style="border:none;background:none;color:${TEAL};cursor:pointer;font-size:11px;padding:0;">Show all ${capture.recentJobs.length} ▾</button>` : ''}
                 </div>
               </div>`
        ) : ''}
        ${factRow('Last post', postAgo)}
        ${Array.isArray(capture.specialties) && capture.specialties.length ? (
          expanded.specialties
            ? `<div style="display:flex;gap:6px;font-size:11px;line-height:1.5;">
                 <span style="color:#94a3b8;min-width:86px;flex:none;">Specialties (${capture.specialties.length})</span>
                 <div style="color:#1f2937;word-break:break-word;">${esc(capture.specialties.join(', '))}
                   <button data-gw-toggle="specialties" style="border:none;background:none;color:${TEAL};cursor:pointer;font-size:11px;padding:0;">&nbsp;Show less ▴</button>
                 </div>
               </div>`
            : (() => {
                const joined = capture.specialties.join(', ');
                const clipped = joined.length > 120 ? joined.slice(0, 120) + '…' : joined;
                return `<div style="display:flex;gap:6px;font-size:11px;line-height:1.5;">
                 <span style="color:#94a3b8;min-width:86px;flex:none;">Specialties (${capture.specialties.length})</span>
                 <div style="color:#1f2937;word-break:break-word;">${esc(clipped)}
                   ${joined.length > 120 ? `&nbsp;<button data-gw-toggle="specialties" style="border:none;background:none;color:${TEAL};cursor:pointer;font-size:11px;padding:0;">Show all ▾</button>` : ''}
                 </div>
               </div>`;
              })()
        ) : ''}
        ${factRow('Phone', capture.phone)}
        ${factRow('About', capture.description, 400)}
        ${factRow('Website', capture.websiteDomain)}
        <div style="margin-top:6px;font-size:11px;">${matchLine}</div>
        <button id="gw-cp-save" ${canSave && !saving ? '' : 'disabled'}
          style="margin-top:8px;width:100%;padding:7px;background:${canSave ? TEAL : '#cbd5e1'};color:#fff;border:none;border-radius:6px;font-size:12px;font-weight:600;cursor:${canSave ? 'pointer' : 'default'};">
          ${saving ? 'Saving…' : 'Save company signals'}
        </button>
        ${canCreate ? `<button id="gw-cp-create" ${saving ? 'disabled' : ''}
          style="margin-top:6px;width:100%;padding:7px;background:${ORANGE};color:#fff;border:none;border-radius:6px;font-size:12px;font-weight:600;cursor:pointer;">
          ${saving ? 'Saving…' : 'Create account & save'}
        </button>` : ''}
        <div id="gw-cp-feedback" style="margin-top:6px;font-size:11px;display:none;"></div>
        <div style="margin-top:4px;font-size:10px;color:#94a3b8;">Reads only what's on this page. Nothing is saved until you tap. Your edits in GoWarm are never overwritten.</div>
      </div>`;

    document.body.appendChild(wrap);
    wrap.querySelector('#gw-cp-close').addEventListener('click', removePanel);
    // v1.23.8 — expander toggles (roles / specialties) re-render in place.
    for (const btn of wrap.querySelectorAll('[data-gw-toggle]')) {
      btn.addEventListener('click', () => {
        const key = btn.getAttribute('data-gw-toggle');
        expanded[key] = !expanded[key];
        renderPanel();
      });
    }
    const saveBtn = wrap.querySelector('#gw-cp-save');
    if (saveBtn) saveBtn.addEventListener('click', () => doSave(false));
    const createBtn = wrap.querySelector('#gw-cp-create');
    if (createBtn) createBtn.addEventListener('click', () => doSave(true));
  }

  function showFeedback(msg, ok) {
    const el = document.getElementById(PANEL_ID)?.querySelector('#gw-cp-feedback');
    if (!el) return;
    el.style.display = 'block';
    el.style.color = ok ? '#166534' : '#b45309';
    el.textContent = msg;
  }

  const SAVE_FAIL_NOTICES = {
    no_matching_account: 'No matching account — use "Create account & save".',
    nothing_extractable: 'Nothing readable on this page to save.',
    no_company_name:     "Couldn't read the company name — can't create an account.",
    NOT_AUTHENTICATED:   'Sign in to GoWarmCRM in another tab, then try again.',
  };

  function doSave(createIfMissing) {
    if (!extensionAlive() || !capture || saving) return;
    saving = true;
    renderPanel();
    chrome.runtime.sendMessage(
      { type: 'GW_COMPANY_SAVE', capture, createIfMissing: !!createIfMissing },
      (res) => {
        saving = false;
        if (chrome.runtime.lastError || !res) {
          renderPanel();
          showFeedback('Could not reach GoWarm — try again.', false);
          return;
        }
        if (res.ok) {
          matchInfo = { accountId: res.accountId, accountName: res.accountName, matchedBy: res.matchedBy || 'linkedin_url' };
          renderPanel();
          const n = (res.written || []).length;
          const kept = (res.skipped || []).filter((s) => s.reason === 'rep_override').length;
          let msg = res.created
            ? `Account created — ${n} signal${n === 1 ? '' : 's'} saved.`
            : `${n} signal${n === 1 ? '' : 's'} saved to ${res.accountName || 'the account'}.`;
          if (kept) msg += ` ${kept} kept your GoWarm edit${kept === 1 ? '' : 's'}.`;
          showFeedback(msg, true);
        } else {
          renderPanel();
          showFeedback(SAVE_FAIL_NOTICES[res.reason] || SAVE_FAIL_NOTICES[res.error] || `Save failed${res.error ? ': ' + res.error : ''}.`, false);
        }
      }
    );
  }

  function refreshMatch() {
    if (!extensionAlive() || !capture) return;
    chrome.runtime.sendMessage(
      { type: 'GW_COMPANY_MATCH', linkedinCompanyUrl: capture.linkedinCompanyUrl, domain: capture.websiteDomain },
      (res) => {
        matchInfo = (res && res.ok !== false)
          ? { accountId: res.accountId || null, accountName: res.accountName || null, matchedBy: res.matchedBy || 'none' }
          : { accountId: null, accountName: null, matchedBy: 'none' };
        renderPanel();
      }
    );
  }

  // ── Init + SPA navigation (mirrors content.js) ─────────────────────────────

  let initTimer = null;
  function init() {
    if (!extensionAlive()) return;
    const slug = getCompanySlug();
    if (!slug) { removePanel(); return; }
    if (currentSlug !== slug) { expanded.roles = false; expanded.specialties = false; }
    currentSlug = slug;
    capture = buildCapture(slug, document, new Date());
    // v1.23.5: jobs accumulate across the rep's own pagination clicks.
    capture.recentJobs = accumulateJobs(slug, capture.recentJobs);
    // A capture with literally nothing readable → no panel noise.
    const hasAnything = capture.name || capture.industry || capture.description
      || capture.memberCount !== null || capture.jobOpenings !== null || capture.latestPostAt || capture.latestJobPostedAt || capture.recentJobs;
    if (!hasAnything) { removePanel(); return; }
    matchInfo = null;
    renderPanel();
    refreshMatch();

    // Jobs count / latest post often hydrate late — one delayed re-read
    // (values only ever ADD; the rep sees the panel update in place).
    setTimeout(() => {
      if (!extensionAlive() || getCompanySlug() !== slug || !capture) return;
      const again = buildCapture(slug, document, new Date());
      let changed = false;
      for (const k of ['jobOpenings', 'latestJobPostedAt', 'latestPostAt', 'memberCount', 'industry', 'description',
                       'tagline', 'followers', 'foundedYear', 'specialties', 'phone', 'sizeRange',
                       'hqCity', 'hqCountry', 'websiteDomain']) {
        if ((capture[k] === null || capture[k] === undefined) && again[k] !== null && again[k] !== undefined) {
          capture[k] = again[k]; changed = true;
        }
      }
      // Job cards hydrate late too — merge, never replace (v1.23.5).
      if (Array.isArray(again.recentJobs) && again.recentJobs.length) {
        const before = (capture.recentJobs || []).length;
        capture.recentJobs = accumulateJobs(slug, again.recentJobs);
        if ((capture.recentJobs || []).length !== before) changed = true;
      }
      if (changed && !saving) renderPanel();
    }, 2500);
  }

  function safeInit() {
    clearTimeout(initTimer);
    initTimer = setTimeout(init, 1000);
  }

  let lastUrl = location.href;
  let orphanWatch = null;
  function tearDownOrphan() {
    try { navObserver.disconnect(); } catch (_) {}
    removePanel();
    if (orphanWatch) { clearInterval(orphanWatch); orphanWatch = null; }
  }

  let jobRescanTimer = null;
  const navObserver = new MutationObserver(() => {
    if (!extensionAlive()) { tearDownOrphan(); return; }
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      if (/linkedin\.com\/company\//.test(location.href)) safeInit();
      else removePanel();
      return;
    }
    // v1.23.5: same-URL re-renders (some pagination/infinite-scroll variants
    // swap the card list without touching the href) — debounced job rescan,
    // merge-only, panel updates in place. Reads only what the rep rendered.
    if (!capture || !currentSlug || saving) return;
    if (!/linkedin\.com\/company\//.test(location.href)) return;
    clearTimeout(jobRescanTimer);
    jobRescanTimer = setTimeout(() => {
      if (!extensionAlive() || !capture || getCompanySlug() !== currentSlug || saving) return;
      const incoming = mergeJobs(
        extractRecentJobs(document, new Date(), capture.name) || [],
        extractRecentJobsFromCards(document, new Date(), capture.name) || [],
        25
      );
      if (!incoming || !incoming.length) return;
      const before = (capture.recentJobs || []).length;
      capture.recentJobs = accumulateJobs(currentSlug, incoming);
      const newest = extractLatestJobPostedAt(document, new Date());
      if (newest && (!capture.latestJobPostedAt || new Date(newest) > new Date(capture.latestJobPostedAt))) {
        capture.latestJobPostedAt = newest;
      }
      if ((capture.recentJobs || []).length !== before) renderPanel();
    }, 1200);
  });
  navObserver.observe(document.body, { childList: true, subtree: true });

  orphanWatch = setInterval(() => { if (!extensionAlive()) tearDownOrphan(); }, 1000);

  safeInit();
})();
