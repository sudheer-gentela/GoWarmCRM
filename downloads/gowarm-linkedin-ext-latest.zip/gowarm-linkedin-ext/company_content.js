// company_content.js — injected into linkedin.com/company/* pages (v1.23, P10)
//
// READS the company page the rep is ALREADY viewing (top card + About +
// Jobs module + latest post date — the People tab is deliberately out of
// scope) and, on an EXPLICIT tap, saves one capture to GoWarmCRM where it
// becomes account-level signals. Rep-present, visible-page-only, no
// crawling, no auto-navigation, no background harvesting — the same posture
// as content.js on /in/* pages.
//
// EXTRACTION STRATEGY (SDUI-resilient, mirrors content.js v1.20):
//   PRIMARY — LinkedIn server-renders entity JSON into <code> blocks on
//   initial page load. We deep-walk them for the organization entity whose
//   universalName matches the /company/<slug> in the URL (owner-bound: a
//   wrong company is never captured; a miss yields null).
//   SECONDARY — targeted DOM text reads with forgiving regexes for the two
//   things the hydration JSON often lacks by the time we run: the Jobs
//   module count ("See all 12 jobs") and the latest feed post's relative
//   timestamp ("2w"). Every extractor degrades to null — the backend's
//   ingest never writes a blank (unknown-never-false starts on this page).
//
// NO FABRICATION: headcount is captured ONLY from a real "associated
// members" style count; the "51-200 employees" range is shown in the panel
// for the rep's eyes but never sent as a number.
//
// Test hook: window.__gowarmCompanyTest exposes the pure extraction
// functions when the page sets window.__GOWARM_TEST__ = true BEFORE this
// script runs (used by the JSDOM harness; inert in production).

(function () {
  'use strict';

  const TEAL     = '#0F9D8E';
  const ORANGE   = '#E8630A';
  const PANEL_ID = 'gowarm-li-company-panel';

  // ── Helpers ────────────────────────────────────────────────────────────────

  function extensionAlive() {
    try { return !!(chrome && chrome.runtime && chrome.runtime.id); }
    catch (_) { return false; }
  }

  function getCompanySlug(href) {
    const m = String(href || location.href).match(/linkedin\.com\/company\/([^/?#]+)/);
    return m ? decodeURIComponent(m[1]).toLowerCase() : null;
  }

  function companyUrlFor(slug) {
    return slug ? `https://www.linkedin.com/company/${slug}` : null;
  }

  function cleanDomain(website) {
    if (!website) return null;
    try {
      const u = new URL(/^https?:\/\//i.test(website) ? website : `https://${website}`);
      const host = u.hostname.replace(/^www\./i, '').toLowerCase();
      return host.includes('.') ? host : null;
    } catch (_) { return null; }
  }

  const toInt = (v) => {
    if (v === null || v === undefined || v === '') return null;
    const n = Number(String(v).replace(/[,\s]/g, ''));
    return Number.isInteger(n) && n >= 0 ? n : null;
  };

  // "2w" / "3d" / "5h" / "1mo" / "2yr" → ISO date (conservative: whole units
  // back from now; day precision is plenty for a 30-day recency signal).
  function parseRelativeTime(text, now) {
    if (!text) return null;
    const m = String(text).trim().match(/^(\d+)\s*(h|hr|d|w|mo|m|yr|y)\b/i);
    if (!m) return null;
    const n = parseInt(m[1], 10);
    if (!Number.isInteger(n) || n < 0) return null;
    const unit = m[2].toLowerCase();
    const MS = { h: 3600e3, hr: 3600e3, d: 86400e3, w: 7 * 86400e3, mo: 30 * 86400e3, m: 30 * 86400e3, yr: 365 * 86400e3, y: 365 * 86400e3 }[unit];
    if (!MS) return null;
    const base = (now && typeof now.getTime === 'function') ? now.getTime() : Date.now();
    return new Date(base - n * MS).toISOString();
  }

  // ── PRIMARY: <code>-block organization entity (owner-bound to the slug) ────

  function extractOrgFromCodeBlocks(slug, doc) {
    const d = doc || document;
    let codes;
    try { codes = d.querySelectorAll('code'); } catch (_) { return null; }
    if (!codes || !codes.length || !slug) return null;

    let found = null;

    function walk(node, depth) {
      if (found || !node || depth > 12) return;
      if (Array.isArray(node)) {
        for (const item of node) { walk(item, depth + 1); if (found) return; }
        return;
      }
      if (typeof node !== 'object') return;

      // An organization entity is recognized by universalName === slug
      // (owner-bound — the page can embed OTHER companies in "similar pages";
      // only the slug's own entity is ever accepted).
      const uni = node.universalName || node.universal_name;
      if (typeof uni === 'string' && uni.toLowerCase() === slug) {
        found = node;
        return;
      }
      for (const k in node) {
        if (Object.prototype.hasOwnProperty.call(node, k)) {
          walk(node[k], depth + 1);
          if (found) return;
        }
      }
    }

    for (const code of codes) {
      let text = code.textContent;
      if (!text || text.length < 50 || text.indexOf(slug) === -1) continue;
      let json;
      try { json = JSON.parse(text); } catch (_) { continue; }
      walk(json, 0);
      if (found) break;
    }
    if (!found) return null;

    // Normalize the fields we care about; every miss is a null, never a guess.
    const org = found;
    const name = typeof org.name === 'string' ? org.name.trim() || null : null;

    let industry = null;
    if (typeof org.industry === 'string') industry = org.industry;
    else if (Array.isArray(org.industries) && typeof org.industries[0] === 'string') industry = org.industries[0];
    else if (org.industry && typeof org.industry === 'object' && typeof org.industry.name === 'string') industry = org.industry.name;
    else if (org.industryV2Taxonomy) {
      // SDUI variant: array of { name } or urn-keyed objects.
      const t = Array.isArray(org.industryV2Taxonomy) ? org.industryV2Taxonomy[0] : org.industryV2Taxonomy;
      if (t && typeof t.name === 'string') industry = t.name;
    }
    industry = industry ? String(industry).trim() || null : null;

    const hq = org.headquarter || org.headquarters || null;
    const hqAddr = hq && typeof hq === 'object' ? (hq.address && typeof hq.address === 'object' ? hq.address : hq) : null;
    const hqCity    = hqAddr && typeof hqAddr.city === 'string' ? hqAddr.city.trim() || null : null;
    const hqCountryRaw = hqAddr ? (hqAddr.country || hqAddr.countryCode || null) : null;
    const hqCountry = typeof hqCountryRaw === 'string' ? hqCountryRaw.trim() || null : null;

    const description = typeof org.description === 'string' ? org.description.trim() || null : null;

    // Real member count only. staffCount is LinkedIn's associated-members
    // number; staffCountRange is the bucket — display-only, never a number.
    const memberCount = toInt(org.staffCount ?? org.staff_count);
    let sizeRange = null;
    const scr = org.staffCountRange || org.staff_count_range;
    if (typeof scr === 'string') sizeRange = scr;
    else if (scr && typeof scr === 'object') {
      const lo = scr.start ?? scr.min, hi = scr.end ?? scr.max;
      if (lo != null) sizeRange = hi != null ? `${lo}-${hi} employees` : `${lo}+ employees`;
    }

    const websiteDomain = cleanDomain(
      typeof org.websiteUrl === 'string' ? org.websiteUrl
        : (typeof org.website === 'string' ? org.website
          : (org.website && typeof org.website === 'object' ? org.website.url : null))
    );

    return { name, industry, hqCity, hqCountry, description, memberCount, sizeRange, websiteDomain };
  }

  // ── SECONDARY: DOM fallbacks for jobs count + latest post time ─────────────

  function extractJobOpenings(doc) {
    const d = doc || document;
    // Anchors into the jobs surface carry text like "See all 12 jobs" /
    // "12 job openings". Scan hrefs first (tight), then a bounded text scan.
    let candidates;
    try {
      candidates = d.querySelectorAll('a[href*="/jobs"], a[href*="currentCompany"]');
    } catch (_) { candidates = []; }
    const RE = /([\d][\d,]*)\s*(?:job(?:s)?(?:\s+opening(?:s)?)?)\b/i;
    for (const a of candidates) {
      const m = (a.textContent || '').match(RE);
      if (m) { const n = toInt(m[1]); if (n !== null) return n; }
    }
    return null;
  }

  function extractLatestPostAt(doc, now) {
    const d = doc || document;
    // Feed update cards carry a relative timestamp near the poster line;
    // <time> elements when present, else short "2w"-style spans. We take the
    // FIRST match in document order (newest post renders first) and stay
    // conservative: unparseable → null.
    try {
      const t = d.querySelector('.feed-shared-update-v2 time, [data-urn*="activity"] time');
      if (t) {
        const dt = t.getAttribute('datetime');
        if (dt) { const parsed = new Date(dt); if (!Number.isNaN(parsed.getTime())) return parsed.toISOString(); }
        const rel = parseRelativeTime(t.textContent, now);
        if (rel) return rel;
      }
    } catch (_) {}
    try {
      const spans = d.querySelectorAll('.feed-shared-update-v2 span[aria-hidden="true"], .update-components-actor__sub-description span[aria-hidden="true"]');
      for (const s of spans) {
        const rel = parseRelativeTime((s.textContent || '').trim(), now);
        if (rel) return rel;
      }
    } catch (_) {}
    return null;
  }

  // ── Assemble one capture (pure given slug/doc/now — the JSDOM test entry) ──

  function buildCapture(slug, doc, now) {
    const org = extractOrgFromCodeBlocks(slug, doc) || {};
    return {
      slug,
      linkedinCompanyUrl: companyUrlFor(slug),
      name:          org.name || null,
      industry:      org.industry || null,
      hqCity:        org.hqCity || null,
      hqCountry:     org.hqCountry || null,
      description:   org.description || null,
      memberCount:   org.memberCount ?? null,
      sizeRange:     org.sizeRange || null,          // display only — never a number
      websiteDomain: org.websiteDomain || null,
      jobOpenings:   extractJobOpenings(doc),
      latestPostAt:  extractLatestPostAt(doc, now),
    };
  }

  // Test hook (inert unless the harness set the flag before injection).
  try {
    if (typeof window !== 'undefined' && window.__GOWARM_TEST__) {
      window.__gowarmCompanyTest = {
        getCompanySlug, parseRelativeTime, cleanDomain,
        extractOrgFromCodeBlocks, extractJobOpenings, extractLatestPostAt, buildCapture,
      };
    }
  } catch (_) {}

  // In the harness there's no chrome runtime — stop before any UI/network.
  if (!extensionAlive()) return;

  // ── Panel ───────────────────────────────────────────────────────────────────

  let currentSlug = null;
  let capture = null;
  let matchInfo = null;   // { accountId, accountName, matchedBy }
  let saving = false;

  function removePanel() { document.getElementById(PANEL_ID)?.remove(); }

  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (ch) => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]
  ));

  function factRow(label, value) {
    if (value === null || value === undefined || value === '') return '';
    const shown = String(value);
    const clipped = shown.length > 140 ? shown.slice(0, 140) + '…' : shown;
    return `<div style="display:flex;gap:6px;font-size:11px;line-height:1.5;">
      <span style="color:#94a3b8;min-width:86px;flex:none;">${esc(label)}</span>
      <span style="color:#1f2937;word-break:break-word;">${esc(clipped)}</span>
    </div>`;
  }

  function renderPanel() {
    removePanel();
    if (!capture) return;

    const wrap = document.createElement('div');
    wrap.id = PANEL_ID;
    wrap.style.cssText = `position:fixed;top:84px;right:16px;width:300px;z-index:99999;
      background:#fff;border:1px solid #e2e8f0;border-radius:10px;
      box-shadow:0 8px 24px rgba(15,23,42,.14);font-family:-apple-system,'Segoe UI',Roboto,sans-serif;overflow:hidden;`;

    const postAgo = capture.latestPostAt
      ? `${Math.max(0, Math.round((Date.now() - new Date(capture.latestPostAt).getTime()) / 86400000))}d ago`
      : null;

    const matchLine = !matchInfo
      ? `<span style="color:#94a3b8;">Matching account…</span>`
      : matchInfo.accountId
        ? `<span style="color:#166534;">✓ ${esc(matchInfo.accountName)}</span>
           <span style="color:#94a3b8;"> (by ${matchInfo.matchedBy === 'linkedin_url' ? 'LinkedIn URL' : 'domain'})</span>`
        : `<span style="color:#b45309;">No matching account in GoWarm</span>`;

    const canSave = matchInfo && matchInfo.accountId;
    const canCreate = matchInfo && !matchInfo.accountId && capture.name;

    wrap.innerHTML = `
      <div style="display:flex;align-items:center;justify-content:space-between;padding:8px 12px;background:${TEAL};">
        <span style="color:#fff;font-size:12px;font-weight:700;">🔥 GoWarm — Company signals</span>
        <button id="gw-cp-close" style="background:none;border:none;color:#fff;font-size:14px;cursor:pointer;line-height:1;">✕</button>
      </div>
      <div style="padding:10px 12px;display:flex;flex-direction:column;gap:4px;">
        <div style="font-size:12px;font-weight:700;color:#111827;margin-bottom:2px;">${esc(capture.name || currentSlug)}</div>
        ${factRow('Industry', capture.industry)}
        ${factRow('HQ', [capture.hqCity, capture.hqCountry].filter(Boolean).join(', ') || null)}
        ${factRow('Members', capture.memberCount)}
        ${capture.memberCount === null ? factRow('Size (range)', capture.sizeRange ? capture.sizeRange + ' — shown only, not saved as a number' : null) : factRow('Size (range)', capture.sizeRange)}
        ${factRow('Open roles', capture.jobOpenings)}
        ${factRow('Last post', postAgo)}
        ${factRow('About', capture.description)}
        ${factRow('Website', capture.websiteDomain)}
        <div style="margin-top:6px;font-size:11px;">${matchLine}</div>
        <button id="gw-cp-save" ${canSave && !saving ? '' : 'disabled'}
          style="margin-top:8px;width:100%;padding:7px;background:${canSave ? TEAL : '#cbd5e1'};color:#fff;border:none;border-radius:6px;font-size:12px;font-weight:600;cursor:${canSave ? 'pointer' : 'default'};">
          ${saving ? 'Saving…' : 'Save company signals'}
        </button>
        ${canCreate ? `<button id="gw-cp-create" ${saving ? 'disabled' : ''}
          style="margin-top:6px;width:100%;padding:7px;background:${ORANGE};color:#fff;border:none;border-radius:6px;font-size:12px;font-weight:600;cursor:pointer;">
          ${saving ? 'Saving…' : 'Create account & save'}
        </button>` : ''}
        <div id="gw-cp-feedback" style="margin-top:6px;font-size:11px;display:none;"></div>
        <div style="margin-top:4px;font-size:10px;color:#94a3b8;">Reads only what's on this page. Nothing is saved until you tap. Your edits in GoWarm are never overwritten.</div>
      </div>`;

    document.body.appendChild(wrap);
    wrap.querySelector('#gw-cp-close').addEventListener('click', removePanel);
    const saveBtn = wrap.querySelector('#gw-cp-save');
    if (saveBtn) saveBtn.addEventListener('click', () => doSave(false));
    const createBtn = wrap.querySelector('#gw-cp-create');
    if (createBtn) createBtn.addEventListener('click', () => doSave(true));
  }

  function showFeedback(msg, ok) {
    const el = document.getElementById(PANEL_ID)?.querySelector('#gw-cp-feedback');
    if (!el) return;
    el.style.display = 'block';
    el.style.color = ok ? '#166534' : '#b45309';
    el.textContent = msg;
  }

  const SAVE_FAIL_NOTICES = {
    no_matching_account: 'No matching account — use "Create account & save".',
    nothing_extractable: 'Nothing readable on this page to save.',
    no_company_name:     "Couldn't read the company name — can't create an account.",
    NOT_AUTHENTICATED:   'Sign in to GoWarmCRM in another tab, then try again.',
  };

  function doSave(createIfMissing) {
    if (!extensionAlive() || !capture || saving) return;
    saving = true;
    renderPanel();
    chrome.runtime.sendMessage(
      { type: 'GW_COMPANY_SAVE', capture, createIfMissing: !!createIfMissing },
      (res) => {
        saving = false;
        if (chrome.runtime.lastError || !res) {
          renderPanel();
          showFeedback('Could not reach GoWarm — try again.', false);
          return;
        }
        if (res.ok) {
          matchInfo = { accountId: res.accountId, accountName: res.accountName, matchedBy: res.matchedBy || 'linkedin_url' };
          renderPanel();
          const n = (res.written || []).length;
          const kept = (res.skipped || []).filter((s) => s.reason === 'rep_override').length;
          let msg = res.created
            ? `Account created — ${n} signal${n === 1 ? '' : 's'} saved.`
            : `${n} signal${n === 1 ? '' : 's'} saved to ${res.accountName || 'the account'}.`;
          if (kept) msg += ` ${kept} kept your GoWarm edit${kept === 1 ? '' : 's'}.`;
          showFeedback(msg, true);
        } else {
          renderPanel();
          showFeedback(SAVE_FAIL_NOTICES[res.reason] || SAVE_FAIL_NOTICES[res.error] || `Save failed${res.error ? ': ' + res.error : ''}.`, false);
        }
      }
    );
  }

  function refreshMatch() {
    if (!extensionAlive() || !capture) return;
    chrome.runtime.sendMessage(
      { type: 'GW_COMPANY_MATCH', linkedinCompanyUrl: capture.linkedinCompanyUrl, domain: capture.websiteDomain },
      (res) => {
        matchInfo = (res && res.ok !== false)
          ? { accountId: res.accountId || null, accountName: res.accountName || null, matchedBy: res.matchedBy || 'none' }
          : { accountId: null, accountName: null, matchedBy: 'none' };
        renderPanel();
      }
    );
  }

  // ── Init + SPA navigation (mirrors content.js) ─────────────────────────────

  let initTimer = null;
  function init() {
    if (!extensionAlive()) return;
    const slug = getCompanySlug();
    if (!slug) { removePanel(); return; }
    currentSlug = slug;
    capture = buildCapture(slug, document, new Date());
    // A capture with literally nothing readable → no panel noise.
    const hasAnything = capture.name || capture.industry || capture.description
      || capture.memberCount !== null || capture.jobOpenings !== null || capture.latestPostAt;
    if (!hasAnything) { removePanel(); return; }
    matchInfo = null;
    renderPanel();
    refreshMatch();

    // Jobs count / latest post often hydrate late — one delayed re-read
    // (values only ever ADD; the rep sees the panel update in place).
    setTimeout(() => {
      if (!extensionAlive() || getCompanySlug() !== slug || !capture) return;
      const again = buildCapture(slug, document, new Date());
      let changed = false;
      for (const k of ['jobOpenings', 'latestPostAt', 'memberCount', 'industry', 'description']) {
        if ((capture[k] === null || capture[k] === undefined) && again[k] !== null && again[k] !== undefined) {
          capture[k] = again[k]; changed = true;
        }
      }
      if (changed && !saving) renderPanel();
    }, 2500);
  }

  function safeInit() {
    clearTimeout(initTimer);
    initTimer = setTimeout(init, 1000);
  }

  let lastUrl = location.href;
  let orphanWatch = null;
  function tearDownOrphan() {
    try { navObserver.disconnect(); } catch (_) {}
    removePanel();
    if (orphanWatch) { clearInterval(orphanWatch); orphanWatch = null; }
  }

  const navObserver = new MutationObserver(() => {
    if (!extensionAlive()) { tearDownOrphan(); return; }
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      if (/linkedin\.com\/company\//.test(location.href)) safeInit();
      else removePanel();
    }
  });
  navObserver.observe(document.body, { childList: true, subtree: true });

  orphanWatch = setInterval(() => { if (!extensionAlive()) tearDownOrphan(); }, 1000);

  safeInit();
})();
